// If you want to build and run this yourself, register for a free Flickr API key and enter it below.
NSString *const FlickrAPIKey = @"aae30de6d53ac30419776d7a9b3ed968";
