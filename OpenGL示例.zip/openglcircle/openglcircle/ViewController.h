//
//  ViewController.h
//  openglcircle
//
//  Created by gaozhimin on 12-9-14.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface ViewController : GLKViewController
{
    GLuint _texCoordSlot;
    GLuint _textureUniform;
}

@end
