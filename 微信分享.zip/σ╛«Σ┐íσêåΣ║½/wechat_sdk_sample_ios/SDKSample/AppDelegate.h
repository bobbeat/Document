//
//  AppDelegate.h
//  ApiClient
//
//  Created by Tencent on 12-2-27.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SendMsgToWeChatViewController.h"
#import "WXApi.h"
#import "RespForWeChatViewController.h"

//@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate, sendMsgToWeChatViewDelegate, UIAlertViewDelegate, WXApiDelegate, RespForWeChatViewDelegate>{
    enum WXScene _scene;
}


@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;



@end
