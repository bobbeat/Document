//
//  CoverageTableViewController.h
//  TableViewTest
//
//  Created by gaozhimin on 12-9-4.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol MyHeadViewDelegate

- (void)touchInMyHeadView:(UIView *)head_view InSection:(NSInteger)section;

@end

@interface MyHeadView : UITableViewCell
{
    id<MyHeadViewDelegate> m_myHeadViewDelegate;
    NSInteger m_section;
    BOOL m_open;
}

@property(nonatomic,assign) BOOL m_open;

- (id)initWithFrame:(CGRect)frame InSection:(NSInteger)section;

@property (nonatomic,assign) id<MyHeadViewDelegate> m_myHeadViewDelegate;

@end

@interface CoverageTableViewController : UITableViewController<MyHeadViewDelegate>
{
    NSDictionary *m_dict;
    NSInteger m_selectSection;
    NSMutableArray *m_myHeadViewArray;
}
@end
