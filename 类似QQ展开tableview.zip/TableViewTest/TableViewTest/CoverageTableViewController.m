//
//  CoverageTableViewController.m
//  TableViewTest
//
//  Created by gaozhimin on 12-9-4.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "CoverageTableViewController.h"

#define HeadView_Height 40.0



@implementation MyHeadView

@synthesize m_open;

@synthesize m_myHeadViewDelegate;

- (id)initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame InSection:0];
}

- (id)initWithFrame:(CGRect)frame InSection:(NSInteger)section
{
    if (self = [super initWithFrame:frame])
    {
        self.userInteractionEnabled = YES;
        m_section = section;
        self.m_open = NO;
    }
    return self;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (m_myHeadViewDelegate)
    {
        [m_myHeadViewDelegate touchInMyHeadView:self InSection:m_section];
    }
}

@end

@interface CoverageTableViewController ()

@end

@implementation CoverageTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self)
    {
        // Custom initialization
       
    }
    return self;
}

- (void)dealloc
{
    [m_myHeadViewArray release];
    [m_dict release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    m_dict = [[NSDictionary alloc] initWithObjectsAndKeys:
              [NSArray arrayWithObjects:@"福州",@"厦门" ,nil],@"福建",
              [NSArray arrayWithObjects:@"和田",@"乌鲁木齐", nil],@"新疆",
              [NSArray arrayWithObjects:@"九江",@"南昌" ,nil],@"江西",
              [NSArray arrayWithObjects:@"杭州",@"绍兴", nil],@"浙江",
              [NSArray arrayWithObjects:@"广州",@"东莞" ,nil],@"广东",
              [NSArray arrayWithObjects:@"朝阳",@"海淀" ,nil],@"北京",
              [NSArray arrayWithObjects:@"石家庄",@"保定", nil],@"河北",
              [NSArray arrayWithObjects:@"攀枝花",@"汶川" ,nil],@"四川",
              nil];
    
    m_myHeadViewArray = [[NSMutableArray alloc] init];
    m_selectSection = -1;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [m_dict count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if ([m_myHeadViewArray count] > section)
    {
        MyHeadView *view = [m_myHeadViewArray objectAtIndex:section];
        if (view.m_open)
        {
            return [[m_dict objectForKey:[[m_dict allKeys] objectAtIndex:section]]  count];
        }
    }
    
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return HeadView_Height;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    NSArray *array = [m_dict objectForKey:[[m_dict allKeys] objectAtIndex:indexPath.section]];
    cell.textLabel.text = [array objectAtIndex:indexPath.row];
    // Configure the cell...
    
    return cell;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if ([m_myHeadViewArray count] <= section ) 
    {
        MyHeadView *view = [[[MyHeadView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, HeadView_Height) InSection:section] autorelease];
        view.backgroundColor = [UIColor grayColor];
        view.textLabel.text = [[m_dict allKeys] objectAtIndex:section];
        view.m_myHeadViewDelegate = self;
        view.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        [m_myHeadViewArray addObject:view];
    }
    
    return [m_myHeadViewArray objectAtIndex:section];
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
}

#pragma mark - head view delegate

- (void)touchInMyHeadView:(UIView *)head_view InSection:(NSInteger)section
{
    MyHeadView *my_view = (MyHeadView*)head_view;
    
    NSMutableArray *indexPaths_array = [[NSMutableArray alloc] init];
    NSArray *array;
    NSIndexPath *_indexPath;
    if (my_view.m_open ==  NO)
    {
        my_view.m_open =  YES;
        array = [m_dict objectForKey:[[m_dict allKeys] objectAtIndex:section]];
        for (int i = 0; i < [array count]; i ++)
        {
            _indexPath = [NSIndexPath indexPathForRow:i inSection:section];
            [indexPaths_array addObject:_indexPath];
        }
        [self.tableView insertRowsAtIndexPaths:indexPaths_array withRowAnimation:UITableViewRowAnimationFade];
    }
    else
    {
        my_view.m_open =  NO;
        array = [m_dict objectForKey:[[m_dict allKeys] objectAtIndex:section]];
        for (int i = 0; i < [array count]; i ++)
        {
            _indexPath = [NSIndexPath indexPathForRow:i inSection:section];
            [indexPaths_array addObject:_indexPath];
        }
        [self.tableView deleteRowsAtIndexPaths:indexPaths_array withRowAnimation:UITableViewRowAnimationFade];
    }    
    
    [indexPaths_array release];
    
    UITableViewCell *cell_view = (UITableViewCell*)head_view;
    NSLog(@"%@",cell_view.textLabel.text);
}

@end
