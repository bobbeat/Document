//
//  AppDelegate.h
//  TableViewTest
//
//  Created by gaozhimin on 12-9-4.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    IBOutlet UINavigationController *navigation;
}

@property (strong, nonatomic) IBOutlet UIWindow *window;


@end
