//
//  ViewController.h
//  PopButton
//
//  Created by gaozhimin on 12-9-3.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PopButtonView.h"

@interface ViewController : UIViewController<PopButtonViewDelegate>

- (IBAction)ButtonPressed:(id)sender;

@end
