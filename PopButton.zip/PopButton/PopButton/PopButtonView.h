//
//  PopButtonView.h
//  PopButton
//
//  Created by gaozhimin on 12-9-3.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@protocol PopButtonViewDelegate 

- (void)ButtonPressed:(UIButton*)button InIndex:(int)index;  //button:指用户按下的按钮 index:指按钮的tag值，视图中左上角按钮的tag值为0。
//按钮和tag的对应关系如下
//    0   1
//    2   3
//    4   5
//    6   7
//   ... ...

@end

@class PopButtonView;

@interface PopButton : UIButton
{
    NSInteger m_subViewTag;
    CGSize m_popViewSize;
    PopButtonView *m_popButtonView;
}


@property (nonatomic,retain) PopButtonView *m_popButtonView;

/*
 sub_frame:按钮界面的大小
 sub_backgound_image:按钮界面的背景图片
 sub_titles:按钮界面中按钮名称的数组
 sub_images:按钮界面中按钮的小图标
 
 注：每个按钮的nomal图标和highlighted图标，在程序中写死，不能改变
*/
- (id)initWithFrame:(CGRect)frame delegate:(id)delegate subFrame:(CGRect)sub_frame subBackgroundImage:(UIImage *)sub_backgound_image subButtonTitles:(NSArray*)sub_titles subButtonImages:(NSArray *)sub_images;

- (void)ShowButtonViewAnimation:(BOOL)appear;

@end
