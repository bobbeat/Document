//
//  ViewController.m
//  PopButton
//
//  Created by gaozhimin on 12-9-3.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
	// Do any additional setup after loading the view, typically from a nib.
    NSArray *titles = [NSArray arrayWithObjects:@"分享給好友",@"图层",@"实时交通",@"消息盒子", nil];
    NSArray *nomal_image = [NSArray arrayWithObjects:
                            [UIImage imageNamed:@"TC-icon1.png"],
                            [UIImage imageNamed:@"TC-icon2.png"],
                            [UIImage imageNamed:@"TC-icon3.png"],
                            [UIImage imageNamed:@"TC-icon4.png"],nil];
    UIImage *background_image = [UIImage imageNamed:@"TC-1.png"];
    PopButton *button = [[PopButton alloc] initWithFrame:CGRectMake(200, 200, 100, 100) delegate:self subFrame:CGRectMake(0, 0, 174, 140) subBackgroundImage:background_image subButtonTitles:titles subButtonImages:nomal_image];
   
    [button setImage:[UIImage imageNamed:@"menu_icon_voice.png"] forState:UIControlStateNormal];
   
    button.frame = CGRectMake(200, 200, [UIImage imageNamed:@"menu_icon_voice.png"].size.width, [UIImage imageNamed:@"menu_icon_voice.png"].size.height);
    button.center = CGPointMake(300, 100);
    
    [button addTarget:self action:@selector(ButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ButtonPressed:(id)sender
{
  /*  UIButton *button = (UIButton *)sender;
    static BOOL exist = NO;
    static PopButtonView *button_view;
    if (exist == NO)
    {
        NSArray *titles = [NSArray arrayWithObjects:@"分享給好友",@"图层",@"实时交通",@"消息盒子", nil];
        NSArray *nomal_image = [NSArray arrayWithObjects:
                                [UIImage imageNamed:@"menu_icon1.png"],
                                [UIImage imageNamed:@"menu_icon2.png"],
                                [UIImage imageNamed:@"menu_icon3.png"],
                                [UIImage imageNamed:@"menu_icon4.png"],nil];
        NSArray *pressed_image = [NSArray arrayWithObjects:
                                  [UIImage imageNamed:@"menu_icon5.png"],
                                  [UIImage imageNamed:@"menu_icon6.png"],
                                  [UIImage imageNamed:@"menu_icon7.png"],
                                  [UIImage imageNamed:@"menu_icon50.png"],nil];;
        button_view = [[PopButtonView alloc] initWithFrame:CGRectMake(0, 0, 200, 200) ButtonTitles:titles ButtonNomalImages:nomal_image ButtonPressedImage:pressed_image];
        button_view.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
        button_view.m_popButtonViewDelegate = self;
        [self.view addSubview:button_view];
        [button_view release];
        exist = YES;
    }
    else
    {
        exist = NO;
        [button_view removeFromSuperview];
    }*/
    NSLog(@"a");
    PopButton *button = (PopButton *)sender;
    
    static BOOL appear = YES;
    if (appear)
    {
        [button ShowButtonViewAnimation:YES];
        appear = NO;
    }
    else
    {
        [button ShowButtonViewAnimation:NO];
        appear = YES;
    }
}



-(void)ButtonPressed:(UIButton *)button InIndex:(int)index
{
    NSLog(@"%d",index);
}

@end
