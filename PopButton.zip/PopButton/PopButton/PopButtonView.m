//
//  PopButtonView.m
//  PopButton
//
//  Created by gaozhimin on 12-9-3.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "PopButtonView.h"


#define min_Scall (float)0.1
#define ARROWS_HEIGHT (float)22.5
#define ARROWS_WIDTH (float)15.0
#define DISTANCE_TO_BOUNDRY (float)20.0
#define IMAGE_FRAME CGRectMake(16, 5, 30, 31)
#define LABLE_FONT 10

@interface PopButtonView : UIView
{
    id<PopButtonViewDelegate> m_popButtonViewDelegate;
}

@property (nonatomic,assign) id<PopButtonViewDelegate> m_popButtonViewDelegate;;


- (id)initWithFrame:(CGRect)frame ButtonTitles:(NSArray*)titles ButtonImages:(NSArray *)images;

- (void)buttonPressed:(id)button;

@end

@implementation PopButtonView

@synthesize m_popButtonViewDelegate;

- (id)initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame ButtonTitles:nil ButtonImages:nil];
}

- (id)initWithFrame:(CGRect)frame ButtonTitles:(NSArray*)titles ButtonImages:(NSArray *)images
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor clearColor];
        UIButton *button;
        int row = [titles count]%2 ? [titles count]/2 + 1 : [titles count]/2;
        UIImage *image_left_nomal = [UIImage imageNamed:@"TC-button_1A.png"];
        UIImage *image_left_highlighted = [UIImage imageNamed:@"TC-button_1B.png"];
        UIImage *image_right_nomal = [UIImage imageNamed:@"TC-button_2A.png"];
        UIImage *image_rifht_highlighted = [UIImage imageNamed:@"TC-button_2B.png"];
        
        
        
        float height = (float)self.frame.size.height/row;
        float width = (float)(self.frame.size.width - ARROWS_WIDTH)/2.0;
        
        float button_width = width - DISTANCE_TO_BOUNDRY;
        float button_height = height - DISTANCE_TO_BOUNDRY/2.0;
        
        for (int i = 0;i < [titles count]; i ++)
        {
            button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.tag = i;
            float button_center_x = i%2 ? width/2.0 + width : width/2;
            float button_center_y = (i/2)*height + height/2;
            if (i%2)
            {
                [button setImage:image_right_nomal forState:UIControlStateNormal];
                [button setImage:image_rifht_highlighted forState:UIControlStateHighlighted];
            }
            else
            {
                [button setImage:image_left_nomal forState:UIControlStateNormal];
                [button setImage:image_left_highlighted forState:UIControlStateHighlighted];
            }
            button.frame = CGRectMake(0, 0, button_width, button_height);
            button.center = CGPointMake(button_center_x, button_center_y);
            
            UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0,button_width, (float)button_height*2.0/5.0)];
            lable.backgroundColor = [UIColor clearColor];
            lable.text = [titles objectAtIndex:i];
            lable.textColor = [UIColor whiteColor];
            lable.textAlignment = NSTextAlignmentCenter;
            lable.center = CGPointMake(button_width/2, button_height  - button_height/5.0);
            lable.font = [UIFont systemFontOfSize:LABLE_FONT];
            [button addSubview:lable];
            [lable release];
            

            if (i >= [images count])
            {
                if ([images count] != 0)
                {
                    
                    UIImageView *view = [[UIImageView alloc] initWithImage:[images objectAtIndex:([images count] - 1)]];
                    view.frame = IMAGE_FRAME;
                    [button addSubview:view];
                    [view release];
                }
            }
            else
            {
                UIImageView *view = [[UIImageView alloc] initWithImage:[images objectAtIndex:i]];
                view.frame = IMAGE_FRAME;
                [button addSubview:view];
                [view release];
            }
            
           
            [button addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
            
            [self addSubview:button];
        }
    }
    return self;
}

- (void)buttonPressed:(id)button
{
    UIButton *_button = (UIButton *)button;
    if (m_popButtonViewDelegate)
    {
        [m_popButtonViewDelegate ButtonPressed:_button InIndex:_button.tag];
    }
}

-(void)dealloc
{
    [super dealloc];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end


@implementation PopButton

@synthesize m_popButtonView;
//+ (id)buttonWithType:(UIButtonType)buttonType delegate:(id)delegate subtag:(NSInteger)sub_tag subFrame:(CGRect)sub_frame subButtonTitles:(NSArray*)sub_titles subButtonNomalImages:(NSArray *)sub_nomal_images subButtonPressedImage:(NSArray *)sub_pressed_image ;
//{
//    self = [super buttonWithType:buttonType];
//    if (self)
//    {
//        PopButtonView *view = [[PopButtonView alloc] initWithFrame:sub_frame ButtonTitles:sub_titles ButtonNomalImages:sub_nomal_images ButtonPressedImage:sub_pressed_image];
//        view.m_popButtonViewDelegate = delegate;
//        UIViewController *view_controlelr = (UIViewController *)delegate;
//        [view_controlelr.view addSubview:view];
//        [view release];
//        view.hidden = YES;
//        view.tag = sub_tag;
//    }
//    return self;
//}

- (id)initWithFrame:(CGRect)frame delegate:(id)delegate subFrame:(CGRect)sub_frame subBackgroundImage:(UIImage *)sub_backgound_image  subButtonTitles:(NSArray*)sub_titles subButtonImages:(NSArray *)sub_images
{
    if (self = [super initWithFrame:frame])
    {
        m_popButtonView = [[PopButtonView alloc] initWithFrame:sub_frame ButtonTitles:sub_titles ButtonImages:sub_images];
        m_popButtonView.m_popButtonViewDelegate = delegate;
        UIViewController *view_controlelr = (UIViewController *)delegate;
        [view_controlelr.view addSubview:m_popButtonView];
        [m_popButtonView release];
        m_popButtonView.hidden = YES;
        m_popButtonView.backgroundColor = [UIColor clearColor];
        m_popButtonView.layer.contents = (id)sub_backgound_image.CGImage;
        
        m_popViewSize = sub_frame.size;
    }
    return self;
}


- (void)ShowButtonViewAnimation:(BOOL)appear
{
    PopButtonView *pop_view;

    pop_view = m_popButtonView;
    
    CGPoint pop_viewNomalCenter;
    CGPoint pop_viewScaleCenter;
    
    if (!pop_view)
    {
        return;
    }
    
    UIImage *image = [self imageForState:UIControlStateNormal];
    CGPoint center = self.center;
    CGSize self_size = image.size;
    
    CGSize s = [[UIScreen mainScreen] bounds].size;
    
    CGSize pop_viewSize = m_popViewSize;
    
    float min_x = min_Scall * pop_viewSize.width/2.0;
    float min_y = min_Scall * pop_viewSize.height/2.0;
    
    if (center.x >= s.width/2 && center.y < s.height/2)
    {
        pop_viewNomalCenter = CGPointMake(center.x - pop_viewSize.width/2.0 - self_size.width/2.0, center.y + pop_viewSize.height/2 - ARROWS_HEIGHT);
        pop_viewScaleCenter = CGPointMake(center.x - self_size.width/2.0 - min_x, center.y + min_y);
    }
    else if (center.x >= s.width/2 && center.y >= s.height/2)
    {
        pop_viewNomalCenter = CGPointMake(center.x - pop_viewSize.width/2.0 - self_size.width/2.0, center.y - pop_viewSize.height/2.0 +  ARROWS_HEIGHT);
        pop_viewScaleCenter = CGPointMake(center.x - self_size.width/2.0 - min_x, center.y - min_y);
    }
    else if (center.x < s.width/2 && center.y < s.height/2)
    {
        pop_viewNomalCenter = CGPointMake(center.x + self_size.width/2.0 + pop_viewSize.width/2.0, center.y + pop_viewSize.height/2 - ARROWS_HEIGHT);
        pop_viewScaleCenter = CGPointMake(center.x + self_size.width/2.0 + min_x, center.y + min_y);
    }
    else if (center.x < s.width/2 && center.y >= s.height/2)
    {
        pop_viewNomalCenter = CGPointMake(center.x + self_size.width/2.0 + pop_viewSize.width/2.0, center.y - pop_viewSize.height/2.0 +  ARROWS_HEIGHT);
        pop_viewScaleCenter = CGPointMake(center.x + self_size.width/2.0 + min_x, center.y - min_y);
    }
    
    if (appear)
    {
        pop_view.hidden = NO;
        pop_view.transform = CGAffineTransformMakeScale(min_Scall, min_Scall);
        pop_view.center = pop_viewScaleCenter;
        [UIView animateWithDuration:0.2f delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^
         {
             pop_view.center = pop_viewNomalCenter;
             pop_view.transform = CGAffineTransformMakeScale(1.0, 1.0);
              
             
         } completion:^(BOOL finished)
         {
             pop_view.hidden = NO;
         }];
    }
    else
    {
        
        pop_view.transform = CGAffineTransformMakeScale(1.0, 1.0);
        pop_view.center = pop_viewNomalCenter;
        [UIView animateWithDuration:0.2f delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^
         {
             pop_view.transform = CGAffineTransformMakeScale(min_Scall, min_Scall);
             pop_view.center = pop_viewScaleCenter;
            
         } completion:^(BOOL finished)
         {
             pop_view.hidden = YES;
         }];
    }
   

}

- (void)dealloc
{
    if (m_popButtonView)
    {
        [m_popButtonView release];
    }
    [super dealloc];
}

@end
