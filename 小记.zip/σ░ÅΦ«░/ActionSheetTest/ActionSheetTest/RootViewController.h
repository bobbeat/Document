//
//  RootViewController.h
//  ActionSheetTest
//
//  Created by 高志闽 on 12-7-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController<UIActionSheetDelegate>


- (IBAction)ActionSheetButtonPressed:(id)sender;

@end
