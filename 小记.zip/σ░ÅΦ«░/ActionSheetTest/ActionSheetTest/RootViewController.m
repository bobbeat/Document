//
//  RootViewController.m
//  ActionSheetTest
//
//  Created by 高志闽 on 12-7-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "UIImageActionSheet.h"
#define PULL_X 18
#define PULL_Y 22

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

#pragma mark -
#pragma mark methods 

- (IBAction)ActionSheetButtonPressed:(id)sender
{
    NSArray *array = [NSArray arrayWithObjects:@"other1",@"other2",@"other3",@"other4", nil];
    UIImageActionSheet *tipsActionSheet = [[UIImageActionSheet alloc] initWithTitle:@"请选择" delegate:self cancelButtonTitle:@"cancel" destructiveButtonTitle:@"destructive" otherButtonTitleArray:array];
    tipsActionSheet.tag = 10;
    [tipsActionSheet showInView:self.view];
    [tipsActionSheet release];
}

#pragma mark -
#pragma mark ActionSheet methods 

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
   // NSLog(@"clicked");
}

- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
   // NSLog(@"didDismiss");
}

- (void)actionSheet:(UIActionSheet *)actionSheet willDismissWithButtonIndex:(NSInteger)buttonIndex
{
    NSLog(@"willDismiss %d",buttonIndex);
}

- (void)actionSheetCancel:(UIActionSheet *)actionSheet
{
   // NSLog(@"%d",1);
}



@end
