//
//  AppDelegate.h
//  ActionSheetTest
//
//  Created by 高志闽 on 12-7-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RootViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    RootViewController *mRootViewController;
}

@property (strong, nonatomic) UIWindow *window;

@end
