//
//  XMLParser.m
//  XMLParserTest
//
//  Created by 高志闽 on 12-8-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "XMLParser.h"
#import "AppDelegate.h"
#import "BookClass.h"

@implementation XMLParser
- (XMLParser *)initXMLParser 
{
    [super  init];
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    return self;
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName
    attributes:(NSDictionary *)attributeDict 
{
    
    if([elementName isEqualToString:@"Books"])
    {
        //Initialize the array.
        //在这里初始化用于存储最终解析结果的数组变量,我们是在当遇到Books根元素时才开始初始化，有关此初始化过程也可以在parserDidStartDocument 方法中实现
        appDelegate.books = [[NSMutableArray alloc] init];
    }
    else if([elementName isEqualToString:@"Book"]) 
    {
        
        //Initialize the book.
        //当碰到Book元素时，初始化用于存储Book信息的实例对象aBook
        aBook = [[BookClass alloc] init];
        
        //Extract the attribute here.
        //从attributeDict字典中读取Book元素的属性
        aBook.bookID = [[attributeDict objectForKey:@"id"] integerValue];
        
    //    NSLog(@"Reading id value :%i", aBook.bookID);
    }
    
   // NSLog(@"Processing Element: %@", elementName);
}
/* 可以看出parser:didStartElement:namespaceURI:qualifiedName:attributes方法实现的就是在解析元素开始标签时，进行一些初始化流程 */

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string 
{
    // 当用于存储当前元素的值是空时，则先用值进行初始化赋值
    
    // 否则就直接追加信息 
    if(!currentElementValue)
        currentElementValue = [[NSMutableString alloc] initWithString:string];
    else
        [currentElementValue appendString:string];
    
   
    
}

// 这里才是真正完成整个解析并保存数据的最终结果的地方
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
    if([elementName isEqualToString:@"Books"])
        return;
    
    //There is nothing to do if we encounter the Books element here.
    //If we encounter the Book element howevere, we want to add the book object to the array 遇到Book元素的结束标签，则添加book对象到设置好的数组中。
    // and release the object.
    if([elementName isEqualToString:@"Book"]) {
        [appDelegate.books addObject:aBook];
        
        [aBook release];
        aBook = nil;
    }
    else
        // 不是Book元素时也不是根元素，则用 setValue:forKey为当前book对象的属性赋值
        [aBook setValue:currentElementValue forKey:elementName];
    
     NSLog(@"Processing Value: %@", currentElementValue);
    [currentElementValue release];
    currentElementValue = nil;
}

- (void) dealloc 
{
    
    [aBook release];
    [currentElementValue release];
    [super dealloc];
}

@end
