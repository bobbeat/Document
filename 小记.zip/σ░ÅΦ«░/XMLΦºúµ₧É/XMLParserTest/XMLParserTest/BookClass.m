//
//  BookClass.m
//  XMLParserTest
//
//  Created by 高志闽 on 12-8-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "BookClass.h"

@implementation BookClass


@synthesize author;
@synthesize summary;
@synthesize title;
@synthesize bookID;
- (void) dealloc {
    
    [summary release];
    [author release];
    [title release];
    [super dealloc];
}

@end
