//
//  AppDelegate.h
//  XMLParserTest
//
//  Created by 高志闽 on 12-8-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    NSMutableArray  *books;
}

@property (nonatomic, retain) NSMutableArray  *books;
@property (strong, nonatomic) UIWindow *window;

@end
