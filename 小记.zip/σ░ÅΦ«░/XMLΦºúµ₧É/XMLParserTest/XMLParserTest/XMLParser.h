//
//  XMLParser.h
//  XMLParserTest
//
//  Created by 高志闽 on 12-8-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@class AppDelegate, BookClass;


@interface XMLParser : NSObject<NSXMLParserDelegate>
{
    NSMutableString *currentElementValue;  //用于存储元素标签的值
    AppDelegate *appDelegate;
    BookClass *aBook;  //书籍实例
}

- (XMLParser *)initXMLParser; //构造器

@end