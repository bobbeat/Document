//
//  BookClass.h
//  XMLParserTest
//
//  Created by 高志闽 on 12-8-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BookClass : NSObject
{
    NSInteger  bookID;
    NSString    *title;
    NSString    *author;
    NSString    *summary;
}

@property (nonatomic, readwrite) NSInteger bookID;
@property (nonatomic, retain) NSString  *title;
@property (nonatomic, retain) NSString  *author;
@property (nonatomic, retain) NSString  *summary;
 
@end
