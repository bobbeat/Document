//
//  GDBL_NetCounter.m
//  AutoNavi
//
//  Created by jingjie lin on 12-6-25.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "GDBL_NetCounter.h"
#define filePath [NSHomeDirectory() stringByAppendingString:@"/Documents/NetCount.plist"]
#define totalCountKey @"totalCount"
static GDBL_NetCounter * instance;

@implementation GDBL_NetCounter
@synthesize byte;
@synthesize totalByte;
@synthesize currentByte;
+(GDBL_NetCounter *)shareInstance
{
    if (instance == nil) {
        instance  = [[GDBL_NetCounter alloc] init];
        instance.currentByte = 0;
        instance.totalByte = 0;
        [instance readData];
    }
    return instance;
}

-(void)setByte:(long)tmpByte
{
    if (tmpByte > 0)
    {
        self.totalByte += tmpByte;
        self.currentByte += tmpByte;
    }
}

-(void)readData
{
    NSDictionary * dic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    if(dic != nil)
    {
        NSNumber *totalCountNum = [dic objectForKey:totalCountKey];
        if (totalCountNum != nil)
        {
            int count = [totalCountNum intValue];
            if (count > 0)
            {
                self.totalByte = [totalCountNum intValue];
            }
            
        }
    }
}

- (void)ClearByteForMonth
{
    self.totalByte = 0;
    [self saveData];
}

-(void)saveData
{
    NSDictionary * dic = [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:self.totalByte] forKey:totalCountKey];
    [dic writeToFile:filePath atomically:YES];
}

-(void)dealloc
{
    [self saveData];
    [super dealloc];
}

@end
