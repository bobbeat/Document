//
//  GDBL_NetCounter.h
//  AutoNavi
//
//  Created by jingjie lin on 12-6-25.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GDBL_NetCounter : NSObject
+(GDBL_NetCounter *)shareInstance;
@property (nonatomic,setter = setByte:)long byte;
@property(nonatomic)long totalByte;      //总流量
@property(nonatomic)long currentByte;    //本次开机流量
-(void)readData;
-(void)saveData;
- (void)ClearByteForMonth;
@end
