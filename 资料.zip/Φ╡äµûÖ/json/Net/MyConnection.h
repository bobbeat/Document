//
//  MyConnection.h
//  plugin_ctrip
//
//  Created by xieminna on 12-7-3.
//  Copyright 2012 autonavi.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetRequest.h"

@interface MyConnection : NSObject {
	NSURLConnection *curConn;
}
-(MyConnection*) initWithNetRequest:(NSURLRequest*)request_url;

//-(void) setNetRequestParam:(NetRequest*)request;
-(void) cancel;
-(void) start;
@end
