//
//  plugin_SearchPoi_Connection.m
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import "plugin_SearchPoi_Connection.h"
#import "GDBL_NetCounter.h"


@implementation plugin_SearchPoi_Connection

@synthesize delegate;


- (id)initWithString:(NSString *)urlString
{
	if (self=[super init]) 
	{
		myurl = [[NSURL alloc] initWithString:urlString];
		mydata = [[NSMutableData alloc] init];
	}
	
	return self;
}


- (id)initWithUrl:(NSURL *)urlT
{
	if (self=[super init]) 
	{
		myurl = urlT;
		[myurl retain];
		mydata = [[NSMutableData alloc] init];
	}
	
	return self;
}


- (void)dealloc
{
	if (myurl) 
	{
		[myurl release];
		myurl = nil;
	}
	
	if (mydata) 
	{
		[mydata release];
		mydata = nil;
	}
	
	if (myrequst) 
	{
		[myrequst release];
		myrequst = nil;
	}
	
	if (myconnection) 
	{
		[myconnection release];
		myconnection = nil;
	}
	
	[super dealloc];
}


- (void)setConnection
{
	//对url是否为空加以判断
	if (myurl == nil) 
	{
		[delegate connectiondidFailWithError:nil];
		return;
	}
	
	if (myrequst) 
	{
		[myrequst release];
		myrequst = nil;
	}	
	myrequst = [[NSMutableURLRequest alloc] initWithURL:myurl];
    [myrequst setTimeoutInterval:NET_TIMEOUT_ASYN];
	if (myconnection) 
	{
		[myconnection release];
		myconnection = nil;
	}
	myconnection = [[NSURLConnection alloc] initWithRequest:myrequst delegate:self];
	
	[myrequst release];
	myrequst = nil;
}


- (void)setGetConnection
{
	//对url是否为空加以判断
	if (myurl == nil) 
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Cannot Open the Request!" 
															message:@"url内容为空，无法下载！" 
														   delegate:nil 
												  cancelButtonTitle:@"OK" 
												  otherButtonTitles:nil];
		[alertView show];
		[alertView release];
		return;
	}
	
	if (myrequst) 
	{
		[myrequst release];
		myrequst = nil;
	}	
	myrequst = [[NSMutableURLRequest alloc] initWithURL:myurl];
	[myrequst setHTTPMethod:@"GET"];
    [myrequst setTimeoutInterval:NET_TIMEOUT_ASYN];
	
	if (myconnection) 
	{
		[myconnection release];
		myconnection = nil;
	}
	myconnection = [[NSURLConnection alloc] initWithRequest:myrequst delegate:self];
	
	[myrequst release];
	myrequst = nil;
}


- (void)setPostConnectionWithBody:(NSData *)bodydata
{
	//对url是否为空加以判断
	if (myurl == nil) 
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Cannot Open the Request!" 
															message:@"url内容为空，无法下载！" 
														   delegate:nil 
												  cancelButtonTitle:@"OK" 
												  otherButtonTitles:nil];
		[alertView show];
		[alertView release];
		return;
	}
	if (myrequst) 
	{
		[myrequst release];
		myrequst = nil;
	}	
	myrequst = [[NSMutableURLRequest alloc] initWithURL:myurl];
	[myrequst setHTTPMethod:@"POST"];
	[myrequst setHTTPBody:bodydata];
	  [myrequst setTimeoutInterval:NET_TIMEOUT_ASYN];
    
	if (myconnection) 
	{
		[myconnection release];
		myconnection = nil;
	}
	myconnection = [[NSURLConnection alloc] initWithRequest:myrequst delegate:self];
	
	[myrequst release];
	myrequst = nil;
    //
    /*
     在WWAN连接情况下，在设置了setHTTPBody之后，系统会默认修改timeoutInterval为240s，可能是因为在WWAN（连wifi测试后也一样...）连接时，一个太短的timeout可能会引起一些不必要的问题，所以apple强制把有body信息的post连接的timeout设定为240s
     */
    //自定义时间超时
    m_timerForTimeout = [NSTimer scheduledTimerWithTimeInterval:NET_TIMEOUT_ASYN target:self selector: @selector(handleTimeoutForPostRequest:) userInfo:myconnection repeats:NO];
}


#pragma mark NSURLConnection Delegate methods

- (void)connection:(NSURLConnection *)aconnection didReceiveResponse:(NSURLResponse *)response
{
	[mydata setLength:0];
}


// 连接失败
- (void)connection:(NSURLConnection *)aconnection didFailWithError:(NSError *)error 
{
	//发送失败消息委托
    if (m_timerForTimeout) {
        [m_timerForTimeout invalidate];
        m_timerForTimeout = nil;
    }
	[delegate connectiondidFailWithError:error];
    [mydata setLength:0];
}


// 接收数据
- (void)connection:(NSURLConnection *)aconnection didReceiveData:(NSData *)data 
{
   
    [mydata appendData:data];
    
}


// 接收数据完成，取消任务，准备解析xml
- (void)connectionDidFinishLoading:(NSURLConnection *)aconnection 
{
    if (m_timerForTimeout) {
        [m_timerForTimeout invalidate];
        m_timerForTimeout = nil;
    }
    [aconnection cancel];
	[delegate connectionDidFinishWithData:mydata];
     [GDBL_NetCounter shareInstance].byte = mydata.length;
}
#pragma mark timeout for post request
-(void)handleTimeoutForPostRequest:(NSTimer *)timer
{
    m_timerForTimeout = nil;
    [mydata setLength:0];
    NSURLConnection *aconnection = ( NSURLConnection *)timer.userInfo;
    if (aconnection) {
        [aconnection cancel];
    }
    [delegate connectiondidFailWithError:nil];

}
@end
