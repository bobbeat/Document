//
//  plugin_SearchPoi_Connection.h
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SearchPoiConnectionDelegate

- (void)connectionDidFinishWithData:(NSData *)netData;//通知客户，网络连接完毕
- (void)connectiondidFailWithError:(NSError *)error;//通知客户网络连接失败

@end

@interface plugin_SearchPoi_Connection : NSObject {
    id<SearchPoiConnectionDelegate> delegate;
	
	NSMutableData *mydata;
	
	NSURL *myurl;
	NSMutableURLRequest *myrequst;
	NSURLConnection *myconnection;
    //
    NSTimer*        m_timerForTimeout;
}

@property (nonatomic ,assign) id<SearchPoiConnectionDelegate> delegate;

- (id)initWithString:(NSString *)urlString;
- (id)initWithUrl:(NSURL *)urlT;
- (void)setConnection;
- (void)setGetConnection;
- (void)setPostConnectionWithBody:(NSData *)bodydata;
@end
