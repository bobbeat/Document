//
//  NetRequest.m
//  Route
//  Net辅助类
//  Created by y y on 11-8-23.
//  Copyright 2011年 autonavi.com. All rights reserved.
//

#import "NetRequest.h"


@implementation NetRequest

@synthesize successTarget;
@synthesize successAction;
@synthesize failureTarget;
@synthesize failureAction;
@synthesize requestURL;
@synthesize requestType;
@synthesize active;
@synthesize data;
@synthesize m_connection;

- (id)init
{
    if (self == [super init])
    {
        data = [[NSMutableData alloc] init];
    }
    return self;
}

- (void)dealloc
{
    if (successTarget)
    {
        [successTarget release];
        successTarget = nil;
    }
    if (failureTarget)
    {
        [failureTarget release];
        failureTarget = nil;
    }
    if (requestURL)
    {
        [requestURL release];
        requestURL = nil;
    }
    if (m_connection)
    {
        [m_connection release];
        m_connection = nil;
    }
    [data release];
    [super dealloc];
}



@end
