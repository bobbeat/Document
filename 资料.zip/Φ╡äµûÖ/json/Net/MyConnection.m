//
//  MyConnection.m
//  plugin_ctrip
//
//  Created by xieminna on 12-7-3.
//  Copyright 2012 autonavi.com. All rights reserved.
//

#import "MyConnection.h"
#import "Net.h"
#import "GDBL_NetCounter.h"

@implementation MyConnection

-(id)init
{
	self = [super init];
	if (self) {
		curConn = nil;
	}
	return self;
}
-(MyConnection*) initWithNetRequest:(NSURLRequest*)request_url
{
	
	if (self = [super init])
	{
		curConn = [[NSURLConnection alloc] initWithRequest:request_url 
															delegate:self startImmediately:NO];
		
		[curConn scheduleInRunLoop:[NSRunLoop currentRunLoop] 
							forMode:NSDefaultRunLoopMode];
		
		return self;
	}
	return nil;
}
-(void) cancel
{
	if (curConn) {
		[curConn cancel];
	}
}
-(void) start
{
	if (curConn)
	{
		[curConn start];
	}
}
//-(void) setNetRequestParam:(NetRequest*)request
//{
//	
//}
-(void)dealloc
{
    if (nil!=curConn) {
        [curConn release];
        curConn = nil;
    }
	[super dealloc];
}
#pragma mark NSURLConnection delegate

-(void)connection:(NSURLConnection *)conn
didReceiveResponse:(NSURLResponse *)response
{
    NetRequest *request =[[Net instance] getRequestForConn:self];
    
	[request.data setLength:0];
}

-(void)connection:(NSURLConnection *)conn
   didReceiveData:(NSData *)data
{
    NetRequest *request =[[Net instance] getRequestForConn:self];
    [request.data appendData:data];
    [GDBL_NetCounter shareInstance].byte = [data length];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)conn
{
    NetRequest *request =[[Net instance] getRequestForConn:self];

	if (nil==request) 
	{
		return;
	}
    request.active = NO;
    [request.successTarget performSelector:request.successAction
                                withObject:request.data withObject: [NSNumber numberWithInt:request.requestType]];
    [[Net instance] connectionEnded:self];
}

-(void)connection:(NSURLConnection *)conn 
 didFailWithError:(NSError *)error
{
    NetRequest *request =[[Net instance] getRequestForConn:self];

	if (nil==request)
	{
		return;
	}
    request.active = NO;
    if(request.failureTarget != nil)
        [request.failureTarget performSelector:request.failureAction 
                                    withObject:error withObject:[NSNumber numberWithInt:request.requestType]];
    [[Net instance] connectionEnded:self];
}


@end
