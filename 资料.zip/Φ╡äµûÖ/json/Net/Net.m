//  
//  Net.m
//  Route
//  辅助类，封装异步网络通讯
//  Created by y y on 11-8-24.
//  Copyright 2011年 autonavi.com. All rights reserved.
//

#import "Net.h"
#import "MyConnection.h"
static Net * net = nil;

@implementation Net

@synthesize concurrentRequestsLimit = _concurrentRequestsLimit;
+(Net *)instance
{    
    if(net == nil)
        net = [[Net alloc] init];
    return net;
}

-(id)init
{
    if(self ==[super init])
    {
        _activeRequestsCount =0;
        _concurrentRequestsLimit = 5;
        _requests =[[NSMutableDictionary alloc] init];
        _queue = [[NSMutableArray alloc] init];
    }
    return self;
}

-(void)dealloc
{
    [self cancelAllRequests];
    
    [_requests release];
    [_queue release];
    [super dealloc];
}

-(void)startRequest:(MyConnection *)conn
{
    NetRequest * request = [_requests objectForKey:
                            [NSValue valueWithNonretainedObject:conn]];
	
    request.active = YES;
    ++_activeRequestsCount;
    [conn start];
}

-(void)stopRequest:(MyConnection *)conn
{
    NetRequest *request = [_requests objectForKey:
                           conn];
	if (nil==request) {
		
	}else {
    request.active = NO;
	}

    --_activeRequestsCount;
    [request.m_connection cancel];
	
	[_requests removeObjectForKey:conn];
}

-(void)queueRequest:(MyConnection *)conn
{
    [_queue addObject:conn];
}

-(MyConnection*)dequeueRequest
{
    MyConnection *conn =[[_queue objectAtIndex:0] retain];
    [_queue removeObjectAtIndex:0];
    return  [conn autorelease];
}

-(void)connectionEnded:(MyConnection*)conn
{
	-- _activeRequestsCount;
	[_requests removeObjectForKey:[NSValue valueWithNonretainedObject:conn]];
//	[conn release];
    if(_activeRequestsCount <_concurrentRequestsLimit &&[_queue count]>0)
        [self startRequest:[self dequeueRequest]];
}
#pragma mark Network Flag Handling

- (NetStatus) localWiFiStatusForFlags: (SCNetworkReachabilityFlags) flags
{
	
	BOOL retVal = Reachable_None;
	if((flags & kSCNetworkReachabilityFlagsReachable) && (flags & kSCNetworkReachabilityFlagsIsDirect))
	{
		retVal = Reachable_WiFi;	
	}
	return retVal;
}

- (NetStatus) networkStatusForFlags: (SCNetworkReachabilityFlags) flags
{
	if ((flags & kSCNetworkReachabilityFlagsReachable) == 0)
	{
			// if target host is not reachable
		return Reachable_None;
	}
	
	BOOL retVal = Reachable_None;
	
	if ((flags & kSCNetworkReachabilityFlagsConnectionRequired) == 0)
	{
		// if target host is reachable and no connection is required
		//  then we'll assume (for now) that your on Wi-Fi
		retVal = Reachable_WiFi;
	}
	
	
	if ((((flags & kSCNetworkReachabilityFlagsConnectionOnDemand ) != 0) ||
		 (flags & kSCNetworkReachabilityFlagsConnectionOnTraffic) != 0))
	{
		// ... and the connection is on-demand (or on-traffic) if the
		//     calling application is using the CFSocketStream or higher APIs
		if ((flags & kSCNetworkReachabilityFlagsInterventionRequired) == 0)
		{
			// ... and no [user] intervention is needed
			retVal = Reachable_WiFi;
		}
	}
	
	if ((flags & kSCNetworkReachabilityFlagsIsWWAN) == kSCNetworkReachabilityFlagsIsWWAN)
	{
		// ... but WWAN connections are OK if the calling application
		//     is using the CFNetwork (CFSocketStream?) APIs.
		retVal = Reachable_WWAN;
	}
	return retVal;
}

- (NetStatus) currentReachabilityStatusWithRef:(SCNetworkReachabilityRef)reachabilityRef isWifi:(BOOL)localWiFiRef
{
//	NSAssert(reachabilityRef != NULL, @"currentNetworkStatus called with NULL reachabilityRef");
	NetStatus retVal = Reachable_None;
	SCNetworkReachabilityFlags flags;
	if (SCNetworkReachabilityGetFlags(reachabilityRef, &flags))
	{
		if(localWiFiRef)
		{
			retVal = [self localWiFiStatusForFlags: flags];
		}
		else
		{
			retVal = [self networkStatusForFlags: flags];
		}
	}
	
	return retVal;
}

//检测网络是否可连接
-(BOOL) connectedToNetwork
{
	BOOL netCheckValue =NO;
	
	// Create zero addy
	struct sockaddr_in zeroAddress;
	bzero(&zeroAddress, sizeof(zeroAddress));
	zeroAddress.sin_len = sizeof(zeroAddress);
	zeroAddress.sin_family = AF_INET;
	
	// Recover reachability flags
	SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);    
	
    NetStatus retVal = Reachable_None;	
	retVal = [self currentReachabilityStatusWithRef:defaultRouteReachability isWifi:NO];
    netCheckValue = ((retVal != Reachable_None) ? YES : NO);
    
	CFRelease(defaultRouteReachability);
	
    return netCheckValue;
}

#pragma mark public
/**
 * @TODO 添加下载请求
 * @param (NSString *)requestUrl: 请求的URL
 * @param (REQUEST_TYPE)type: 请求的类型
 * @param (NSData *)body: 提交的data
 * @param (int)request_type: 请求的方式，0：GET 1：POST
 * @param (id)successTarget:
 * @param (SEL)successAction: succ接收函数
 * @param (id)failureTarget:
 * @param (SEL)failureAction: fail接收函数
 * @param
 */
- (MyConnection *)addRequest:(NSString *) requestUrl ofType:(REQUEST_TYPE) type
                    withBody:(NSData*)body  RequestType:(int)request_type
               successTarget:(id)successTarget successAction:(SEL)successAction
               failureTarget:(id)failureTarget failureAction:(SEL)failureAction
{
	printf("request url = %s\n\n", [requestUrl UTF8String]);
    NSURL *url = [NSURL URLWithString:requestUrl];

    for (NetRequest *request in [_requests allValues]) //防止相同请求重复
    {
        if ([request.requestURL isEqualToString:requestUrl] && type == request.requestType)
        {
            return nil;
        }
    }
    
	NSMutableURLRequest *req = [[NSMutableURLRequest alloc] initWithURL:url];
    [req setTimeoutInterval:NET_TIMEOUT_ASYN];
	if (request_type == 1)
    {
		[req setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
        if (body != nil)
        {
            [req setHTTPBody:body];
        }
		[req addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
		[req setValue:[NSString stringWithFormat:@"%d",[body length]] forHTTPHeaderField:@"Content-Length"];
		[req setHTTPMethod:@"POST"];
	}
    else
    {
        [req setHTTPMethod:@"GET"];
    }
	MyConnection *conn = [[MyConnection alloc] initWithNetRequest:req];
    [req release];

    if(conn == nil)
        return nil;
    NetRequest *request = [[NetRequest alloc] init];
    request.successTarget = successTarget;
    request.successAction = successAction;
    request.failureTarget = failureTarget;
    request.failureAction = failureAction;
    request.requestURL = requestUrl;
	request.requestType = type;
    request.m_connection = conn;
    [_requests setObject:request forKey:
     [NSValue valueWithNonretainedObject:conn]];
    [request release];
    if(_activeRequestsCount < _concurrentRequestsLimit)
        [self startRequest:conn];
    else
        [self queueRequest:conn];
    return [conn autorelease];
}

/**
 * @TODO 图片，文件上传请求
 * @param (NSString *)requestUrl: 请求的URL
 * @param (NSDictionary *)dic: 提交的表单，包括图片,文件
 * @param (NSString *)fileName: 图片或文件的名称
 * @param (NSString *)fileType: 图片或文件的提交类型，如 image/png image/jpg 等
 * @param (id)successTarget:
 * @param (SEL)successAction: succ接收函数
 * @param (id)failureTarget:
 * @param (SEL)failureAction: fail接收函数
 * @param
 */
- (MyConnection *)addRequest:(NSString *) requestUrl ofType:(REQUEST_TYPE) type
                         dic:(NSDictionary *)params fileKey:(NSString *)fileKey
                    fileName:(NSString *)fileName fileType:(NSString *)fileType
               successTarget:(id)successTarget successAction:(SEL)successAction
               failureTarget:(id)failureTarget failureAction:(SEL)failureAction;
{
    NSLog(@"%@",requestUrl);
    //分界线的标识符
    NSString *TWITTERFON_FORM_BOUNDARY = @"AaB03x";
    //根据url初始化req
    NSMutableURLRequest* req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:requestUrl]
                                                           cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                       timeoutInterval:10];
    //分界线 --AaB03x
    NSString *MPboundary=[[NSString alloc]initWithFormat:@"--%@",TWITTERFON_FORM_BOUNDARY];
    //结束符 --AaB03x--
    NSString *endMPboundary=[[NSString alloc]initWithFormat:@"%@--",MPboundary];
    //要上传的图片，文件
    UIImage *image=[params objectForKey:fileKey];
    //得到图片的data
    NSData* data = UIImagePNGRepresentation(image);
    //http body的字符串
    NSMutableString *body=[[NSMutableString alloc]init];
    //参数的集合的所有key的集合
    NSArray *keys= [params allKeys];
    
    //遍历keys
    for(int i=0;i<[keys count];i++)
    {
        //得到当前key
        NSString *key=[keys objectAtIndex:i];
        //如果key不是fileKey，说明value是字符类型，比如name：Boris
        if(![key isEqualToString:fileKey])
        {
            //添加分界线，换行
            [body appendFormat:@"%@\r\n",MPboundary];
            //添加字段名称，换2行
            [body appendFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n",key];
            //添加字段的值
            [body appendFormat:@"%@\r\n",[params objectForKey:key]];
        }
    }
    
    ////添加分界线，换行
    [body appendFormat:@"%@\r\n",MPboundary];
    //声明fileKey字段，文件名为fileName
    [body appendFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"file.png\"\r\n",fileName];
    //声明上传文件的格式
    NSString *content_type = [NSString stringWithFormat:@"Content-Type: image/png"];
    [body appendFormat:@"%@\r\n\r\n",content_type];
    
    
    //声明myRequestData，用来放入http body
    NSMutableData *myRequestData=[NSMutableData data];
    //将body字符串转化为UTF8格式的二进制
    [myRequestData appendData:[body dataUsingEncoding:NSUTF8StringEncoding]];
    //将image的data加入
    [myRequestData appendData:data];
    
    //声明结束符：--AaB03x--
    NSString *end=[[NSString alloc]initWithFormat:@"\r\n%@",endMPboundary];
    //加入结束符--AaB03x--
    [myRequestData appendData:[end dataUsingEncoding:NSUTF8StringEncoding]];
    
    //设置HTTPHeader中Content-Type的值
    NSString *content=[[NSString alloc]initWithFormat:@"multipart/form-data; boundary=%@",TWITTERFON_FORM_BOUNDARY];
    //设置HTTPHeader
    [req setValue:content forHTTPHeaderField:@"Content-Type"];
    //设置Content-Length
    [req setValue:[NSString stringWithFormat:@"%d", [myRequestData length]] forHTTPHeaderField:@"Content-Length"];
    //设置http body
    [req setHTTPBody:myRequestData];
    //http method
    [req setHTTPMethod:@"POST"];
    
    [end release];
    [content release];
    [body release];
    [MPboundary release];
    [endMPboundary release];
    
    //建立连接，设置代理
    MyConnection *conn = [[MyConnection alloc] initWithNetRequest:req];
    
    if(conn == nil)
        return nil;
    NetRequest *request = [[NetRequest alloc] init];
    request.successTarget = successTarget;
    request.successAction = successAction;
    request.failureTarget = failureTarget;
    request.failureAction = failureAction;
    request.requestURL = requestUrl;
	request.requestType = type;
    request.m_connection = conn;
    [_requests setObject:request forKey:
     [NSValue valueWithNonretainedObject:conn]];
    [request release];
    if(_activeRequestsCount < _concurrentRequestsLimit)
        [self startRequest:conn];
    else
        [self queueRequest:conn];
    return [conn autorelease];
}

-(NetRequest *)getRequestForConn:(MyConnection*)conn
{
	if (nil==_requests||[_requests count]<1) {
		return nil;
	}
	return [_requests objectForKey: [NSValue valueWithNonretainedObject:conn]];
}


/**
 * @TODO 取消单个请求的连接
 * @param (MyConnection *)conn:取消的连接
 */
-(void)cancelRequest:(MyConnection *)conn
{
    NetRequest *request = [_requests objectForKey:
                           [NSValue valueWithNonretainedObject:conn]];
    if(request == nil)
        return;
    if(request.active)
        [self stopRequest:conn];
    else
        [_queue removeObject:conn];    
    [_requests removeObjectForKey:[NSValue valueWithNonretainedObject:conn]];
}

/**
 * @TODO 取消所有网络连接
 */
-(void)cancelAllRequests
{
	for (NSValue *value in [_requests allKeys]) {
        NetRequest *request = [_requests objectForKey:
                               value];
		if (nil== request) {
			continue;
		}
        if(request.active)
		{
			[self stopRequest:(MyConnection *)value];

		}
    }
    [_requests removeAllObjects];
    [_queue removeAllObjects];
}
/**
 * @TODO 通过URL读取网络图片
 */
-(UIImage*)getImageByUrl:(NSString *)url
{
    return [[UIImage alloc]initWithData:
			[NSData dataWithContentsOfURL:
			 [NSURL URLWithString:
			  [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]]];
}

@end
