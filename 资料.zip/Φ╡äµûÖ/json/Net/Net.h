//
//  Net.h
//  Route
//
//  Created by y y on 11-8-24.
//  Copyright 2011年 autonavi.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <netdb.h>
#import <arpa/inet.h>
#import "NetRequest.h"
#import "MyConnection.h"

#define kRetOk	@"true"
#define kResultForKey	@"result"   //parse xml result
#define kTotalForKey	@"total"	//allhotelId or city count
#define kDataForKey	@"data"		//hotel detail list or city info List


@interface Net : NSObject {
    int _activeRequestsCount;
    int _concurrentRequestsLimit;
    // NSValues with NSURLConnections -> NetRequests
    NSMutableDictionary *_requests;
    NSMutableArray *_queue; // NSURLConnections
}
enum NET_RES{
    CONN_SERVER_FAIL,   //服务器出错
    CONN_SUCC,          //连接成功200
    CONN_CANCEL,        //连接取消
    CRC_ERROR,          //CRC16校验错误
    CONN_CLOSE,         //网络未初始化
    CONN_REQUEST_BUSY,  //网络繁忙（累积请求数太多）
    CONN_BAD_REQUEST,   //错误的请求400
    CONN_FORBIDDEN,     //请示被禁止403
    CONN_NOT_FOUND,     //404
    CONN_SERVER_ERROR,  //500
    CONN_OVERTIME,      //超时503
    CONN_UNDEFINED,     //网络连接(未知/未定义错误)
    TRAN_UNDEFINED,     //传输（未知/未定义错误）
    TRAN_FINISH         //传输完成
};
#pragma mark net
typedef enum {
	Reachable_None = 0,
	Reachable_WiFi,
	Reachable_WWAN
} NetStatus;

//检测是否可以连接wifi
//BOOL localWiFiRef;
//SCNetworkReachabilityRef reachabilityRef;

@property (nonatomic, assign) int concurrentRequestsLimit;

+ (Net *)instance;

//检测网络是否可连接
- (BOOL) connectedToNetwork;
- (id)init;
- (void)startRequest:(MyConnection *)conn;
- (void)stopRequest:(MyConnection *)conn;
- (void)queueRequest:(MyConnection *)conn;
- (MyConnection *)dequeueRequest;
- (void)connectionEnded:(MyConnection*)conn;

#pragma mark Public
/**
 * @TODO 添加下载请求
 * @param (NSString *)requestUrl: 请求的URL
 * @param (REQUEST_TYPE)type: 请求的类型
 * @param (NSData *)body: 提交的data
 * @param (int)request_type: 请求的方式，0：GET 1：POST
 * @param (id)successTarget: 
 * @param (SEL)successAction: succ接收函数
 * @param (id)failureTarget:
 * @param (SEL)failureAction: fail接收函数
 * @param
 */
- (MyConnection *)addRequest:(NSString *) requestUrl ofType:(REQUEST_TYPE) type
                    withBody:(NSData*)body  RequestType:(int)request_type
                  successTarget:(id)successTarget successAction:(SEL)successAction
                  failureTarget:(id)failureTarget failureAction:(SEL)failureAction;

/**
 * @TODO 图片，文件上传请求
 * @param (NSString *)requestUrl: 请求的URL
 * @param (NSDictionary *)dic: 提交的表单，包括图片,文件
 * @param (NSString *)fileName: 图片或文件的名称
 * @param (NSString *)fileType: 图片或文件的提交类型，如 image/png image/jpg 等
 * @param (id)successTarget:
 * @param (SEL)successAction: succ接收函数
 * @param (id)failureTarget:
 * @param (SEL)failureAction: fail接收函数
 * @param
 */
- (MyConnection *)addRequest:(NSString *) requestUrl ofType:(REQUEST_TYPE) type
               dic:(NSDictionary *)params fileKey:(NSString *)fileKey
                    fileName:(NSString *)fileName fileType:(NSString *)fileType
               successTarget:(id)successTarget successAction:(SEL)successAction
               failureTarget:(id)failureTarget failureAction:(SEL)failureAction;

-(NetRequest *)getRequestForConn:(MyConnection*)conn;

- (void)cancelRequest:(NSURLConnection *)conn;
- (void)cancelAllRequests;

-(UIImage*)getImageByUrl:(NSString*)url;

@end
