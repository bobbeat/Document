//
//  NetRequest.h
//  Route
//
//  Created by y y on 11-8-23.
//  Copyright 2011年 autonavi.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kTServerHost	@"http://telematics.autonavi.com/"
//#define SERVER_HOST @"http://car.autonavi.com/hotel/"
#define kTServerDataVer	@"xm"
#define kTServerChannel	@"autonavi_navigation"
#define kTServerKey	@"ae429b811e400b831201c78301a9ad2e"

#define kCtripCityHead	@"ws/value_added/hotel/support-city"
#define kCtripListHead	@"ws/value_added/hotel/list/"
#define kCtripDetailHead	@"ws/value_added/hotel/detail/"

#define kDefaultHotelSign	@"0379D2BC446F9C7AB1D7DA3DCB54A5C0"

#define kRepastTypeHead      @"ws/mapapi/restaurant/category/"
#define kRepastListHead      @"ws/mapapi/restaurant/search-around/"


#define kUGCDetail            @"/layer/searchbyid/"
#define kUGCUpload            @"/layer/uploadlayer_v2/"

#define kGolfArea             @"ws/value_added/golf/ad-list/"
#define kGolfList             @"ws/value_added/golf/club-list/"
#define kGolfSearch           @"ws/value_added/golf/club-search/"
#define kGolfDetail           @"ws/value_added/golf/club-info/"
#define kGolfCourse           @"ws/value_added/golf/course-info/"


typedef enum REQUEST_TYPE{
	//ctrip 
	REQ_HOTEL_LIST		=0,
	REQ_HOTEL_DETAIL    ,
    REQ_CITY_LIST       ,
	
	//UGC
	REQ_UGC_SYNC		=40,
	REQ_UGC_LIST,
	REQ_UGC_DETAIL,
	REQ_UGC_SYN,
	
	//BHotel
	REQ_BHOTEL_LIST,
	REQ_BHOTEL_DETAIL,
	
	//Repast
	REQ_REPAST_TYPE,
	REQ_REPAST_LIST,
	
    //Golf club
    REQ_GOLF_AREA,      //golf 支持的城市区域
    REQ_GOLF_LIST,      //查询golf club
    REQ_GOLF_DETAIL,    //golf 详情
    REQ_GOLF_COURSE,    //golf 球场信息
    
    //onlineMap
    REQ_ONLINE_ENABLE,
    
	REQ_NIL
}REQUEST_TYPE;

@class MyConnection;

@interface NetRequest : NSObject {
    id successTarget;
    SEL successAction;
    id failureTarget;
    SEL failureAction;
    NSString *requestURL;
	REQUEST_TYPE requestType;
    
    BOOL active;
    NSMutableData *data;
    MyConnection *m_connection;
}



@property (nonatomic, retain) id successTarget;
@property (nonatomic, assign) SEL successAction;
@property (nonatomic, retain) id failureTarget;
@property (nonatomic, assign) SEL failureAction;
@property (nonatomic, retain) NSString *requestURL;
@property (nonatomic, assign) REQUEST_TYPE requestType;
@property (nonatomic, assign) BOOL active;
@property (nonatomic, retain) NSMutableData *data;
@property (nonatomic, retain) MyConnection *m_connection;
- (id)init;
@end
