//
//  GDBL_DetectMute.h
//  AutoNavi
//
//  Created by huang longfeng on 13-7-10.
//
//
/**
     检测系统静音键
     调用示例：
    [[GDBL_DetectMute sharedInstance] setDelegate:self];
    [[GDBL_DetectMute sharedInstance] detectMuteSwitch];
 
    - (void)isMuted:(BOOL)muted {
    }
  */

#import <Foundation/Foundation.h>
#include <AudioToolbox/AudioToolbox.h>

@class GDBL_DetectMute;

@protocol GDBL_DetectMuteDelegate
    @required
    - (void)isMuted:(BOOL)muted;
@end

@interface GDBL_DetectMute : NSObject
{
        @private
        NSObject<GDBL_DetectMuteDelegate> *delegate;
        float soundDuration;
        NSTimer *playbackTimer;
}

@property (readwrite, retain) NSObject<GDBL_DetectMuteDelegate> *delegate;


+(GDBL_DetectMute *)sharedInstance;

- (void)detectMuteSwitch;

@end
