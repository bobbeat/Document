//
//  CinLoggerManager.h
//  TableTest
//
//  Created by gaozhimin on 13-1-29.
//  Copyright (c) 2013年 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum CinLogLevel {
    CinLogLevelDebug = 1,
    CinLogLevelInfo,
    CinLogLevelWarn,
    CinLogLevelError,
}CinLogLevel;

@interface CinLoggerManager : NSObject
{
    CinLogLevel mLogLevel;
    NSCondition* _signal;
    NSMutableArray* _queue;
    NSString *timeString;
    NSString *localMapVersion;
    NSString *mapType;
    BOOL     dismissed;
}

@property (nonatomic,assign) CinLogLevel mLogLevel;
@property (nonatomic,copy) NSString *timeString;
@property (nonatomic,copy) NSString *localMapVersion;
@property (nonatomic,copy) NSString *mapType;

+ (id)SharedInstance;
- (void)setMapVersion:(NSString *)mapVersion AndMapType:(int)type;
- ( void ) appendLogEntry: ( NSMutableDictionary* )entry;

@end
void SignalHandler(int signal);
