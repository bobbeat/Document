//
//  CinLoggerManager.m
//  TableTest
//
//  Created by gaozhimin on 13-1-29.
//  Copyright (c) 2013年 autonavi. All rights reserved.
//

#import "CinLoggerManager.h"
#include <sys/types.h>
#include <sys/sysctl.h>
#import "ANDataSource.h"
#import "ANParamValue.h"
#include <execinfo.h>
#include <libkern/OSAtomic.h>

#define FeLogDebug(format,...)        writeCinLog(__FUNCTION__,CinLogLevelDebug,format,##__VA_ARGS__)
#define FeLogInfo(format,...)        writeCinLog(__FUNCTION__,CinLogLevelInfo,format,##__VA_ARGS__)
#define FeLogWarn(format,...)        writeCinLog(__FUNCTION__,CinLogLevelWarning,format,##__VA_ARGS__)
#define FeLogError(format,...)        writeCinLog(__FUNCTION__,CinLogLevelError,format,##__VA_ARGS__)
#define fileType                      @".log"

static CinLoggerManager *g_CinLoggerManager = nil;

NSString * const GDUncaughtExceptionHandlerSignalExceptionName = @"GDUncaughtExceptionHandlerSignalExceptionName";
NSString * const GDUncaughtExceptionHandlerSignalKey = @"GDUncaughtExceptionHandlerSignalKey";
NSString * const GDUncaughtExceptionHandlerAddressesKey = @"GDUncaughtExceptionHandlerAddressesKey";
volatile int32_t GDUncaughtExceptionCount = 0;
const int32_t GDUncaughtExceptionMaximum = 10;
const NSInteger GDUncaughtExceptionHandlerSkipAddressCount = 4;
const NSInteger GDUncaughtExceptionHandlerReportAddressCount = 5;

BOOL isFinish = NO;

@implementation CinLoggerManager

@synthesize mLogLevel;
@synthesize timeString;
@synthesize localMapVersion;
@synthesize mapType;

void blockingFlushLogs(const char* function)
{
    while(!isFinish);
}

void writeCinLog( const char* function,        // 记录日志所在的函数名称
                 CinLogLevel level,            // 日志级别，Debug、Info、Warn、Error
                 NSString* format,            // 日志内容，格式化字符串
                 ... )                        // 格式化字符串的参数
{
    CinLoggerManager* manager = [CinLoggerManager SharedInstance]; // CinLoggerManager是单件的日志管理器
    
    if ( manager.mLogLevel > level || ! format ) // 先检查当前程序设置的日志输出级别。如果这条日志不需要输出，就不用做字符串格式化
        return;
    
    va_list args;
    va_start( args, format );
    NSString* str = [ [ NSString alloc ] initWithFormat: format arguments: args ];
    va_end( args );
    NSThread* currentThread = [ NSThread currentThread ];
    NSString* threadName = [ currentThread name ];
    NSString* functionName = [ NSString stringWithUTF8String: function ];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYYMMddhhmmss"];
    manager.timeString = [formatter stringFromDate: [NSDate date]];
    [formatter release];
    

    NSString *sysVersion = CurrentSystemVersion;
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithFormat:@"%s",machine];
    NSString *applicationState = [NSString stringWithFormat:@"%d",[[UIApplication sharedApplication] applicationState] ];
    NSString *softWareVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString *)kCFBundleVersionKey];
    if (! softWareVersion) {
        softWareVersion = @"";
    }
    if (! manager.localMapVersion) {
        manager.localMapVersion = @"";
    }
    if (! sysVersion) {
        sysVersion = @"";
    }
    if (! platform) {
        platform = @"";
    }
    if (! manager.timeString) {
        manager.timeString = @"";
    }
    if ( ! threadName )
        threadName = @"";
    if ( ! functionName )
        functionName = @"";
    if ( ! str )
        str = @"";
    
    // NSDictionary中加入所有需要记录到日志中的信息
    NSMutableDictionary* entry = [[NSMutableDictionary alloc] init];
    [entry setValue:@"LogEntry" forKey:@"Type"];
    [entry setValue:str forKey:@"Message"];                                    // 日志内容
    [entry setValue:manager.timeString forKey:@"Date"];                        // 日志生成时间
    [entry setValue:platform forKey:@"Platform"];
    [entry setValue:sysVersion forKey:@"System"];
    [entry setValue:softWareVersion forKey:@"Version"];
    [entry setValue:manager.localMapVersion forKey:@"MapVersion"];
    [entry setValue:manager.mapType forKey:@"MapType"];
    [entry setValue:[NSNumber numberWithUnsignedInteger:level] forKey:@"Level"];// 本条日志级别
    [entry setValue:threadName forKey:@"ThreadName"];                           // 本条日志所在的线程名称
    [entry setValue:functionName forKey:@"FunctionName"];                       // 本条日志所在的函数名称
    [entry setValue:applicationState forKey:@"ApplicationState"];
                           
    [ str release ];
    [ manager appendLogEntry: entry ];
    [ entry release ];
}


static void handleRootException( NSException* exception )
{
    NSLog(@"handleRootException");
    NSString* name = [ exception name ];
    NSString* reason = [ exception reason ];
    
    NSArray* symbols;
    if (0 == [[exception callStackSymbols] count]) {
        symbols = [[exception userInfo] objectForKey:GDUncaughtExceptionHandlerAddressesKey];
    }
    else{
        symbols = [ exception callStackSymbols ]; // 异常发生时的调用栈
    }
    
    NSMutableString* strSymbols = [ [ NSMutableString alloc ] init ]; // 将调用栈拼成输出日志的字符串
    for ( NSString* item in symbols )
    {
        [ strSymbols appendString: item ];
        [ strSymbols appendString: @"\r\n" ];
    }
    isFinish = NO;
    //写日志，级别为ERROR
    writeCinLog( __FUNCTION__, CinLogLevelError, @"\r\n[ Uncaught Exception ]\r\nName: %@\r\nReason: %@\r\n[ Fe Symbols Start ]\r\n%@[ Fe Symbols End ]", name, reason, strSymbols );
    
    [[CinLoggerManager SharedInstance] MyCrashAlertView:exception Message:[NSString stringWithFormat:@"\r\n[ Uncaught Exception ]\r\n名字: %@\r\n原因: %@\r\n[ 堆栈信息 Start ]\r\n%@[ 堆栈信息 End ]",name,reason,strSymbols]];
    [ strSymbols release ];
    //Hold住当前线程，等待日志线程将日志成功输出，当前线程再继续运行
    blockingFlushLogs( __FUNCTION__ );
    
}
+ (NSArray *)backtrace
{
    void* callstack[128];
    int frames = backtrace(callstack, 128);
    char **strs = backtrace_symbols(callstack, frames);
    
    int i;
    NSMutableArray *backtrace = [NSMutableArray arrayWithCapacity:frames];
    for (
         i = GDUncaughtExceptionHandlerSkipAddressCount;
         i < frames;
         i++)
    {
	 	[backtrace addObject:[NSString stringWithUTF8String:strs[i]]];
    }
    free(strs);
    
    return backtrace;
}

- (void)setMapVersion:(NSString *)mapVersion AndMapType:(int)type
{
    CinLoggerManager* manager = [CinLoggerManager SharedInstance];
    manager.localMapVersion = [NSString stringWithFormat:@"%@",mapVersion];
    manager.mapType = [NSString stringWithFormat:@"%d",type];
}
+ (id)SharedInstance
{
    if (g_CinLoggerManager == nil)
    {
        g_CinLoggerManager = [[CinLoggerManager alloc] init];
    }
    return g_CinLoggerManager;
}

- (id)init
{
    if (self = [super init])
    {
        _queue = [[NSMutableArray alloc] init];
        NSSetUncaughtExceptionHandler(handleRootException);
        signal(SIGABRT, SignalHandler);
        signal(SIGILL, SignalHandler);
        signal(SIGSEGV, SignalHandler);
        signal(SIGFPE, SignalHandler);
        signal(SIGBUS, SignalHandler);
        signal(SIGPIPE, SignalHandler);
        signal(SIGQUIT, SignalHandler);
        signal(SIGTRAP, SignalHandler);
        signal(SIGEMT, SignalHandler);
        signal(SIGSYS, SignalHandler);
        signal(SIGALRM, SignalHandler);
        signal(SIGXCPU, SignalHandler);
        signal(SIGXFSZ, SignalHandler);
        
    }
    return self;
}

- (void)dealloc
{
    [_queue release];
    [super dealloc];
}
//查看文件是否存在
- (BOOL)checkFileCreated
{
    CinLoggerManager* cinManager = [CinLoggerManager SharedInstance];
    NSFileManager *manager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSError *myError;
	NSDictionary *DirectoryAttrib = [NSDictionary dictionaryWithObject:[NSNumber numberWithUnsignedLong:0777UL] forKey:NSFilePosixPermissions];
    NSString *crash_path = [NSString stringWithFormat:@"%@/crashLog/", documentsDirectory];
	if (![[NSFileManager defaultManager] fileExistsAtPath:crash_path] ) {
        [[NSFileManager defaultManager] createDirectoryAtPath:crash_path withIntermediateDirectories:YES attributes:DirectoryAttrib error:&myError];
	}
   
    NSString *logPath = [NSString stringWithFormat:@"%@%@_%@%@",crash_path,cinManager.timeString,[[ANDataSource sharedInstance] GMD_GetDeviceID],fileType];
    if ([manager fileExistsAtPath:logPath])
    {
        return YES;
    }
    else
    {
        BOOL sign = NO;
        sign = [manager createFileAtPath:logPath contents:nil attributes:nil];
        return sign;
    }
    return NO;
}
//写crashlog
- (void)logToFile:(NSArray*)array
{
    CinLoggerManager* cinManager = [CinLoggerManager SharedInstance];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *crash_path = [NSString stringWithFormat:@"%@/crashLog/", documentsDirectory];
    NSString *logPath = [NSString stringWithFormat:@"%@%@_%@%@",crash_path,cinManager.timeString,[[ANDataSource sharedInstance] GMD_GetDeviceID],fileType];
    
    [array writeToFile:logPath atomically:YES];
    isFinish = YES;

}

//appendLogEntry实现如下：
- ( void ) appendLogEntry: ( NSMutableDictionary* )entry
{
    [ _signal lock ];
    [ _queue addObject: entry ];
    
    NSArray* items = [ NSArray arrayWithArray: _queue ];
    [ _queue removeAllObjects ];
    if ( [ items count ] > 0 && [ self checkFileCreated ] /* 检查日志文件是否已创建 */ )
    {
        [ self logToFile: items ]; // 输出到文件以及控制台
    }
    
    [ _signal signal ];
    [ _signal unlock ];
}
- (void)MyCrashAlertView:(NSException *)exception Message:(NSString *)message
{
#if  PROJECTMODE
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"很抱歉，程序出现异常，您可以选择[继续]，但程序可能会不稳定。" message:message delegate:self cancelButtonTitle:@"退出" otherButtonTitles:@"继续", nil];
    [alertView show];
    [alertView release];
    CFRunLoopRef runLoop = CFRunLoopGetCurrent();
    
    CFArrayRef allModes = CFRunLoopCopyAllModes(runLoop);
    
    while (!dismissed)
        
    {
        
        for (NSString *mode in (NSArray *)allModes)
            
        {
            
            CFRunLoopRunInMode((CFStringRef)mode, 0.001, false);
            
        }
        
    }
    
    CFRelease(allModes);
    NSSetUncaughtExceptionHandler(NULL);
    
    signal(SIGABRT, SIG_DFL);
    signal(SIGILL, SIG_DFL);
    signal(SIGSEGV, SIG_DFL);
    signal(SIGFPE, SIG_DFL);
    signal(SIGBUS, SIG_DFL);
    signal(SIGPIPE, SIG_DFL);
    signal(SIGQUIT, SIG_DFL);
    signal(SIGTRAP, SIG_DFL);
    signal(SIGEMT, SIG_DFL);
    signal(SIGSYS, SIG_DFL);
    signal(SIGALRM, SIG_DFL);
    signal(SIGXCPU, SIG_DFL);
    signal(SIGXFSZ, SIG_DFL);
    
    if ([[exception name] isEqual:GDUncaughtExceptionHandlerSignalExceptionName])
        
    {
        
        kill(getpid(), [[[exception userInfo] objectForKey:GDUncaughtExceptionHandlerSignalKey] intValue]);
        
    }
    else
    {
        
        //[exception raise];
        
    }
    
#endif
}
- (void)alertView:(UIAlertView *)anAlertView clickedButtonAtIndex:(NSInteger)anIndex

{
    
    if (anIndex == 0)
        
    {
        dismissed = YES;
        
    }
    
}
@end
//奔溃信号回调
void SignalHandler(int signal)
{
    NSLog(@"%@",[NSString stringWithFormat:
                 NSLocalizedString(@"Signal %d crash error.", nil),
                 signal]);
	int32_t exceptionCount = OSAtomicIncrement32(&GDUncaughtExceptionCount);
	if (exceptionCount > GDUncaughtExceptionMaximum)
	{
		return;
	}
	
	NSMutableDictionary *userInfo =
    [NSMutableDictionary
     dictionaryWithObject:[NSNumber numberWithInt:signal]
     forKey:GDUncaughtExceptionHandlerSignalKey];
    
	NSArray *callStack = [CinLoggerManager  backtrace];
	[userInfo
     setValue:callStack
     forKey:GDUncaughtExceptionHandlerAddressesKey];
	
    handleRootException([NSException
                         exceptionWithName:GDUncaughtExceptionHandlerSignalExceptionName
                         reason:
                         [NSString stringWithFormat:
                          NSLocalizedString(@"Signal %d was raised.", nil),
                          signal]
                         userInfo:
                         userInfo]);

}
