//
//  UIApplication+Category.h
//  AutoNavi
//
//  Created by GHY on 12-3-5.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIApplication(Category)

- (void)exitApplication;

@end
