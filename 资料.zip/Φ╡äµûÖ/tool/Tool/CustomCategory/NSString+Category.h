//
//  NSString+Category.h
//  AutoNavi
//
//  Created by GHY on 12-3-19.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(Category)
+(NSString*)getFileMD5WithPath:(NSString*)path;
+ (NSString*)chinaFontStringWithCString:(const char *)cString;
-(NSString*)CutFromNSString:(NSString*)Cutstring;
-(NSString*)CutToNSString:(NSString*)Cutstring;
-(NSString*)CutFromNSString:(NSString*)CutFromstring Tostring:(NSString*)CutTostring;
-(NSString *)CutToNSStringBackWard:(NSString *)Cutstring;

- (NSString *) stringFromMD5;

/**
 *	检测字符串标准 ： 汉字、字母、数字、@、&、_
 *
 *	@param	checkStr	要检测字符串
 *
 *	@return	符合标准返回yes 不符合标准 返回no
 */
+ (BOOL) checkStringStandardWith:(NSString *)checkStr;

/**
 *	检测电话号码标准 ：数字、-、和“、”
 *
 *	@param	checkPhone	要检测电话字符串
 *
 *	@return	符合标准返回yes 不符合标准 返回no
 */
+ (BOOL) checkPhoneStandardWith:(NSString *)checkPhone;
@end
