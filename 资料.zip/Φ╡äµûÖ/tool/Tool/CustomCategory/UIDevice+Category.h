//
//  UIDevice+Category.h
//  AutoNavi
//
//  Created by yu.liao on 13-9-5.
//
//

#import <UIKit/UIKit.h>

enum {
    
    
    UIDevice_iPhoneStandardRes      = 1,  // iPhone 1,3,3GS 标准分辨率(320x480)
    
    UIDevice_iPhoneHiRes            = 2,  // iPhone 4,4S    高清分辨率(640x960)
    
    UIDevice_iPhoneTallerHiRes      = 3,  // iPhone 5,5S    高清分辨率(640x1136)
    
    UIDevice_iPadStandardRes        = 4,  // iPad 1,2,mini  标准分辨率(1024x768)
    
    UIDevice_iPadHiRes              = 5,  // NewPad         高清分辨率(2048x1536)
    
}; typedef NSUInteger UIDeviceResolution;

@interface UIDevice (Category)

- (NSString *) uniqueDeviceIdentifier;

/*!
  @brief 当前设备分辨率类型
  */
+ (UIDeviceResolution) currentResolution;

/*!
  @brief 当前设备分辨率名称（iPhone3,iPhone4,iPhone5,iPad,NewPad）
  */
+ (NSString *) currentResolutionName;

@end
