//
//  NSString+Category.m
//  AutoNavi
//
//  Created by GHY on 12-3-19.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "NSString+Category.h"
#import <CommonCrypto/CommonDigest.h>
#import "RegexKitLite.h"

@implementation NSString(Category)

+ (NSString *)chinaFontStringWithCString:(const char *)cString
{
    if (cString == NULL) {
        return @"";
    }
	NSStringEncoding encode = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    if (strlen(cString) == 0) {
        return @"";
    }
    
    NSString *string = [[[NSString alloc] initWithCString:cString encoding:encode] autorelease];
    
    
    string = [string stringByReplacingOccurrencesOfString:STR(@"Main_NoDefinedRoad", @"Main") withString:STR(@"Main_unNameRoad", @"Main")];
    
    return string;
}

-(NSString*)CutFromNSString:(NSString*)Cutstring
{
	if (self == nil) 
	{
		return nil;
	}
	NSRange range = [self rangeOfString:Cutstring];
	if (range.length == 0) 
	{
		range.location = 0;
		return @"";
	}
	else 
	{
		return [self substringFromIndex:range.location+range.length];
	}	
	
}
-(NSString*)CutToNSString:(NSString*)Cutstring
{
	if (self == nil) 
	{
		return nil;
	}
	NSRange range = [self rangeOfString:Cutstring];
	if (range.length == 0) 
	{
		range.location = 0;
		return @"";
	}
	else 
	{
		return [self substringToIndex:range.location];
	}	
	
}
-(NSString*)CutFromNSString:(NSString*)CutFromstring Tostring:(NSString*)CutTostring
{
	if (self == nil) 
	{
		return nil;
	}
	NSString *temp = [self CutFromNSString:CutFromstring];
	temp = [temp CutToNSString:CutTostring];
	return temp;
    
}
-(NSString *)CutToNSStringBackWard:(NSString *)Cutstring
{
    if (self == nil) 
	{
		return nil;
	}
	NSRange range = [self rangeOfString:Cutstring options:NSBackwardsSearch];
	if (range.length == 0) 
	{
		range.location = 0;
		return @"";
	}
	else 
	{
		return [self substringToIndex:range.location +1];
	}	
}

- (NSString *) stringFromMD5{
    
    if(self == nil || [self length] == 0)
       return [NSString stringWithFormat:@"01234567890123456789012345678901"];
    
    const char *value = [self UTF8String];
    
    unsigned char outputBuffer[CC_MD5_DIGEST_LENGTH];
    CC_MD5(value, strlen(value), outputBuffer);
    
    NSMutableString *outputString = [[NSMutableString alloc] initWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for(NSInteger count = 0; count < CC_MD5_DIGEST_LENGTH; count++){
        [outputString appendFormat:@"%02x",outputBuffer[count]];
    }
    
    return [outputString autorelease];
}

/**
 *	检测字符串标准 ： 汉字、字母、数字、@、&、_
 *
 *	@param	checkStr	要检测字符串
 *
 *	@return	符合标准返回yes 不符合标准 返回no
 */
+ (BOOL) checkStringStandardWith:(NSString *)checkStr
{
    if ([[checkStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length]==0) { return NO; }
    if (![checkStr isMatchedByRegex:@"^[\u4e00-\u9fa5A-Za-z0-9 @&_]+$"])
    {
        return NO;
    }
    return YES;
}

/**
 *	检测电话号码标准 ：数字、-、和“、”
 *
 *	@param	checkPhone	要检测电话字符串
 *
 *	@return	符合标准返回yes 不符合标准 返回no
 */
+ (BOOL) checkPhoneStandardWith:(NSString *)checkPhone
{
    if (![checkPhone isMatchedByRegex:@"^[0-9、;-]+$"])
    {
        return NO;
    }
    return YES;
}

#define FileHashDefaultChunkSizeForReadingData 1024*8

+(NSString*)getFileMD5WithPath:(NSString*)path

{
    
    return (NSString *)FileMD5HashCreateWithPath((__bridge CFStringRef)path,FileHashDefaultChunkSizeForReadingData);
    
}




CFStringRef FileMD5HashCreateWithPath(CFStringRef filePath,size_t chunkSizeForReadingData) {
    
    // Declare needed variables
    
    CFStringRef result = NULL;
    
    CFReadStreamRef readStream = NULL;
    
    // Get the file URL
    
    CFURLRef fileURL =
    
    CFURLCreateWithFileSystemPath(kCFAllocatorDefault,
                                  
                                  (CFStringRef)filePath,
                                  
                                  kCFURLPOSIXPathStyle,
                                  
                                  (Boolean)false);
    
    if (!fileURL) goto done;
    
    // Create and open the read stream
    
    readStream = CFReadStreamCreateWithFile(kCFAllocatorDefault,
                                            
                                            (CFURLRef)fileURL);
    
    if (!readStream) goto done;
    
    bool didSucceed = (bool)CFReadStreamOpen(readStream);
    
    if (!didSucceed) goto done;
    
    // Initialize the hash object
    
    CC_MD5_CTX hashObject;
    
    CC_MD5_Init(&hashObject);
    
    // Make sure chunkSizeForReadingData is valid
    
    if (!chunkSizeForReadingData) {
        
        chunkSizeForReadingData = FileHashDefaultChunkSizeForReadingData;
        
    }
    
    // Feed the data to the hash object
    
    bool hasMoreData = true;
    
    while (hasMoreData) {
        
        uint8_t buffer[chunkSizeForReadingData];
        
        CFIndex readBytesCount = CFReadStreamRead(readStream,(UInt8 *)buffer,(CFIndex)sizeof(buffer));
        
        if (readBytesCount == -1) break;
        
        if (readBytesCount == 0) {
            
            hasMoreData = false;
            
            continue;
            
        }
        
        CC_MD5_Update(&hashObject,(const void *)buffer,(CC_LONG)readBytesCount);
        
    }
    
    // Check if the read operation succeeded
    
    didSucceed = !hasMoreData;
    
    // Compute the hash digest
    
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    
    CC_MD5_Final(digest, &hashObject);
    
    // Abort if the read operation failed
    
    if (!didSucceed) goto done;
    
    // Compute the string result
    
    char hash[2 * sizeof(digest) + 1];
    
    for (size_t i = 0; i < sizeof(digest); ++i) {
        
        snprintf(hash + (2 * i), 3, "%02x", (int)(digest[i]));
        
    }
    
    result = CFStringCreateWithCString(kCFAllocatorDefault,(const char *)hash,kCFStringEncodingUTF8);
    
    
    
done:
    
    if (readStream) {
        
        CFReadStreamClose(readStream);
        
        CFRelease(readStream);
        
    }
    
    if (fileURL) {
        
        CFRelease(fileURL);
        
    }
    
    return result;
    
}

@end
