//
//  UINavigationController+Rotation_IOS6.h
//  AutoNavi
//
//  Created by huang on 13-11-6.
//
//

#import <UIKit/UIKit.h>

@interface UINavigationController (Rotation_IOS6)

@end
