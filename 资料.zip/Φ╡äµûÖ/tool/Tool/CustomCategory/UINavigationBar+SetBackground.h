//
//  UINavigationBar+SetBackground.h
//  AutoNavi
//
//  Created by huang on 13-11-6.
//
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (SetBackground)
-(void)setBackgroundImage:(UIImage *)backgroundImage;
@end
