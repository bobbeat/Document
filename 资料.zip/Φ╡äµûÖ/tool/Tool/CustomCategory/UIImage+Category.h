//
//  UIImage+Category.h
//  AutoNavi
//
//  Created by huang longfeng on 13-3-1.
//
//

#import <UIKit/UIKit.h>
#import "MWTypedef.h"

@interface UIImage (Category)

//获取图片 name:图片名称 imagePathType:图片获取类型(1 从mainbundle中获取 2 区分白天黑夜的bundle)
+ (UIImage *)imageWithName:(NSString *)name pathType:(IMAGEPATHTYPE)imagePathType;

//设置白天黑夜模式
+ (void)setImageDayNightMode:(BOOL)dayNightMode;

//设置皮肤类型：NO 默认 YES 指定皮肤
+ (void)setImageSkinType:(BOOL)skinType SkinPath:(NSString *)skinPath;
@end
