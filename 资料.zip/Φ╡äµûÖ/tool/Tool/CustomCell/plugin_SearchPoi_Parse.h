//
//  plugin_SearchPoi_Parse.h
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin_PoiNode.h"

@interface plugin_SearchPoi_Parse : NSObject {
    NSMutableArray *result;
	
	NSMutableString *currentProperty;
	plugin_PoiNode *poiNode;
}

- (id)initWitharray:(NSMutableArray *)parray;
- (BOOL)parser:(NSData *)data;
@end
