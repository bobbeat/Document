//
//  FileItemTableCell.m
//  autonavi
//
//  Created by hlf on 11-11-9.
//  Copyright 2011 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AroundCustomCell : UITableViewCell
{
	
}

@end
