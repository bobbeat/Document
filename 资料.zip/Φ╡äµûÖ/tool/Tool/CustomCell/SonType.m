
//
//  Quotation.h
//  AutoNavi
//
//  Created by huang longfeng on 12-7-3.
//  Copyright 2011 autonavi. All rights reserved.
//
#import "SonType.h"


@implementation SonType

@synthesize name,checked;
+ (SonType*) sonType
{
	return [[self alloc] init];
}
- (void)dealloc {
    [name release];
    
    [super dealloc];
}

@end
