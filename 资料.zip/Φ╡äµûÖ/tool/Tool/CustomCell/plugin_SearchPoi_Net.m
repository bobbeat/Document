//
//  plugin_SearchPoi_net.m
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import "plugin_SearchPoi_Net.h"
#import "plugin_SearchPoi_Parse.h"
#import "plugin_PoiNode.h"

static plugin_SearchPoi_Net *sharedSearchPoiOperateManager = nil;

@implementation plugin_SearchPoi_Net

@synthesize delegate;

+(plugin_SearchPoi_Net *)sharedInstance
{
	if (sharedSearchPoiOperateManager == nil) 
	{
		sharedSearchPoiOperateManager = [[plugin_SearchPoi_Net alloc] init];
	}
	
	return sharedSearchPoiOperateManager;
}
- (id)init
{
    self = [super init];
    if(self!=nil)
    {
        poiList = [[NSMutableArray alloc] init];
		
    }
	
    return self;
}


/**********************************************************************
 * 函数名称: SearchPOI_Net
 * 功能描述: 网络搜索poi
 * 输入参数:  (int)searchType（搜索类型）：0－正常 1－周边搜索
 * 输出参数: 
 * 返 回 值: 
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(void)SearchPOI_Net:(int)searchType
{
	NSString *url = [NSString stringWithFormat:@"%@"];//填充url
	if (myconnection) 
	{
		[myconnection release];
		myconnection = nil;
	}
	
	myconnection = [[plugin_SearchPoi_Connection alloc] initWithString:url];
	myconnection.delegate = self;
	[myconnection setConnection];
}

/**********************************************************************
 * 函数名称: localPOIList
 * 功能描述: 返回poi列表
 * 输入参数: 
 * 输出参数: 
 * 返 回 值: poi列表
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(NSMutableArray *)localPOIList
{
	return [NSMutableArray arrayWithArray:poiList];
}

//通知客户，网络连接完毕
- (void)connectionDidFinishWithData:(NSData *)netData
{
	NSString *string = [[NSString alloc] initWithData:netData  encoding:NSUTF8StringEncoding];
	
	NSString *tmpstr = @"<archive>";
	NSRange range = [string rangeOfString:tmpstr];
	if (range.length) 
	{
		NSString *strdata = [string substringFromIndex:range.location];//去除前面的无关信息
		[strdata retain];
		
		NSData *data = [strdata dataUsingEncoding:NSUTF8StringEncoding];
		[strdata release];
		strdata = nil;
		
		if (contextArray) 
		{
			[contextArray release];
			contextArray = nil;
		}
		contextArray = [[NSMutableArray alloc] init];
		//－－服务器返回解析结果,填充到contextArray
		BOOL result = NO;
		
		if (result) //成功
		{
			for (int i =0; i<[contextArray count]; i++) 
			{
				plugin_PoiNode *tmpnode = [contextArray objectAtIndex:i];
				
				[poiList addObject:tmpnode];
				
			}
			[delegate dataparseDone];//解析成功，委托回调
		}
		else //失败
		{
			[delegate dataparseFail:nil];//解析失败，委托回调
		}
		
	}
	
	[string release];
	string = nil;
}


//通知客户网络连接失败
- (void)connectiondidFailWithError:(NSError *)error
{
	[delegate dataparseFail:nil];
}


@end
