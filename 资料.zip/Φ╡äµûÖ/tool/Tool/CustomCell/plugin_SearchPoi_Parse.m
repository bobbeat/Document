//
//  plugin_SearchPoi_Parse.m
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import "plugin_SearchPoi_Parse.h"


@implementation plugin_SearchPoi_Parse

- (id)initWitharray:(NSMutableArray *)parray
{
	if (self = [super init]) 
	{
		if (parray!=nil) 
		{
			result = parray;
		}
	}
	
	return self;
}


- (BOOL)parser:(NSData *)data
{
	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
    [parser parse]; 
	if ([parser parserError]) 
	{
		UIAlertView *ParseFailedAlert = [[UIAlertView alloc] initWithTitle:@"Xml解析失败" 
																   message:@"xml数据错误" 
																  delegate:nil
														 cancelButtonTitle:@"确定" 
														 otherButtonTitles:nil];
		[ParseFailedAlert show];
		[ParseFailedAlert release];
		return NO;
	}
	
    [parser release];
	return YES;
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict 
{
    if (qName) 
	{
        elementName = qName;
	}
	
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if (currentProperty) 
	{
        [currentProperty appendString:string];
    }
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName 
{
    if (qName) 
	{
        elementName = qName;
    }
	
	
	currentProperty = nil;
}

@end
