//
//  plugin_SearchPoi_net.h
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin_SearchPoi_Connection.h"

@protocol SearchPoi_NetDelegate

- (void)dataparseDone;//通知客户，数据解析完毕
- (void)dataparseFail:(NSError*)error;//通知客户数据解析失败

@end

@class plugin_SearchPoi_Connection;
@class plugin_SearchPoi_Parse;

@interface plugin_SearchPoi_Net : NSObject <SearchPoiConnectionDelegate>{
	
	plugin_SearchPoi_Connection *myconnection;
	plugin_SearchPoi_Parse *myparser;
	
	id<SearchPoi_NetDelegate> delegate;
    NSMutableArray *poiList;
	 NSMutableArray *contextArray;
	
}

@property(nonatomic,assign) id<SearchPoi_NetDelegate> delegate;

+(plugin_SearchPoi_Net *)sharedInstance;

/**********************************************************************
 * 函数名称: SearchPOI_Net
 * 功能描述: 网络搜索poi
 * 输入参数:  (int)searchType（搜索类型）：0－正常 1－周边搜索
 * 输出参数: 
 * 返 回 值: 
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(void)SearchPOI_Net:(int)searchType;

/**********************************************************************
 * 函数名称: localPOIList
 * 功能描述: 返回poi列表
 * 输入参数: 
 * 输出参数: 
 * 返 回 值: poi列表
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(NSMutableArray *)localPOIList;


@end
