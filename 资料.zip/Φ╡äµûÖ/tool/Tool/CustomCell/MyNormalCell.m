//
//  MyNormalCell.m
//  AutoNavi
//
//  Created by huang longfeng on 12-8-10.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "MyNormalCell.h"

@implementation MyNormalCell
+ (Class)layerClass {
    
    return [CAGradientLayer class];
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        static NSMutableArray *colorsCell = nil;
        if (colorsCell == nil) {
            colorsCell = [[NSMutableArray alloc] initWithCapacity:3];
            UIColor *color = nil;
            color = [UIColor colorWithRed:112/255.0 green:112/255.0 blue:112/255.0 alpha:0.3];
            [colorsCell addObject:(id)[color CGColor]];
            color = [UIColor colorWithRed:20/255.0 green:20/255.0  blue:20/255.0  alpha:0.6];
            [colorsCell addObject:(id)[color CGColor]];
            color = [UIColor colorWithRed:20/255.0 green:20/255.0  blue:20/255.0  alpha:0.6];
            [colorsCell addObject:(id)[color CGColor]];
            color = [UIColor colorWithRed:155/255.0 green:155/255.0 blue:155/255.0 alpha:0.6];
            [colorsCell addObject:(id)[color CGColor]];
        }
        [(CAGradientLayer *)self.layer setColors:colorsCell];
        [(CAGradientLayer *)self.layer setLocations:[NSArray arrayWithObjects:[NSNumber numberWithFloat:0.96],[NSNumber numberWithFloat:0.97], [NSNumber numberWithFloat:0.98],[NSNumber numberWithFloat:0.99],  nil]];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
