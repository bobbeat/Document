
//
//  SectionHeaderView.h
//  AutoNavi
//
//  Created by huang longfeng on 11-12-14.
//  Copyright 2011 autonavi. All rights reserved.
//

#import "MySectionHeaderView.h"
#import <QuartzCore/QuartzCore.h>

@implementation MySectionHeaderView


@synthesize titleLabel,sizeLabel, disclosureButton, delegate, section,myImageView;


+ (Class)layerClass {
    
    return [CAGradientLayer class];
}


-(id)initWithFrame:(CGRect)frame title:(NSString*)title size:(NSString*)totalsize section:(NSInteger)sectionNumber delegate:(id <MySectionHeaderViewDelegate>)aDelegate {
    
    self = [super initWithFrame:frame];
    
    if (self != nil) {
        
        // Set up the tap gesture recognizer.
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggleOpen:)];
        [self addGestureRecognizer:tapGesture];
        [tapGesture release];

        delegate = aDelegate;        
        self.userInteractionEnabled = YES;
        
        // Create and configure the title label.
        section = sectionNumber;
        CGRect titleLabelFrame = self.bounds;
        titleLabelFrame.origin.x += 45.0;
        titleLabelFrame.size.width -= 65.0;
        CGRectInset(titleLabelFrame, 0.0, 5.0);
        titleLabel = [[UILabel alloc] initWithFrame:titleLabelFrame];
        titleLabel.text = title;
        titleLabel.font = [UIFont boldSystemFontOfSize:17.0];
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:titleLabel];
		[titleLabel release];
        
		sizeLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.bounds.size.width-147, 8.0, 100.0, 30.0)];
        sizeLabel.text = totalsize;
        sizeLabel.font = [UIFont systemFontOfSize:17.0];
        sizeLabel.textColor = [UIColor blackColor];
        sizeLabel.backgroundColor = [UIColor clearColor];
		 sizeLabel.textAlignment = UITextAlignmentRight;
        [self addSubview:sizeLabel];
        [sizeLabel release];
        
        // Create and configure the disclosure button.
        disclosureButton = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
        disclosureButton.frame = CGRectMake(self.bounds.size.width-32, 10.0, 30.0, 30.0);
		disclosureButton.backgroundColor = [UIColor clearColor];
        [disclosureButton addTarget:self action:@selector(toggleOpen:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:disclosureButton];
        [disclosureButton release];
        
        myImageView = [[UIImageView alloc] initWithFrame:CGRectMake(5.0, (self.bounds.size.height-30.0)/2, 30.0, 30.0)];
        myImageView.backgroundColor = [UIColor clearColor];
        [self addSubview:myImageView];
        [myImageView release];

		
    }
    
    return self;
}

- (void)layoutSubviews
{
	[super layoutSubviews];
	CGRect titleLabelFrame = self.bounds;
    titleLabelFrame.origin.x += 45.0;
    titleLabelFrame.size.width -= 70.0;
	titleLabel.frame = titleLabelFrame;
    
    
    NSString *sysVersion = CurrentSystemVersion;
    static NSMutableArray *colorsCell = nil;
    if (colorsCell == nil) {
        colorsCell = [[NSMutableArray alloc] initWithCapacity:3];
        UIColor *color = nil;
        color = [UIColor colorWithRed:112/255.0 green:112/255.0 blue:112/255.0 alpha:0.3];
        [colorsCell addObject:(id)[color CGColor]];
        color = [UIColor colorWithRed:20/255.0 green:20/255.0  blue:20/255.0  alpha:0.6];
        [colorsCell addObject:(id)[color CGColor]];
        color = [UIColor colorWithRed:20/255.0 green:20/255.0  blue:20/255.0  alpha:0.6];
        [colorsCell addObject:(id)[color CGColor]];
        color = [UIColor colorWithRed:155/255.0 green:155/255.0 blue:155/255.0 alpha:0.6];
        [colorsCell addObject:(id)[color CGColor]];
    }
    [(CAGradientLayer *)self.layer setColors:colorsCell];
    [(CAGradientLayer *)self.layer setLocations:[NSArray arrayWithObjects:[NSNumber numberWithFloat:0.95],[NSNumber numberWithFloat:0.96], [NSNumber numberWithFloat:0.98],[NSNumber numberWithFloat:0.99],  nil]];
    //disclosureButton.frame = CGRectMake(self.bounds.size.width-32, 8.0, 30.0, 30.0);
}
-(IBAction)toggleOpen:(id)sender {
    
    [self toggleOpenWithUserAction:YES];
}


-(void)toggleOpenWithUserAction:(BOOL)userAction {
    
    // Toggle the disclosure button state.
    disclosureButton.selected = !disclosureButton.selected;
    
    // If this was a user action, send the delegate the appropriate message.
    if (userAction) {
        if (disclosureButton.selected) {
			
            if ([delegate respondsToSelector:@selector(sectionHeaderView:sectionOpened:)]) {
                [delegate sectionHeaderView:self sectionOpened:section];
            }
        }
        else {
            if ([delegate respondsToSelector:@selector(sectionHeaderView:sectionClosed:)]) {
                [delegate sectionHeaderView:self sectionClosed:section];
            }
        }
    }
}


- (void)dealloc {
    
    //[titleLabel release];
    
    
    [super dealloc];
}


@end
