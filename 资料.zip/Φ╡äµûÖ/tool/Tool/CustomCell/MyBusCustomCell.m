//
//  MyBusCustomCell.m
//  AutoNavi
//
//  Created by huang longfeng on 12-9-4.
//
//

#import "MyBusCustomCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation MyBusCustomCell

@synthesize labelAddress;

+ (Class)layerClass {
    
    return [CAGradientLayer class];
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
	{
        
		self.textLabel.backgroundColor = [UIColor clearColor];
		self.textLabel.opaque = NO;
		self.textLabel.textColor = [UIColor whiteColor];
		self.textLabel.font = [UIFont boldSystemFontOfSize:20.0];
		
		self.detailTextLabel.textAlignment = UITextAlignmentLeft;
		self.detailTextLabel.font = [UIFont systemFontOfSize:15];
		self.detailTextLabel.backgroundColor = [UIColor clearColor];
        self.detailTextLabel.textColor = [UIColor colorWithRed:180/255.0 green:180/255.0 blue:180/255.0 alpha:1.0];
		
		labelAddress = [[UILabel alloc] init];
		labelAddress.textAlignment = UITextAlignmentLeft;
        labelAddress.backgroundColor = [UIColor clearColor];
		labelAddress.opaque = NO;
		labelAddress.textColor = [UIColor whiteColor];
		labelAddress.font = [UIFont systemFontOfSize:19.0];
		[self.contentView addSubview:labelAddress];
		[labelAddress release];
		
		static NSMutableArray *colorsCell = nil;
        if (colorsCell == nil) {
            colorsCell = [[NSMutableArray alloc] initWithCapacity:3];
            UIColor *color = nil;
            color = [UIColor colorWithRed:112/255.0 green:112/255.0 blue:112/255.0 alpha:0.3];
            [colorsCell addObject:(id)[color CGColor]];
            color = [UIColor colorWithRed:20/255.0 green:20/255.0  blue:20/255.0  alpha:0.6];
            [colorsCell addObject:(id)[color CGColor]];
            color = [UIColor colorWithRed:20/255.0 green:20/255.0  blue:20/255.0  alpha:0.6];
            [colorsCell addObject:(id)[color CGColor]];
            color = [UIColor colorWithRed:155/255.0 green:155/255.0 blue:155/255.0 alpha:0.6];
            [colorsCell addObject:(id)[color CGColor]];
        }
        [(CAGradientLayer *)self.layer setColors:colorsCell];
        [(CAGradientLayer *)self.layer setLocations:[NSArray arrayWithObjects:[NSNumber numberWithFloat:0.96],[NSNumber numberWithFloat:0.97], [NSNumber numberWithFloat:0.98],[NSNumber numberWithFloat:0.99],  nil]];
	}
	return self;
}

- (void)layoutSubviews
{
	[super layoutSubviews];
	
    CGRect contentRect = [self.contentView bounds];
	
//	CGRect frame = CGRectMake(contentRect.origin.x + 10.0, contentRect.size.height/2, contentRect.size.width, 40.0);
//	self.textLabel.frame = frame;
	
    CGRect frame = CGRectMake(contentRect.origin.x + 85.0, 7.0, contentRect.size.width - 95.0, 20.0);
	labelAddress.frame = frame;
	
	frame = CGRectMake(contentRect.origin.x +85.0, 30.0, contentRect.size.width - (contentRect.origin.x + 100.0), 20.0);
	self.detailTextLabel.frame = frame;
	
}

- (void)dealloc
{
    
    [super dealloc];
}
@end
