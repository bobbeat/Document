//
//  MyLabelCell.h
//  AutoNavi
//
//  Created by GHY on 11-9-27.
//  Copyright 2011 Nat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyLabelCell : UITableViewCell 
{
	CGRect  m_rcImageView;
    BOOL    m_bResetImageViewFrame;
    CGRect  m_rcTitle;
    BOOL    m_bResetTitleFrame;
}

- (void)setlabel:(NSString*)tex;
/*
 Function: reset the frame of imageview
 */
- (void)setImageViewRect:(CGRect)rcRect;
/*
 Function: reset the frame of title
 */
- (void)setTitleRect:(CGRect)rcRect;
/*
 Function: reset the frame of subview, the original set is disabled
 */
- (void)resetCustomSetFrame;
@end
