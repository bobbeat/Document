//
//  Quotation.h
//  AutoNavi－sj
//
//  Created by huang longfeng on 12-7-3.
//  Copyright 2011 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SonType : NSObject {

}

@property (nonatomic, retain) NSString *name;

@property (nonatomic, assign)	BOOL			checked;

+ (SonType*) sonType;
@end
