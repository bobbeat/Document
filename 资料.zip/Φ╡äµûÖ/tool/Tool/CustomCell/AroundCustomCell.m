//
//  FileItemTableCell.m
//  autonavi
//
//  Created by hlf on 11-11-9.
//  Copyright 2011 autonavi. All rights reserved.
//

#import "AroundCustomCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation AroundCustomCell

+ (Class)layerClass {
    
    return [CAGradientLayer class];
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
	{   
//        static NSMutableArray *colors = nil;
//		if (colors == nil) {
//			colors = [[NSMutableArray alloc] initWithCapacity:3];
//			UIColor *color = nil;
//			color = [UIColor colorWithRed:0.265 green:0.265 blue:0.265 alpha:0.9];
//			[colors addObject:(id)[color CGColor]];
//			color = [UIColor colorWithRed:0.43 green:0.43 blue:0.43 alpha:1.0];
//			[colors addObject:(id)[color CGColor]];
//			color = [UIColor colorWithRed:0.197 green:0.197 blue:0.197 alpha:1.0];
//			[colors addObject:(id)[color CGColor]];
//		}
//		[(CAGradientLayer *)self.layer setColors:colors];
//		[(CAGradientLayer *)self.layer setLocations:[NSArray arrayWithObjects:[NSNumber numberWithFloat:0.96], [NSNumber numberWithFloat:0.0], [NSNumber numberWithFloat:0.04], nil]];
		
	}
	return self;
}
- (void)layoutSubviews
{
	[super layoutSubviews];
	self.backgroundColor = [UIColor clearColor];
    static NSMutableArray *colors = nil;
    if (colors == nil) {
        colors = [[NSMutableArray alloc] initWithCapacity:2];
        UIColor *color = nil;
        color = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.5];
        [colors addObject:(id)[color CGColor]];
        color = [UIColor colorWithRed:54/255.0 green:54/255.0 blue:54/255.0 alpha:1.0];
        [colors addObject:(id)[color CGColor]];
    }
    [(CAGradientLayer *)self.layer setColors:colors];
    [(CAGradientLayer *)self.layer setLocations:[NSArray arrayWithObjects:[NSNumber numberWithFloat:0.98],[NSNumber numberWithFloat:0.99], nil]];
//    [(CAGradientLayer *)self.layer setColors:colors];
//    [(CAGradientLayer *)self.layer setLocations:[NSArray arrayWithObjects:[NSNumber numberWithFloat:0.96], [NSNumber numberWithFloat:0.0], [NSNumber numberWithFloat:0.04], nil]];
    
}

- (void)dealloc 
{
    [super dealloc];
}


@end
