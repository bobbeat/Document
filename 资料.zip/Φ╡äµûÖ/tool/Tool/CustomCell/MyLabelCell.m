//
//  MyLabelCell.m
//  AutoNavi
//
//  Created by GHY on 11-9-27.
//  Copyright 2011 Nat. All rights reserved.
//

#import "MyLabelCell.h"


@implementation MyLabelCell


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier 
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) 
	{
        self.detailTextLabel.textAlignment = UITextAlignmentRight;
        self.detailTextLabel.textColor = [UIColor blueColor];//[UIColor colorWithRed:0.7922f green:0.6745f blue:0.3020f alpha:1.0f];
        self.detailTextLabel.font = [UIFont systemFontOfSize:kSize2];
        self.detailTextLabel.backgroundColor = [UIColor clearColor];
        m_bResetImageViewFrame = NO;
        m_bResetTitleFrame = NO;
	
    }
	
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    
    CGRect contentRect = [self.contentView bounds];
	
//	CGRect frame = CGRectMake(contentRect.origin.x , contentRect.size.height/2, contentRect.size.width,contentRect.size.height);
//	self.detailTextLabel.frame = frame;
    //
    if (m_bResetImageViewFrame) {
//        self.imageView.frame = m_rcImageView;
    }
    //
    if (m_bResetTitleFrame) {
        self.textLabel.frame = m_rcTitle;
    }

}

- (void)setlabel:(NSString*)tex
{
	self.detailTextLabel.text = tex;
}


- (void)dealloc 
{
    [super dealloc];
}
/*
 Function: reset the frame of imageview
 */
- (void)setImageViewRect:(CGRect)rcRect
{
    m_bResetImageViewFrame = YES;
    m_rcImageView = rcRect;
}
/*
 Function: reset the frame of title
 */
- (void)setTitleRect:(CGRect)rcRect
{
    m_bResetTitleFrame = YES;
    m_rcTitle = rcRect;
}
/*
 Function: reset the frame of subview, the original set is disabled
 */
- (void)resetCustomSetFrame
{
    m_bResetTitleFrame = NO;
    m_bResetImageViewFrame = NO;
}
@end
