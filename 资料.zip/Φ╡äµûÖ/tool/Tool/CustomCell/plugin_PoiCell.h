//
// plugin_PoiCell.m
//  autonavi
//
//  Created by hlf on 11-11-9.
//  Copyright 2011 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KeyWordLable.h"

@interface plugin_PoiCell : UITableViewCell
{
	
	KeyWordLable *labelAddress;
	UIProgressView	*progressBar;
	KeyWordLable *m_nameLable;
}

@property (nonatomic, retain) KeyWordLable *labelAddress;
@property (nonatomic, retain) KeyWordLable *m_nameLable;

@end
