
//
//  SectionHeaderView.h
//  AutoNavi
//
//  Created by huang longfeng on 11-12-14.
//  Copyright 2011 autonavi. All rights reserved.
//
#import <Foundation/Foundation.h>

@protocol MySectionHeaderViewDelegate;


@interface MySectionHeaderView : UIView {
}

@property (nonatomic, retain) UILabel *titleLabel;
@property (nonatomic, retain) UILabel *sizeLabel;
@property (nonatomic, retain) UIButton *disclosureButton;
@property (nonatomic, retain) UIImageView *myImageView;
@property (nonatomic, assign) NSInteger section;
@property (nonatomic, assign) id <MySectionHeaderViewDelegate> delegate;

-(id)initWithFrame:(CGRect)frame title:(NSString*)title size:(NSString*)totalsize section:(NSInteger)sectionNumber delegate:(id <MySectionHeaderViewDelegate>)aDelegate;
-(void)toggleOpenWithUserAction:(BOOL)userAction;

@end


@protocol MySectionHeaderViewDelegate <NSObject>

@optional
-(void)sectionHeaderView:(MySectionHeaderView*)sectionHeaderView sectionOpened:(NSInteger)section;
-(void)sectionHeaderView:(MySectionHeaderView*)sectionHeaderView sectionClosed:(NSInteger)section;

@end

