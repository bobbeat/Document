//
//  MyBusCustomCell.h
//  AutoNavi
//
//  Created by huang longfeng on 12-9-4.
//
//

#import <UIKit/UIKit.h>

@interface MyBusCustomCell : UITableViewCell
{
	UILabel *labelAddress;
}

@property (nonatomic, retain) UILabel *labelAddress;


@end
