//
//  CustomCell.m
//  autonavi
//
//  Created by hlf on 11-11-9.
//  Copyright 2011 autonavi. All rights reserved.
//

#import "plugin_PoiCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation plugin_PoiCell

@synthesize labelAddress;
@synthesize m_nameLable;

+ (Class)layerClass {
    
    return [CAGradientLayer class];
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
	{   
        self.textLabel.hidden = YES;
        m_nameLable = [[KeyWordLable alloc] init];
		m_nameLable.backgroundColor = [UIColor clearColor];
		m_nameLable.opaque = NO;
		m_nameLable.textColor = TEXTCOLOR;
        m_nameLable.font=[UIFont systemFontOfSize:kSize2];

		[self.contentView addSubview:m_nameLable];
		[m_nameLable release];
        
		self.detailTextLabel.textAlignment = UITextAlignmentLeft;
		self.detailTextLabel.font = [UIFont systemFontOfSize:kSize5];
		self.detailTextLabel.backgroundColor = [UIColor clearColor];
        self.detailTextLabel.textColor=TEXTCOLOR;
//
		labelAddress = [[KeyWordLable alloc] initWithType:Address_Lable];
		labelAddress.textAlignment = UITextAlignmentLeft;
        labelAddress.backgroundColor = [UIColor clearColor];
		labelAddress.opaque = NO;
        labelAddress.textColor=TEXTDETAILCOLOR;
        labelAddress.font=[UIFont systemFontOfSize:kSize5];


		[self.contentView addSubview:labelAddress];
		[labelAddress release];
		
//		static NSMutableArray *colorsCell = nil;
//        if (colorsCell == nil) {
//            colorsCell = [[NSMutableArray alloc] initWithCapacity:3];
//            UIColor *color = nil;
//            color = [UIColor colorWithRed:112/255.0 green:112/255.0 blue:112/255.0 alpha:0.3];
//            [colorsCell addObject:(id)[color CGColor]];
//            color = [UIColor colorWithRed:20/255.0 green:20/255.0  blue:20/255.0  alpha:0.6];
//            [colorsCell addObject:(id)[color CGColor]];
//            color = [UIColor colorWithRed:20/255.0 green:20/255.0  blue:20/255.0  alpha:0.6];
//            [colorsCell addObject:(id)[color CGColor]];
//            color = [UIColor colorWithRed:155/255.0 green:155/255.0 blue:155/255.0 alpha:0.6];
//            [colorsCell addObject:(id)[color CGColor]];
//        }
//        [(CAGradientLayer *)self.layer setColors:colorsCell];
//        [(CAGradientLayer *)self.layer setLocations:[NSArray arrayWithObjects:[NSNumber numberWithFloat:0.96],[NSNumber numberWithFloat:0.97], [NSNumber numberWithFloat:0.98],[NSNumber numberWithFloat:0.99],  nil]];
	}
	return self;
}

- (void)layoutSubviews
{
	[super layoutSubviews];
    CGRect contentRect = [self.contentView bounds];
	CGRect frame = CGRectMake(contentRect.origin.x + 10.0, 1.0, contentRect.size.width - 20, contentRect.size.height);
	self.m_nameLable.frame = frame;
	 frame = CGRectMake(contentRect.origin.x +10.0, 42.0, contentRect.size.width-90.0, 20.0);
	labelAddress.frame = frame;
	frame = CGRectMake(contentRect.size.width-75.0, 42.0, contentRect.size.width-175.0, 20.0);
	self.detailTextLabel.frame = frame;
	
}

- (void)dealloc
{
    [super dealloc];
}


@end
