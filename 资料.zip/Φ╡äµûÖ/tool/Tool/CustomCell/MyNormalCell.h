//
//  MyNormalCell.h
//  AutoNavi
//
//  Created by huang longfeng on 12-8-10.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNormalCell : UITableViewCell

@end
