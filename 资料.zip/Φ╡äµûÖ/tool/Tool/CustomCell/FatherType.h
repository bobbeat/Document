
//
//  play.h
//  AutoNavi
//
//  Created by huang longfeng on 12-7-3.
//  Copyright 2011 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FatherType : NSObject {

}

@property (nonatomic, retain) NSString *name;

@property (nonatomic, retain) NSMutableArray *quotations;

@end
