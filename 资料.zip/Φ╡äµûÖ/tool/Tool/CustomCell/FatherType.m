
//
//  play.h
//  AutoNavi
//
//  Created by huang longfeng on 12-7-3.
//  Copyright 2011 autonavi. All rights reserved.
//

#import "FatherType.h"


@implementation FatherType

@synthesize name, quotations;

- (void)dealloc {
    [name release];
	
    [quotations release];
    [super dealloc];
}

@end
