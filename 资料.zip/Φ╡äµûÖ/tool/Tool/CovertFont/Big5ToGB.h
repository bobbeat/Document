//
//  Big5ToGB.h
//  AutoNavi
//
//  Created by xiaolong.zeng on 11-3-29.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface Big5ToGB : NSObject {
	unsigned char tbl[30000];

}
- (BOOL)readConvertedTbl;
- (NSString *)big5ToGB:(NSString *)big5;

@end
