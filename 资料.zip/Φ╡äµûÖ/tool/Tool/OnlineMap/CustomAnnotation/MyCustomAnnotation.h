//
//  MyCustomAnnotation.h
//  MyMapDemo
//
//  Created by gaozhimin on 13-3-4.
//  Copyright (c) 2013年 autonavi. All rights reserved.
//

#import <CoreLocation/CLLocation.h>
#import "MAPointAnnotation.h"
#import "Plugin_OnLineStruct.h"
#import "MWSearchResult.h"

enum
{
    Annotation_Start_Point = 1,
    Annotation_End_Point,
    Annotation_PassBy_Point,
    Annotation_POI_Point,
    Annotation_Car_Point,
    Annotation_ClickImage_Point,
    Annotation_ClickPoi
};
typedef NSInteger AnnotationType;


@interface MyCustomAnnotation : MAPointAnnotation
{
    AnnotationType m_annotationType;
    UIImage* m_clickImage;
}

@property (nonatomic,assign) AnnotationType m_annotationType;
@property (nonatomic,assign) int m_tag;
@property (nonatomic,assign) id<OnLineMapClickImageDelegate> m_onLineMapClickImageDelegate;
@property (nonatomic,retain) UIImage* m_clickImage;
@property (nonatomic,retain) MWPoi *poiInfo;

//@property (nonatomic, assign) CLLocationCoordinate2D coordinate;

- (id)initWithType:(AnnotationType)annotationType;

@end
