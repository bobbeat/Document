//
//  MyCustomAnnotation.m
//  MyMapDemo
//
//  Created by gaozhimin on 13-3-4.
//  Copyright (c) 2013年 autonavi. All rights reserved.
//

#import "MyCustomAnnotation.h"

@implementation MyCustomAnnotation

@synthesize m_annotationType,m_tag,m_onLineMapClickImageDelegate,m_clickImage,poiInfo;

- (id)initWithType:(AnnotationType)annotationType
{
    self = [super init];
    if (self)
    {
        m_annotationType = annotationType;
    }
    return self;
}

- (void)dealloc
{
    self.poiInfo = nil;
    if (m_clickImage)
    {
        [m_clickImage release];
        m_clickImage = nil;
    }
    [super dealloc];
}

@end
