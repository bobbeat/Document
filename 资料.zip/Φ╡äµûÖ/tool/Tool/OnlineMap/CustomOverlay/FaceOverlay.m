//
//  FaceOverlay.m
//  CustomOverlayViewDemo
//
//  Created by songjian on 13-3-12.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import "FaceOverlay.h"

@interface FaceOverlay ()

@property (nonatomic, readwrite) CLLocationCoordinate2D *m_coords;
@property (nonatomic, readwrite) NSUInteger m_count;
@property (nonatomic, readwrite) MAMapRect boundingMapRect;
@end

@implementation FaceOverlay 

@synthesize m_coords = _m_coords;
@synthesize m_count = _m_count;
@synthesize m_drawLineType;
@synthesize boundingMapRect = _boundingMapRect;
#pragma mark - Utility

- (void)dealloc
{
    if (_m_count)
    {
        free(_m_coords);
        _m_coords = NULL;
    }
    [super dealloc];
}


#pragma mark - Static Methods


+ (id)faceWithhCoordinates:(CLLocationCoordinate2D *)coords count:(NSUInteger)count
{
    FaceOverlay *faceOverlay = [[self alloc] init];
    faceOverlay.m_coords = (CLLocationCoordinate2D *)malloc(sizeof(CLLocationCoordinate2D) * count);
    memset(faceOverlay.m_coords,0,count);
    faceOverlay.m_count = count;
    for (int i = 0; i < count; i++)
    {
        faceOverlay.m_coords[i].latitude = coords[i].latitude;
        faceOverlay.m_coords[i].longitude = coords[i].longitude;
    }
    
    return faceOverlay;
}


@end
