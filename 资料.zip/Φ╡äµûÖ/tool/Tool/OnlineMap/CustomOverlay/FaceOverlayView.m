//
//  FaceOverlayView.m
//  CustomOverlayViewDemo
//
//  Created by songjian on 13-3-12.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import "FaceOverlayView.h"
#import "GLESRenderUtility.h"

@implementation FaceOverlayView

#pragma mark - Utility

- (void)drawCicleWithCenterCoordinate:(CLLocationCoordinate2D)centerCoordinate radius:(CLLocationDistance)radius
{
    /* Drawing Circle with OpenGLES. */
//    CGFloat hypotenuse = MAMapPointsPerMeter() * radius;
//    MAMapPoint centerMapPoint = MAMapPointForCoordinate(centerCoordinate);
//    
//#define INCISION_PRECISION 360
//    MAMapPoint *points = (MAMapPoint*)malloc(INCISION_PRECISION * sizeof(MAMapPoint));
//    for (int i = 0; i < INCISION_PRECISION; i++)
//    {
//        CGFloat radian  = i * M_PI / 180.f;
//        CGFloat xOffset = sin(radian) * hypotenuse;
//        CGFloat yOffset = cos(radian) * hypotenuse;
//        
//        points[i].x = centerMapPoint.x + xOffset;
//        points[i].y = centerMapPoint.y + yOffset;
//    }
//    
//    CGPoint *glPoints = [self glPointsForMapPoints:points count:INCISION_PRECISION];
//    
//    [GLESRenderUtility drawPolygon:glPoints
//                             count:INCISION_PRECISION
//                       strokeColor:self.strokeColor
//                         lineWidth:[self lineWidth]
//                         fillColor:self.fillColor];
//    
//    free(points), points = NULL;
//    free(glPoints), glPoints = NULL;
}

- (void)drawLineFrom:(CLLocationCoordinate2D)from to:(CLLocationCoordinate2D)to
{
    MAMapPoint mapPoint[2];
    mapPoint[0] = MAMapPointForCoordinate(from);
    mapPoint[1] = MAMapPointForCoordinate(to);
    
    CGPoint *glPoints = [self glPointsForMapPoints:mapPoint count:2];
    
    [GLESRenderUtility drawPolyline:glPoints
                              count:2
                              color:self.strokeColor
                          lineWidth:[self lineWidth]];
    
    free(glPoints), glPoints = NULL;
}

- (void)drawLineWithCoors:(CLLocationCoordinate2D*)coors Count:(NSUInteger)count
{
    MAMapPoint mapPoint[count];
    for (int i = 0; i < count; i++)
    {
        mapPoint[i] = MAMapPointForCoordinate(coors[i]);
    }
    
    CGPoint *glPoints = [self glPointsForMapPoints:mapPoint count:count];
    
    [GLESRenderUtility drawPolyline:glPoints
                              count:count
                              color:self.strokeColor
                          lineWidth:[self lineWidth]];
    
    free(glPoints), glPoints = NULL;
}

#pragma mark - Interface

- (FaceOverlay *)faceOverlay
{
    return (FaceOverlay*)self.overlay;
}

#pragma mark - Override

- (void)glRender
{
    FaceOverlay *faceOverlay = [self faceOverlay];
    if (faceOverlay.m_drawLineType == Guide_Line)
    {
        [self drawLineWithCoors:faceOverlay.m_coords Count:faceOverlay.m_count];
        return;
    }
    [self drawLineWithCoors:faceOverlay.m_coords Count:faceOverlay.m_count];
}

- (void)renderLinesWithPoints:(CGPoint *)points pointCount:(NSUInteger)pointCount strokeColor:(UIColor *)strokeColor lineWidth:(CGFloat)lineWidth looped:(BOOL)looped
{
    printf("111");
}

#pragma mark - Life Cycle

- (id)initWithFaceOverlay:(FaceOverlay *)faceOverlay;
{
    self = [super initWithOverlay:faceOverlay];
    if (self)
    {
        
    }
    
    return self;
}

@end
