//
//  FaceOverlay.h
//  CustomOverlayViewDemo
//
//  Created by songjian on 13-3-12.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import "MAMapKit.h"

typedef enum
{
    Route_Line = 1,
    Guide_Line
}DrawLineType;


@interface FaceOverlay : MAShape<MAOverlay>
{
    DrawLineType m_drawLineType;
    MAMapRect _boundingMapRect;
}


+ (id)faceWithhCoordinates:(CLLocationCoordinate2D *)coords count:(NSUInteger)count;

@property (nonatomic, readonly) CLLocationCoordinate2D *m_coords;
@property (nonatomic, readonly) NSUInteger m_count;
@property (nonatomic, assign) DrawLineType m_drawLineType;
@property (nonatomic, readonly) MAMapRect boundingMapRect;
@end
