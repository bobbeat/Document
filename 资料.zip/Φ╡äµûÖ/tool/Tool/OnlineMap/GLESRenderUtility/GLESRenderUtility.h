//
//  GLESRenderUtility.h
//  MAMapKitDemo
//
//  Created by songjian on 12-12-28.
//  Copyright (c) 2012年 songjian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#import <UIKit/UIKit.h>

typedef enum{
    
    GLESRenderUtilityType_Line_Loop   = GL_LINE_LOOP,
    GLESRenderUtilityType_Line_Strip  = GL_LINE_STRIP,
    GLESRenderUtilityType_Trangle_Fan = GL_TRIANGLE_FAN,
    
}GLESRenderUtilityType;

@interface GLESRenderUtility : NSObject

+ (void)drawType:(GLESRenderUtilityType)type
      linePoints:(CGPoint *)linePoints
           count:(NSUInteger)count
           color:(UIColor *)color
       lineWidth:(CGFloat)lineWidth;

+ (void)drawPolyline:(CGPoint *)linePoints
               count:(NSUInteger)count
               color:(UIColor *)color
           lineWidth:(CGFloat)lineWidth;

+ (void)drawPolygon:(CGPoint *)linePoints
              count:(NSUInteger)count
        strokeColor:(UIColor *)strokeColor
          lineWidth:(CGFloat)lineWidth
          fillColor:(UIColor *)fillColor;

@end
