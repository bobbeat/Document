//
//  GLESRenderUtility.m
//  MAMapKitDemo
//
//  Created by songjian on 12-12-28.
//  Copyright (c) 2012年 songjian. All rights reserved.
//

#import "GLESRenderUtility.h"

@implementation GLESRenderUtility

+ (void)drawType:(GLESRenderUtilityType)type linePoints:(CGPoint *)linePoints count:(NSUInteger)count color:(UIColor *)color lineWidth:(CGFloat)lineWidth;
{
    /* Add by sijiu. */
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    GLfloat *points = (GLfloat*)malloc(sizeof(GLfloat) * 3 * count);
    for (int i = 0; i < count; i++)
    {
        points[i*3]   = linePoints[i].x;
        points[i*3+1] = linePoints[i].y;
        points[i*3+2] = 0.0f;
    }
    
	glDisable(GL_TEXTURE_2D);
	glEnableClientState(GL_VERTEX_ARRAY);
    
    /* Line Width. */
    glLineWidth(lineWidth);
    
    /* Stroke Color. */
    const CGFloat *component = CGColorGetComponents(color.CGColor);
    glColor4f(component[0], component[1], component[2], component[3]);
    
	glVertexPointer(3, GL_FLOAT, 0, points);
    
    /* Type. */
	glDrawArrays(type ,0 ,count);
    
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    
    free(points), points = NULL;
}

+ (void)drawPolyline:(CGPoint *)linePoints count:(NSUInteger)count color:(UIColor *)color lineWidth:(CGFloat)lineWidth
{
    [self drawType:GLESRenderUtilityType_Line_Strip linePoints:linePoints count:count color:color lineWidth:lineWidth];
}

+ (void)drawPolygon:(CGPoint *)linePoints count:(NSUInteger)count strokeColor:(UIColor *)strokeColor lineWidth:(CGFloat)lineWidth fillColor:(UIColor *)fillColor
{
    [self drawType:GLESRenderUtilityType_Trangle_Fan linePoints:linePoints count:count color:fillColor lineWidth:lineWidth];
    
    [self drawType:GLESRenderUtilityType_Line_Loop linePoints:linePoints count:count color:strokeColor lineWidth:lineWidth];
}

@end
