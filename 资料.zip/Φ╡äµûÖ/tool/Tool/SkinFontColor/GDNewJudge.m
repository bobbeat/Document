//
//  GDNewJudge.m
//  AutoNavi
//
//  Created by jiangshu-fu on 14-1-7.
//
//

#import "GDNewJudge.h"


@implementation GDNewJudge

#define NEW_JUDGE_PATH [NSHomeDirectory() stringByAppendingString:@"/Documents/Skin/newJudge.plist"]
#define ID_KEY @"id"

+ (GDNewJudge *) sharedInstance
{
    static GDNewJudge *gdNewJudge = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gdNewJudge = [[GDNewJudge alloc] init];
    });
	return gdNewJudge;
}

- (id) init
{
    self = [super init];
    if (self) {
        if([[NSFileManager defaultManager] fileExistsAtPath:NEW_JUDGE_PATH])
        {
            _dictionary = [[NSMutableDictionary alloc] initWithContentsOfFile:NEW_JUDGE_PATH];
        }
        else
        {
            _dictionary = [[NSMutableDictionary alloc] init];
            [_dictionary setObject:[[NSMutableDictionary alloc]init]
                            forKey:[NSString stringWithFormat:@"%d",NEW_JUDGE_SKIN_TYPE]];
            [_dictionary setObject:[[NSMutableDictionary alloc]init]
                            forKey:[NSString stringWithFormat:@"%d",NEW_JUDGE_CAR_TYPE]];
            //更具类型，添加默认显示new的值
            [self addObjectWithType:NEW_JUDGE_SKIN_TYPE withArray:[NSArray arrayWithObjects:@"3", nil]];
//            [self addObjectWithType:NEW_JUDGE_CAR_TYPE withArray:[NSArray arrayWithObjects:@"2", nil]];
            //设置皮肤的设置内容
            if([self isAppearNewWithType:NEW_JUDGE_SKIN_TYPE])
            {
                [[MWPreference sharedInstance] setValue:PREF_IS_FIRSTENTERSKIN Value:1];
            }
            BOOL returnbool = [_dictionary writeToFile:NEW_JUDGE_PATH atomically:YES];
            NSLog(@"%d",returnbool);
        }
    }
    return self;
}

#pragma mark ---  处理是否显示new的函数  ---
/***
 * @name    添加服务器下发的新id
 * @param   type - 下发的是皮肤还是车主的id   addArray - 下发的数组
 * @author  by bazinga
 ***/
- (void) addObjectWithType:(NEW_JUDGE_TYPE)type withArray:(NSArray *)addArray
{
    NSMutableDictionary *dict = [_dictionary objectForKey:[NSString stringWithFormat:@"%d",type]];
    if(dict != nil)
    {
        for (int i = 0; i < addArray.count; i ++) {
            NSString *tempKey =  [NSString stringWithFormat:@"%d",[[addArray objectAtIndex:i] intValue]];
            if(![dict objectForKey:tempKey])
            {
                NSDictionary *tempDict = [NSDictionary dictionaryWithObjectsAndKeys:
                                          [NSNumber numberWithBool:YES],JUDGE_MAIN_KEY,
                                           [NSNumber numberWithBool:YES],JUDGE_ID_KEY,nil];
                [dict setObject:tempDict forKey:tempKey];
            }
        }
        [_dictionary setObject:dict forKey:[NSString stringWithFormat:@"%d",type]];
    }
    [self save];
}

/***
 * @name    删除字典中的所有对象（即还原）
 * @param   
 * @author  by bazinga
 ***/
- (void) deleteAll
{
    [_dictionary removeAllObjects];
    [_dictionary setObject:[[NSMutableDictionary alloc]init] forKey:[NSString stringWithFormat:@"%d",NEW_JUDGE_SKIN_TYPE]];
    [_dictionary setObject:[[NSMutableDictionary alloc]init] forKey:[NSString stringWithFormat:@"%d",NEW_JUDGE_CAR_TYPE]];
}

/***
 * @name    将字典保存到文件中去
 * @param
 * @author  by bazinga
 ***/
- (void) save
{
    [_dictionary writeToFile:NEW_JUDGE_PATH atomically:YES];
}

/***
 * @name    通过key和类型，设置字典对应key值的值
 * @param   key - 就是所设置的id值
 * @param   type - 是车主服务还是皮肤类型
 * @author  by bazinga
 ***/
- (void) setNoForKey:(NSString *)key withType:(NEW_JUDGE_TYPE)type
{
    NSMutableDictionary *dict = [_dictionary objectForKey:[NSString stringWithFormat:@"%d",type]];
    NSMutableDictionary *secDict = [NSMutableDictionary dictionaryWithDictionary: [dict objectForKey:key]];
    if(dict != nil && secDict != nil)
    {
        [secDict  setObject:[NSNumber numberWithBool:NO] forKey:JUDGE_ID_KEY];
        
        [dict setObject:secDict forKey:key];
    
        [_dictionary setObject:dict forKey:[NSString stringWithFormat:@"%d",type]];
    }
    [self save];
}


/***
 * @name    根据类型，返回是否需要显示new图标
 * @param   type - 类型
 * @author  by bazinga
 ***/
- (BOOL) isAppearNewWithType:(NEW_JUDGE_TYPE)type
{
    BOOL returnBool = NO;
    NSMutableDictionary *dict = [_dictionary objectForKey:[NSString stringWithFormat:@"%d",type]];
    NSArray *keys = [dict allKeys];
    for (id key in  keys)
    {
       if([[[dict objectForKey:key] objectForKey:JUDGE_MAIN_KEY] boolValue])
       {
           returnBool = YES;
           break;
       }
    }
    return returnBool;
}

/***
 * @name    根据类型，隐藏new图标
 * @param   type - 类型
 * @author  by bazinga
 ***/
- (void) setHiddenNewByKey:(NEW_JUDGE_TYPE)type
{
    NSMutableDictionary *dict = [_dictionary objectForKey:[NSString stringWithFormat:@"%d",type]];
    if(dict != nil)
    {
        NSArray *keys = [dict allKeys];
        for (id key in  keys)
        {
            NSMutableDictionary *keyDict = [NSMutableDictionary dictionaryWithDictionary:[dict objectForKey:key]];
            if(keyDict != nil)
            {
                [keyDict setObject:[NSNumber numberWithBool:NO] forKey:JUDGE_MAIN_KEY];
                [dict setObject:keyDict forKey:key];
            }
        }
        [_dictionary setObject:dict forKey:[NSString stringWithFormat:@"%d",type]];
        [self save];
    }
}

/***
 * @name    根据类型，获取需要显示new 的id数组
 * @param   type - 需要获取的类型key值
 * @author  by bazinga
 ***/
- (NSArray *) getNewArrayByType:(NEW_JUDGE_TYPE)type
{
    NSMutableArray *array = [[[NSMutableArray alloc]init] autorelease];
    NSMutableDictionary *dict = [_dictionary objectForKey:[NSString stringWithFormat:@"%d",type]];
    NSArray *keys = [dict allKeys];
    for (id key in keys)
    {
        if([[[dict objectForKey:key] objectForKey:JUDGE_ID_KEY] boolValue])
        {
            [array addObject:key];
        }
    }
    
    return array;
}


@end
