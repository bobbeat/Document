//
//  GDNewJudge.h
//  AutoNavi
//
//  Created by jiangshu-fu on 14-1-7.
//
//

#import <Foundation/Foundation.h>



typedef enum NEW_JUDGE_TYPE {
    NEW_JUDGE_SKIN_TYPE = 0,
    NEW_JUDGE_CAR_TYPE = 1,
}NEW_JUDGE_TYPE;

#define  JUDGE_MAIN_KEY @"mainNewKey" //主界面显示new的变量的key值
#define  JUDGE_ID_KEY   @"idNewKey"   //内部变量显示new的key值

@interface GDNewJudge : NSObject
{
    NSMutableDictionary *_dictionary;
}

/***
 * @name    单例获取对象
 * @param
 * @author  by bazinga
 ***/
+ (GDNewJudge *) sharedInstance;

/***
 * @name    添加服务器下发的新id
 * @param   type - 下发的是皮肤还是车主的id   addArray - 下发的数组
 * @author  by bazinga
 ***/
- (void) addObjectWithType:(NEW_JUDGE_TYPE)type withArray:(NSArray *)addArray;

/***
 * @name    删除字典中的所有对象（即还原）
 * @param
 * @author  by bazinga
 ***/
- (void) deleteAll;

/***
 * @name    将字典保存到文件中去
 * @param
 * @author  by bazinga
 ***/
- (void) save;

/***
 * @name    通过key和类型，设置字典对应key值的值
 * @param   key - 就是所设置的id值
 * @param   type - 是车主服务还是皮肤类型
 * @author  by bazinga
 ***/
- (void) setNoForKey:(NSString *)key withType:(NEW_JUDGE_TYPE)type;

/***
 * @name    根据类型，返回是否需要显示new图标
 * @param   type - 类型
 * @author  by bazinga
 ***/
- (BOOL) isAppearNewWithType:(NEW_JUDGE_TYPE)type;

/***
 * @name    根据类型，隐藏new图标
 * @param   type - 类型
 * @author  by bazinga
 ***/
- (void) setHiddenNewByKey:(NEW_JUDGE_TYPE)type;

/***
 * @name    根据类型，获取需要显示new
 * @param
 * @author  by bazinga
 ***/
- (NSArray *) getNewArrayByType:(NEW_JUDGE_TYPE)type;
@end
