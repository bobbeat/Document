//
//  ANTableViewController.h
//  AutoNavi
//
//  Created by gaozhimin on 13-9-20.
//
//

#import "ANViewController.h"
#import "POIDefine.h"
#define TABLE_HEAD_OFFSET 10

@interface ANTableViewController : ANViewController
{
    UITableView* _tableView;
}

@end
