//
//  ParentViewController.h
//  AutoNavi
//
//  Created by yu.liao on 12-8-22.
//
//

#import <UIKit/UIKit.h>

@interface ParentViewController : UINavigationController
{
 
}

@end
