//
//  GDImagePickerViewController.h
//  AutoNavi
//
//  Created by huang on 13-10-30.
//
//

#import <UIKit/UIKit.h>
//用于进入相册选图时进入状态栏样式的改变
@interface GDImagePickerController : UIImagePickerController

@end
