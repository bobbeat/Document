//
//  VCCustomNavigationBar.m
//  Custom NavBar
//
//  Created by ljj on 12-7-16.
//  Copyright (c) 2012Âπ?autonavi. All rights reserved.
//

#import "VCCustomNavigationBar.h"

@implementation VCCustomNavigationBar
@synthesize navigationBarBackgroundImage = _navigationBarBackgroundImage;
@synthesize landscapeBarBackground = _landscapeBarBackground;
@synthesize portraitBarBackground = _portraitBarBackground;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self awakeFromNib];
    }
    return self;
}
- (void)awakeFromNib {
    self.isRotate=YES;
    if (isPad) {
         self.landscapeBarBackground = IMAGE(@"navigatorBarBg.png",IMAGEPATH_TYPE_1);
    }
    else
        self.landscapeBarBackground = IMAGE(@"navigatorBarBgl.png",IMAGEPATH_TYPE_1);
    self.portraitBarBackground = IMAGE(@"navigatorBarBg.png",IMAGEPATH_TYPE_1);
    self.navigationBarBackgroundImage=self.portraitBarBackground;
    self.backgroundColor = [UIColor clearColor];
//    if (IOS_7) {
        self.backgroundColor=[UIColor colorWithPatternImage:IMAGE(@"viewBackground.png", IMAGEPATH_TYPE_1)];
//    }

}
-(void)refeshBackground
{
    if (isPad) {
        self.landscapeBarBackground = IMAGE(@"navigatorBarBg.png",IMAGEPATH_TYPE_1);
    }
    else
        self.landscapeBarBackground = IMAGE(@"navigatorBarBgl.png",IMAGEPATH_TYPE_1);
    self.portraitBarBackground = IMAGE(@"navigatorBarBg.png",IMAGEPATH_TYPE_1);
    self.backgroundColor=[UIColor colorWithPatternImage:IMAGE(@"viewBackground.png", IMAGEPATH_TYPE_1)];
   

   UIInterfaceOrientation interfaceO= [[UIApplication sharedApplication] statusBarOrientation];
//    if (!OrientationSwitch) {
//        interfaceO=Orientation;
//    }
    
    if(interfaceO == UIInterfaceOrientationPortrait || interfaceO == UIInterfaceOrientationPortraitUpsideDown)
    {
         self.navigationBarBackgroundImage=self.portraitBarBackground;
    }
    else
    {
        self.navigationBarBackgroundImage=self.landscapeBarBackground;
    }
    
    [self setNeedsDisplay];
}
-(void)setIsRotate:(BOOL)isRotate
{
    _isRotate=isRotate;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (isRotate) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeBackgroundImage:) name:UIDeviceOrientationDidChangeNotification object:NULL];
    }
}

- (void)drawRect:(CGRect)rect
{
    if (self.navigationBarBackgroundImage)
    {
        [self.navigationBarBackgroundImage drawAsPatternInRect:rect];
    }
}

- (void)setBackgroundForDeviceOrientation:(UIDeviceOrientation)orientation;
{
    if (!_isRotate)
    {
        return;
    }
    if (!OrientationSwitch) {
        return;
    }
    
    if ((orientation == UIDeviceOrientationLandscapeLeft)
        || (orientation == UIDeviceOrientationLandscapeRight)) {
       self.navigationBarBackgroundImage = self.landscapeBarBackground;
    }
    else if (orientation == UIDeviceOrientationPortrait || orientation == UIDeviceOrientationPortraitUpsideDown) {
        
        self.navigationBarBackgroundImage = self.portraitBarBackground;
    }
    [self setNeedsDisplay];
}

- (void)clearBackground
{
    self.navigationBarBackgroundImage = nil;
    [self setNeedsDisplay];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

- (void)changeBackgroundImage:(NSNotification *)notification {
    UIDeviceOrientation currentOrientation = [[UIDevice currentDevice] orientation];
    if ( (currentOrientation == UIDeviceOrientationFaceUp)
        || (currentOrientation == UIDeviceOrientationFaceDown)
        || (currentOrientation == UIDeviceOrientationUnknown)) {
        return;
    }
    [self setBackgroundForDeviceOrientation:currentOrientation];
}

@end
