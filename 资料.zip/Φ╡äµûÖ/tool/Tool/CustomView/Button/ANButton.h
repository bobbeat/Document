//	按钮
//  ANButton.h
//  AutoNavi
//
//  Created by GHY on 12-3-19.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ANButton : UIButton 
{
	
}

@property (nonatomic, assign) CGFloat textOffsetValue;
@property (nonatomic, assign) CGFloat textRightsetValue;

@end
