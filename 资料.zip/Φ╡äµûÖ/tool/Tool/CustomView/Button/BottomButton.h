//
//  BottomButton.h
//  AutoNavi
//
//  Created by jiangshu.fu on 13-9-9.
//
//

#import <UIKit/UIKit.h>

@interface BottomButton : UIButton
{
}

@property (nonatomic, assign) CGFloat textOffsetValue;
@property (nonatomic, assign) CGFloat textRightsetValue;
@property (nonatomic, assign) CGRect imageRect;
@property (nonatomic, assign) CGFloat   textWidth;

@end

