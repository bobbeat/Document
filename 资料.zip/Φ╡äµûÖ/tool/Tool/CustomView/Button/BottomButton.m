//
//  BottomButton.m
//  AutoNavi
//
//  Created by jiangshu.fu on 13-9-9.
//
//

#import "BottomButton.h"

@implementation BottomButton

@synthesize textOffsetValue;
@synthesize textRightsetValue;
@synthesize imageRect;
@synthesize textWidth;

- (id)init
{
	self = [super init];
    if(self)
    {
        textOffsetValue = 0;
        textRightsetValue = 0;
        imageRect = CGRectZero;
        textWidth = 0;
        [self setExclusiveTouch:YES];
    }
	return self;
}



- (void) setFrame:(CGRect)frame
{
    [super setFrame:frame];
}

- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
	contentRect.origin.y += textOffsetValue;
    contentRect.origin.x += textRightsetValue;
    if(textWidth != 0)
    {
        contentRect.size.width = textWidth;
    }
	return contentRect;
}

- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
	return self.imageRect;
}

@end

