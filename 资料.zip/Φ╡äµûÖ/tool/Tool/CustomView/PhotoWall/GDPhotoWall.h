//
//  GDPhotoWall.h
//  AutoNavi
//
//  Created by huang longfeng on 13-8-30.
//
//

#import <UIKit/UIKit.h>

@interface GDPhotoItem : NSObject

@property (readwrite, nonatomic, copy) NSString *imageName;
@property (readwrite, nonatomic, copy) NSString *titleString;
@property (readwrite, nonatomic, copy) NSString *alertString;
@property (readwrite, nonatomic) int lon;
@property (readwrite, nonatomic) int lat;
@property (readwrite, nonatomic) int lonOffset;
@property (readwrite, nonatomic) int latOffset;
@property (readwrite,nonatomic,copy) UIImage *image;

@end

@protocol GDPhotoHeaderDelegate <NSObject>

@optional
- (void)photoHeaderTaped:(id)header;

@end

@interface GDPhotoHeader : UIView

@property (assign) id<GDPhotoHeaderDelegate> headerDelegate;

- (id)initWithFrame:(CGRect)frame Title:(NSString *)title imageName:(NSString *)imageName;
@end

@protocol GDPhotoWallDelegate <NSObject>

- (void)photoWallPhotoTaped:(NSUInteger)index;
- (void)photoWallMovePhotoFromIndex:(NSInteger)index toIndex:(NSInteger)newIndex;
- (void)photoWallAddAction;
- (void)photoWallAddFinish;
- (void)photoWallDeleteFinish;
- (void)photowallAddFaild;

@end

@interface GDPhotoWall : UIView

@property (assign) id<GDPhotoWallDelegate> delegate;
@property (retain, nonatomic) NSMutableArray *arrayPhotos;
- (void)setPhotos:(NSArray*)photos;
- (void)setEditModel:(BOOL)canEdit;
- (void)addPhoto:(GDPhotoItem *)photoItem;
- (void)deletePhotoByIndex:(NSUInteger)index;
-(void)photoRefreshPoint:(BOOL)isEditModle;
@end
