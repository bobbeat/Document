//
//  GDPhotoWall.m
//  AutoNavi
//
//  Created by huang longfeng on 13-8-30.
//
//

#import "GDPhotoWall.h"
#import "GDPhoto.h"
#import "POIDefine.h"
#import "StyledPageControl.h"
#define kFrameHeight 120+6
#define kFrameHeight2x 175.
#define kFrameSpace 10
#define kTotalPhoto        8
#define kOneCellPhotoCount 3

#define kImagePositionx @"positionx"
#define kImagePositiony @"positiony"
#define kDeletePhoto    @"CommonDelete1.png"
#define kDeleteHPhoto   @"CommonDelete2.png"
@implementation GDPhotoItem
-(void)dealloc
{
    CRELEASE(_image);
    CRELEASE(_imageName);
    CRELEASE(_titleString);
    CRELEASE(_alertString);
    [super dealloc];
}
@end

@interface GDPhotoWall() <GDPhotoDelegate,UIScrollViewDelegate>
{
    int rowCount;
    CGPoint startPoint;
    float rowDis;
    float sectionDic;
    UIScrollView *_scrollView;
    UIImageView *_imageViewBg;
    StyledPageControl *_pageControl;
    BOOL scrollToFirst;                 //是否滚动到第一页
    int orientation;
   
}

@property (retain, nonatomic) NSArray *arrayPositions;

@property (nonatomic) BOOL isEditModel;

@end

@implementation GDPhotoHeader

- (id)initWithFrame:(CGRect)frame Title:(NSString *)title imageName:(NSString *)imageName
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.4];
        
        UILabel *labelTitle = [[UILabel alloc] init];
        [labelTitle setFrame:CGRectMake(10.0, 10.0, self.bounds.size.width-80.0, 30.0)];
        [labelTitle setBackgroundColor:[UIColor clearColor]];
        [labelTitle setText:title];
        [self addSubview:labelTitle];
        [labelTitle release];
        
        UIButton *button_fun = [UIButton buttonWithType:UIButtonTypeCustom];
        [button_fun setFrame:CGRectMake(frame.size.width-50.0, 10.0, 30.0, 30.0)];
        [button_fun setImage:IMAGE(kDeletePhoto,IMAGEPATH_TYPE_1) forState:UIControlStateNormal];
        [button_fun setImage:IMAGE(kDeleteHPhoto,IMAGEPATH_TYPE_1) forState:UIControlStateHighlighted];
        [button_fun addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button_fun];
    }
    return self;
}

- (void)buttonAction:(id)sender
{
    if (self.headerDelegate && [self.headerDelegate respondsToSelector:@selector(photoHeaderTaped:)] ) {
        [self.headerDelegate photoHeaderTaped:sender];
    }
}
-(void)dealloc
{
    
    [super dealloc];
}

@end

@implementation GDPhotoWall
@synthesize arrayPositions,arrayPhotos,isEditModel;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:CGRectMake(0, 0.,CCOMMON_APP_WIDTH, kFrameHeight)];
    if (self) {

        self.backgroundColor=[UIColor clearColor];
        CGRect rect=self.bounds;
        rect.origin.y=10;
        rect.size.width-=0;
        _imageViewBg=[[UIImageView alloc] initWithFrame:rect];
        
        _imageViewBg.image=[IMAGE(@"TableCellBgGroup.png", IMAGEPATH_TYPE_1) stretchableImageWithLeftCapWidth:15 topCapHeight:20];
        [self addSubview:_imageViewBg];
        [_imageViewBg release];
        
        
        self.clipsToBounds=YES;
        
        rect.origin.x+=5;
        rect.size.width-=10;
        _scrollView=[[UIScrollView alloc] initWithFrame:rect];
        [self addSubview:_scrollView];
        _scrollView.delegate=self;
        [_scrollView release];
        
        rowCount=3;
        startPoint = CGPointMake(4, 10);
        rowDis=10;
        sectionDic=10;
        
        
        _pageControl = [[StyledPageControl alloc] initWithFrame:CGRectZero];
        _pageControl.frame = CGRectMake(150, 100, 80, 20);//指定位置大小
        _pageControl.numberOfPages = 2;//指定页面个数
        _pageControl.diameter=9;
        _pageControl.currentPage = 0;//指定pagecontroll的值，默认选中的小白点（第一个）
        _pageControl.coreSelectedColor=GETSKINCOLOR(@"ToolBarSliderColor");
        _pageControl.coreNormalColor=GETSKINCOLOR(@"PlaceholderColor");
        [_imageViewBg addSubview:_pageControl];
        [_pageControl release];
        
        
        NSMutableArray *arr=[NSMutableArray arrayWithCapacity:0];
        for (int i=0;i<9; i++) {
            CGPoint point=CGPointMake(startPoint.x+(kPhotoWidth+rowDis)*(i%rowCount), startPoint.y+(i/rowCount)*(sectionDic+kPhotoHeight));
            NSValue *value=[NSValue valueWithCGPoint:point];
            [arr addObject:value];
        }
        self.arrayPositions=arr;
        self.arrayPhotos = [NSMutableArray arrayWithCapacity:1];
        _scrollView.pagingEnabled=YES;
        scrollToFirst=NO;
        orientation=Interface_Flag;
    }
    return self;
}

- (void)dealloc
{
    self.delegate=nil;
    self.arrayPhotos=nil;
    self.arrayPositions=nil;
    [super dealloc];
    
}

- (void)setPhotos:(NSArray*)photos
{
    [self.arrayPhotos removeAllObjects];
    NSUInteger count = [photos count];
    
    for (int i=0; i<count; i++) {
        GDPhotoItem *item = [photos objectAtIndex:i];
        GDPhoto *photoTemp = [[GDPhoto alloc] initWithOrigin:CGPointZero];
        photoTemp.delegate = self;
        
        [photoTemp setBackgroundImage:item.image];
        if (item.titleString) {
            [photoTemp setPhotoTitle:item.titleString];
        }
        if (item.alertString) {
            [photoTemp setPhotoAlert:item.alertString];
        }
        [photoTemp setPhotoCoordWithLon:item.lon Lat:item.lat LonOffset:item.lonOffset LatOffset:item.latOffset];
        
        [_scrollView addSubview:photoTemp];
        [self.arrayPhotos addObject:photoTemp];
        [photoTemp release];
    }
    GDPhoto *photoTemp1=self.arrayPhotos[0];
    [photoTemp1 setPhotoType: PhotoTypeHome];
    photoTemp1=self.arrayPhotos[1];
    [photoTemp1 setPhotoType: PhotoTypeCompany];
    
 
    [self allocAddPhoto];
    [self setEditModel:NO];
    scrollToFirst=NO;
//    [self photoRefreshPoint:self.isEditModel withAction:NO];
}

- (void)setEditModel:(BOOL)canEdit
{
    self.isEditModel = canEdit;
    if (self.isEditModel) {
        GDPhoto *viewTemp = [self.arrayPhotos lastObject];
        viewTemp.hidden = YES;
        
    } else {
        GDPhoto *viewTemp = [self.arrayPhotos lastObject];
        if (self.arrayPhotos.count>kTotalPhoto) {
            viewTemp.hidden = YES;
        }
        else
        viewTemp.hidden = NO;
        
    }
    
    NSUInteger count = [self.arrayPhotos count]-1;
    for (int i=0; i<count; i++) {
        GDPhoto *viewTemp = [self.arrayPhotos objectAtIndex:i];
        [viewTemp setEditModel:self.isEditModel];
    }
    [self refreshView:canEdit withAction:NO];

}

- (void)addPhoto:(GDPhotoItem *)photoItem
{
    NSUInteger index = [self.arrayPhotos count] - 1;
    NSValue *value= self.arrayPositions[index];
    GDPhoto *photoTemp = [[GDPhoto alloc] initWithOrigin:[value CGPointValue]];
    photoTemp.delegate = self;
    [photoTemp setBackgroundImage:photoItem.image];
    [photoTemp setPhotoTitle:photoItem.titleString];
    [photoTemp setPhotoCoordWithLon:photoItem.lon Lat:photoItem.lat LonOffset:photoItem.lonOffset LatOffset:photoItem.latOffset];
    [self.arrayPhotos insertObject:photoTemp atIndex:index];
    [_scrollView addSubview:photoTemp];
    [photoTemp release];
    if (self.arrayPhotos.count>kTotalPhoto) {
        [[self.arrayPhotos lastObject] setHidden:YES];
    }
    [self reloadPhotos:YES];
}
//创建添加photo;
-(void)allocAddPhoto
{
    GDPhoto *photoTemp = [[GDPhoto alloc] initWithOrigin:CGPointZero];
    photoTemp.delegate = self;
    photoTemp.hidden = YES;
    [photoTemp setPhotoType:PhotoTypeAdd];
    [self.arrayPhotos addObject:photoTemp];
    [_scrollView addSubview:photoTemp];
    if (self.arrayPhotos.count>kTotalPhoto) {
        photoTemp.hidden=YES;
    }
    [photoTemp release];
}
- (void)deletePhotoByIndex:(NSUInteger)index
{
    GDPhoto *photoTemp = [self.arrayPhotos objectAtIndex:index];
    if (index == 0 || index == 1) {
        [photoTemp setPhotoAlert:STR(@"POI_NoSetting",@"POI")];
        [photoTemp setPhotoCoordWithLon:0 Lat:0 LonOffset:0 LatOffset:0];
        photoTemp.buttonDelete.hidden=YES;
    }
    else{
        [self.arrayPhotos removeObject:photoTemp];
        [photoTemp removeFromSuperview];
    }
    
//    [self reloadPhotos:YES];
     [self refreshView:self.isEditModel withAction:NO];
}

#pragma mark - Photo

- (void)photoTaped:(GDPhoto*)photo
{
    NSUInteger type = [photo getPhotoType];
    if (type == PhotoTypeAdd) {
        if (self.arrayPhotos.count > kTotalPhoto) {
            if ([self.delegate respondsToSelector:@selector(photoWallAddAction)]) {
                [self.delegate photowallAddFaild];
            }
        }
        else{
            if ([self.delegate respondsToSelector:@selector(photoWallAddAction)]) {
                [self.delegate photoWallAddAction];
            }
        }
        
    }
    else /*if (type == PhotoTypePhoto)*/ {
        NSUInteger index = [self.arrayPhotos indexOfObject:photo];
        if ([self.delegate respondsToSelector:@selector(photoWallPhotoTaped:)]) {
            [self.delegate photoWallPhotoTaped:index];
        }
    }
}

- (void)photoMoveFinished:(GDPhoto*)photo
{
    CGPoint pointPhoto = CGPointMake(photo.frame.origin.x, photo.frame.origin.y);
    CGFloat space = -1;
    NSUInteger oldIndex = [self.arrayPhotos indexOfObject:photo];
    NSUInteger newIndex = -1;
    
    NSUInteger count = [self.arrayPhotos count] - 1;
    for (int i=0; i<count; i++) {
        
        NSValue *value= self.arrayPositions[i];
        
        CGFloat spaceTemp = [self spaceToPoint:pointPhoto FromPoint:[value CGPointValue]];
        if (space < 0) {
            space = spaceTemp;
            newIndex = i;
        } else {
            if (spaceTemp < space) {
                space = spaceTemp;
                newIndex = i;
            }
        }
    }
    
    [self.arrayPhotos removeObject:photo];
    [self.arrayPhotos insertObject:photo atIndex:newIndex];
    
    [self reloadPhotos:NO];
    
    if ([self.delegate respondsToSelector:@selector(photoWallMovePhotoFromIndex:toIndex:)]) {
        [self.delegate photoWallMovePhotoFromIndex:oldIndex toIndex:newIndex];
    }
}

- (void)reloadPhotos:(BOOL)add
{
    NSUInteger count = -1;
    if (add) {
        count = [self.arrayPhotos count];
    } else {
        count = [self.arrayPhotos count] - 1;
    }
    CGFloat frameHeight = kFrameHeight;
    [self photoRefreshPoint:self.isEditModel];
    self.frame = CGRectMake(CCOMMON_SPACE, 0., (Interface_Flag ==0 ? APPWIDTH :APPHEIGHT)-2*CCOMMON_SPACE, frameHeight);
}
//刷新视图用于刷新视图的大小
-(void)refreshView:(BOOL)isEditModle withAction:(BOOL)action
{
    if (isPad) {
        rowCount=Interface_Flag==0?4:5;
    }
    else
    {
        rowCount=Interface_Flag==0?3:4;
    }
    CGRect frame = self.frame;
    float width =(Interface_Flag==0?APPWIDTH:APPHEIGHT)-2*CCOMMON_SPACE;
    CGRect rect=_imageViewBg.frame;
    rect.size.width=width;
    rect.size.height=frame.size.height-7;
    _imageViewBg.frame=rect;
    rect.origin.x+=5;
    rect.size.width-=10;
    rect.size.height-=3;
    _scrollView.frame=rect;
    [self setAllPhotosPhotoWithAction:action];
    _pageControl.center=CGPointMake(CGRectGetWidth( _imageViewBg.frame )/2, 107);
    int count=self.arrayPhotos.count>kTotalPhoto?kTotalPhoto:self.arrayPhotos.count;
    _scrollView.contentSize=CGSizeMake(((count-isEditModle-1)/rowCount+1)*CGRectGetWidth(_scrollView.frame),CGRectGetHeight(_scrollView.frame));
    _pageControl.numberOfPages=ceilf((count-isEditModle)/1.0/rowCount);
    if(_pageControl.numberOfPages==1)
    {
        _pageControl.hidden=YES;
    }
    else
    {
        _pageControl.hidden=NO;
    }
    

}
//刷新photo
-(void)photoRefreshPoint:(BOOL)isEditModle
{
    [self photoRefreshPoint:isEditModel withAction:NO];
}
//刷新photo
-(void)photoRefreshPoint:(BOOL)isEditModle withAction:(BOOL)action
{
    /*
    rowCount=3;
    
    if (isPad) {
        rowCount=Interface_Flag==0?4:5;
    }
    else
    {
        rowCount=Interface_Flag==0?3:4;
    }
    
     float width =(Interface_Flag==0?APPWIDTH:APPHEIGHT)-2*CCOMMON_SPACE;

    
    
    
    CGRect rect=_imageViewBg.frame;
    rect.size.width=width;
    _imageViewBg.frame=rect;
    rect.origin.x+=5;
    rect.size.width-=10;
    _scrollView.frame=rect;
    
    _pageControl.center=CGPointMake(CGRectGetWidth( _imageViewBg.frame )/2, 107);

    _scrollView.contentSize=CGSizeMake(((count-isEditModle-1)/rowCount+1)*CGRectGetWidth(_scrollView.frame),kFrameHeight);
    _pageControl.numberOfPages=ceilf((count-isEditModle)/1.0/rowCount);
     */
    int count=self.arrayPhotos.count>kTotalPhoto?kTotalPhoto:self.arrayPhotos.count;
   [self refreshView:isEditModel withAction:action];
    
    if (scrollToFirst==NO) {
        _pageControl.currentPage=0;
    
    }
    else{
        int oldRowCount;
        if (orientation==Interface_Flag) {
            oldRowCount=rowCount;
        }
        else
        {
        if (isPad) {
            oldRowCount=Interface_Flag!=0?4:5;
        }
        else
        {
            oldRowCount=Interface_Flag!=0?3:4;
        }
        }
    
        int secCount = (_pageControl.currentPage+1)*oldRowCount;
        if (secCount>count) {
            _pageControl.currentPage = (count-1)/rowCount;
        }
        else
        {
            _pageControl.currentPage=(secCount-1)/rowCount;
        }
    }
    if (orientation!=Interface_Flag) {
        orientation=Interface_Flag;
    }
    if(_pageControl.numberOfPages<=_pageControl.currentPage+1)
    {
        _pageControl.currentPage=_pageControl.numberOfPages-1;
    }
    scrollToFirst=YES;
    _scrollView.contentOffset=CGPointMake((_pageControl.currentPage * _scrollView.frame.size.width), 0);

    
}
//设置photo的位置
-(void)setAllPhotosPhotoWithAction:(BOOL)action
{
    startPoint = CGPointMake(13, 13-15);
    rowDis=13;
    sectionDic=10;
    float photoWidth =((CCOMMON_APP_WIDTH-2*CCOMMON_SPACE) - startPoint.x*2 -(rowCount-1)*rowDis)/rowCount;
    float photoHeight =kPhotoHeight;
    float width =(Interface_Flag==0?APPWIDTH:APPHEIGHT)-2*CCOMMON_SPACE-10;
    for (int i=0; i<self.arrayPhotos.count; i++) {
        CGPoint point=CGPointMake(startPoint.x-5+(i%rowCount)*(photoWidth+rowDis)+(i/rowCount)*(width), startPoint.y);
        GDPhoto *photoTemp = [self.arrayPhotos objectAtIndex:i];
        [photoTemp moveToPosition:point withAction:action];
        [photoTemp setSize:CGSizeMake(photoWidth, photoHeight)];
    }

}
- (CGFloat)spaceToPoint:(CGPoint)point FromPoint:(CGPoint)otherPoint
{
    float x = point.x - otherPoint.x;
    float y = point.y - otherPoint.y;
    return sqrt(x * x + y * y);
}

#pragma mark -UIScrollerView

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    int page = scrollView.contentOffset.x / CGRectGetWidth(scrollView.frame);
    NSLog(@"page=%i",page);
    _pageControl.currentPage=page;
}
@end
