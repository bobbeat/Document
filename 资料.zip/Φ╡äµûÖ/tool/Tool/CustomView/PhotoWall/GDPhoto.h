//
//  GDPhoto.h
//  AutoNavi
//
//  Created by huang longfeng on 13-8-30.
//
//

#import <UIKit/UIKit.h>

#define kPhotoSize 75.
#define kPhotoWidth 86
#define kPhotoHeight 86
@class GDPhoto;


@protocol GDPhotoDelegate <NSObject>

@optional
- (void)photoTaped:(GDPhoto*)photo;
- (void)photoMoveFinished:(GDPhoto*)photo;

@end


typedef NS_ENUM(NSInteger, PhotoType) {
    PhotoTypePhoto  = 0, //Default
    
    PhotoTypeAdd = 1,
    PhotoTypeHome,
    PhotoTypeCompany,
};

@interface GDPhoto : UIView

@property (nonatomic) int  lon;                           //保存点经度
@property (nonatomic) int  lat;                           //保存点纬度
@property (nonatomic) int  lonOffset;                     //保存点经度偏移值
@property (nonatomic) int  latOffset;                     //保存点经度偏移值
@property (retain, nonatomic) UILabel     *labelName;     //按钮名称
@property (retain, nonatomic) UILabel     *labelAlert;    //提示
@property (assign) id<GDPhotoDelegate> delegate;
@property (nonatomic) PhotoType type;                     //按钮类型
@property (retain, nonatomic) UIButton    *buttonDelete;  //删除按钮
- (id)initWithOrigin:(CGPoint)origin;

- (void)setPhotoType:(PhotoType)photoType;       //设置按钮类型
- (PhotoType)getPhotoType;                  //获取按钮类型
- (void)setPhotoUrl:(NSString*)photoUrl;    //设置按钮背景通过url下载
- (void)setPhotoName:(NSString *)photoName; //设置按钮背景
- (void)setPhotoTitle:(NSString *)photoTitle;
- (void)setBackgroundImage:(UIImage *)image;
- (void)setPhotoAlert:(NSString *)photoAlert;
- (void)setPhotoCoordWithLon:(int)poiLon Lat:(int)poiLat LonOffset:(int)lonoffset LatOffset:(int)latoffset;
- (void)moveToPosition:(CGPoint)point;      //移动到指定point
-(void)moveToPosition:(CGPoint)point withAction:(BOOL)action;
- (void)setEditModel:(BOOL)edit;            //设置编辑模式
- (void)setSize:(CGSize)size;
@end
