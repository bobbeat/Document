//
//  GDPhoto.m
//  AutoNavi
//
//  Created by huang longfeng on 13-8-30.
//
//

#import "GDPhoto.h"
#import <QuartzCore/QuartzCore.h>
#import "POIDefine.h"

@interface GDPhoto() <UIGestureRecognizerDelegate>

@property (retain, nonatomic) UIView      *viewMask;      //长按灰色遮罩
@property (retain, nonatomic) UIImageView *viewPhoto;     //背景
@property (retain, nonatomic) UIImageView *iconImageView; //图标

@property (retain, nonatomic) NSString    *stringImageUrl;//背景url

@property (nonatomic) CGPoint pointOrigin;
@property (nonatomic) BOOL editModel;                     //编辑状态



@end



#define kAddButtonImage @"CROSS_2D.png"
#define kPhotoBackground [IMAGE(@"CommonPhoto1.png", IMAGEPATH_TYPE_1) stretchableImageWithLeftCapWidth:5 topCapHeight:5];
#define kPhotohighlightedBackground [IMAGE(@"CommonPhoto2.png", IMAGEPATH_TYPE_1) stretchableImageWithLeftCapWidth:5 topCapHeight:5];
@implementation GDPhoto

@synthesize viewMask,viewPhoto,buttonDelete,stringImageUrl,labelName,labelAlert,pointOrigin,editModel,lon,lat,type,iconImageView,lonOffset,latOffset;

- (id)initWithOrigin:(CGPoint)origin
{
    self = [super initWithFrame:CGRectMake(origin.x, origin.y, kPhotoWidth, kPhotoWidth)];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
        viewPhoto = [[UIImageView alloc] initWithFrame:self.bounds];
//        viewPhoto.layer.cornerRadius = 12;
//        viewPhoto.layer.masksToBounds = YES;
        viewPhoto.image=kPhotoBackground;
        viewPhoto.highlightedImage=kPhotohighlightedBackground;
        viewPhoto.userInteractionEnabled=YES;
        viewMask = [[UIView alloc] initWithFrame:self.bounds];
        viewMask.alpha = 0.6;
//        viewMask.backgroundColor = [UIColor blackColor];
        viewMask.layer.cornerRadius = 11;
        viewMask.layer.masksToBounds = YES;
        
        iconImageView=[[UIImageView alloc] initWithFrame:CGRectZero];
        
        buttonDelete = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonDelete setFrame:CGRectMake(self.bounds.size.width-25.0, -25.0, 50.0, 50)];
        [buttonDelete setImage:IMAGE(@"CommonDelete1.png",IMAGEPATH_TYPE_1) forState:UIControlStateNormal];
        [buttonDelete setImage:IMAGE(@"CommonDelete2.png",IMAGEPATH_TYPE_1) forState:UIControlStateNormal];
        [buttonDelete addTarget:self action:@selector(tapPress:) forControlEvents:UIControlEventTouchUpInside];

        labelName = [[UILabel alloc] initWithFrame:CGRectMake(0.0, self.bounds.size.width/2.0-15.0, self.bounds.size.width, 30.0)];
        labelName.textColor = GETSKINCOLOR(@"CommonHeadViewButtonColor");
        labelName.backgroundColor = [UIColor clearColor];
        labelName.textAlignment = NSTextAlignmentCenter;
        labelName.font=[UIFont systemFontOfSize:kSize6];
        
        labelAlert = [[UILabel alloc] initWithFrame:CGRectMake(10.0, self.bounds.size.width/2.0+15.0, self.bounds.size.width-20.0, 25.0)];
        labelAlert.textColor = GETSKINCOLOR(@"CommonHeadViewButtonColor");
        labelAlert.backgroundColor = [UIColor clearColor];
        labelAlert.textAlignment = NSTextAlignmentCenter;
        labelAlert.hidden = YES;
        [labelAlert setFont:[UIFont systemFontOfSize:10]];
        
  
        UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapPress:)];
        
        [self addSubview:viewPhoto];
        [viewPhoto addSubview:iconImageView];
        [self addSubview:viewMask];
        [viewPhoto addSubview:labelName];
        [viewPhoto addSubview:labelAlert];
        [self addSubview:buttonDelete];
        
        [viewPhoto release];
        [iconImageView release];
        [viewMask release];
        [labelAlert release];
        [labelName release];
        [viewPhoto addGestureRecognizer:tapRecognizer];
        [tapRecognizer release];
        
        self.editModel = NO;
        self.viewMask.hidden = YES;
        self.buttonDelete.hidden = YES;
        [self setPhotoType:PhotoTypePhoto];
    }
    return self;
}
- (void)setSize:(CGSize)size
{
    /*
    CGRect rect=self.frame;
    rect.size=size;
    self.frame=rect;
    viewPhoto.frame=self.bounds;
    
    iconImageView.center=CGPointMake(size.width/2,size.height/2-(type==PhotoTypeAdd?0:15));
    [buttonDelete setFrame:CGRectMake(self.bounds.size.width-30.0, -25.0, 50.0, 50)];
 
    labelName.frame=CGRectMake(0.0, self.bounds.size.height/2.0-6, self.bounds.size.width, 30.0);
    labelAlert.frame=CGRectMake(10.0, self.bounds.size.height/2.0+10.0, self.bounds.size.width-20.0, 25.0);
    */
    
    CGRect rect=self.frame;
    size.width+=15;
    size.height+=15;
    rect.size=size;

    self.frame=rect;
    
    rect=self.bounds;
    size.width-=15;
    size.height-=15;
    rect.origin.y+=15;
    rect.size=size;

    viewPhoto.frame=rect;
    
    iconImageView.center=CGPointMake(size.width/2,size.height/2-(type==PhotoTypeAdd?0:15));
    [buttonDelete setFrame:CGRectMake(viewPhoto.bounds.size.width-30.0, -25.0+15, 50.0, 50)];
    
//    size=[labelName.text sizeWithFont:labelName.font forWidth:viewPhoto.bounds.size.width-10 lineBreakMode:NSLineBreakByCharWrapping];
    size=[labelName.text sizeWithFont:labelName.font constrainedToSize:CGSizeMake(viewPhoto.bounds.size.width-10, 100)];
    float addHeight=0;
    if (size.height>16) {
        addHeight=8;
    }
    
    labelName.frame=CGRectMake(5.0, viewPhoto.bounds.size.height/2.0-6+addHeight, viewPhoto.bounds.size.width-10, 30.0+IOS_7*5);
    labelName.numberOfLines=0;
    labelAlert.frame=CGRectMake(10.0, viewPhoto.bounds.size.height/2.0+10.0, viewPhoto.bounds.size.width-20.0, 25.0);
     
}
- (void)dealloc
{
    CRELEASE(stringImageUrl);
    CLOG_DEALLOC(self);
    [super dealloc];
    
}
- (void)setPhotoType:(PhotoType)photoType
{
    type = photoType;
    
    NSString *imageName1;
    NSString *imageName2;
    if (self.type == PhotoTypeAdd) {
        imageName1=@"CommonAdd1.png";
        imageName2=@"CommonAdd2.png";
       
    }
    else if(type==PhotoTypeHome)
    {
        imageName1=@"CommonHome1.png";
        imageName2=@"CommonHome2.png";
      
 
    }
    else if(type==PhotoTypeCompany)
    {
        imageName1=@"CommonCompany1.png";
        imageName2=@"CommonCompany1.png";
       
    }
    else
    {
        self.labelName.numberOfLines=2;
        imageName1=@"CommonNormal1.png";
        imageName2=@"CommonNormal2.png";
    }
    UIImage *image=IMAGE(imageName1, IMAGEPATH_TYPE_1);
    self.iconImageView.image=IMAGE(imageName1, IMAGEPATH_TYPE_1);
    self.iconImageView.highlightedImage=IMAGE(imageName2, IMAGEPATH_TYPE_1);
    self.iconImageView.frame=CGRectMake(0, 0, image.size.width, image.size.height);
}

- (PhotoType)getPhotoType
{
    return self.type;
}

- (void)setPhotoUrl:(NSString*)photoUrl
{
    //[self.viewPhoto setImageWithURL:[NSURL URLWithString:photoUrl] placeholderImage:nil];
}

-(void)setBackgroundImage:(UIImage*)image
{
    if (image) {
         self.viewPhoto.image=image;
    }
   
}
- (void)setPhotoName:(NSString *)photoName
{
    [self.viewPhoto setImage:IMAGE(photoName,IMAGEPATH_TYPE_1)];
}

- (void)setPhotoTitle:(NSString *)photoTitle
{
    if (photoTitle && [photoTitle length] > 0) {
        [self.labelName setText:photoTitle];
    }
    
}

- (void)setPhotoAlert:(NSString *)photoAlert
{
    if (photoAlert && [photoAlert length] > 0) {
        self.labelAlert.hidden = NO;
        [self.labelAlert setText:photoAlert];
    }
    else{
        self.labelAlert.hidden = YES;
    }
    
}

- (void)setPhotoCoordWithLon:(int)poiLon Lat:(int)poiLat LonOffset:(int)lonoffset LatOffset:(int)latoffset
{
    self.lon = poiLon;
    self.lat = poiLat;
    self.lonOffset = lonoffset;
    self.latOffset = latoffset;
}

- (void)moveToPosition:(CGPoint)point
{
    
    __block GDPhoto *weakSelf=self;
    if (self.type == PhotoTypePhoto) {
        [UIView animateWithDuration:0.5 animations:^{
            weakSelf.frame = CGRectMake(point.x, point.y, weakSelf.frame.size.width, weakSelf.frame.size.height);
        } completion:nil];
    } else {
        weakSelf.frame = CGRectMake(point.x, point.y, weakSelf.frame.size.width, weakSelf.frame.size.height);
    }
}
-(void)moveToPosition:(CGPoint)point withAction:(BOOL)action
{
    __block GDPhoto *weakSelf=self;
    if (self.type == PhotoTypePhoto)
    {
        if (action)
        {
            [UIView animateWithDuration:0.5 animations:^{
                weakSelf.frame = CGRectMake(point.x, point.y, weakSelf.frame.size.width, weakSelf.frame.size.height);
            } completion:nil];
        }
        else
        {
            weakSelf.frame = CGRectMake(point.x, point.y, weakSelf.frame.size.width, weakSelf.frame.size.height);
        }

    }
    else {
        weakSelf.frame = CGRectMake(point.x, point.y, weakSelf.frame.size.width, weakSelf.frame.size.height);
    }
}


- (void)setEditModel:(BOOL)edit
{
    editModel=edit;
    if (self.type != PhotoTypeAdd) {
        if (edit) {
            UILongPressGestureRecognizer *longPressreRecognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
            longPressreRecognizer.delegate = self;
            [self addGestureRecognizer:longPressreRecognizer];
            [longPressreRecognizer release];
            
            if (self.labelAlert.hidden) {
                self.buttonDelete.hidden = NO;
            }
            else{//回家，回公司未设置则编辑时不显示删除按钮
                self.buttonDelete.hidden = YES;
            }
            
            
            //摇晃动画处理
            CGFloat rotation = 0.03;
            
            CABasicAnimation *shake = [CABasicAnimation animationWithKeyPath:@"transform"];
            shake.duration = 0.13;
            shake.autoreverses = YES;
            shake.repeatCount  = MAXFLOAT;
            shake.removedOnCompletion = NO;
            shake.fromValue = [NSValue valueWithCATransform3D:CATransform3DRotate(self.layer.transform,-rotation, 0.0 ,0.0 ,1.0)];
            shake.toValue   = [NSValue valueWithCATransform3D:CATransform3DRotate(self.layer.transform, rotation, 0.0 ,0.0 ,1.0)];
            
            [self.layer addAnimation:shake forKey:@"shakeAnimation"];
        }
        else {
            for (UIGestureRecognizer *recognizer in [self gestureRecognizers]) {
                if ([recognizer isKindOfClass:[UILongPressGestureRecognizer class]]) {
                    [self removeGestureRecognizer:recognizer];
                    break;
                }
            }
            self.buttonDelete.hidden = YES;
            [self.layer removeAnimationForKey:@"shakeAnimation"];
        }
    }
}

#pragma mark - UIGestureRecognizer

- (void)tapPress:(id)sender
{
    if (self.editModel&&sender!=buttonDelete) {
        return;
    }
    
    if ([self.delegate respondsToSelector:@selector(photoTaped:)]) {
        
        [self.delegate photoTaped:self];
    }
}

- (void)handleLongPress:(id)sender
{
    return;
    UILongPressGestureRecognizer *recognizer = sender;
    CGPoint point = [recognizer locationInView:self];
    
    CGFloat diffx = 0.;
    CGFloat diffy = 0.;
    
    if (UIGestureRecognizerStateBegan == recognizer.state) {
        self.viewMask.hidden = NO;
        self.pointOrigin = point;
        [self.superview bringSubviewToFront:self];
    } else if (UIGestureRecognizerStateEnded == recognizer.state) {
        self.viewMask.hidden = YES;
        if ([self.delegate respondsToSelector:@selector(photoMoveFinished:)]) {
            [self.delegate photoMoveFinished:self];
        }
    } else {
        diffx = point.x - self.pointOrigin.x;
        diffy = point.y - self.pointOrigin.y;
    }
    
    CGFloat originx = self.frame.origin.x +diffx;
    CGFloat originy = self.frame.origin.y +diffy;
    
    self.frame = CGRectMake(originx, originy, self.frame.size.width, self.frame.size.height);
}



@end
