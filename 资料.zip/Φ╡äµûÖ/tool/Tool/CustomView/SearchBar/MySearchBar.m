//
//  MySearchBar.m
//  AutoNavi
//
//  Created by huang longfeng on 12-6-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import "MySearchBar.h"


@implementation MySearchBar
@synthesize selectButton;

-(id)initWithFrame:(CGRect)frame{
	if (self = [super initWithFrame:frame])
	{
		self.selectButton = [UIButton buttonWithType:UIButtonTypeCustom];
		self.selectButton.contentEdgeInsets = (UIEdgeInsets){.left=4,.right=4};
		//[self.selectButton addTarget:self action:@selector(pressedButton:) forControlEvents:UIControlEventTouchUpInside];
		
		self.selectButton.titleLabel.numberOfLines = 1;
		self.selectButton.titleLabel.adjustsFontSizeToFitWidth = YES;
		self.selectButton.titleLabel.lineBreakMode = UILineBreakModeClip;
		
		[self addSubview:self.selectButton];
        bCustomerized = FALSE;
		//[self.selectButton setFrame:CGRectMake(5, 6, 60, 31)];
	}
	
	return self;
}
//
-(id) initWithFrame:(CGRect)frame textFieldFrame:(CGRect)TFframe buttonFrame:(CGRect)BTNframe
{
    if (self = [super initWithFrame:frame])
    {
        self.selectButton = [UIButton buttonWithType:UIButtonTypeCustom];
		[self addSubview:self.selectButton];
        //
        m_rcBackground = frame;
        m_rcTextField = TFframe;
        m_rcButton = BTNframe;
        bCustomerized = TRUE;
    }
    return self;
}
-(void) setFrame:(CGRect)frame textFieldFrame:(CGRect)TFframe buttonFrame:(CGRect)BTNframe;
{
    if (bCustomerized) {
        m_rcBackground = frame;
        m_rcTextField = TFframe;
        m_rcButton = BTNframe;
    }
    [self setFrame:m_rcBackground];
}
-(void)layoutSubviews
{
	[super layoutSubviews];
	if (!bCustomerized)
    {
	float cancelButtonWidth = 65.0;
	UITextField *searchField = [self.subviews objectAtIndex:1];
	
	if (self.showsCancelButton == YES)
		[searchField setFrame:CGRectMake(5, 4, self.frame.size.width - 70 - cancelButtonWidth, self.frame.size.height - 10)];
	else
		[searchField setFrame:CGRectMake(5, 5, self.frame.size.width - 70, self.frame.size.height - 10)];

    }
    else
    {
        [self.selectButton setFrame:m_rcButton];
        [[self.subviews objectAtIndex:1] setFrame:m_rcTextField];
    }
}

-(void)dealloc
{
	if (selectButton) {
		[selectButton release];
		selectButton  = nil;
	}
	[super dealloc];
}


@end
