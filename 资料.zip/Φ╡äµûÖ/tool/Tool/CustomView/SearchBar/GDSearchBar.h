//
//  GDSearchBar.h
//  AutoNavi
//
//  Created by huang longfeng on 13-9-11.
//
//

#import <UIKit/UIKit.h>

@interface GDSearchBar : UISearchBar

@end
