//
//  GDSearchBar.m
//  AutoNavi
//
//  Created by huang longfeng on 13-9-11.
//
//

#import "GDSearchBar.h"

#define SEARCHBAR_BAC @""

@implementation GDSearchBar

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)layoutSubviews {
    
    UITextField *searchField;
    
    NSUInteger numViews = [self.subviews count];
    
    for(int i = 0; i < numViews; i++) {
        
        if([[self.subviews objectAtIndex:i] isKindOfClass:[UITextField class]]) { //conform?
            
            searchField = [self.subviews objectAtIndex:i];
            
        }
        
    }
    
    
    if(!(searchField == nil)) {
        
        searchField.textColor = [UIColor blackColor];
        
        [searchField setBorderStyle:UITextBorderStyleRoundedRect];
        
//        UIImage *image = [IMAGE(SEARCHBAR_BAC, IMAGEPATH_TYPE_1) stretchableImageWithLeftCapWidth:5 topCapHeight:5];
//        
//        UIImageView *iView = [[UIImageView alloc] initWithImage:image];
//        
//        searchField.leftView = iView;
        
    }
    
    [super layoutSubviews];
    
}

@end
