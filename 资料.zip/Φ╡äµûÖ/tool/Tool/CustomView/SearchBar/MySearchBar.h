//
//  MySearchBar.h
//  AutoNavi
//
//  Created by huang longfeng on 12-6-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MySearchBar : UISearchBar {
	UIButton *selectButton;
	BOOL bCustomerized;
    CGRect m_rcBackground;
    CGRect m_rcTextField;
    CGRect m_rcButton;
}
@property (nonatomic,retain) UIButton *selectButton;
-(id) initWithFrame:(CGRect)frame textFieldFrame:(CGRect)TFframe buttonFrame:(CGRect)BTNframe;
-(void) setFrame:(CGRect)frame textFieldFrame:(CGRect)TFframe buttonFrame:(CGRect)BTNframe;
@end
