//
//  UIImageActionSheet.h
//  ActionSheetTest
//
//  Created by 高志闽 on 12-7-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIImageActionSheet : UIActionSheet
{
    UIImage *mTitleImage;
    NSMutableArray *mButtonArray;
    CGRect mMyFrame;
    id <UIActionSheetDelegate> mDelegate;
    NSString *_cancelButtonTitle;
}

@property (nonatomic,copy) NSString *_cancelButtonTitle;
-(id) initWithTitle:(NSString *)title
           delegate:(id <UIActionSheetDelegate>)delegate
  cancelButtonTitle:(NSString *)cancelButtonTitle
destructiveButtonTitle:(NSString *)destructiveButtonTitle
  otherButtonTitleArray:(NSArray *)otherButtonTitles;

- (void)ButtonPressed:(id)sender;
@end
