//
//  UIImageActionSheet.m
//  ActionSheetTest
//
//  Created by 高志闽 on 12-7-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UIImageActionSheet.h"

#define DISTANCE_TO_TOP 45
#define PULL_X 18
#define PULL_Y 22
#define DOUBLE_ROW_SUPPORT 0

@implementation UIImageActionSheet
@synthesize _cancelButtonTitle;

-(id) initWithTitle:(NSString *)title
           delegate:(id <UIActionSheetDelegate>)delegate
  cancelButtonTitle:(NSString *)cancelButtonTitle
destructiveButtonTitle:(NSString *)destructiveButtonTitle
  otherButtonTitleArray:(NSArray *)otherButtonTitles
{
   
    if (self = [super initWithTitle:title delegate:delegate cancelButtonTitle:nil destructiveButtonTitle:destructiveButtonTitle otherButtonTitles: nil]) 
    {
        mButtonArray = [[NSMutableArray alloc] init];//保存按钮的名称
        if (destructiveButtonTitle) //判断是否有destructive按钮
        {
            [mButtonArray addObject:destructiveButtonTitle];
            
        }
        _cancelButtonTitle = cancelButtonTitle;
#if DOUBLE_ROW_SUPPORT
        UIButton *button;
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation]; //获取手机设备的方向
        if (orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight) 
        {
            //
            for (int i = 0; i < [otherButtonTitles count]; i++) 
            {
                button = [UIButton  buttonWithType:UIButtonTypeRoundedRect];
                [button setFrame:CGRectMake(0,0, 220, 46)];
                [button setTitle:[otherButtonTitles objectAtIndex:i] forState:UIControlStateNormal];
                button.tag = destructiveButtonTitle?i+1:i;
                [button addTarget:self action:@selector(ButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
                [self addSubview:button];
                [mButtonArray addObject:[otherButtonTitles objectAtIndex:i]];
            }
            
        }
        else
#endif
        {
            for (NSString *str in otherButtonTitles)
            {
                [mButtonArray addObject:str];
                [self addButtonWithTitle:str];
            }
        }
        
        if (cancelButtonTitle)
        {
            [mButtonArray addObject:cancelButtonTitle];
#if DOUBLE_ROW_SUPPORT
            if (orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight)
            {
                button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
                [button addTarget:self action:@selector(ButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
                [button setFrame:CGRectMake(0,0, 220, 46)];
                [button setTitle:cancelButtonTitle forState:UIControlStateNormal];
                button.tag = destructiveButtonTitle?[otherButtonTitles count]+1:[otherButtonTitles count];
                [self addSubview:button];
            }
            else
#endif
            {
                [self addButtonWithTitle:cancelButtonTitle];
                 self.cancelButtonIndex = self.numberOfButtons-1;
            }
        }
        
        mDelegate = delegate;
       
        mTitleImage = IMAGE(@"sheet_hight.png", IMAGEPATH_TYPE_1) ;
    }
    return self;
}


- (void)ButtonPressed:(id)sender
{
    UIButton *button = (UIButton *)sender;
    if ([mDelegate respondsToSelector:@selector(actionSheet:clickedButtonAtIndex:)])
    {
        [mDelegate actionSheet:self clickedButtonAtIndex:button.tag];
    }
    [self dismissWithClickedButtonIndex:button.tag animated:YES];
}


-(void) layoutSubviews{
    [super layoutSubviews];
    
    for(UIView *view in self.subviews)
    {
#if DOUBLE_ROW_SUPPORT
        if([view isKindOfClass:[UILabel class]])
        {
            UILabel *lable = (UILabel *)view;
            lable.font = [UIFont systemFontOfSize:14];
            lable.frame = CGRectMake(0, 0, self.frame.size.width, DISTANCE_TO_TOP - 10);
        }
#endif
        if([view isKindOfClass:[UIButton class]])
        {
            UIButton *button = (UIButton *)view;
            
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            NSString *str = [button titleForState:UIControlStateNormal];
            UIImage *buttonImageNormal1 = IMAGE(@"sheet_green.png", IMAGEPATH_TYPE_1) ;
            UIImage *stretchableButtonImageNormal = [buttonImageNormal1 stretchableImageWithLeftCapWidth:PULL_X topCapHeight:PULL_Y];
            [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateHighlighted];
            if (_cancelButtonTitle == nil) 
            {
                UIImage *buttonImageNormal1 = IMAGE(@"sheet_black.png", IMAGEPATH_TYPE_1) ;
                UIImage *stretchableButtonImageNormal = [buttonImageNormal1 stretchableImageWithLeftCapWidth:PULL_X topCapHeight:PULL_Y];
                [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
            }
            else
            {
                if ([str compare:[mButtonArray objectAtIndex:[mButtonArray count] - 1]])
                {
                    UIImage *buttonImageNormal1 =IMAGE(@"sheet_black.png", IMAGEPATH_TYPE_1) ;
                    UIImage *stretchableButtonImageNormal = [buttonImageNormal1 stretchableImageWithLeftCapWidth:PULL_X topCapHeight:PULL_Y];
                    [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
                }
                else
                {
                    UIImage *buttonImageNormal1 =IMAGE(@"sheet_blue.png", IMAGEPATH_TYPE_1) ;
                    UIImage *stretchableButtonImageNormal = [buttonImageNormal1 stretchableImageWithLeftCapWidth:PULL_X topCapHeight:PULL_Y];
                    [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
                }
            }
            

#if DOUBLE_ROW_SUPPORT
            [button.titleLabel setFont:[UIFont systemFontOfSize:18]];
            UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
            if (orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight) 
            {
                for (NSString *button_title in mButtonArray)
                {
                    if (![str compare:button_title]) 
                    {
                        CGRect current_frame;
                        current_frame = [view frame];
                        current_frame.size.width = 220;
                        if ([mButtonArray indexOfObject:button_title]%2 == 0) 
                        {
                            current_frame.origin.x = 10;
                        }
                        else
                        {
                            current_frame.origin.x = 250;
                        }
                        current_frame.origin.y = DISTANCE_TO_TOP + ([mButtonArray indexOfObject:button_title]/2)*53;
                        [view setFrame:current_frame];
                        
                        
                        break;
                    }
                    
                    
                }
                
    CGRect rect;
    rect = [self frame];
                rect.origin.y = 320 - DISTANCE_TO_TOP - ([mButtonArray count] + 1)/2*53 -20;
                rect.size.height = DISTANCE_TO_TOP + ([mButtonArray count] + 1)/2*53 + 20;
                [self setFrame:rect];
        
            }
#endif
        
    }
        
    }
    
}


 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    CGSize s = self.frame.size;
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 5.0f);
    CGContextSetRGBStrokeColor(context, 82.0/255.0, 82.0/255.0, 82.0/255.0, 0.8);
    CGContextSetRGBFillColor(context, 82.0/255.0, 82.0/255.0, 82.0/255.0, 0.8);
    CGContextMoveToPoint(context, 0, DISTANCE_TO_TOP-10);
    CGContextAddLineToPoint(context, s.width, DISTANCE_TO_TOP-10);
    CGContextAddLineToPoint(context, s.width,s.height);
    CGContextAddLineToPoint(context, 0, s.height);
    CGContextClosePath(context);
    CGContextFillPath(context);
    
    CGContextTranslateCTM(context, 0, self.frame.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);//2
    CGContextDrawImage(context, CGRectMake(0, s.height - DISTANCE_TO_TOP +10, self.frame.size.width,DISTANCE_TO_TOP + 10 ), mTitleImage.CGImage);
}

- (void)dealloc
{
    if (mButtonArray)
    {
        [mButtonArray release];
    }
    [super dealloc];
    
}


@end
