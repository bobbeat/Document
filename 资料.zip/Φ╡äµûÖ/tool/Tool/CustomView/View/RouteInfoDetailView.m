//
//  RouteInfoDetailView.m
//  AutoNavi
//
//  Created by jingjie lin on 12-6-13.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "RouteInfoDetailView.h"

@implementation RouteInfoDetailView
@synthesize textArray;
- (id)initWithFrame:(CGRect)frame textArray:(NSArray *)theArray
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.textArray = theArray;
        float startPos = 0.0f;
        for (int i = 0; i < [textArray count]; i++) {
            float labelWidth = (frame.size.width - 14)/3;
            if(i == 0)
            {
                labelWidth += 14;
            }
            UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(startPos, 0.0f, labelWidth, frame.size.height)];
            startPos += labelWidth;
            label.backgroundColor = [UIColor clearColor];
            label.textColor = [UIColor whiteColor];
            label.text = [textArray objectAtIndex:i];
            label.adjustsFontSizeToFitWidth = YES;
            label.textAlignment = UITextAlignmentCenter;
            label.font = [UIFont systemFontOfSize: 12.0];
            [self addSubview:label];
            [label release];
        }
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
