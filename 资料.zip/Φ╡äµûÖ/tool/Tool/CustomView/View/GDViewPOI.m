//
//  GDActionSheet.h
//  AutoNavi
//
//  Created by huang longfeng on 13-8-21.
//
//

#import "GDViewPOI.h"

#define LABELCOUNT   3
#define BUTTONCOUNT  4

#define BUTTON_TOPLINE             @"topButtonBac.png"
#define BUTTON_TOPLINE_ICON        @"topButtonIcon.png"
#define BACKGROUNDLINE             @"bac_line.png"
#define BUTTON_LEFT_IMG            @"btn_poi_4_2.png"
#define BUTTON_RIGHT_IMG           @"btn_poi_5_2.png"
#define BUTTON_CALL_IMG_NORMAL     @"btn_1.png"
#define BUTTON_CALL_IMG_TOUCH      @"btn_2.png"
#define BUTTON_CALL_ICON           @"icn1.png"
#define BUTTON_COLLECT_IMG_NORMAL  @"btn_poi_1_1.png"
#define BUTTON_COLLECT_IMG_TOUCH   @"btn_poi_1_2.png"
#define BUTTON_COLLECT_ICON        @"icn1.png"
#define BUTTON_SHARE_IMG_NORMAL    @"btn_poi_2_1.png"
#define BUTTON_SHARE_IMG_TOUCH     @"btn_poi_2_2.png"
#define BUTTON_SHARE_ICON          @"icn2.png"
#define BUTTON_CONTACT_IMG_NORMAL  @"btn_poi_3_1.png"
#define BUTTON_CONTACT_IMG_TOUCH   @"btn_poi_3_2.png"
#define BUTTON_CONTACT_ICON        @"icn3.png"


@interface GDViewPOI()
{
    UIScrollView *_scrollView;
}

@property (nonatomic, retain) NSArray        *infoArray;
@property (nonatomic, assign) int            arrayIndex;
@property (nonatomic, retain) NSMutableArray *buttons;
@property (nonatomic, retain) NSMutableArray *labels;
@property (nonatomic, assign) int _currentType;
@property (nonatomic, retain) UIView *_firstView;
@property (nonatomic, retain) UIView *_secondView;
@property (nonatomic, retain) UIView *_thirdView;
@property (nonatomic, retain) UIScrollView *_scrollView;
@end

@implementation GDViewPOI

@synthesize infoArray = _infoArray,arrayIndex = _arrayIndex,buttons,labels,_currentType,_firstView,_secondView,_thirdView;
#pragma mark public
#pragma mark ---  程序界面初始化  ---

- (id)initWithFrame:(CGRect)frame withInfoArray:(NSArray *) array withIndex:(int) index
{
    self = [super initWithFrame:frame];
    if(self)
    {
        //        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ChangeOrientation:) name:UIDeviceOrientationDidChangeNotification object:nil];
        self.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.8];
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.autoresizesSubviews = YES;
        self.hidden = YES;
        self.infoArray = array;
        self.arrayIndex = index;
        NSLog(@"init==%d",index);
        labels = [[NSMutableArray alloc] init];
        buttons = [[NSMutableArray alloc] init];
        
        [self initScrollView];
        [self initTopLineButton];
        if (self.infoArray.count > 1) {
            [self initLeftAndRightButton:-1];
            [self initLeftAndRightButton:1];
            if (self.arrayIndex == 0) {
                self._currentType = 0;
                [self creatFirstView];
                
            }else if (self.arrayIndex == self.infoArray.count - 1){
                self._currentType = 1;
                [self creatLastView];
            }else{
                self._currentType = 2;
                [self createIndexView];
            }
        }
        else if (self.infoArray.count == 1){
            [self createOneView];
        }
        
        [self setLabelTitle];
        [self setLabelAndButtonFrame];
        //添加手势
        //        UIPanGestureRecognizer *panDropGR = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handPanGesture:)];
        //        panDropGR.delegate = self;
        //        [self addGestureRecognizer:panDropGR];
        
        
        
    }
    return self;
}
- (void)initScrollView
{
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0 , 0, self.bounds.size.width , self.bounds.size.height)];
    _scrollView.delegate = self;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _scrollView.autoresizesSubviews = YES;
    _scrollView.pagingEnabled = YES;
    
    [self addSubview:_scrollView];
    [_scrollView release];
}
- (void) dealloc
{
    if(_infoArray)
    {
        [_infoArray release];
        _infoArray = nil;
    }
    
    if (labels) {
        [labels release];
        labels = nil;
    }
    if (buttons) {
        [buttons release];
        buttons  = nil;
    }
    
    [super dealloc];
}

/***
 * 三个view进行设置，可以循环显示
 * author by bazinga  @2013.8.2
 ***/
- (void) reloadScrollView
{
    
}

- (void)ChangeOrientation:(NSNotification*)notify
{
    //    UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    //    if(orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight)
    //	{
    //		//[self setFrame:CGRectMake(0, 480-250, 480, 150)];
    //        [self setFrame:CGRectMake(0, 480-250, 480, 150)];
    //
    //	}
    //	else if(orientation == UIInterfaceOrientationPortrait || orientation == UIInterfaceOrientationPortraitUpsideDown)
    //	{
    //		//[self setFrame:CGRectMake(0, 480-250, 320, 150)];
    //        [self setFrame:CGRectMake(0, 480-250, 320, 150)];
    //
    //    }
    [self setFrame:CGRectZero];
}

- (void)setFrame:(CGRect)frame
{
    NSArray  *windows = [UIApplication sharedApplication].windows;
    UIWindow *window = [windows objectAtIndex:0];
    CGSize windowSize = window.rootViewController.view.bounds.size;
    
    frame = CGRectMake(0,windowSize.height-255.0, windowSize.width, 185.0);
    [super setFrame:frame];

    [_scrollView setFrame:CGRectMake(0.0, 0.0, windowSize.width, windowSize.height)];
    
    if (_currentType == 0) {
        [_firstView setFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
        [_secondView setFrame:CGRectMake(self.bounds.size.width, 0.0, self.bounds.size.width, self.bounds.size.height)];
        [_scrollView scrollRectToVisible:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height) animated:NO];
        _scrollView.contentSize = CGSizeMake(self.bounds.size.width*2.0, self.bounds.size.height);
    }
    else if (_currentType == 1){
        [_firstView setFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
        [_secondView setFrame:CGRectMake(self.bounds.size.width, 0.0, self.bounds.size.width, self.bounds.size.height)];
        
        [_scrollView scrollRectToVisible:CGRectMake(self.bounds.size.width, 0, self.bounds.size.width, self.bounds.size.height) animated:NO];
        _scrollView.contentSize = CGSizeMake(self.bounds.size.width*2.0, self.bounds.size.height);
    }
    else if (_currentType == 2){
        [_firstView setFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
        [_secondView setFrame:CGRectMake(self.bounds.size.width, 0.0, self.bounds.size.width, self.bounds.size.height)];
        [_thirdView setFrame:CGRectMake(self.bounds.size.width*2.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
        [_scrollView scrollRectToVisible:CGRectMake(self.bounds.size.width, 0, self.bounds.size.width, self.bounds.size.height) animated:NO];
        _scrollView.contentSize = CGSizeMake(self.bounds.size.width*3.0, self.bounds.size.height);
    }
    else{
        [_firstView setFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
        [_scrollView scrollRectToVisible:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height) animated:NO];
        _scrollView.contentSize = CGSizeMake(self.bounds.size.width, self.bounds.size.height);
    }
    [self setLabelAndButtonFrame];
}
- (void)ShowOrHidden:(BOOL)show Animation:(BOOL)animation
{
    NSArray  *windows = [UIApplication sharedApplication].windows;
    UIWindow *window = [windows objectAtIndex:0];
    CGSize windowSize = window.rootViewController.view.bounds.size;
    UIView *view = [self superview];
    CGSize size = view.bounds.size;
    
    if (show)
    {
        
        self.hidden = NO;
        
        [self setFrame:CGRectMake(0.0, 0.0, windowSize.width, 0)];
        if (YES == animation) {
            self.center = CGPointMake(windowSize.width/2, size.height + self.frame.size.height/2);
            [UIView animateWithDuration:0.3f animations:^
             {
                 [self setFrame:CGRectMake(0.0, windowSize.height-255.0, windowSize.width, 185.0)];
                 
             }
                             completion:^(BOOL finished)
             {
                 
             }];
        }
        else{
            [self setFrame:CGRectMake(0.0, windowSize.height-250.0, windowSize.width, 185.0)];
            
        }
    }
    else
    {
        
        if (self.hidden == YES)
        {
            
            return;
        }
        
        if (YES == animation) {
           
            
            self.frame = CGRectMake(0, 0, size.width, 0);
            self.center = CGPointMake(size.width/2, self.frame.size.height/2);
            [UIView animateWithDuration:0.5f animations:^
             {
                 self.center = CGPointMake(windowSize.width/2, windowSize.height/2*3);
                 
                
                 
             }
                             completion:^(BOOL finished)
             {
                 self.hidden = YES;
                
             }];
        }
        else{
            self.hidden = YES;
        }
        
    }
}

#pragma mark ---  视图上一些控件的初始化  ---

/***
 * 初始化最上边的可点击的线条按钮
 *author by bazinga  @ 2013.7.26
 ***/
- (void) initTopLineButton
{
    UIButton *tempLineButton = [UIButton buttonWithType:UIButtonTypeCustom];
    tempLineButton.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tempLineButton.autoresizesSubviews = YES;
    [tempLineButton setFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, 20.0)];
    //[tempLineButton addTarget:self action:@selector(mapTopLinePress:) forControlEvents:UIControlEventTouchUpInside];
    UIImage *buttonImageNormal2 = [UIImage imageWithName:BUTTON_TOPLINE pathType:IMAGEPATH_TYPE_1];
    UIImage *stretchableButtonImageNormal2 = [buttonImageNormal2 stretchableImageWithLeftCapWidth:buttonImageNormal2.size.width/2 topCapHeight:buttonImageNormal2.size.height/2];
    [tempLineButton setBackgroundImage:stretchableButtonImageNormal2 forState:UIControlStateNormal];
    [tempLineButton setImage:[UIImage imageWithName:BUTTON_TOPLINE_ICON pathType:IMAGEPATH_TYPE_1] forState:UIControlStateNormal];
    [tempLineButton setImageEdgeInsets:UIEdgeInsetsMake(6.0f, tempLineButton.frame.size.width/2.0-11.0, 6.0f, tempLineButton.frame.size.width/2.0-11.0)];
    
    [self addSubview:tempLineButton];
}

/***
 * 初始化左右两边的按钮
 * param :side —— -1:左边   1:右边
 * author by bazinga  @ 2013.7.26
 ***/
- (void) initLeftAndRightButton :(int) side
{
    UIButton *tempButton = [UIButton buttonWithType:UIButtonTypeCustom];
    //[tempButton addTarget:self action:@selector(PreNextPress:) forControlEvents:UIControlEventTouchUpInside];

    tempButton.autoresizesSubviews = YES;
    tempButton.tag = side;
    [self addSubview:tempButton];
    if(side == -1)
    {
        tempButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
        [tempButton setFrame:CGRectMake(0.0, 20.0, 30, 50.0)];
        
        [tempButton setBackgroundImage:[UIImage imageWithName:BUTTON_LEFT_IMG pathType:IMAGEPATH_TYPE_1] forState:UIControlStateNormal];
        
    }
    else
    {
        tempButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
        [tempButton setFrame:CGRectMake(self.bounds.size.width-30.0, 20.0, 30.0, 50.0)];
        [tempButton setBackgroundImage:[UIImage imageWithName:BUTTON_RIGHT_IMG pathType:IMAGEPATH_TYPE_1] forState:UIControlStateNormal];
    }
}

- (UIView *)createViewForScrollWithFrame:(CGRect)frame
{
    UIView *m_view = [[UIView alloc] initWithFrame:frame];
    m_view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    m_view.autoresizesSubviews = YES;
    UIButton *tempLineButton1 = [UIButton buttonWithType:UIButtonTypeCustom];
    tempLineButton1.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tempLineButton1.autoresizesSubviews = YES;
    [tempLineButton1 setFrame:CGRectMake(0.0, 85.0, self.bounds.size.width, 2.0)];
    [tempLineButton1 setBackgroundImage:[UIImage imageWithName:BACKGROUNDLINE pathType:IMAGEPATH_TYPE_1] forState:UIControlStateNormal];
    
    [m_view addSubview:tempLineButton1];
    for (int i = 0; i < LABELCOUNT; i ++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, 50, 50)];
        label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        label.textColor = [UIColor whiteColor];
        label.backgroundColor = [UIColor clearColor];
        [self.labels addObject:label];
        [m_view addSubview: label];
        [label release];
    }
    for (int j = 0; j < BUTTONCOUNT; j ++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.titleLabel.textColor = [UIColor whiteColor];
        button.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        button.tag = j;
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.buttons addObject:button];
        [m_view addSubview:button];
        
    }
    return [m_view autorelease];
}
- (void)createOneView{
    [self.buttons removeAllObjects];
    [self.labels removeAllObjects];
    [_firstView removeFromSuperview];
    [_secondView removeFromSuperview];
    [_thirdView removeFromSuperview];
    
    self._firstView = [self createViewForScrollWithFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
    [_scrollView addSubview:self._firstView];
    
    [_scrollView scrollRectToVisible:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height) animated:NO];
    _scrollView.contentSize = CGSizeMake(self.bounds.size.width, self.bounds.size.height);
    _currentType = 3;
}
- (void)createIndexView{
    [self.buttons removeAllObjects];
    [self.labels removeAllObjects];
    [_firstView removeFromSuperview];
    [_secondView removeFromSuperview];
    [_thirdView removeFromSuperview];
    NSLog(@"indexview===%f",self.bounds.size.width);
    self._firstView = [self createViewForScrollWithFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
    [_scrollView addSubview:self._firstView];
    
    
    self._secondView = [self createViewForScrollWithFrame:CGRectMake(self.bounds.size.width, 0.0, self.bounds.size.width, self.bounds.size.height)];
    [_scrollView addSubview:self._secondView];
    
    
    self._thirdView = [self createViewForScrollWithFrame:CGRectMake(self.bounds.size.width*2.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
    [_scrollView addSubview:self._thirdView];
    
    [_scrollView scrollRectToVisible:CGRectMake(self.bounds.size.width, 0, self.bounds.size.width, self.bounds.size.height) animated:NO];
    _scrollView.contentSize = CGSizeMake(self.bounds.size.width*3.0, self.bounds.size.height);
    _currentType = 2;
}
- (void)creatFirstView{
    [self.buttons removeAllObjects];
    [self.labels removeAllObjects];
    [_firstView removeFromSuperview];
    [_secondView removeFromSuperview];
    [_thirdView removeFromSuperview];
    
    self._firstView = [self createViewForScrollWithFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
    [_scrollView addSubview:self._firstView];
    
    self._secondView = [self createViewForScrollWithFrame:CGRectMake(self.bounds.size.width, 0.0, self.bounds.size.width, self.bounds.size.height)];
    [_scrollView addSubview:self._secondView];
    
    _scrollView.contentSize = CGSizeMake(self.bounds.size.width*2.0, self.bounds.size.height);
    [_scrollView scrollRectToVisible:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height) animated:NO];
    _currentType = 0;
}
- (void)creatLastView{
    [self.buttons removeAllObjects];
    [self.labels removeAllObjects];
    [_firstView removeFromSuperview];
    [_secondView removeFromSuperview];
    [_thirdView removeFromSuperview];
    
    self._firstView = [self createViewForScrollWithFrame:CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height)];
    [_scrollView addSubview:self._firstView];
    
    
    self._secondView = [self createViewForScrollWithFrame:CGRectMake(self.bounds.size.width, 0.0, self.bounds.size.width, self.bounds.size.height)];
    [_scrollView addSubview:self._secondView];
    
    _scrollView.contentSize = CGSizeMake(self.bounds.size.width*2.0, self.bounds.size.height);
    [_scrollView scrollRectToVisible:CGRectMake(self.bounds.size.width, 0, self.bounds.size.width, self.bounds.size.width) animated:NO];
    _currentType = 1;
}
//根据数据源，返回View对象
//@param    info —— 数据源，即，要显示的数据参数
//          index —— 这个view是三个要显示的view的第几个 （用于设置该view的frame）
//- (UIView *) viewWithInfo :(id) info withIndex:(int) index
//{
//    CGRect rect = self.topScrollerView.bounds;
//    rect.origin.x = rect.size.width * index;
//    
//    UIImageView *m_imageView = [[[UIImageView alloc] initWithFrame:rect] autorelease];
//    m_imageView.autoresizesSubviews = YES;
//    m_imageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//    m_imageView.userInteractionEnabled = YES;
//    
//    for (int i = 0; i < LABELCOUNT; i ++) {
//        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, 50, 50)];
//        label.textColor = [UIColor whiteColor];
//        label.backgroundColor = [UIColor clearColor];
//        [self.labels addObject:label];
//        [m_imageView addSubview: label];
//        [label release];
//    }
//    for (int j = 0; j < BUTTONCOUNT; j ++) {
//        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
//        [self.buttons addObject:button];
//        [m_imageView addSubview:button];
//        
//    }
//    
//    return m_imageView;
//}

//对滑动界面的数据进行填充
//- (void) setArrayContent :(int) arrayCount withIndex:(int) index
//{
//    int firstIndex;
//    int middleIndex;
//    int lastIndex;
//    //保证索引的indedx不会越界
//    if(index < 0 || index >= arrayCount)
//    {
//        NSLog(@"数组越界了");
//        return ;
//    }
//    //对数组进行索引进行赋值
//    if(index == 0)
//    {
//        firstIndex = arrayCount - 1;
//        middleIndex = index;
//        lastIndex = index + 1;
//    }
//    else if(index == arrayCount - 1)
//    {
//        firstIndex = index - 1;
//        middleIndex = index;
//        lastIndex = 0;
//    }
//    else 
//    {
//        firstIndex = index - 1;
//        middleIndex = index;
//        lastIndex = index +1;
//    }
//    
//    //*** 数组源的设置
//    
//    //进行数组清空
//    
//
//    for (UILabel *label in self.labels) {
//        [label removeFromSuperview];
//    }
//    for (UIButton *button in self.buttons) {
//        [button removeFromSuperview];
//    }
//    
//    for (UIImageView *image in m_threeScrollView)
//    {
//        [image removeFromSuperview];
//    }
//    [self.labels removeAllObjects];
//    [self.buttons removeAllObjects];
//    [m_threeScrollView removeAllObjects];
//    //添加数据
//    [m_threeScrollView addObject:[self viewWithInfo:[self.infoArray objectAtIndex:firstIndex] withIndex:FIRST_VIEW]];
//    [m_threeScrollView addObject:[self viewWithInfo:[self.infoArray objectAtIndex:middleIndex] withIndex:MIDDLE_VIEW]];
//    [m_threeScrollView addObject:[self viewWithInfo:[self.infoArray objectAtIndex:lastIndex] withIndex:LAST_VIEW]];
//    
//    for (int i = 0; i < m_threeScrollView.count; i++)
//    {
//        [self.topScrollerView addSubview:[m_threeScrollView objectAtIndex:i ]];
//    }
//    //设置第一次显示的界面，是数组中的第几个
//    [self.topScrollerView setContentOffset:CGPointMake(self.topScrollerView.frame.size.width , 0) animated:NO];
//    
//    [self setLabelAndButtonFrame];
//    [self setLabelTitle:self.arrayIndex];
//}

/**
 * 初始化信息详情的scrollerview 面板
 * author by bazinga  @ 2013.7.26
 ***/
//-(void) initTopScrollView
//{
//    MapLongTopScrollView *tempScrollerView = [[MapLongTopScrollView alloc] initWithFrame:TOP_SCROLL_VIEW];
//    tempScrollerView.showsHorizontalScrollIndicator = NO;
//    tempScrollerView.showsVerticalScrollIndicator = NO;
//    tempScrollerView.autoresizesSubviews = YES;
//    tempScrollerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
//    //if (self.ViewType == ViewPOI_ViewMap)
//    {
//        tempScrollerView.pagingEnabled = YES;
//    }
////    else{
////        tempScrollerView.pagingEnabled = NO;
////    }
//    
//    tempScrollerView.delegate = self;
//    tempScrollerView.userInteractionEnabled = YES;
//    tempScrollerView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.7];
//    //设置内容大小
//    CGFloat width = tempScrollerView.frame.size.width;
//    CGFloat height = tempScrollerView.frame.size.height;
//    CGSize size = self.infoArray == nil ? CGSizeMake(width, height) : CGSizeMake(width * self.infoArray.count, height);
//    [tempScrollerView setContentSize:size];
//    
//
////    //添加在scrollerView上的点击事件 手势
////    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewTap:)];
////    [tempScrollerView addGestureRecognizer:tapGR];
//    
//    self.topScrollerView = tempScrollerView;
//    [self addSubview:self.topScrollerView];
//   
//    //设置初始化显示的scrollerview
//    
//    [tempScrollerView release];
//    //[tapGR release];
//
//}
#pragma mark -填充数据
- (void)setLabelAndButtonFrame
{
    if (!(self.labels && self.buttons && self.labels.count > 0 && self.buttons.count > 0)) {
        return;
    }
    float buttonWidth = (self.bounds.size.width-40)/3.0;
    int viewCount = 0;
    if (_currentType == 3) {
        viewCount = 1;
    }
    else if (_currentType == 2) {
        viewCount = 3;
    }
    else{
        viewCount = 2;
    }
    for (int i = 0 ; i < viewCount ; i++) {
        for (int k = 0; k < LABELCOUNT; k++) {
            UILabel *label = (UILabel *)[self.labels objectAtIndex:i*LABELCOUNT + k];
            switch (k) {
                case 0:
                {
                    [label setFrame:CGRectMake(40.0, 20.0, self.bounds.size.width-120.0, 30.0)];
                    
                }
                    break;
                case 1:
                {
                    [label setTextAlignment:NSTextAlignmentRight];
                    [label setFrame:CGRectMake(self.bounds.size.width-130.0, 20.0, 100.0, 30.0)];
                }
                    break;
                case 2:
                {
                    [label setFrame:CGRectMake(40.0, 50.0, self.bounds.size.width-70.0, 30.0)];
                }
                    break;
                    
                default:
                    break;
            }
        }
        
    }
    
    for (int j = 0 ; j < viewCount ; j++) {
        for (int n = 0; n < BUTTONCOUNT; n ++) {
            UIButton *button = (UIButton *)[self.buttons objectAtIndex:j*BUTTONCOUNT+n];
            switch (n) {
                case 0:
                {
                    [button setFrame:CGRectMake(20.0, 90.0, self.bounds.size.width-40.0, 40.0)];
                    UIImage *buttonImageNormal1 = [UIImage imageWithName:BUTTON_CALL_IMG_NORMAL pathType:IMAGEPATH_TYPE_1];
                    UIImage *stretchableButtonImageNormal = [buttonImageNormal1 stretchableImageWithLeftCapWidth:buttonImageNormal1.size.width/2 topCapHeight:buttonImageNormal1.size.height/2];
                    UIImage *buttonImageNormal2 = [UIImage imageWithName:BUTTON_CALL_IMG_TOUCH pathType:IMAGEPATH_TYPE_1];
                    UIImage *stretchableButtonImageNormal2 = [buttonImageNormal2 stretchableImageWithLeftCapWidth:buttonImageNormal2.size.width/2 topCapHeight:buttonImageNormal2.size.height/2];
                    [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
                    [button setBackgroundImage:stretchableButtonImageNormal2 forState:UIControlStateHighlighted];
                    [button setImage:[UIImage imageWithName:BUTTON_CALL_ICON pathType:IMAGEPATH_TYPE_1] forState:UIControlStateNormal];
                    [button setImageEdgeInsets:UIEdgeInsetsMake(6.0f, 30.0f, 6.0f, button.frame.size.width-28.0-30.0)];
                    
                    
                }
                    break;
                case 1:
                {
                    [button setFrame:CGRectMake(20, 135.0, buttonWidth, 40.0)];
                    UIImage *buttonImageNormal1 = [UIImage imageWithName:BUTTON_COLLECT_IMG_NORMAL pathType:IMAGEPATH_TYPE_1];
                    UIImage *stretchableButtonImageNormal = [buttonImageNormal1 stretchableImageWithLeftCapWidth:buttonImageNormal1.size.width/2 topCapHeight:buttonImageNormal1.size.height/2];
                    UIImage *buttonImageNormal2 = [UIImage imageWithName:BUTTON_COLLECT_IMG_TOUCH pathType:IMAGEPATH_TYPE_1];
                    UIImage *stretchableButtonImageNormal2 = [buttonImageNormal2 stretchableImageWithLeftCapWidth:buttonImageNormal2.size.width/2 topCapHeight:buttonImageNormal2.size.height/2];
                    [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
                    [button setBackgroundImage:stretchableButtonImageNormal2 forState:UIControlStateHighlighted];
                    [button setImage:[UIImage imageWithName:BUTTON_COLLECT_ICON pathType:IMAGEPATH_TYPE_1] forState:UIControlStateNormal];
                    [button setImageEdgeInsets:UIEdgeInsetsMake(6.0f, 10.0f, 6.0f, button.frame.size.width-28.0-10.0)];
                }
                    break;
                case 2:
                {
                    [button setFrame:CGRectMake(20.0+buttonWidth, 135.0, buttonWidth, 40.0)];
                    UIImage *buttonImageNormal1 = [UIImage imageWithName:BUTTON_SHARE_IMG_NORMAL pathType:IMAGEPATH_TYPE_1];
                    UIImage *stretchableButtonImageNormal = [buttonImageNormal1 stretchableImageWithLeftCapWidth:buttonImageNormal1.size.width/2 topCapHeight:buttonImageNormal1.size.height/2];
                    UIImage *buttonImageNormal2 = [UIImage imageWithName:BUTTON_SHARE_IMG_TOUCH pathType:IMAGEPATH_TYPE_1];
                    UIImage *stretchableButtonImageNormal2 = [buttonImageNormal2 stretchableImageWithLeftCapWidth:buttonImageNormal2.size.width/2 topCapHeight:buttonImageNormal2.size.height/2];
                    [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
                    [button setBackgroundImage:stretchableButtonImageNormal2 forState:UIControlStateHighlighted];
                    [button setImage:[UIImage imageWithName:BUTTON_SHARE_ICON pathType:IMAGEPATH_TYPE_1] forState:UIControlStateNormal];
                    [button setImageEdgeInsets:UIEdgeInsetsMake(6.0f, 10.0f, 6.0f, button.frame.size.width-28.0-10.0)];
                }
                    break;
                case 3:
                {
                    [button setFrame:CGRectMake(20.0+2*buttonWidth, 135.0, buttonWidth, 40.0)];
                    UIImage *buttonImageNormal1 = [UIImage imageWithName:BUTTON_CONTACT_IMG_NORMAL pathType:IMAGEPATH_TYPE_1];
                    UIImage *stretchableButtonImageNormal = [buttonImageNormal1 stretchableImageWithLeftCapWidth:buttonImageNormal1.size.width/2 topCapHeight:buttonImageNormal1.size.height/2];
                    UIImage *buttonImageNormal2 = [UIImage imageWithName:BUTTON_CONTACT_IMG_TOUCH pathType:IMAGEPATH_TYPE_1];
                    UIImage *stretchableButtonImageNormal2 = [buttonImageNormal2 stretchableImageWithLeftCapWidth:buttonImageNormal2.size.width/2 topCapHeight:buttonImageNormal2.size.height/2];
                    [button setBackgroundImage:stretchableButtonImageNormal forState:UIControlStateNormal];
                    [button setBackgroundImage:stretchableButtonImageNormal2 forState:UIControlStateHighlighted];
                    [button setImage:[UIImage imageWithName:BUTTON_CONTACT_ICON pathType:IMAGEPATH_TYPE_1] forState:UIControlStateNormal];
                    [button setImageEdgeInsets:UIEdgeInsetsMake(6.0f, 10.0f, 6.0f, button.frame.size.width-28.0-10.0)];
                    
                }
                    break;
                default:
                    break;
            }
        }
        
    }
}
- (void)setLabelTitle
{
    if (!(self.labels && self.buttons && self.labels.count > 0 && self.buttons.count > 0)) {
        return;
    }
    NSLog(@"init==%d",self.arrayIndex);
    switch (_currentType) {
        case 0:
        {
            plugin_PoiNode *viewPOI;
            //label
            for (int i = 0 ; i < 2 ; i++) {
                
                viewPOI = self.infoArray[self.arrayIndex + i];
                for (int k = 0; k < LABELCOUNT; k ++) {
                    UILabel *label = self.labels[i*LABELCOUNT + k];
                    switch (k) {
                        case 0:
                        {
                            if (viewPOI.szName && [viewPOI.szName length] > 0) {
                                [label setText:viewPOI.szName];
                            }
                            else{
                                [label setText:@""];
                            }
                            
                        }
                            break;
                        case 1:
                        {
                            if (viewPOI.lDistance > 1000) {
                                [label setText:[NSString stringWithFormat:@"%.1fkm",viewPOI.lDistance/1000.0]];
                            }
                            else{
                                [label setText:[NSString stringWithFormat:@"%dm",viewPOI.lDistance]];
                            }
                            
                        }
                            break;
                        case 2:
                        {
                            NSString *town,*address;
                            if (viewPOI.szTown && [viewPOI.szTown length] > 0) {
                                town = viewPOI.szTown;
                            }
                            else{
                                town = @"";
                            }
                            if (viewPOI.szAddr && [viewPOI.szAddr length] > 0) {
                                address = viewPOI.szAddr;
                            }
                            else{
                                address = @"";
                            }
                            [label setText:[NSString stringWithFormat:@"%@%@",town,address]];
                        }
                            break;
                            
                        default:
                            break;
                    }
                }
                
            }
            //button
            for (int j = 0 ; j < 2 ; j++) {
                
                viewPOI = self.infoArray[self.arrayIndex+j];
                for (int n = 0; n < BUTTONCOUNT; n++) {
                    
                    UIButton *button = self.buttons[j*BUTTONCOUNT + n];
                    switch (n) {
                        case 0:
                        {
                            if ([viewPOI.szTel length] == 0) {
                                
                                [button setHidden:YES];
                            }
                            else{
                                [button setTitle:[NSString stringWithString:viewPOI.szTel] forState:UIControlStateNormal];
                                
                            }
                            
                        }
                            break;
                        case 1:
                        {
                            [button setTitle:@"收藏" forState:UIControlStateNormal];
                            
                        }
                            break;
                        case 2:
                        {
                            [button setTitle:@"分享" forState:UIControlStateNormal];
                        }
                            break;
                        case 3:
                        {
                            [button setTitle:@"通讯录" forState:UIControlStateNormal];
                        }
                            break;
                        default:
                            break;
                    }
                }
            }
            
        }
            break;
        case 1:
        {
            plugin_PoiNode *viewPOI;
            for (int i = 0 ; i < 2 ; i++) {
                
                viewPOI = self.infoArray[self.arrayIndex + i -1];
                for (int k = 0; k < LABELCOUNT; k ++) {
                    UILabel *label = self.labels[i*LABELCOUNT + k];
                    switch (k) {
                        case 0:
                        {
                            if (viewPOI.szName && [viewPOI.szName length] > 0) {
                                [label setText:viewPOI.szName];
                            }
                            else{
                                [label setText:@""];
                            }
                            
                        }
                            break;
                        case 1:
                        {
                            if (viewPOI.lDistance > 1000) {
                                [label setText:[NSString stringWithFormat:@"%.1fkm",viewPOI.lDistance/1000.0]];
                            }
                            else{
                                [label setText:[NSString stringWithFormat:@"%dm",viewPOI.lDistance]];
                            }
                            
                        }
                            break;
                        case 2:
                        {
                            NSString *town,*address;
                            if (viewPOI.szTown && [viewPOI.szTown length] > 0) {
                                town = viewPOI.szTown;
                            }
                            else{
                                town = @"";
                            }
                            if (viewPOI.szAddr && [viewPOI.szAddr length] > 0) {
                                address = viewPOI.szAddr;
                            }
                            else{
                                address = @"";
                            }
                            [label setText:[NSString stringWithFormat:@"%@%@",town,address]];
                        }
                            break;
                            
                        default:
                            break;
                    }
                }
                
            }
            
            //button
            for (int j = 0 ; j < 2 ; j++) {
                
                viewPOI = self.infoArray[self.arrayIndex + j - 1];
                for (int n = 0; n < BUTTONCOUNT; n++) {
                    
                    UIButton *button = self.buttons[j*BUTTONCOUNT + n];
                    switch (n) {
                        case 0:
                        {
                            if ([viewPOI.szTel length] == 0) {
                                
                                [button setHidden:YES];
                            }
                            else{
                                [button setTitle:[NSString stringWithString:viewPOI.szTel] forState:UIControlStateNormal];
                                
                            }
                            
                        }
                            break;
                        case 1:
                        {
                            [button setTitle:@"收藏" forState:UIControlStateNormal];
                            
                        }
                            break;
                        case 2:
                        {
                            [button setTitle:@"分享" forState:UIControlStateNormal];
                        }
                            break;
                        case 3:
                        {
                            [button setTitle:@"通讯录" forState:UIControlStateNormal];
                        }
                            break;
                        default:
                            break;
                    }
                }
            }
        }
            break;
        case 2:
        {
            plugin_PoiNode *viewPOI;
            for (int i = 0 ; i < 3 ; i++) {
                
                viewPOI = self.infoArray[self.arrayIndex + i -1];
                for (int k = 0; k < LABELCOUNT; k ++) {
                    UILabel *label = self.labels[i*LABELCOUNT + k];
                    switch (k) {
                        case 0:
                        {
                            if (viewPOI.szName && [viewPOI.szName length] > 0) {
                                [label setText:viewPOI.szName];
                            }
                            else{
                                [label setText:@""];
                            }
                            
                        }
                            break;
                        case 1:
                        {
                            if (viewPOI.lDistance > 1000) {
                                [label setText:[NSString stringWithFormat:@"%.1fkm",viewPOI.lDistance/1000.0]];
                            }
                            else{
                                [label setText:[NSString stringWithFormat:@"%dm",viewPOI.lDistance]];
                            }
                            
                        }
                            break;
                        case 2:
                        {
                            NSString *town,*address;
                            if (viewPOI.szTown && [viewPOI.szTown length] > 0) {
                                town = viewPOI.szTown;
                            }
                            else{
                                town = @"";
                            }
                            if (viewPOI.szAddr && [viewPOI.szAddr length] > 0) {
                                address = viewPOI.szAddr;
                            }
                            else{
                                address = @"";
                            }
                            [label setText:[NSString stringWithFormat:@"%@%@",town,address]];
                        }
                            break;
                            
                        default:
                            break;
                    }
                }
                
            }
            //button
            for (int j = 0 ; j < 3 ; j++) {
                
                viewPOI = self.infoArray[self.arrayIndex + j -1 ];
                for (int n = 0; n < BUTTONCOUNT; n++) {
                    
                    UIButton *button = self.buttons[j*BUTTONCOUNT + n];
                    switch (n) {
                        case 0:
                        {
                            if ([viewPOI.szTel length] == 0) {
                                
                                [button setHidden:YES];
                            }
                            else{
                                [button setTitle:[NSString stringWithString:viewPOI.szTel] forState:UIControlStateNormal];
                                
                            }
                            
                        }
                            break;
                        case 1:
                        {
                            [button setTitle:@"收藏" forState:UIControlStateNormal];
                            
                        }
                            break;
                        case 2:
                        {
                            [button setTitle:@"分享" forState:UIControlStateNormal];
                        }
                            break;
                        case 3:
                        {
                            [button setTitle:@"通讯录" forState:UIControlStateNormal];
                        }
                            break;
                        default:
                            break;
                    }
                }
            }
        }
            break;
        case 3:
        {
            plugin_PoiNode *viewPOI;
            //label
            
            viewPOI = self.infoArray[self.arrayIndex];
            for (int k = 0; k < LABELCOUNT; k ++) {
                    UILabel *label = self.labels[k];
                    switch (k) {
                        case 0:
                        {
                            if (viewPOI.szName && [viewPOI.szName length] > 0) {
                                [label setText:viewPOI.szName];
                            }
                            else{
                                [label setText:@""];
                            }
                            
                        }
                            break;
                        case 1:
                        {
                            if (viewPOI.lDistance > 1000) {
                                [label setText:[NSString stringWithFormat:@"%.1fkm",viewPOI.lDistance/1000.0]];
                            }
                            else{
                                [label setText:[NSString stringWithFormat:@"%dm",viewPOI.lDistance]];
                            }
                            
                        }
                            break;
                        case 2:
                        {
                            NSString *town,*address;
                            if (viewPOI.szTown && [viewPOI.szTown length] > 0) {
                                town = viewPOI.szTown;
                            }
                            else{
                                town = @"";
                            }
                            if (viewPOI.szAddr && [viewPOI.szAddr length] > 0) {
                                address = viewPOI.szAddr;
                            }
                            else{
                                address = @"";
                            }
                            [label setText:[NSString stringWithFormat:@"%@%@",town,address]];
                        }
                            break;
                            
                        default:
                            break;
                    }
                }
                
            //button
           
            viewPOI = self.infoArray[self.arrayIndex];
            for (int n = 0; n < BUTTONCOUNT; n++) {
                    
                    UIButton *button = self.buttons[n];
                    switch (n) {
                        case 0:
                        {
                            if ([viewPOI.szTel length] == 0) {
                                
                                [button setHidden:YES];
                            }
                            else{
                                [button setTitle:[NSString stringWithString:viewPOI.szTel] forState:UIControlStateNormal];
                                
                            }
                            
                        }
                            break;
                        case 1:
                        {
                            [button setTitle:@"收藏" forState:UIControlStateNormal];
                            
                        }
                            break;
                        case 2:
                        {
                            [button setTitle:@"分享" forState:UIControlStateNormal];
                        }
                            break;
                        case 3:
                        {
                            [button setTitle:@"通讯录" forState:UIControlStateNormal];
                        }
                            break;
                        default:
                            break;
                    }
                }
            
        }
        default:
            break;
    }
    
    
}

- (void)setScrollerView:(int)index
{
    switch (_currentType) {
        case 0:
        {
            self.arrayIndex = self.arrayIndex + index;
            if (index == 1) {
                [self createIndexView];
                
            }
            break;
        }
        case 1:
        {
            self.arrayIndex = self.arrayIndex + index - 1;
            if (index == 0) {
                [self createIndexView];
            }
            break;
        }
        case 2:
        {
            self.arrayIndex = self.arrayIndex + index - 1;
            if (self.arrayIndex == 0) {
                [self creatFirstView];
            }else if (self.arrayIndex == self.infoArray.count - 1){
                [self creatLastView];
            }else{
                [self createIndexView];
            }
            break;
        }
        default:
            break;
    }
    [self setLabelTitle];
    [self setLabelAndButtonFrame];
}


#pragma mark ---  按钮点击响应函数  ---


- (void)buttonAction:(id)sender
{
    
}


#pragma  mark ---  UIScrollView的delegate  ---
//- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
//{
//    self.arrayIndex = abs(scrollView.contentOffset.x / scrollView.frame.size.width);
//    NSLog(@"scrollViewDidEndDragging ****** %f,%f",scrollView.contentOffset.x,scrollView.frame.size.width);
//    NSLog(@"scrollViewDidEndDragging  arrayIndex = %d",self.arrayIndex );
//    [self setArrayContent:self.infoArray.count withIndex:self.arrayIndex];
//
//}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    CGFloat pageWidth = scrollView.frame.size.width;
    int pageIndex = floor((scrollView.contentOffset.x - pageWidth/2)/pageWidth) + 1;
    [self setScrollerView:pageIndex];
    NSLog(@"_index = %d",self.arrayIndex);
    scrollView.userInteractionEnabled = YES;
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
    scrollView.userInteractionEnabled = NO;
}


#pragma mark ---  手势  ---
/***
 * view上下拉的手势
 * 位置确定还需要修改
 * author by bazinga @2013.7.26
 ***/
-(void) handPanGesture:(UIPanGestureRecognizer *)gestureRecognizer
{
    CGPoint translation = [gestureRecognizer translationInView:self];
    //界面到达最顶端
    if(gestureRecognizer.view.frame.origin.y + translation.y <= 0)
    {
        [gestureRecognizer.view setFrame:CGRectMake(0,0,gestureRecognizer.view.frame.size.width,gestureRecognizer.view.frame.size.height)];
    }
    //界面到达最底端
    else if(gestureRecognizer.view.frame.origin.y + translation.y >= self.bounds.size.height*0.8)
    {
        [gestureRecognizer.view setFrame:CGRectMake(0,self.bounds.size.height*0.8,gestureRecognizer.view.frame.size.width,self.bounds.size.height
                                                    )];
    }
    else
    {
        gestureRecognizer.view.center = CGPointMake(self.frame.size.width/2,
                                                    gestureRecognizer.view.center.y + translation.y);
    }
    [gestureRecognizer setTranslation:CGPointMake(0, 0) inView:self];
    //手势完成后
    if(gestureRecognizer.state == UIGestureRecognizerStateEnded)
    {
        CGPoint velocity = [gestureRecognizer velocityInView:self];
        CGFloat magnitude = sqrtf((velocity.x * velocity.x) +(velocity.y * velocity.y));
        CGFloat slideMult = magnitude / 200;
        float slideFactore = 0.1 * slideMult;
        CGPoint finalPoint = CGPointMake(gestureRecognizer.view.frame.origin.x + (velocity.x * slideFactore),
                                         gestureRecognizer.view.frame.origin.y + (velocity.y * slideFactore));
        
        finalPoint.x = MIN(MAX(finalPoint.x, 0), self.bounds.size.width);
        finalPoint.y = MIN(MAX(finalPoint.y, 0), self.bounds.size.height);
        if(finalPoint.y <= gestureRecognizer.view.frame.origin.y)//最顶端
        {
            [UIView animateWithDuration:0.4 animations:^{
                [gestureRecognizer.view setFrame:CGRectMake(0, 0,
                                                            self.bounds.size.width, self.bounds.size.height)];
                
            }];
        }
        else//最底端
        {
            [UIView animateWithDuration:0.4 animations:^{
                [gestureRecognizer.view setFrame:CGRectMake(0, self.bounds.size.height*0.8,
                                                            self.bounds.size.width, self.bounds.size.height)];
                
            }];
        }
        
    }
}

/***
 * 信息面板的点击手势
 * author by bazinga @2013.7.26
 ***/
-(void)scrollViewTap:(UIGestureRecognizer *)sender
{
    //TODO ::
    NSLog(@"scrollViewTap");
}

@end
