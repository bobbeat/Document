//
//  GDViewPOI.h
//  AutoNavi
//
//  Created by huang longfeng on 13-8-21.
//
//

#import <UIKit/UIKit.h>

@interface GDViewPOI : UIView <UIScrollViewDelegate,UIGestureRecognizerDelegate>

- (id)initWithFrame:(CGRect)frame withInfoArray:(NSArray *) array withIndex:(int) index;

- (void)ShowOrHidden:(BOOL)show Animation:(BOOL)animation;
@end
