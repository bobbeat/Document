//
//  FlyAppearView.m
//  AutoNavi
//
//  @name  从某一处飞出信息条
//
//  Created by jiangshu.fu on 13-8-6.
//
//

#import "FlyAppearView.h"

#pragma  mark ---  飞出的自定义button  ---

@interface AppearButton : UIButton

@property (nonatomic, retain) UILabel *firstLabel;
@property (nonatomic, retain) UILabel *lastLabel;

@end

@implementation AppearButton

@synthesize firstLabel = _firstLabel;
@synthesize lastLabel = _lastLabel;

- (id) init
{
    self = [super init];
    if(self)
    {
        _firstLabel = [[UILabel alloc] init];
        _lastLabel = [[UILabel alloc] init];
        _firstLabel.userInteractionEnabled = NO;
        _lastLabel.userInteractionEnabled = NO;
        _firstLabel.textAlignment = NSTextAlignmentCenter;
        _lastLabel.textAlignment = NSTextAlignmentCenter;
        _firstLabel.backgroundColor = [UIColor clearColor];
        _lastLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:self.firstLabel];
        [self addSubview:self.lastLabel];
    }
    return self;
}

- (void) setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
    [_firstLabel setFrame:CGRectMake(0, 0, 3*frame.size.width / 8,frame.size.height )];
    [_lastLabel setFrame:CGRectMake(3*frame.size.width / 8, 0, 5*frame.size.width / 8,frame.size.height )];

}

- (void) setHidden:(BOOL)hidden
{
    [_firstLabel setHidden:hidden];
    [_lastLabel setHidden:hidden];
    [super setHidden:hidden];
}

- (void) dealloc
{
    if(_firstLabel)
    {
        [_firstLabel release];
        _firstLabel = nil;
    }
    if(_lastLabel)
    {
        [_lastLabel release];
        _lastLabel = nil;
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

@end


@interface FlyAppearView ()
{
    NSMutableArray *m_arrayButton;
    BOOL        m_isShow;
}
@end

@implementation FlyAppearView

#define BUTTON_HEIGHT  40.0f

@synthesize arrayInfo = _arrayInfo;
@synthesize animateTimes = _animateTimes;
@synthesize flyAppearDelegate = _flyAppearDelegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id) initWithY:(int)y withAnimationInfo:(NSArray *) array withDelegate:(id<FlyAppearViewDelegate>)delegate
{
    self = [super init];
    if (self) {
        [self setFrame:CGRectMake(0, y, 0, 0)];
        self.backgroundColor = [UIColor clearColor];
        // Initialization code
        NSArray *arrayFirstInfo = [[NSArray alloc] initWithObjects:
                                            @"推荐路线",@"经济路线",@"距离最短",@"高速优先", nil];
        _arrayInfo = [[NSMutableArray alloc] initWithArray:array];
        m_arrayButton = [[NSMutableArray alloc] init];
        _animateTimes = 0.1;
        for (int i = 0; i < 4 ; i++)
        {
            
            AppearButton *button = [[AppearButton alloc] init];
            button.backgroundColor = [UIColor whiteColor];
            //为了初始化label
            [button setTag:i];
            [button setTitle:@"" forState:UIControlStateNormal];
            [button addTarget:self action:@selector(buttonPress:) forControlEvents:UIControlEventTouchUpInside];
            button.firstLabel.text = [arrayFirstInfo objectAtIndex:i];
            [self addSubview:button];
            [m_arrayButton addObject:button];
        }
        for (int k = 0; k < array.count; k++)
        {
            if(k < 4)
            {
                ((AppearButton *)[m_arrayButton objectAtIndex:k]).lastLabel.text = [array objectAtIndex: k];
            }
        }
        [self initstatusBarOrientation: self];
        self.flyAppearDelegate = delegate;
        m_isShow = NO;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(initstatusBarOrientation:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
    }
    return self;
}

- (void) setButtonData :(NSMutableArray *)array
{
    self.arrayInfo = array;
    for (int k = 0; k < array.count; k++)
    {
        if(k < 4)
        {
            ((AppearButton *)[m_arrayButton objectAtIndex:k]).lastLabel.text = [array objectAtIndex: k];
        }
    }
}

- (void) dealloc
{
    if(_arrayInfo)
    {
        [_arrayInfo release];
        _arrayInfo = nil;
    }
    _flyAppearDelegate = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

#pragma mark ---  界面控件坐标设置  ---
//初始化界面控件位置以及旋转界面的控件设置
- (void)initstatusBarOrientation : (id) sender
{
    [self setHidden:!m_isShow];
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    if(orientation == UIInterfaceOrientationPortrait || orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        [self setPortrait];
    }
    else
    {
        [self setLandscape];
    }
    [self setButtonFrame];
}

- (void) setPortrait
{
    [self setFrame: CGRectMake(0, self.frame.origin.y, [[UIScreen mainScreen] applicationFrame].size.width , 4 * BUTTON_HEIGHT)];
}

- (void) setLandscape
{
     [self setFrame: CGRectMake(0, self.frame.origin.y, [[UIScreen mainScreen] applicationFrame].size.height , 4 * BUTTON_HEIGHT)];
}

- (void) setButtonFrame
{
    for (int i = 0; i < m_arrayButton.count; i ++) {
        AppearButton *button = [m_arrayButton objectAtIndex:i];
        [button setFrame:CGRectMake(0, i * BUTTON_HEIGHT, self.frame.size.width, BUTTON_HEIGHT)];
    }
}

- (void) setHidden:(BOOL)hidden
{
    
    for (int i = 0; i < m_arrayButton.count; i ++) {
        AppearButton *button = [m_arrayButton objectAtIndex:i];
        [button setHidden:hidden];
    }
    [super setHidden:hidden];
}

- (void) show
{
    [self initstatusBarOrientation:self];
    self.hidden = NO;
    m_isShow = YES;
    for (int i = 0; i < m_arrayButton.count; i ++) {
        AppearButton *button = [m_arrayButton objectAtIndex:i];
        [button setFrame:CGRectMake(0, -BUTTON_HEIGHT, self.frame.size.width, BUTTON_HEIGHT)];
    }
    [self beginAnimateAppear:0];
}

- (void) hide
{
    m_isShow = NO;
    [self beginAnimateDisappear:3];
}

- (void) beginAnimateAppear :(int) index
{
    if( index == m_arrayButton.count)
    {
        return ;
    }
    __block NSMutableArray *blockArray = m_arrayButton;
    [UIView animateWithDuration:self.animateTimes
                     animations:^{
                         AppearButton *button = [blockArray objectAtIndex:index];
                         [button setFrame:CGRectMake(0, index * BUTTON_HEIGHT, self.frame.size.width, BUTTON_HEIGHT)];
                     }
                     completion:^(BOOL finish){
                         [self beginAnimateAppear:index + 1];
                     }];
}

- (void) beginAnimateDisappear :(int) index
{
    if( index == -1)
    {
        self.hidden = YES;
        return ;
    }
    __block NSMutableArray *blockArray = m_arrayButton;
    [UIView animateWithDuration:self.animateTimes
                     animations:^{
                         AppearButton *button = [blockArray objectAtIndex:index];
                         [button setFrame:CGRectMake(0, -BUTTON_HEIGHT, self.frame.size.width, BUTTON_HEIGHT)];
                     }
                     completion:^(BOOL finish){
                         [self beginAnimateDisappear:index - 1];
                     }];
}

-(void) buttonPress :(id)sender
{
    if(self.flyAppearDelegate && [self.flyAppearDelegate respondsToSelector:@selector(selectLoad: WithIndex :)])
    {
        [self.flyAppearDelegate selectLoad:self WithIndex:((AppearButton *)sender).tag];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
