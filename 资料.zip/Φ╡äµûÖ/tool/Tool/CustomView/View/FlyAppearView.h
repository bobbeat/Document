//
//  FlyAppearView.h
//  AutoNavi
//
//  Created by jiangshu.fu on 13-8-6.
//
//

#import <UIKit/UIKit.h>

@class FlyAppearView;

@protocol FlyAppearViewDelegate <NSObject>

@optional
- (void) selectLoad:(FlyAppearView *) view WithIndex :(int)index;

@end

@interface FlyAppearView : UIScrollView 
//设置显示的数组信息 —— 顺序 4个信息  —— 推荐路线，经济路线，距离最短，高速优先
@property (nonatomic, retain) NSMutableArray *arrayInfo;
@property (nonatomic, assign) CGFloat animateTimes;             //设置每一个动画效果的事件，默认是 0.1 s

@property (nonatomic, assign) id<FlyAppearViewDelegate> flyAppearDelegate;

- (id) initWithY:(int)y withAnimationInfo:(NSArray *) array withDelegate:(id<FlyAppearViewDelegate>)delegate;
- (void) show;
- (void) hide;
- (void) setButtonData :(NSMutableArray *)array;
@end
