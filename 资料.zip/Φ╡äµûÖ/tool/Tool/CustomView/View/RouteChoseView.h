//
//  RouteChoseView.h
//  AutoNavi
//
//  Created by jingjie lin on 12-6-14.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RouteInfoDetailView.h"
@protocol routeChoseDelegate <NSObject>

-(void)choseRoute:(int)index;
-(void)routeCalculation;
-(void)didClickButton;
@end

@interface RouteInfo : NSObject
@property(nonatomic,copy)NSString * totalDistance;
@property(nonatomic,copy)NSString * totalTime;
@property(nonatomic,copy)NSString * tollboothCount;
@end

@interface RouteChoseView : UIView
{
    UIButton * buttonLeft;
    UIButton * buttonRight;
    //UIButton *subButton1,*subButton2,*subButton3,*subButton4;
    NSMutableArray * subButtons;
    NSMutableArray * labelsInRightView;
    UIView * viewLeft;
    UIImageView * viewRight;
    RouteInfoDetailView *detailTitle;
    BOOL hasMultiRoute;
    //
    BOOL m_bMounceUseful;       // 鼠标有作用
}
@property(nonatomic,retain)NSArray * routeInfos;
@property(nonatomic)BOOL isBig;
@property(nonatomic)int nowChose;
@property(nonatomic,assign)id<routeChoseDelegate> delegate;
@property (nonatomic, assign) BOOL psbMounceUseful;
- (id)initWithFrame:(CGRect)frame routeInfos:(NSArray *)infos;
@end
