//
//  RouteInfoDetailView.h
//  AutoNavi
//
//  Created by jingjie lin on 12-6-13.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RouteInfoDetailView : UIView
@property(nonatomic,retain)NSArray * textArray;
- (id)initWithFrame:(CGRect)frame textArray:(NSArray *)textArray;
@end
