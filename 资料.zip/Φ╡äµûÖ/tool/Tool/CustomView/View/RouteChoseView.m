//
//  RouteChoseView.m
//  AutoNavi
//
//  Created by jingjie lin on 12-6-14.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "RouteChoseView.h"
#import "ANDataSource.h"
#import "Constants.h"
#import "ANParamValue.h"
#define kHeihgt 278.0f
@implementation RouteInfo
@synthesize totalDistance;
@synthesize totalTime;
@synthesize tollboothCount;
@end

@implementation RouteChoseView
@synthesize routeInfos;
@synthesize isBig;
@synthesize nowChose;
@synthesize delegate;
@synthesize psbMounceUseful = m_bMounceUseful;
- (id)initWithFrame:(CGRect)frame routeInfos:(NSArray *)infos 
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        self.backgroundColor = [UIColor clearColor];
        self.routeInfos = infos;
        frame.size.height = kHeihgt/(1+!isBig);
        
        buttonRight = [UIButton buttonWithType:UIButtonTypeCustom];
        
        [buttonRight addTarget:self action:@selector(rightButtonFun) forControlEvents:UIControlEventTouchUpInside];
       
        buttonRight.titleLabel.numberOfLines = 10;
        buttonRight.titleLabel.lineBreakMode = UILineBreakModeWordWrap;
        [buttonRight setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        buttonRight.titleLabel.font = [UIFont systemFontOfSize: 14.0];
        
        [self addSubview:buttonRight];
        
        buttonLeft = [UIButton buttonWithType:UIButtonTypeCustom];
        
        [buttonLeft addTarget:self action:@selector(leftButtonFun) forControlEvents:UIControlEventTouchUpInside];
        
        buttonLeft.titleLabel.numberOfLines = 10;
        buttonLeft.titleLabel.lineBreakMode = UILineBreakModeWordWrap;
        [buttonLeft setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        buttonLeft.titleLabel.font = [UIFont systemFontOfSize: 14.0];
        [self addSubview:buttonLeft];
        
        if(fontType == 0)
        {
            [buttonLeft setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonRight.png"] forState:UIControlStateNormal];
            [buttonRight setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonLeft.png"] forState:UIControlStateNormal];
            [buttonLeft setTitle:@"路\n线\n对\n比\n\n" forState:UIControlStateNormal];
            [buttonRight setTitle:@"路\n线\n详\n情\n\n" forState:UIControlStateNormal];
           // titles = [NSArray arrayWithObjects:@"总距离",@"时间",@"收费站",nil];
        }
        else if(fontType == 1)
        {
            [buttonLeft setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonRight.png"] forState:UIControlStateNormal];
            [buttonRight setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonLeft.png"] forState:UIControlStateNormal];
            [buttonLeft setTitle:@"路\n線\n對\n比\n\n" forState:UIControlStateNormal];
            [buttonRight setTitle:@"路\n線\n詳\n情\n\n" forState:UIControlStateNormal];
        }
        else if(fontType == 2)
        {
            [buttonLeft setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonCompare0_yw.png"] forState:UIControlStateNormal];
            [buttonRight setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonDetail0_yw.png"] forState:UIControlStateNormal];
        }
        
        
        viewLeft = [[UIView alloc] init];
        viewLeft.backgroundColor = [UIColor clearColor];
        
        viewRight = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"RouteChoseRightSubView.png"]];
        
        NSArray * titles;
        
        if(fontType == 0)
        {
            titles = [NSArray arrayWithObjects:@"总距离",@"时间",@"收费站",nil];
        }
        else if(fontType == 1)
        {
            titles = [NSArray arrayWithObjects:@"總距離",@"時間",@"收費站",nil];
        }
        else if(fontType == 2)
        {
            titles = [NSArray arrayWithObjects:@"Distance",@"Time",@"Tolls",nil];
        }
        
        detailTitle = [[RouteInfoDetailView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 158.0f, 19.0f)
                                                       textArray:titles];
        [viewRight addSubview:detailTitle];
        
        [detailTitle release];
        
        subButtons = [[NSMutableArray alloc] init];
//        labelsInRightView = [[NSMutableArray alloc] init];
        
        if(fontType == 0)
        {
            titles = [NSArray arrayWithObjects:@"  推荐路线    ",@"  高速优先    ",@"  经济路线    ",@"  最短路线    ",nil];
        }
        else if(fontType == 1)
        {
            titles = [NSArray arrayWithObjects:@"  推薦路線    ",@"  高速優先    ",@"  經濟路線    ",@"  最短路線    ",nil];
        }
        else if(fontType == 2)
        {
            titles = [NSArray arrayWithObjects:@"  Default    ",@"  Highway    ",@"  Economic    ",@"  Shortest    ",nil];
        }

        for (int i = 0; i < 4; i++)
        {
            UIButton * subButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [subButton setTitle:[titles objectAtIndex:i] forState:UIControlStateNormal];
            subButton.titleLabel.adjustsFontSizeToFitWidth = YES;
            subButton.tag = i;
            [subButton addTarget:self action:@selector(routeButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
            [viewLeft addSubview:subButton];
            [subButtons addObject:subButton];
        }
        
        [self addSubview:viewRight];
        [self addSubview:viewLeft];
        [self setSubButtonsImage];
        [self setSubFramesWithFrame:frame];
        viewLeft.hidden = YES;
        viewRight.hidden = YES;
        buttonRight.hidden = YES;
    }
    return self;
}

- (void)dealloc
{
    if (subButtons)
    {
        [subButtons release];
        subButtons = nil;
    }
    [super dealloc];
}

-(void)setSubButtonsImage
{
    for (int i = 0; i < 4; i++)
    {
        UIButton * subButton = [subButtons objectAtIndex:i];
        if(i != nowChose)
        {
            NSString *imgName = [NSString stringWithFormat:@"SubButton%d_1.png",i+1];
            [subButton setBackgroundImage:[UIImage imageNamed:imgName] forState:UIControlStateNormal];
        }
        else
        {
            NSString *imgName = [NSString stringWithFormat:@"SubButton%d_2.png",i+1];
            [subButton setBackgroundImage:[UIImage imageNamed:imgName] forState:UIControlStateNormal];
        }
    }
}

-(void)setFrame:(CGRect)frame
{
    frame.size.height = kHeihgt/(1+!isBig);
    [super setFrame:frame];
    [self setSubFramesWithFrame:frame];
}

-(void)setNowChose:(int)newChose
{
    nowChose = newChose;
    [self setSubButtonsImage];
}

-(void)setSubFramesWithFrame:(CGRect)frame
{
    float buttonHeight = 240.0f/(1+!isBig);
    float buttonWidth = 84.0f/(1+!isBig);
    buttonLeft.frame = CGRectMake(0.0f, 38.0f/(1+!isBig), buttonWidth, buttonHeight);
    buttonRight.frame = CGRectMake(frame.size.width - 84.0f/(1+!isBig), 38.0f/(1+!isBig), buttonWidth, buttonHeight);
    
    float subButtonHeight = 60.0f/(1+!isBig);
    float subButtonWidth = 172.0f/(1+!isBig);
    
    viewLeft.frame = CGRectMake(buttonWidth, 38.0f/(1+!isBig), subButtonWidth, subButtonHeight * [subButtons count]);
    
    
    for (int i = 0; i < [subButtons count]; i++)
    {
        UIButton *subButton = [subButtons objectAtIndex:i];
        subButton.frame = CGRectMake(0.0f, subButtonHeight * i, subButtonWidth, subButtonHeight);
    }
    
    viewRight.frame = CGRectMake(frame.size.width - buttonWidth - 316.0f/(1+!isBig), 0.0f, 316.0f/(1+!isBig), 278.0f/(1+!isBig));
    
    
}

-(void)reloadRightView
{
    for (int i = 0; i < 4; i++) {
        float labelHeight = 30.0f;
        NSString *totalDis = [[ANDataSource sharedInstance] GMD_GetPathStatisticInfoWithMainID:1 index:i];
        NSString *totalTime = [[ANDataSource sharedInstance] GMD_GetPathStatisticInfoWithMainID:3 index:i];
        NSString *totaltoll = [[ANDataSource sharedInstance] GMD_GetPathStatisticInfoWithMainID:0 index:i];
        RouteInfoDetailView * detailLabel = [[RouteInfoDetailView alloc] initWithFrame:CGRectMake(0.0f, 19.0f+i*labelHeight, 158.0f, labelHeight)
                                                                             textArray:[NSArray arrayWithObjects:totalDis,totalTime,totaltoll, nil]];
        [viewRight addSubview:detailLabel];
    }
    
}

-(void)leftButtonFun
{
    
    if(!hasMultiRoute)
    {
        hasMultiRoute = YES;
        [delegate routeCalculation];
        [self reloadRightView];
    }
    if(viewLeft.hidden)
    {
        viewLeft.hidden = NO;
        buttonRight.hidden = NO;
        if(fontType == 0 || fontType == 1)
        {
            [buttonLeft setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonLeft.png"] forState:UIControlStateNormal];
        }
        else if(fontType == 2)
        {
            [buttonLeft setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonCompare1_yw.png"] forState:UIControlStateNormal];
        }
    }
    else
    {
        viewLeft.hidden = YES;
        //viewRight.hidden = YES;
        //buttonRight.hidden = YES;
        if(fontType == 0 || fontType == 1)
        {
            [buttonLeft setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonRight.png"] forState:UIControlStateNormal];
        }
        else if(fontType == 2)
        {
            [buttonLeft setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonCompare0_yw.png"] forState:UIControlStateNormal];
        }
    }
    if ([delegate respondsToSelector:@selector(didClickButton)])
    {
        [delegate didClickButton];
    }
}


-(void)rightButtonFun
{
    if(viewRight.hidden)
    {
        viewRight.hidden = NO;
        if(fontType == 0 || fontType == 1)
        {
            [buttonRight setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonRight.png"] forState:UIControlStateNormal];
        }
        else if(fontType == 2)
        {
            [buttonRight setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonDetail1_yw.png"] forState:UIControlStateNormal];
        }
    }
    else
    {
        viewRight.hidden = YES;
        if(fontType == 0 || fontType == 1)
        {
            [buttonRight setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonLeft.png"] forState:UIControlStateNormal];
        }
        else if(fontType == 2)
        {
            [buttonRight setBackgroundImage:[UIImage imageNamed:@"RouteChoseMenuButtonDetail0_yw.png"] forState:UIControlStateNormal];
        }
    }
    if ([delegate respondsToSelector:@selector(didClickButton)])
    {
        [delegate didClickButton];
    }
}

-(void)routeButtonClicked:(UIButton *)sender
{
 //   [delegate routeCalculation];
    [delegate choseRoute:sender.tag];
    if ([delegate respondsToSelector:@selector(didClickButton)])
    {
        [delegate didClickButton];
    }
    //self.nowChose = sender.tag;
}
//
- (BOOL) touchPointInRouteView:(CGPoint)touchPoint withEvent:(UIEvent *)event
{
        if (buttonLeft.hidden==NO&&[buttonLeft pointInside:touchPoint withEvent:event]) {
        return YES;
        }
        if (buttonRight.hidden==NO&&[buttonRight pointInside:touchPoint withEvent:event]) {
        return YES;;
        }
        if (viewLeft.hidden==NO&&[viewLeft pointInside:touchPoint withEvent:event]) {
        return YES;;
    }
    if (viewRight.hidden==NO&&[viewRight pointInside:touchPoint withEvent:event]) {
        return YES;;
        }
    return NO;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 判读是否在按钮范围内，如果是，则不传递消息
    CGPoint touchPoint = [[[touches allObjects] objectAtIndex:0] locationInView:self];
    BOOL bInButton = [self touchPointInRouteView:touchPoint withEvent:event];
    if ([delegate respondsToSelector:@selector(psbMounceUseful)]) {
        if (![delegate performSelector:@selector(psbMounceUseful) withObject:nil]&&!bInButton) {
        m_bMounceUseful = TRUE;
//        [[delegate dispatchFirstTouchAtPoint:[[touches allObjects] objectAtIndex:0] locationInView:self] secondTouchAtPoint:CGPointMake(0.0, 0.0)];
        NSValue* vlPoint1 = [NSValue valueWithCGPoint:[[[touches allObjects] objectAtIndex:0] locationInView:self]];
        NSValue* vlPoint2 = [NSValue valueWithCGPoint:CGPointMake(0.0, 0.0)];
            if ([delegate respondsToSelector:@selector(movemapFirstTouchAtPoint:secondTouchAtPoint:)]) {
        [delegate performSelector:@selector(movemapFirstTouchAtPoint:secondTouchAtPoint:) withObject:vlPoint1 withObject:vlPoint2];
            }
        }
    }

}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 判读是否在按钮范围内，如果是，则不传递消息
        CGPoint touchPoint = [[[touches allObjects] objectAtIndex:0] locationInView:self];
    BOOL bInButton = [self touchPointInRouteView:touchPoint withEvent:event];
    if (m_bMounceUseful&&!bInButton) {
        NSValue* vlPoint2 = [NSValue valueWithCGPoint:[[[touches allObjects] objectAtIndex:0] locationInView:self]];
        NSValue* vlPoint1 = [NSValue valueWithCGPoint:CGPointMake(0.0, 0.0)];
        if ([delegate respondsToSelector:@selector(movemapFirstTouchAtPoint:secondTouchAtPoint:)]) {
        [delegate performSelector:@selector(movemapFirstTouchAtPoint:secondTouchAtPoint:) withObject:vlPoint1 withObject:vlPoint2];
        }
        }
}
    
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 判读是否在按钮范围内，如果是，则不传递消息
    m_bMounceUseful = FALSE;
}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 判读是否在按钮范围内，如果是，则不传递消息
    m_bMounceUseful = FALSE;
}

@end
