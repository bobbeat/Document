//
//  RemindTextImageView.h
//  AutoNavi
//
//  Created by jiangshu.fu on 13-7-3.
//
//

#import <UIKit/UIKit.h>

@interface RemindTextImageView : UIImageView
{
    UILabel *titleRemind;
}
- (id)initWithFrame:(CGRect)frame withTitle:(NSString *) title;

- (id)initWithFrame:(CGRect)frame withTitle:(NSString *) title withImage:(UIImage *)imge;
- (void) setTitle:(NSString *)title;
@end
