//
//  BottomBarForBrowse.h
//  AutoNavi
//
//  Created by jingjie lin on 12-6-14.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BottomBarForBrowse : UIImageView
@property(nonatomic,retain)NSArray * buttonArray;
- (id)initWithFrame:(CGRect)frame buttons:(NSArray *)array;
- (void) setViewFrame:(CGRect)viewFrame buttonFrame:(CGRect)btnFrame;
@end
