//
//  BottomBarForBrowse.m
//  AutoNavi
//
//  Created by jingjie lin on 12-6-14.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "BottomBarForBrowse.h"
#define buttonAroundDistance 5
@implementation BottomBarForBrowse
@synthesize buttonArray;
- (id)initWithFrame:(CGRect)frame buttons:(NSArray *)array
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
        [self setImage:IMAGE(@"bottomBarBackground.png", IMAGEPATH_TYPE_1)];
        self.userInteractionEnabled = YES;
        self.buttonArray = array;
        for (int i = 0; i < [array count]; i++)
        {
            UIButton *button = [array objectAtIndex:i];
            [self addSubview:button];
        }
        [self setButtonsPosWithFram:frame];
    }
    
    return self;
}


-(void)setButtonsPosWithFram:(CGRect)frame
{
    int buttonCount = [buttonArray count];
    float buttonWidth = (frame.size.width - (buttonCount+1) * buttonAroundDistance) / buttonCount;
    float buttonHeight = frame.size.height - 2 * buttonAroundDistance;
    float beginX = 0;
    for (int i = 0; i < buttonCount; i++)
    {
        UIButton *button = [buttonArray objectAtIndex:i];
        button.frame = CGRectMake(0.0f, 0.0f, buttonWidth, buttonHeight);
        beginX += buttonAroundDistance;
        button.center = CGPointMake(beginX + buttonWidth/2+frame.origin.x, frame.size.height / 2);
        beginX += buttonWidth;
    }
}

-(void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    [self setButtonsPosWithFram:frame];
}
- (void) setViewFrame:(CGRect)viewFrame buttonFrame:(CGRect)btnFrame;
{
    [super setFrame:viewFrame];
    [self setButtonsPosWithFram:btnFrame];
}
- (void)drawRect:(CGRect)dirtyRect
{
    // Drawing code here.
}
-(void)dealloc
{
    if (buttonArray) {
        [buttonArray release];
        buttonArray  = nil;
    }
    [super dealloc];
}
@end
