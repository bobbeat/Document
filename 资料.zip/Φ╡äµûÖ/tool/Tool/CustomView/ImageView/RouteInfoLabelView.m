//
//  RouteInfoLabelView.m
//  AutoNavi
//
//  Created by jingjie lin on 12-6-11.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "RouteInfoLabelView.h"
#import "Constants.h"
#import "ANParamValue.h"

#define kViewHeight         35
#define DISTANCEIMG_WIDTH   19.0     //总距离图片宽度
#define DISTANCEIMG_HEIGHT  19.0     //总距离图片高度

#define TIMEIMG_WIDTH       19.0     //到达时间图片宽度
#define TIMEIMG_HEIGHT      19.0     //到达时间图片高度

#define TOLLIMG_WIDTH       19.0     //收费站图片宽度
#define TOLLIMG_HEIGHT      19.0     //收费站图片高度

#define DISTANCE_IMG_NAME   @"totalDistance.png"   //总距离图片名称
#define TIME_IMG_NAME       @"totalTime.png"   //到达时间图片名称
#define TOLL_IMG_NAME       @"totalToll.png"   //收费站图片名称

@implementation RouteInfoLabelView
@synthesize nowChose;
- (id)initWithFrame:(CGRect)frame
{
    frame.size.height = kViewHeight;
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        curRouteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [curRouteButton setBackgroundColor:[UIColor colorWithRed:0 green:102/255 blue:1 alpha:1.0f]];
        [curRouteButton.layer setBackgroundColor:[[UIColor clearColor] CGColor]];
        [curRouteButton.layer setBorderColor:[[UIColor clearColor] CGColor]];
        [curRouteButton.layer setBorderWidth:1.5];
		[curRouteButton.layer setCornerRadius:5.0];
		[curRouteButton.layer setMasksToBounds:YES];
        curRouteButton.titleLabel.font = [UIFont systemFontOfSize:15.0f];
        curRouteButton.titleLabel.adjustsFontSizeToFitWidth = YES;
        [self addSubview:curRouteButton];
        
        
//        NSArray * titles;
//        
//        if(fontType == 0)
//        {
//            titles = [NSArray arrayWithObjects:@"总距离 ",@"时间 ",@"收费站 ",nil];
//        }
//        else if(fontType == 1)
//        {
//            titles = [NSArray arrayWithObjects:@"總距離 ",@"時間 ",@"收費站 ",nil];
//        }
//        else if(fontType == 2)
//        {
//            titles = [NSArray arrayWithObjects:@"  Distance:",@"  Time:",@"  Tolls:",nil];
//        }
        
//        totalDistance = [[UILabel alloc] init];
//        totalDistance.font = [UIFont boldSystemFontOfSize:15.0];  
//        totalDistance.textAlignment = UITextAlignmentRight;
//        totalDistance.backgroundColor = [UIColor clearColor];
//        totalDistance.text = [titles objectAtIndex:0];
//        totalDistance.textColor = [UIColor whiteColor];
//        totalDistance.adjustsFontSizeToFitWidth = YES;
//        [self addSubview:totalDistance];
        totalDistance = [[UIImageView alloc] initWithImage:IMAGE(DISTANCE_IMG_NAME, IMAGEPATH_TYPE_1)];
        [self addSubview:totalDistance];
        [totalDistance release];
        
        totalDistanceInfo = [[UILabel alloc] init];
        totalDistanceInfo.font = [UIFont boldSystemFontOfSize:15.0];  
        totalDistanceInfo.textAlignment = UITextAlignmentLeft;
        totalDistanceInfo.backgroundColor = [UIColor clearColor];
        totalDistanceInfo.text = @"00km";
        totalDistanceInfo.textColor = [UIColor whiteColor];
        totalDistanceInfo.adjustsFontSizeToFitWidth = YES;
        [self addSubview:totalDistanceInfo];
        [totalDistanceInfo release];
//        arriveTime = [[UILabel alloc] init];
//        arriveTime.font = [UIFont boldSystemFontOfSize:15.0];  
//        arriveTime.textAlignment = UITextAlignmentRight;
//        arriveTime.backgroundColor = [UIColor clearColor];
//        arriveTime.text = [titles objectAtIndex:1];
//        arriveTime.textColor = [UIColor whiteColor];
//        arriveTime.adjustsFontSizeToFitWidth = YES;
//        [self addSubview:arriveTime];
        arriveTime = [[UIImageView alloc] initWithImage: IMAGE(TIME_IMG_NAME, IMAGEPATH_TYPE_1)];
        [self addSubview:arriveTime];
        [arriveTime release];
        
        arriveTimeInfo = [[UILabel alloc] init];
        arriveTimeInfo.font = [UIFont boldSystemFontOfSize:15.0];  
        arriveTimeInfo.textAlignment = UITextAlignmentLeft;
        arriveTimeInfo.backgroundColor = [UIColor clearColor];
        arriveTimeInfo.text = @"00:00";
        arriveTimeInfo.textColor = [UIColor whiteColor];
        arriveTimeInfo.adjustsFontSizeToFitWidth = YES;
        [self addSubview:arriveTimeInfo];
        [arriveTimeInfo release];
//        tollCount = [[UILabel alloc] init];
//        tollCount.font = [UIFont boldSystemFontOfSize:15.0];  
//        tollCount.textAlignment = UITextAlignmentRight;
//        tollCount.backgroundColor = [UIColor clearColor];
//        tollCount.text = [titles objectAtIndex:2];
//        tollCount.textColor = [UIColor whiteColor];
//        tollCount.adjustsFontSizeToFitWidth = YES;
//        [self addSubview:tollCount];
        
        tollCount = [[UIImageView alloc] initWithImage:IMAGE(TOLL_IMG_NAME, IMAGEPATH_TYPE_1) ];
        [self addSubview:tollCount];
        [tollCount release];
        
        tollCountInfo = [[UILabel alloc] init];
        tollCountInfo.font = [UIFont boldSystemFontOfSize:15.0];  
        tollCountInfo.textAlignment = UITextAlignmentLeft;
        tollCountInfo.backgroundColor = [UIColor clearColor];
        tollCountInfo.text = @"0";
        tollCountInfo.textColor = [UIColor whiteColor];
        tollCountInfo.adjustsFontSizeToFitWidth = YES;
        [self addSubview:tollCountInfo];
        [tollCountInfo release];
        [self setSubFramesWithFrame:frame];
        [self setImage:IMAGE(@"bottomBarBackground.png", IMAGEPATH_TYPE_1)  ];
    }
    return self;
}


-(void)setSubFramesWithFrame:(CGRect)frame
{
    float buttonsWidth = 69.0f;
    float buttonsHeight = frame.size.height - 10;
    curRouteButton.frame = CGRectMake(5.0f, 5.0f, buttonsWidth, buttonsHeight);
    float labelsWidth = 0;
    float labelsHeight = buttonsHeight;
    float labelsXPos = buttonsWidth + 10.0f; 
    float labelsTotalWidth = (frame.size.width - buttonsWidth - 10);
    
    UIFont *tmpFont = [UIFont systemFontOfSize:14.0];
    CGSize tmpSize = CGSizeMake(320, buttonsHeight);
    float totalTextLength = DISTANCEIMG_WIDTH + [totalDistanceInfo.text sizeWithFont:tmpFont].width + TIMEIMG_WIDTH + [arriveTimeInfo.text sizeWithFont:tmpFont].width + TOLLIMG_WIDTH + [tollCountInfo.text sizeWithFont:tmpFont].width;
    totalTextLength *= 1.1;
    
    labelsWidth = labelsTotalWidth * DISTANCEIMG_WIDTH / totalTextLength;
    totalDistance.frame = CGRectMake(labelsXPos, 8.0f, DISTANCEIMG_WIDTH, DISTANCEIMG_HEIGHT);
    labelsXPos+=labelsWidth;
    
    //totalDistanceInfo.backgroundColor = [UIColor greenColor];
    labelsWidth = labelsTotalWidth * [totalDistanceInfo.text sizeWithFont:tmpFont constrainedToSize:tmpSize].width / totalTextLength;
    totalDistanceInfo.frame = CGRectMake(labelsXPos, 5.0f, labelsWidth, labelsHeight);
    labelsXPos+=labelsWidth;
    
    labelsWidth = labelsTotalWidth * TIMEIMG_WIDTH / totalTextLength;
    //arriveTime.backgroundColor = [UIColor redColor];
    arriveTime.frame = CGRectMake(labelsXPos, 8.0f, TIMEIMG_WIDTH, TIMEIMG_HEIGHT);
    labelsXPos+=labelsWidth;
    
    labelsWidth = labelsTotalWidth * [arriveTimeInfo.text sizeWithFont:tmpFont constrainedToSize:tmpSize].width / totalTextLength;
    arriveTimeInfo.frame = CGRectMake(labelsXPos, 5.0f, labelsWidth, labelsHeight);
    labelsXPos+=labelsWidth;
    
    labelsWidth = labelsTotalWidth * TOLLIMG_WIDTH / totalTextLength;
    tollCount.frame = CGRectMake(labelsXPos, 8.0f, TOLLIMG_WIDTH, TOLLIMG_HEIGHT);
    labelsXPos+=labelsWidth;
    
    labelsWidth = labelsTotalWidth * [tollCountInfo.text sizeWithFont:tmpFont constrainedToSize:tmpSize].width / totalTextLength;
    tollCountInfo.frame = CGRectMake(labelsXPos, 5.0f, labelsWidth, labelsHeight);
}

-(void)setFrame:(CGRect)frame
{
    frame.size.height = kViewHeight;
    [super setFrame:frame];
    [self setSubFramesWithFrame:frame];
}
- (void) setViewFrame:(CGRect)viewFrame buttonFrame:(CGRect)btnFrame
{
    viewFrame.size.height = kViewHeight;
    [super setFrame:viewFrame];
    [self setSubFramesWithFrame:btnFrame];
}

-(void)setNowChose:(int)newChose
{
    NSArray *titles;
    if(fontType == 0)
    {
        titles = [NSArray arrayWithObjects:@"推荐路线",@"高速优先",@"经济路线",@"最短路线",nil];
    }
    else if(fontType == 1)
    {
        titles = [NSArray arrayWithObjects:@"推薦路線",@"高速優先",@"經濟路線",@"最短路線",nil];
    }
    else if(fontType == 2)
    {
        titles = [NSArray arrayWithObjects:@"Default",@"Highway",@"Economic",@"Shortest",nil];
    }
    nowChose = newChose;
    
    //NSString * imageName = [NSString stringWithFormat:@"RouteInfoButton%d.png",nowChose+1];
    
    switch (nowChose) {
        case 0:
        {
            [curRouteButton setBackgroundColor:[UIColor colorWithRed:0.0 green:0.4 blue:1.0 alpha:1.0f]];
            
        }
            break;
        case 1:
        {
            [curRouteButton setBackgroundColor:[UIColor colorWithRed:0.8 green:0.56 blue:0.098 alpha:1.0f]];
            
        }
            break;
        case 2:
        {
            [curRouteButton setBackgroundColor:[UIColor colorWithRed:0.027 green:0.68 blue:0.031 alpha:1.0f]];
            
        }
            break;
        case 3:
        {
            [curRouteButton setBackgroundColor:[UIColor colorWithRed:0.80 green:0.047 blue:0.78 alpha:1.0f]];
            
        }
            break;
        default:
        {
            [curRouteButton setBackgroundColor:[UIColor colorWithRed:0.0 green:0.4 blue:1.0 alpha:1.0f]];
        }
            break;
    }
    
    [curRouteButton setTitle:[titles objectAtIndex:newChose] forState:UIControlStateNormal];
}
-(void)setTotalDistance:(NSString *)distance
{
    totalDistanceInfo.text = [NSString stringWithFormat:@"%@",distance];
    [self setSubFramesWithFrame:self.frame];
}
-(void)setArriveTime:(NSString *)time
{
    arriveTimeInfo.text = [NSString stringWithFormat:@"%@",time];
    [self setSubFramesWithFrame:self.frame];
}
-(void)setTollCount:(NSString *)count
{
    tollCountInfo.text = [NSString stringWithFormat:@"%@",count];
    [self setSubFramesWithFrame:self.frame];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
