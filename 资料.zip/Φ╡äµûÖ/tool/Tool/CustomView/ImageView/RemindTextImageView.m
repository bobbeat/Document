//
//  RemindTextImageView.m
//  AutoNavi
//
//  Created by jiangshu.fu on 13-7-3.
//
//

#import "RemindTextImageView.h"

@implementation RemindTextImageView

- (id)initWithFrame:(CGRect)frame withTitle:(NSString *) title
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        titleRemind = [[UILabel alloc]init];
        titleRemind.text = title;
        titleRemind.textColor = [UIColor whiteColor];
        titleRemind.backgroundColor = [UIColor clearColor];
        titleRemind.textAlignment = UITextAlignmentCenter;
        titleRemind.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
        titleRemind.adjustsFontSizeToFitWidth =YES;
        [titleRemind setFrame:CGRectMake(0,0,
                                         self.frame.size.width*2/3,
                                         self.frame.size.height * 6/7)];
        titleRemind.center = CGPointMake(self.frame.size.width/2,
                                         self.frame.size.height / 2);
        [self addSubview:titleRemind];

    }
    return self;
}

- (id)initWithFrame:(CGRect)frame withTitle:(NSString *) title withImage:(UIImage *)image
{
     self = [self initWithFrame:frame withTitle:title];
    if (self) {
        // Initialization code
        self.image = image;
    }
    return self;
}

- (void) setTitle:(NSString *)title
{
    titleRemind.text = title;
}

-(void) setFrame:(CGRect)frame
{
    [super setFrame:frame];
    [titleRemind setFrame:CGRectMake(0,0,
                                     self.frame.size.width*2/3,
                                     self.frame.size.height * 6/7)];
    titleRemind.center = CGPointMake(self.frame.size.width/2,
                                     self.frame.size.height / 2);
}

- (void) dealloc
{
    if(titleRemind)
    {
        [titleRemind release];
    }
    [super dealloc];
}

@end
