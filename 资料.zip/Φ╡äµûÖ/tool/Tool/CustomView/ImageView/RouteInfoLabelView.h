//
//  RouteInfoLabelView.h
//  AutoNavi
//
//  Created by jingjie lin on 12-6-11.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RouteInfoLabelView : UIImageView
{
    UIButton * curRouteButton;
    UIImageView *totalDistance,*arriveTime,*tollCount;
    UILabel *totalDistanceInfo,*arriveTimeInfo,*tollCountInfo;
}
@property(nonatomic)int nowChose;
-(void)setTotalDistance:(NSString *)distance;
-(void)setArriveTime:(NSString *)time;
-(void)setTollCount:(NSString *)count;
-(void) setViewFrame:(CGRect)viewFrame buttonFrame:(CGRect)btnFrame;
@end
