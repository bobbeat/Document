//
//  ANParamValue.h
//  AutoNavi
//
//  保存全局变量,主界面状态组合,逻辑判断处理
//
//  Created by GHY on 12-4-19.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constants.h"
#import "HMI_typedef.h"

@interface ANParamValue : NSObject 
{
    GCOORD startCoord;
}

@property (nonatomic, assign) int isReq95190Des;                   //是否请求95190目的地

@property (nonatomic, assign) BOOL isInit;                          //引擎是否初始化

@property (nonatomic, assign) BOOL isMove;                //当前是否是移图状态
@property (nonatomic, assign, readonly) BOOL isPath;                //当前是否是引导状态
@property (nonatomic, assign, readonly) BOOL isSafe;                //当前是否是屏保状态
@property (nonatomic, assign, readonly) BOOL isNavi;                //当前是否在模拟导航


@property (nonatomic, assign) long    total_byte;                   //总流量
@property (nonatomic, assign) long current_byte;                    //当前流量

@property (nonatomic, assign) int nSpeed;                           //摄像头类型
@property (nonatomic, assign) int eCategory;                        //摄像头类型

@property (nonatomic, assign) BOOL FavEditFlag;                     //我的收藏编辑标志：no：失败 yes：成功

@property (nonatomic, assign) GCOORD searchMapInfo;
@property (nonatomic, assign) BOOL addHistory;                      //添加到历史目的地

@property (nonatomic, assign) BOOL isDriveComputer;                 //是否进入行车电脑界面
@property (nonatomic, assign) BOOL isHud;                           //是否进入HUD界面

@property (nonatomic, retain) NSDictionary *busEndingPoint;
@property (nonatomic, retain) NSDictionary *navEndingPoint;

@property (nonatomic, assign) int scaleFactor;
//设备比例因子
@property (nonatomic, assign) double locationAccuracy;              //信号强度

@property (nonatomic,assign) int isSelectCity;                      //去哪里搜索是否选择区域

@property (nonatomic,assign) GCOORD startCoord;                     //保存routing起点坐标
@property (nonatomic,assign) GCOORD desCoord;                       //保存routing终点坐标
@property (nonatomic,assign) GCOORD curGPSCoord;                    //保存当前gps定位点


@property (nonatomic,assign) BOOL bSupportAutorate;

@property (nonatomic,assign) BOOL beFirstNewFun;                    //是否是第一次新功能介绍
@property (nonatomic,assign) BOOL beFirstDown;                      //第一次进入地图数据下载列表

@property (nonatomic,assign) BOOL is3DDomo;                         //是否3D导航演示


@property (nonatomic,assign) BOOL netWorkMap;                       //后台中网络功能的禁用标志，为NO，则不显示网络地图开关。
@property (nonatomic,assign) BOOL netWorkSearchNWSwitch; //关闭服务后，本地搜索不到结果时，不自动切换到网络搜索，直接提示：搜索结果为空
@property (nonatomic,assign) BOOL realTimeTrafficNWSwitch;//关闭服务后，点击开启实时交通的按钮时，弹出提示框：该服务正在维护中暂停使用，2s后消失
@property (nonatomic,assign) BOOL realTimeTrafficInfoNWSwitch;//关闭服务后，点击实时交通，不请求事件信息，且不在图面中显示
@property (nonatomic,assign) BOOL trafficBroadcastNWSwitch;//关闭服务后，在符合播报的条件下不请求后台数
@property (nonatomic,assign) BOOL ctripOnlineNWSwitch;    //关闭服务后，从图层中点击进入时弹出提示框：该服务正在维护中暂停使用，2s后消失
@property (nonatomic,assign) BOOL repastNWSwitch;//关闭服务后，从图层中点击进入时弹出提示框：该服务正在维护中暂停使用，2s后消失
@property (nonatomic,assign) BOOL golfNWSwitch;//关闭服务后，从图层中点击进入时弹出提示框：该服务正在维护中暂停使用，2s后消失


@property (nonatomic,assign) BOOL isMainViewController;//当前视图是否是主地图


@property (nonatomic,assign) BOOL isUseNETMap;//当前是否使用的是网络地图

@property (nonatomic,assign) BOOL new_fun_flag;//

@property (nonatomic,assign) BOOL isParseFinish;//地图数据下载列表是否已经下载过，如果更改了字体，则该变量会重新置为NO

@property (nonatomic,assign) BOOL isTMCRequest; //实时交通是否正在请求

@property (nonatomic,assign) GCOORD smsCoord;//短信移图经纬度

@property (nonatomic,assign) GCOORD voiceDriveCoord;//第三方软件语驾经纬度

@property (nonatomic,assign) GPOI palellerRoadPOI;//平行道路起点

@property (nonatomic,assign,setter = setIsWarningView:) BOOL isWarningView;//是否在警告界面

@property (nonatomic,assign) int skinType;      //皮肤的颜色类型 0 - 默认颜色



#pragma mark 单例
+ (ANParamValue *)sharedInstance;

- (int)GMD_GetViewConditon;

#pragma mark 判断当前比例尺是否大于5KM
- (BOOL)GMD_CurrentScaleIs_5KM;


#pragma mark 主地图（更多按钮）new图标是否显示
- (BOOL) GMD_isMoreNew;

/*
 
 获取消息盒子是否要显示new图标
 */
-(BOOL)GMD_IsShowMyBoxNewIcon;


#pragma mark 判断某个点是否已在指定类别收藏过
- (BOOL) GMD_IsFavorited:(GFAVORITECATEGORY)favCategory GPOI:(GPOI)poi;

#pragma mark 判断实时交通是否开启
- (BOOL) GMD_isTMCOn;
@end
