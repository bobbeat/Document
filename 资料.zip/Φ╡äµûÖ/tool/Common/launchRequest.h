//
//  launchRequest.h
//  AutoNavi
//
//  Created by huang longfeng on 13-5-24.
//
//

#import <Foundation/Foundation.h>
#import "NetKit.h"
#import "LogCommit.h"


@protocol NetReqToViewCtrDelegate;

@interface launchRequest : NSObject <NetReqToViewCtrDelegate>
{
    LogCommit                  *postCrashLog;
}

+ (launchRequest *)shareInstance;

- (void)launchRequest;
//软件版本升级检测
- (void)softWareVersionUpdateRequest;
- (void)UploadToken;
- (void)UploadTokenToAutonavi:(NSString *)token;
- (void)UploadLocationInfo;//上传位置信息至后台
- (void)DataUpdateRequest;//地图数据升级检测
// 软件升级测试接口
- (void)UpdateAppRequest;

@end
