//
//  launchRequest.m
//  AutoNavi
//
//  Created by huang longfeng on 13-5-24.
//
//

#import "launchRequest.h"
#import "GDBL_LaunchRequest.h"
#import "ANParamValue.h"
#import "Utility.h"
#import "GDBL_LaunchRequest.h"
#import "ANDataSource.h"
#import "NSString+Category.h"
#import "Plugin_GresourseManager.h"
#import "ANOperateMethod.h"
#import "GDAlertView.h"
#import "ControlCreat.h"
#import "UMengEventDefine.h"
#import "GDCacheManager.h"
#import "GDNewJudge.h"
#import "MWDialectDownloadManage.h"
#import "MWSkinAndCarListRequest.h"


static launchRequest* instance;

typedef enum LAUNCH_ALERTTYPE
{
    LAUNCH_ALERT_SCORE               = 1,   //对高德导航进行评分
} LAUNCH_ALERTTYPE;

@interface launchRequest()
{
    MWSkinAndCarListRequest* _skinAndCarRequest;
}

@property (nonatomic,copy) NSString *powerVoiceExpired;
@property (nonatomic,copy) NSString *launchImageExpired;
@property (nonatomic,assign) int powerVoiceID;

@end

@implementation launchRequest

@synthesize powerVoiceExpired,powerVoiceID,launchImageExpired;

- (id)init
{
    if (self == [super init]) {
        _skinAndCarRequest = [[MWSkinAndCarListRequest alloc] init] ;
    }
    return self;
}
+ (launchRequest *)shareInstance
{
    if (instance == nil) {
        instance = [[launchRequest alloc] init];
    }
    return instance;
}

- (void)launchRequest
{
    double delayInSeconds = 2.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self UserBehaviorCountRequest];   //用户行为统计上传
    });
    [self DataUpdateRequest];          //数剧升级检测
    [self onlineEnableRequest];//网络地图开关
    [self UserYawCountRequest];//用户偏航统计
#if PROJECTMODE
    [self crashLogUploadRequest];//奔溃日志上传
#endif
    if (![Plugin_GresourseManager sharedInstance].cancelGresourceCheck) {
        [[Plugin_GresourseManager sharedInstance] GresourseCheckFuntion];//Gresource资源检测更新
    }
    //    [self UpdateAppRequest];        // 软件升级接口
    [self PowerVoiceRequest];   //开机语音请求
    
    [self backgroundLaunchImageRequest]; //开机图片后台请求判断是否过期
    
    [[MWDialectDownloadManage sharedInstance] RequestDialectURLWithID:0 requestType:RT_DialectUpdate];//方言升级检测
    
    [self MainNewRequest];  //开机new图标请求
}

//软件版本升级检测
- (void)softWareVersionUpdateRequest
{
//#if PROJECTMODE
//    //    [self showLoadingViewInView:STR(@"Setting_CheckingUpdate", @"Setting") view:self.view];
//    [[GDBL_LaunchRequest sharedInstance] Net_UpdateAppWithControl:self withRequestType:REQ_UPDATE_APP];
//#else
    
    [[GDBL_LaunchRequest sharedInstance] Net_SoftVersionUpdateRequest:self  withRequestType:RT_LaunchRequest_SoftWareUpdate];
    
//#endif
    
}
#pragma mark request method
- (void)crashLogUploadRequest
{
    postCrashLog = [[LogCommit alloc] init] ;
    [postCrashLog logRequest];
    
}
- (void)UserYawCountRequest
{
    if ([[GDBL_UserBehaviorCountNew shareInstance].PathYawCount count] > 0) {
        
        [[GDBL_LaunchRequest sharedInstance] Net_UserYawCountRequest:self withRequestType:RT_LaunchRequest_UserYawUpload];
    }
}
- (void)onlineEnableRequest
{
    [[GDBL_LaunchRequest sharedInstance] Net_NetWorkSwitchControlRequest:self withRequestType:RT_Background_SwitchOnOff];
}
- (void)UserBehaviorCountRequest
{
    //上传用户行为统计数据
    //    [GDBL_UserBehaviorCountNew shareInstance].openNavigation ++;//用户数据上传比函数applicationDidBecomeActive更快，因此会造成刚进程序的那一次无法统计
    [[GDBL_UserBehaviorCountNew shareInstance] timeCount];
    if([GDBL_UserBehaviorCountNew shareInstance].openNavigation == 0)
    {
        return ;
    }
    //统计时间
    //导航
    if ([GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds_InPath != 0) {
        [MobClick event:UM_EVENTID_NAVI_VIEW_TIME label:UM_LABEL_NORTH_UP durations:([GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds_InPath * 60 * 1000)];
    }
    if([GDBL_UserBehaviorCountNew shareInstance].upViewSeconds_InPath != 0)
    {
        [MobClick event:UM_EVENTID_NAVI_VIEW_TIME label:UM_LABEL_HEADING durations:([GDBL_UserBehaviorCountNew shareInstance].upViewSeconds_InPath * 60 * 1000)];
    }
    if ([GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds_InPath != 0) {
        [MobClick event:UM_EVENTID_NAVI_VIEW_TIME label:UM_LABEL_3D durations:([GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds_InPath * 60 * 1000)];
    }
    
    //巡航
    if([GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds != 0)
    {
        [MobClick event:UM_EVENTID_CRUISE_VIEW_TIME label:UM_LABEL_NORTH_UP durations:([GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds * 60 * 1000)];
    }
    if ([GDBL_UserBehaviorCountNew shareInstance].upViewSeconds != 0) {
        [MobClick event:UM_EVENTID_CRUISE_VIEW_TIME label:UM_LABEL_HEADING durations:([GDBL_UserBehaviorCountNew shareInstance].upViewSeconds * 60 * 1000)];
    }
    if ([GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds != 0) {
        [MobClick event:UM_EVENTID_CRUISE_VIEW_TIME label:UM_LABEL_3D durations:([GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds * 60 * 1000)];
    }
    if([GDBL_UserBehaviorCountNew shareInstance].TMCTime != 0)
    {
        [MobClick event:UM_EVENTID_TRAFFIC_TIME durations:([GDBL_UserBehaviorCountNew shareInstance].TMCTime * 1000)];
    }
    
    [[GDBL_LaunchRequest sharedInstance] Net_UserBehaviorCountRequest:self withRequestType:RT_LaunchRequest_UBC];
}
- (void)DataUpdateRequest
{
    
    //[[Plugin_TravelRequestUpdate sharedInstance] Plugin_Travel_Update_Request];//旅游数据升级检测
    
    [[GDBL_LaunchRequest sharedInstance] Net_MapUpdateRequest:self withRequestType:RT_LaunchRequest_MapUpgrade];//地图数据升级检测
    
}

- (void)UploadToken
{
    NSNumber *sign = [[NSUserDefaults standardUserDefaults] objectForKey:MWUploadTokenSuccess];
    if (![sign boolValue])
    {
        NSString *str = [[ANDataSource sharedInstance] GMD_getDeviceAndOSInfo];
        [[GDBL_LaunchRequest sharedInstance] Net_UploadTokenWithControl:self uuid:deviceID token:deviceTokenEx softversion:[NSString stringWithFormat:@"%.1f",SOFTVERSIONNUM] devicetype:str withRequestType:RT_Upload_Token];
    }
}

- (void)UploadTokenToAutonavi:(NSString *)token
{
    NSNumber *sign = [[NSUserDefaults standardUserDefaults] objectForKey:MWUploadTokenAutoNaviSuccess];
    if (![sign boolValue])
    {
        [[GDBL_LaunchRequest sharedInstance] Net_UploadTokenWithControl:self uuid:deviceID token:token withRequestType:RT_Upload_Token_To_Autonavi];
    }
}

- (void)UploadLocationInfo;//上传位置信息至后台
{
    if ([[MWPreference sharedInstance] getValue:PREF_UPLOADLOCATION])
    {
        [[GDBL_LaunchRequest sharedInstance] Net_UploadLocationInfoWithControl:self withRequestType:REQ_UPLOAD_LOCATIONINFO];
    }
}

/**
 *	软件升级接口，成功时返回的数据result为字典（NSDictonary）  如下示例
 key                value类型                 value示例
 
 @"Result"          NSNumber             [NSNumber numberWithBool:YES]
 @"UpdateCommand"   Nsstring             @"itms-services://?action=download-manifest&amp;url=http://210.13.211.107:8083/ipa.plist"
 
 */
- (void)UpdateAppRequest
{
    [[GDBL_LaunchRequest sharedInstance] Net_UpdateAppWithControl:self withRequestType:REQ_UPDATE_APP];
}

- (void)PowerVoiceRequest
{
    [[GDBL_LaunchRequest sharedInstance] NET_PowerVoiceRequest:self withRequestType:RT_PowerVoiceRequest];
}

- (void)backgroundLaunchImageRequest
{
    [[GDBL_LaunchRequest sharedInstance] NET_BackgroundLaunchImageRequest:self withRequestType:RT_Background_launchImageRequest];
}

- (void)MainNewRequest
{
    [_skinAndCarRequest Net_NewRequest:REQ_SKIN_NEW delegate:self];
    [_skinAndCarRequest Net_NewRequest:REQ_CAR_NEW delegate:self];
}



#pragma mark -
#pragma mark ==NetReqToViewCtrDelegate request===
- (void)requestToViewCtrWithRequestType:(RequestType)requestType didFinishLoadingWithResult:(id)result{
    if (!result) {
        return;
    }
    if (REQ_UPLOAD_LOCATIONINFO == requestType)
    {
        NSString *tmp = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
        if ([tmp rangeOfString:@"<Result>OK</Result>"].length > 0)
        {
            [[MWPreference sharedInstance] setValue:PREF_UPLOADLOCATION Value:0];
        }
        [tmp release];
    }
    else if (RT_Upload_Token_To_Autonavi == requestType)
    {
        NSString *tmp = [[NSString alloc] initWithData:result encoding:0x80000632];
        if ([tmp rangeOfString:@"<rsptype>OK</rsptype>"].length > 0 || [tmp rangeOfString:@"<rspcode>1011</rspcode>"].length > 0)
        {
            [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:YES] forKey:MWUploadTokenAutoNaviSuccess];
        }
        [tmp release];
    }
    else if (RT_Upload_Token == requestType)
    {
        NSString *tmp = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
        if ([tmp rangeOfString:@"<Result>SUCCESS</Result>"].length > 0)
        {
            [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:YES] forKey:MWUploadTokenSuccess];
        }
        [tmp release];
    }
    else if (RT_LaunchRequest_MapUpgrade == requestType) {//地图数据升级检测
        NSString *tmp = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
        NSLog(@"数据升级检测结果：%@",tmp);
        NSString *updateUrl = [NSString stringWithFormat:@"%@",[tmp CutFromNSString:@"<Updateurl>" Tostring:@"</Updateurl>"]];
        NSString *curVersion = [NSString stringWithFormat:@"%@",[tmp CutFromNSString:@"<Version>" Tostring:@"</Version>"]];        //服务器地图版本
        NSString *localVersion = [[ANDataSource sharedInstance] GMD_GetVersionInfoWithMainID:1];//获取本地地图数据版本
        NSString *EngineVersion = [[ANDataSource sharedInstance] GMD_GetVersionInfoWithMainID:2];//获取引擎版本
        
        GVERSION pEngineVersion ={0};
        GVERSION pServiceMapVersion = {0};
        GVERSION pMapVersion ={0};
        GVERCHECKRESULT pResult= {0};
        GVERCHECKRESULT pResult1 = {0};
        
        memcpy(pServiceMapVersion.szVersion,NSSTRING_TO_CSTRING(curVersion),strlen(NSSTRING_TO_CSTRING(curVersion)));
        memcpy(pMapVersion.szVersion,NSSTRING_TO_CSTRING(localVersion),strlen(NSSTRING_TO_CSTRING(localVersion)));
        memcpy(pEngineVersion.szVersion,NSSTRING_TO_CSTRING(EngineVersion),strlen(NSSTRING_TO_CSTRING(EngineVersion)));
        NSString *str = [NSString stringWithUTF8String:pServiceMapVersion.szVersion ];
        NSArray *array = [str componentsSeparatedByString:@"."];
        NSArray *array_first;
        if (array && [array count] > 3) {
            array_first = [[array objectAtIndex:0] componentsSeparatedByString:@" "];
            pServiceMapVersion.nData1 = [[array_first objectAtIndex:1] intValue];
            pServiceMapVersion.nData2 = [[array objectAtIndex:1] intValue];
            pServiceMapVersion.nData3 = [[array objectAtIndex:2] intValue];
            pServiceMapVersion.nData4 = [[array objectAtIndex:3] intValue];
        }
        
        str = [NSString stringWithUTF8String:pEngineVersion.szVersion ];
        array = [str componentsSeparatedByString:@"."];
        if (array && [array count] > 3) {
            array_first = [[array objectAtIndex:0] componentsSeparatedByString:@" "];
            pEngineVersion.nData1 = [[array_first objectAtIndex:1] intValue];
            pEngineVersion.nData2 = [[array objectAtIndex:1] intValue];
            pEngineVersion.nData3 = [[array objectAtIndex:2] intValue];
            pEngineVersion.nData4 = [[array objectAtIndex:3] intValue];
        }
        
        str = [NSString stringWithUTF8String:pMapVersion.szVersion ];
        array = [str componentsSeparatedByString:@"."];
        if (array && [array count] > 3) {
            array_first = [[array objectAtIndex:0] componentsSeparatedByString:@" "];
            pMapVersion.nData1 = [[array_first objectAtIndex:1] intValue];
            pMapVersion.nData2 = [[array objectAtIndex:1] intValue];
            pMapVersion.nData3 = [[array objectAtIndex:2] intValue];
            pMapVersion.nData4 = [[array objectAtIndex:3] intValue];
        }
        
        GDBL_MapMapVerCompare(&pServiceMapVersion,&pMapVersion,&pResult);
        GDBL_EngineMapVerCompare(&pEngineVersion,&pMapVersion,&pResult1);
        
        [[MWPreference sharedInstance] setValue:PREF_UPGRADEMONTH Value:[[MWPreference sharedInstance] getValue:PREF_CURRENTMONTH]];
        if(pResult == GVERSION_NEWER && pResult1 == GVERSION_SAME)
        { //地图数据版本较旧
            
            
            NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:1],@"checkResult",updateUrl,@"updateUrl",curVersion,@"curVersion",nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_MapDataUpdate] userInfo:dic];
            [dic release];
        }
        else if (pResult == GVERSION_OLDER || pResult == GVERSION_SAME )//地图数据为最新的
        {
            
            NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:0],@"checkResult",nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_MapDataUpdate] userInfo:dic];
            [dic release];
        }
        else if (pResult1 == GVERSION_OLDER)//地图数据与引擎不匹配
        {
            
            NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:2],@"checkResult",nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_MapDataUpdate] userInfo:dic];
            [dic release];
        }
        [tmp release];
        
    }
    else if (RT_LaunchRequest_UserYawUpload == requestType)//用户偏航数据上传
    {
        NSString *tmp = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
        NSString *result = [tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"];
        
        if ([result isEqualToString:@"SUCCESS"] )
        {
            [[GDBL_UserBehaviorCountNew shareInstance] resetPathYawData];//如果上传成功重置数据
            
        }
        [tmp release];
    }
    else if (RT_LaunchRequest_SoftWareUpdate == requestType)//软件版本升级
    {
        NSString *tmp = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
        NSLog(@"软件升级：%@",tmp);
        NSString *result = [tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"];
        NSString *version_Cmp = [tmp CutFromNSString:@"<Version_Cmp>" Tostring:@"</Version_Cmp>"];
        
        
        if ([result isEqualToString:@"SUCCESS"] && [version_Cmp isEqualToString:@"FALSE"])//有新版本
        {
            
            NSString *newVersion = [tmp CutFromNSString:@"<Version_Newest>" Tostring:@"</Version_Newest>"];
            
            NSString *updateVersion = [[NSUserDefaults standardUserDefaults] valueForKey:MWSoftWareUpdateReminderKey];
            if ([newVersion isEqualToString:updateVersion]) {
                return;
            }
            
            NSString *versionDetail = [tmp CutFromNSString:@"<Describe>" Tostring:@"</Describe>"];
            NSString *message=[NSString stringWithFormat:@"%@",versionDetail];
            GDAlertView *alertView = [[[GDAlertView alloc] initWithTitle:STR(@"Setting_NewVersion",@"Setting") andMessage:message]autorelease];
            
            
            [alertView addButtonWithTitle:STR(@"Setting_UpdateSure",@"Setting") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView){
                
                [ANOperateMethod rateToAppStore:0];
                
            }];
            [alertView addButtonWithTitle:STR(@"Setting_NoPrompt", @"Setting") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView* alertView){
                
                [[NSUserDefaults standardUserDefaults] setValue:(newVersion ? newVersion : @"") forKey:MWSoftWareUpdateReminderKey];
            }];
            [alertView addButtonWithTitle:STR(@"Setting_RemindMeLater",@"Setting") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView){
            }];
            [alertView show];
            
        }
        [tmp release];
    }
    else if(RT_Background_SwitchOnOff == requestType) // 后台服务功能开关接口
    {
        //返回的数据处理，返回的是字典数据
        //key —— 功能id
        //value —— NSArray(2) —— index 0：开关的状态  index 1：功能名称
        NSDictionary *dict = ((NSDictionary *)result);
        if ([dict objectForKey:@"GD001"] && [[dict objectForKey:@"GD001"] count] > 0) {
            [ANParamValue sharedInstance].netWorkMap = [[[dict objectForKey:@"GD001"] objectAtIndex:0] intValue];
        }
        if ([dict objectForKey:@"GD003"] && [[dict objectForKey:@"GD003"] count] > 0) {
            [ANParamValue sharedInstance].realTimeTrafficNWSwitch = [[[dict objectForKey:@"GD003"] objectAtIndex:0] intValue];
        }
        if ([dict objectForKey:@"GD004"] && [[dict objectForKey:@"GD004"] count] > 0) {
            [ANParamValue sharedInstance].trafficBroadcastNWSwitch = [[[dict objectForKey:@"GD004"] objectAtIndex:0] intValue];
        }
        if ([dict objectForKey:@"GD005"] && [[dict objectForKey:@"GD005"] count] > 0) {
            [ANParamValue sharedInstance].realTimeTrafficInfoNWSwitch = [[[dict objectForKey:@"GD005"] objectAtIndex:0] intValue];
        }
        if ([dict objectForKey:@"GD006"] && [[dict objectForKey:@"GD006"] count] > 0) {
            [ANParamValue sharedInstance].netWorkSearchNWSwitch = [[[dict objectForKey:@"GD006"] objectAtIndex:0] intValue];
        }
        if ([dict objectForKey:@"GD007"] && [[dict objectForKey:@"GD007"] count] > 0) {
            [ANParamValue sharedInstance].ctripOnlineNWSwitch = [[[dict objectForKey:@"GD007"] objectAtIndex:0] intValue];
        }
        if ([dict objectForKey:@"GD008"] && [[dict objectForKey:@"GD008"] count] > 0) {
            [ANParamValue sharedInstance].repastNWSwitch = [[[dict objectForKey:@"GD008"] objectAtIndex:0] intValue];
        }
        if ([dict objectForKey:@"GD009"] && [[dict objectForKey:@"GD009"] count] > 0) {
            [ANParamValue sharedInstance].golfNWSwitch = [[[dict objectForKey:@"GD009"] objectAtIndex:0] intValue];
        }
    }
    else if (RT_LaunchRequest_UBC == requestType)
    {
        
        NSString *tmp = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
        NSString *m_result = [tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"];
        if ([m_result isEqualToString:@"SUCCESS"]) {
            [[GDBL_UserBehaviorCountNew shareInstance] resetData];//如果上传成功重置数据
            [[GDBL_UserBehaviorCountNew shareInstance] saveData];
        }
        [tmp release];
    }
    else if(requestType==REQ_UPDATE_APP)
    {
        
        if ([[result objectForKey:@"Result"] intValue]==1) {
            NSString *describe = [result objectForKey:@"Describe"];
            GDAlertView *alertView =nil;
            if (describe.length>1) {
                alertView= [[[GDAlertView alloc] initWithTitle:STR(@"Setting_NewVersion",@"Setting") andMessage:describe]autorelease];
            }
            else
            {
                alertView= [[[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Setting_NewVersion",@"Setting")]autorelease];
            }
            
            [alertView addButtonWithTitle:STR(@"Setting_UpdateCancel",@"Setting") type:GDAlertViewButtonTypeCancel handler:nil];
            NSString *command=[result objectForKey:@"UpdateCommand"] ;
            [alertView addButtonWithTitle:STR(@"Setting_UpdateSure",@"Setting") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView){
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:command]];
                
            }];
            [alertView show];
            
        }
        
        
    }
    else if (requestType == RT_PowerVoiceRequest)
    {
        NSString *tmp = [[NSString alloc] initWithData:((NSData *)result) encoding:NSUTF8StringEncoding];
        
        if([[tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"] isEqualToString:@"SUCCESS"])
        {
            NSString *voiceUrl = [tmp CutFromNSString:@"<url>" Tostring:@"</url>"];
            
            NSLog(@"开机语音下载地址：%@",voiceUrl);
            
            if (voiceUrl && [voiceUrl length] > 0)
            {
                self.powerVoiceExpired = [tmp CutFromNSString:@"<expired>" Tostring:@"</expired>"];
                
                self.powerVoiceID = [[tmp CutFromNSString:@"<id>" Tostring:@"</id>"] intValue];
                
                if ([[MWPreference sharedInstance] getValue:PREF_POWERVOICEID] != self.powerVoiceID){
                    
                    [[GDBL_LaunchRequest sharedInstance] NET_PowerVoiceDownload:self WithRequestType:RT_PowerVoiceDownload DownloadUrl:voiceUrl];
                }
                
                
            }
        }
        else{
            
        }
        
    }
    else if (requestType == RT_PowerVoiceDownload)
    {
        [[MWPreference sharedInstance] setValue:PREF_IS_POWERVOICE_PLAY Value:NO];
        [[MWPreference sharedInstance] setValue:PREF_POWERVOICEID Value:self.powerVoiceID];
        
        [[GDCacheManager globalCache] setData:result forKey:GDCacheType_PowerVoice withTimeoutString:@"2222-01-15"];//设置不过期
    }
    else if (requestType == RT_Background_launchImageRequest)
    {
        NSString *tmp = [[NSString alloc] initWithData:((NSData *)result) encoding:NSUTF8StringEncoding];
        
        if([[tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"] isEqualToString:@"SUCCESS"])
        {
            NSString *imageUrl = [tmp CutFromNSString:@"<url>" Tostring:@"</url>"];
            
            NSLog(@"开机图片下载地址：%@",imageUrl);
            
            if (imageUrl && [imageUrl length] > 0)
            {
                self.launchImageExpired = [tmp CutFromNSString:@"<expired>" Tostring:@"</expired>"];
                
                if (![[GDCacheManager globalCache] isSameForDateWithString:self.launchImageExpired Key:GDCacheType_LaunchImage]){
                    
                    [[GDBL_LaunchRequest sharedInstance] NET_BackgroundLaunchImageDownload:self WithRequestType:RT_Background_launchImageDownload DownloadUrl:imageUrl];
                }
                
                
            }
        }
        else{
            
        }
        
    }
    else if (requestType == RT_Background_launchImageDownload)
    {

        [[GDCacheManager globalCache] setData:result forKey:GDCacheType_LaunchImage withTimeoutString:self.launchImageExpired];
    }
    else if(requestType == REQ_SKIN_NEW)    //皮肤new请求类型
    {
        NSArray *array = (NSArray *)result;
        [[GDNewJudge sharedInstance] addObjectWithType:NEW_JUDGE_SKIN_TYPE withArray:array];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_SkinNew] userInfo:nil];
    }
    else if(requestType == REQ_CAR_NEW)
    {
        NSArray *array = (NSArray *)result;
        [[GDNewJudge sharedInstance] addObjectWithType:NEW_JUDGE_CAR_TYPE withArray:array];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_CarNew] userInfo:nil];
    }
    
}

- (void)requestToViewCtrWithRequestType:(RequestType)requestType didFailWithError:(NSError *)error{
    if (RT_LaunchRequest_MapUpgrade == requestType) {//地图数据升级检测
        
        NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:3],@"checkResult",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_MapDataUpdate] userInfo:dic];
        [dic release];
    }    
}

#pragma  mark UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (alertView.tag) {
        case LAUNCH_ALERT_SCORE:
        {
            switch (buttonIndex)
			{
				case 0://现在评价
				{
                    [ANOperateMethod rateToAppStore:1];
                    [[MWPreference sharedInstance]  setValue:PREF_NEXT_HIGHTPRAISE_COUNT
                                                       Value:2];
				}
					break;
					
				case 1://下次评价
				{
                    [[MWPreference sharedInstance]  setValue:PREF_NEXT_HIGHTPRAISE_COUNT
                                                       Value:([[MWPreference sharedInstance] getValue:PREF_NEXT_HIGHTPRAISE_COUNT]+1)];
				}
					break;
                case 2://不再评价
                {
                    [[MWPreference sharedInstance]  setValue:PREF_NEXT_HIGHTPRAISE_COUNT
                                                       Value:2];
                }
                    break;
                default:
					break;
			}
            
        }
            break;
            
            
        default:
            break;
    }
    
    
}

@end
