//
//  ANOperateMethod.m
//  AutoNavi
//
//  Created by GHY on 12-3-1.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//


#import "ANOperateMethod.h"
#import "ANDataSource.h"
#import "ANParamValue.h"
#import "PublicDefine.h"
#import "DefineNotificationParam.h"
#include <sys/xattr.h>
#import "Global.h"
#import "Utility.h"
#import "mapDataManage.h"
#include <sys/types.h>
#include <sys/sysctl.h>
#import"sys/utsname.h"
#import "GDBL_Account.h"
#import "Plugin_OnLineMapUtility.h"
#import "GDBL_Location.h"
#import "TrafficEventReport.h"
#import "TrafficEventManager.h"
#import "MWMapOperator.h"
#import "MWGuideOperator.h"
#import	<CoreMotion/CoreMotion.h>
#import "MWSearchResult.h"
#import "POICommon.h"
#import "MWTMCRequest.h"
#import "QLoadingView.h"
#import "GDBL_TTS.h"
#import "CustomRealTimeTraffic.h"
#import "CustomTrafficPlaySound.h"
#import "MWTMCRequest.h"
#import "UMengEventDefine.h"

#import <AudioToolbox/AudioToolbox.h>

@interface ANOperateMethod()

@property (nonatomic,retain) id mainControllDelegate;
@end

static ANOperateMethod *sharedANOperateMethod = nil;

static BOOL fun(void)
{
    return YES;
}

@implementation ANOperateMethod

@synthesize localizeType,mainControllDelegate;

#pragma mark 单例
+ (ANOperateMethod *)sharedInstance {
	
	if (nil==sharedANOperateMethod)
	{
		sharedANOperateMethod = [[ANOperateMethod alloc] init];
	}
	return sharedANOperateMethod;
}

- (id)init {
	
	self = [super init];
	if (self)
	{
       
	}
	return self;
}

/**********************************************************************
 * 函数名称: GMD_SetVoicePlayType
 * 功能描述: 设置地图类型
 * 输入参数: int voiceType 0：播报本地语音 1：播报网络地图语音 2:本网结合
 * 输出参数:
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2013/03/27        1.0			黄龙锋
 **********************************************************************/
- (int)GMD_SetVoicePlayType:(int)voiceType
{
    GSTATUS res;
    res = GDBL_SetVoicePlayType(voiceType);
    return res;
}
/**********************************************************************
 * 函数名称: GMD_GetVoicePlayType
 * 功能描述: 获取语音播报类型
 * 输入参数:
 * 输出参数: 0：播报本地语音 1：播报网络地图语音 2:本网结合
 * 返 回 值: 返回地图类型
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2013/03/27        1.0			黄龙锋
 **********************************************************************/
- (int)GMD_GetVoicePlayType
{
    return GDBL_GetVoicePlayType();
}

#pragma mark -
#pragma mark  公交:起点－终点==================================================================

#pragma mark 保存公交历史目的地(当前点)
- (void)GMD_SetBusEndingPointWithMainID {
	
	//获取地图中心信息
    GMAPCENTERINFO mapinfo = {0};
    [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
	
	GPOI PointInfo = {0};
	PointInfo.Coord = mapinfo.CenterCoord;
	strcpy(PointInfo.szName, mapinfo.szRoadName);
    
	[[ANParamValue sharedInstance] setAddHistory:YES];
	[[ANDataSource sharedInstance] GetNearPOI:GMAP_VIEW_TYPE_MAIN];
}
#pragma mark 保存公交历史目的地(指定点)
- (void)GMD_SetBusEndingPointWithLon:(int)lon Lat:(int)lat RoadName:(char *)roadName {
    
    NSString *town = [[[ANDataSource sharedInstance] GMD_CoordToAreaInfo:lon Lat:lat] objectForKey:@"town"];
    [[ANParamValue sharedInstance] setBusEndingPoint:[NSDictionary dictionaryWithObjectsAndKeys:
                                                      [NSString chinaFontStringWithCString:roadName],@"name",
                                                      town,@"town",nil]];
    
}

#pragma mark 其他操作==========================================================================

#pragma mark 回家
- (BOOL)GMD_GoHome {
	
	GFAVORITEPOILIST  *ppFavoritePOIList = {0};
	
	GSTATUS res;
	res = GDBL_GetFavoriteList(1, &ppFavoritePOIList);
	if (res!=0)
	{
		return NO;
	}
    
	[[MWGuideOperator sharedInstance] MW_SetDesPointWithMainID:6 POI:ppFavoritePOIList->pFavoritePOI[0].Poi];
	return YES;
}

#pragma mark 回公司
- (BOOL)GMD_GoCompany {
	
	GFAVORITEPOILIST  *ppFavoritePOIList = {0};
	
	GSTATUS res;
	res = GDBL_GetFavoriteList(2, &ppFavoritePOIList);
	if (res!=0)
	{
		return NO;
	}
    
    [[MWGuideOperator sharedInstance] MW_SetDesPointWithMainID:6 POI:ppFavoritePOIList->pFavoritePOI[0].Poi];
    
	return YES;
}

//#pragma mark 通过微享编码启动导航
//- (id)GMD_StartWithID:(NSInteger)ID Lon:(long long)lLon Lat:(long long)lLat {
//	
//	static long long lon = 0;
//	static long long lat = 0;
//	
//	switch (ID)
//	{
//		case 0:
//		{
//			[[MWMapOperator sharedInstance] MW_SetMapOperateType:20];//通过微享编码启动导航(流程)
//		}
//			break;
//			
//		case 1:
//		{
//			[[MWMapOperator sharedInstance] MW_SetMapOperateType:21];//通过微享编码启动导航(流程)
//		}
//			break;
//			
//		case 20:
//		{
//			[[ANOperateMethod sharedInstance] GMD_MoveMapWithType:0 Lon:lon Lat:lat];//通过微享编码启动导航(设终点)
//		}
//			break;
//			
//		case 21:
//		{
//            
//			GMOVEMAP moveMap;
//            moveMap.eOP = MOVEMAP_OP_GEO_DIRECT;
//            moveMap.deltaCoord.x = lon;
//            moveMap.deltaCoord.y = lat;
//            [[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
//			NSLog(@"MOVE=%lld,%lld",lon,lat);
//            
//		}
//			break;
//			
//		default:
//			break;
//	}
//	
//	lon = lLon;
//	lat = lLat;
//	
//	return [NSNumber numberWithBool:YES];
//}

#pragma mark 设置相应的目录不备份
-(void)GMD_BackUp
{
	NSURL *url;
    url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",document_path]];
    
    //    if(&NSURLIsExcludedFromBackupKey == nil)// iOS <= 5.0.1
    {
        const char* filePath = [[url path] fileSystemRepresentation];
        const char* attrName = "com.apple.MobileBackup";
        u_int8_t attrValue = 1;
        setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
    }
    //   else// iOS >= 5.1
    //    {
    //        NSError *error = nil;
    //       [url setResourceValue:[NSNumber numberWithBool:YES] forKey:NSURLIsExcludedFromBackupKey error:&error];
    //    }
}

#pragma mark 软件升级的情况一体化数据里面的资源重新解压
-(void)GMD_UnZipLogic
{
    NSLog(@"GMD_UnZipLogic");
    NSString *tmpPath = [NSString stringWithFormat:@"%@/%s",document_path,FILE_NAME];
    NSString *filePath = @"";
    filePath = [filePath stringByAppendingPathComponent:[NSString stringWithFormat:@"%s",g_data_path]];
    if([[NSFileManager defaultManager] fileExistsAtPath:tmpPath])
    {
        if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%s",g_data_path]])
        {
            [mapDataManage setMapDataType:self dataType:1];
        }
        if ([[Utility GetMapVersion] isEqualToString:[MWPreference sharedInstance].mapVersion])
        {
            if (![[NSFileManager defaultManager] fileExistsAtPath:filePath])
            {
                BOOL indexReadSuc = [mapDataManage initMapDataWithPath:tmpPath dataType:1];
                if (indexReadSuc) {
                    [mapDataManage readResourceToPath:[NSString stringWithFormat:@"%@/res.gdzip",document_path]];
                }
            }
        }
        else
        {
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%s",g_data_path]])
            {
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%s",g_data_path] error:nil];
            }
            BOOL indexReadSuc = [mapDataManage initMapDataWithPath:tmpPath dataType:1];
            if (indexReadSuc) {
                [mapDataManage readResourceToPath:[NSString stringWithFormat:@"%@/res.gdzip",document_path]];
            }
        }
        
    }
    NSLog(@"endGMD_UnZipLogic");
}

- (BOOL)Copy_I4_to_I5  //document下若无iPhone5文件夹,创建iPhone5文件夹，将document下iPhone4文件夹数据,复制至iPhone5
{
    NSString *iphone5_path = [document_path stringByAppendingString:@"/iPhone5"];
    NSString *iphone4_path = [document_path stringByAppendingString:@"/iPhone4"];
    NSError *error = nil;
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:iphone5_path])
    {
        BOOL sign =[[NSFileManager defaultManager]   createDirectoryAtPath:iphone5_path  withIntermediateDirectories:NO attributes:nil error:&error];
        if (sign)
        {
            if([[NSFileManager defaultManager] fileExistsAtPath:iphone4_path])
            {
                NSFileManager *file_manager = [NSFileManager defaultManager];
                NSArray *array = [file_manager contentsOfDirectoryAtPath:iphone4_path error:&error];
                for (int i = 0; i < [array count]; i ++)
                {
                    [file_manager copyItemAtPath:[iphone4_path stringByAppendingFormat:@"/%@",[array objectAtIndex:i]] toPath:[iphone5_path stringByAppendingFormat:@"/%@",[array objectAtIndex:i]] error:&error];
                    if (error)
                    {
                        return NO;
                    }
                }
                return YES;
            }
        }
    }
    return NO;
}

#pragma mark 根据当前机型，将bundle中的Gconfig移动到document下Documents/iPhone3/GNaviRes/Gconfig.dat (或者ipad，iphone4，newpad)
-(BOOL)GMD_Gconfig_Change_Path
{
    NSLog(@"GMD_Gconfig_Change_Path");
    NSString *g_path = [NSString stringWithUTF8String:g_data_path];
    NSRange range = [g_path rangeOfString:@"Documents/"];
    g_path = [g_path substringFromIndex:range.location + range.length];
    g_path = [g_path substringToIndex:[g_path length] - 1];
    if ([g_path isEqualToString:@"iPhone5"])
    {
        [self Copy_I4_to_I5];
    }
    NSString *path1 = [[NSBundle mainBundle] pathForResource:@"Gconfig" ofType:@"dat" inDirectory:g_path];
    
    char tmp_path[1024];
    memset(tmp_path, 0, 1024);
    sprintf(tmp_path, "%sGNaviRes/Gconfig.dat",g_data_path);
    NSString *path2 = [NSString stringWithUTF8String:tmp_path];
    
    NSError *error = nil;
    if([[NSFileManager defaultManager] fileExistsAtPath:path1])
    {
        if([[NSFileManager defaultManager] fileExistsAtPath:path2])
        {
            [[NSFileManager defaultManager] removeItemAtPath:path2 error:&error];
        }
        [[NSFileManager defaultManager] copyItemAtPath:path1 toPath:path2 error:&error];
        
    }
    if (error)
    {
        NSLog(@"errorGMD_Gconfig_Change_Path");
        return NO;
    }
    NSLog(@"endGMD_Gconfig_Change_Path");
    return YES;
}


#pragma mark 关闭plainmapmode
-(BOOL)GMD_ClosePlainMap
{
    if (NO == [[ANParamValue sharedInstance] isInit])
    {
        return NO;
    }
    Gbool status= Gtrue;
	GDBL_SetParam(G_MAP_SHOW_CURSOR, &status);
    Gbool showPlain = Gfalse;
    GDBL_SetParam(G_MAP_SHOW_PLAIN_MODE, &showPlain);
    return YES;
}

#pragma mark 拨打95190
- (void)getListenMessage:(NSNotification *)notify
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_ACCOUNT object:nil];
    NSArray* result = (NSArray*)[notify object];
    int requestType=[[result objectAtIndex:1] intValue];
	if (result==nil||[result count]<3)
    {
        if(requestType == REQ_PRE_CALL_95190)
        {
            NSLog(@"pre_call fail");
        }
		return;
	}
    
    NSString *notifyName =[notify name];
	if ([notifyName isEqual:NOTIFY_ACCOUNT])
    {
		if ([[result objectAtIndex:0] isEqual:PARSE_OK])
        {
            if(requestType == REQ_PRE_CALL_95190)
            {
                
                int nResult = [[result objectAtIndex:2] intValue];
                if (nResult == GD_ERR_OK)
                {
                    NSLog(@"pre_call success");
                }
                else
                {
                    NSLog(@"pre_call fail");
                }
            }
        }
        
    }
}

-(void)GMD_Call_95190:(NSString *)phone
{
    
    [ANParamValue sharedInstance].isReq95190Des = 1;
    NSURL *telURL = [NSURL URLWithString:[NSString stringWithFormat:@"telprompt://%@",phone]];
    [[UIApplication sharedApplication] openURL:telURL];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getListenMessage:) name:NOTIFY_ACCOUNT object:nil];
}

#pragma mark 将view转化成镜子中的view显示
- (void)GMD_ChangeTomirrorViewInView:(UIView *)view isSwitch:(BOOL)isSwitch
{
    static UIImageView *mirror_view = nil;
    if (view == nil)
    {
        if (mirror_view != nil)
        {
            [mirror_view removeFromSuperview];
            [mirror_view release];
            mirror_view = nil;
        }
        return;
    }

    if (mirror_view == nil)
    {
        mirror_view = [[UIImageView alloc] initWithFrame:view.bounds];
    }
    else
    {
        [mirror_view removeFromSuperview];
    }
    
    if(!isSwitch)
    {
        [mirror_view removeFromSuperview];
        [mirror_view release];
        mirror_view = nil;
        return;
    }
    
    mirror_view.frame = view.bounds;
    mirror_view.center = CGPointMake(view.bounds.size.width/2, view.bounds.size.height/2);
//    CGAffineTransform trans = CGAffineTransformMakeRotation(M_PI);
//    [mirror_view setTransform:trans];
    
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.opaque, 0); //高清下scale为2，否则为1
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSaveGState(context);
    
    CGContextTranslateCTM(context, 0,view.bounds.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
        
    [view.layer renderInContext:context];
    mirror_view.image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    [view addSubview:mirror_view];
    [view bringSubviewToFront:mirror_view];
}

#pragma mark 设置系统语言
-(BOOL)GMD_SetSystemLanguage:(BOOL)isEngineInit
{
    if (isEngineInit) {//引擎已初始化
        if (![[MWPreference sharedInstance] getValue:PREF_SETLANGUAGEMANUALLY])
        {
            // UI保存当前的语言选项0简体1繁体2英文
            // en:英文  zh-Hans:简体中文   zh-Hant:繁体中文    ja:日本  ......
            NSUserDefaults* defs = [NSUserDefaults standardUserDefaults];
            NSArray* languages = [defs objectForKey:@"AppleLanguages"];
            NSString* preferredLang = [languages objectAtIndex:0];
            if ([preferredLang isEqualToString:@"zh-Hans"]) {
                [[MWPreference sharedInstance] setValue:PREF_UILANGUAGE Value:0];
            }
            else if([preferredLang isEqualToString:@"zh-Hant"]){
                [[MWPreference sharedInstance] setValue:PREF_UILANGUAGE Value:1];
                
            }else{
                [[MWPreference sharedInstance] setValue:PREF_UILANGUAGE Value:2];
            }
        }
        else{
            localizeType = [[MWPreference sharedInstance] getValue:PREF_UILANGUAGE];
            [[MWPreference sharedInstance] setValue:PREF_UILANGUAGE Value:localizeType];
            [GDBL_TTS GDBL_TTSSetLanguageIndex:localizeType];//主要是为了区分英语和简体、繁体的语音播报资源不同
            
        }
    }
    else{
        if (![[MWPreference sharedInstance] getValue:PREF_SETLANGUAGEMANUALLY])
        {
            // UI保存当前的语言选项0简体1繁体2英文
            // en:英文  zh-Hans:简体中文   zh-Hant:繁体中文    ja:日本  ......
            NSUserDefaults* defs = [NSUserDefaults standardUserDefaults];
            NSArray* languages = [defs objectForKey:@"AppleLanguages"];
            NSString* preferredLang = [languages objectAtIndex:0];
            if ([preferredLang isEqualToString:@"zh-Hans"]) {
                localizeType = 0;
            }
            else if([preferredLang isEqualToString:@"zh-Hant"]){
                localizeType = 1;
                
            }else{
                localizeType = 2;
            }
            
        }
    }
    
    return YES;
}

#pragma mark 设置本地化路径
- (NSString *)GMD_SetLocalizeKey:(NSString *)key table:(NSString *)tableName
{
    NSString *path = nil;
    if (0 == localizeType) {
        path=[[NSBundle mainBundle] pathForResource:@"zh-Hans" ofType:@"lproj"];
    }
    else if (1 == localizeType){
        path=[[NSBundle mainBundle] pathForResource:@"zh-Hant" ofType:@"lproj"];
    }
    else if (2 == localizeType){
        path=[[NSBundle mainBundle] pathForResource:@"en" ofType:@"lproj"];
    }
    
    NSBundle *bundle = [NSBundle bundleWithPath:path];
    NSString *string = [bundle localizedStringForKey:key value:@"" table:tableName];
    return string;
}
#pragma mark 切换平行道路
-(BOOL)GMD_ChangeCarRoad:(int)ParallelID
{
    GSTATUS res = GDBL_ChangeCarRoad(ParallelID);
    if (res == GD_ERR_OK) {
        return YES;
    }
    return NO;
}

#pragma mark 阿拉伯数字转汉字
- (NSString *)ArabToChinese:(int)num
{
    NSArray *array = [NSArray arrayWithObjects:@"零",@"一",@"二",@"三",@"四",@"五",@"六",@"七",@"八",@"九",@"十",nil];
    
    NSString *temp = [NSString string];
    temp = @"方案";
    int ten = num/10;
    if (ten)
    {
        if (ten != 1)
        {
            temp = [temp stringByAppendingString:[array objectAtIndex:ten]];
        }
        temp = [temp stringByAppendingString:@"十"];
    }
    
    int bits = num%10;
    if (bits)
    {
        temp = [temp stringByAppendingString:[array objectAtIndex:bits]];
    }
    temp = [temp stringByAppendingString:@":"];
    
    return temp;
}

-(int)GMD_PassInfoToDrive
{
    if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 1) //使用TBT导航数据
    {
        [[Plugin_OnLineMapUtility sharedInstance] NET_PassInfoToDrive];
    }
    else
    {
        GCARINFO pCarInfo;
        GDBL_GetCarInfo(&pCarInfo);
        
        GGPSINFO pGpsInfo1 = {0};
        GDBL_GetGPSInfo(&pGpsInfo1);
        NSDictionary *tmpNaviInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                     [[ANDataSource sharedInstance] GMD_GetManeuverInfoWithMainID:10],@"roadName",
                                     [[ANDataSource sharedInstance] GMD_GetManeuverInfoWithMainID:1],@"distance",
                                     [NSString stringWithFormat:@"%d",0],@"demospeed",
                                     [NSString stringWithFormat:@"%d",pGpsInfo1.nSpeed],@"speed",
                                     [NSNumber numberWithInt:(450- pCarInfo.nAzimuth)],@"cardirection",
                                     nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_PASSINFOTODRIVE object:nil userInfo:tmpNaviInfo
         ];
        tmpNaviInfo = nil;
    }
    return 0;
}

-(void)GMD_PassInfoToHud
{
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_PASSINFOTOHUD object:nil userInfo:nil
     ];
}

#pragma mark根据行政编码查看是否有地图数据
//flag:0 判断当前所在位置是否有地图数据 1 传入指定行政编码看是否有地图数据
-(int)GMD_checkIsExistData:(long)adminCode flag:(int)bCurrentAdminCode
{
    GADAREAINFOEX areaInfo = {0};
	if (bCurrentAdminCode == 0) {
		long Admin_code;
		Admin_code = [[ANDataSource sharedInstance] GMD_GetCurrentAdmincode];
		if (Admin_code == 0) {
			
			return 0;
		}
        NSLog(@"admincode==%ld",Admin_code);
        GDBL_GetAdareaInfoEx(Admin_code,&areaInfo);
		if (areaInfo.bHasData == 1) {
			
			return 1;
		}
		else {
			
			return 0;
		}
        
	}
	else if(bCurrentAdminCode == 1){
		GDBL_GetAdareaInfoEx(adminCode,&areaInfo);
		if (adminCode == 0)
        {
            return 2;
        }
		return areaInfo.bHasData;
	}
    return 0;
}

#pragma mark -
#pragma mark 判断当前点是否有数据 不判断比例尺
-(int)GMD_CheckExistDataWithLon:(long)lon Lat:(long)lat
{
    if ([mapDataManage getMapDataType] == 1)//一体化数据
    {
        return 0;
    }
    else if ([mapDataManage getMapDataType] == 2)
    {//分城市数据
        int admincode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:lon Lat:lat];
        int sign = [self GMD_checkIsExistData:admincode flag:1];
        if (sign  == 0)
        {//当前区域无数据
            return 1;
        }
        else if (sign == 2)
        {//当前区域处于海
            return 2;
        }
        else
        {
            return 0;
        }
    }
    return 0;
}




#pragma mark 多路线概览点击路线切换高亮,点击图标返回事件，交通流信息,参数number大于0表示点击了图标，touchNumber为－1说明未点击到路径，否则返回相应的路径规划原则
- (NSString *)GMD_guideRouteAndIconTouch:(GMAPVIEWTYPE)mapViewType TouchPoint:(CGPoint)touchPoint Elements:(GEVENTINFO **)elements EventNumber:(int *)number TouchRouteNumber:(int *)touchNumber
{
//    if (![[MWPreference sharedInstance] getValue:PREF_TRAFFICEVENT]) {
//        *touchNumber = -1;
//        *number = 0;
//        return nil;
//    }
    if ([[MWPreference sharedInstance] getValue:PREF_MAPVIEWMODE] == MAP_3D) {
        *touchNumber = -1;
        *number = 0;
        return nil;
    }
    
    NSString *avoidString = @"";
    GHGUIDEROUTE *guideroute = NULL;
    GGUIDEROUTEINFO stGuideRouteInfo = {0};
    Gint32 routeTouchnumber = 0;
    Gint32 iconTouchNumber = 0;
    GSELECTPARAM param = {0};
    
    param.eViewType = mapViewType;
    param.pos.x = touchPoint.x * [ANParamValue sharedInstance].scaleFactor;
    param.pos.y = touchPoint.y * [ANParamValue sharedInstance].scaleFactor;
    
    //点击图标返回信息
    param.eCmd = GSELECT_CMD_EVENT;
    
    GEVENTINFO *eventInfo = {0};
    [[MWGuideOperator sharedInstance] MW_SelectElementsByHit:&param Elements:(void **)&eventInfo NumberOfElements:&iconTouchNumber];
    if (iconTouchNumber > 0) {
        *elements = eventInfo;
        NSString *disFromCar;
        NSString *streamType;
        NSString *impactRange;
        //道路名字
        NSString *roadName = [NSString chinaFontStringWithCString:eventInfo->szOccured];
        
        //车辆距事件，交通流距离
        
        float fDistance = eventInfo->nDisToCar;
        if (fDistance>1000) {
            fDistance = fDistance/1000;
            disFromCar = [NSString stringWithFormat:@"%.2f%@", fDistance,STR(@"Universal_KM", @"Localizable")];
        }else{
            disFromCar = [NSString stringWithFormat:@"%.f%@", fDistance,STR(@"Universal_M", @"Localizable")];
        }
        
        //交通流类型
        int eventID = eventInfo->nEventID > 20 ? ((eventInfo->nEventID >> 16) & 0Xff) : eventInfo->nEventID;
        if (eventID == 2 || eventID == 3) {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_slow", @"TMC")];
        }
        else if(eventID == 4 || eventID == 5)
        {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_congest", @"TMC")];
        }
        else if(eventID == 33)
        {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_accident", @"TMC")];
        }
        else if(eventID == 34)
        {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_underConstruction", @"TMC")];
        }
        else if(eventID == 35)
        {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_trafficControl", @"TMC")];
        }
        else if(eventID == 36)
        {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_roadBarrier", @"TMC")];
        }
        else if(eventID == 37)
        {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_events", @"TMC")];
        }
        else if(eventID == 38)
        {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_disaster", @"TMC")];
        }
        else if(eventID == 39)
        {
            streamType = [NSString stringWithFormat:@"%@" ,STR(@"TMC_badWeather", @"TMC")];
        }
        else{
            streamType = @"";
        }
        //影响范围
        
        float fRange = eventInfo->nEventRange;
        if (fRange>1000) {
            fRange = fRange/1000;
            impactRange = [NSString stringWithFormat:@"%.2f%@", fRange,STR(@"Universal_KM", @"Localizable")];
        }else{
            impactRange = [NSString stringWithFormat:@"%.f%@", fRange,STR(@"Universal_M", @"Localizable")];
        }
        
        avoidString = [NSString stringWithFormat:STR(@"TMC_trafficInfo", @"TMC"),disFromCar,roadName,streamType,impactRange];
        
        NSLog(@"event==%@,ID=%d",avoidString,eventID);
        
        *number = iconTouchNumber;
        return avoidString;
    }
    
    param.eCmd = GSELECT_CMD_ROUTE;
    //点击路线切换
    [[MWGuideOperator sharedInstance] MW_SelectElementsByHit:&param Elements:(void **)&guideroute NumberOfElements:&routeTouchnumber];
    
    
    if (routeTouchnumber > 0)
    {
        int curRule,selectRule;
        GDBL_GetParam(G_ROUTE_OPTION, &curRule);
        
        NSMutableArray *ruleArray = [[NSMutableArray alloc] init];
        for (int i = 0; i < routeTouchnumber; i++) {
            [[MWGuideOperator sharedInstance] MW_GetGuideRouteInfo:guideroute[i] RouteInfo:&stGuideRouteInfo];
            [ruleArray addObject:[NSNumber numberWithInt:stGuideRouteInfo.nRule]];
            
        }
        
        for (NSNumber *i in ruleArray) {
            if ([i intValue] > curRule) {
                selectRule = [i intValue];
                break;
            }
            selectRule = [ruleArray[0] intValue];
        }
        
        GDBL_SetParam(G_ROUTE_OPTION, &selectRule);
        GDBL_SelectRoute(selectRule);
        [[MWMapOperator sharedInstance] MW_ShowMapView:GMAP_VIEW_TYPE_MULTIWHOLE WithParma1:0 WithParma2:0 WithParma3:0];
        *touchNumber = selectRule;
        
    }
    else{
        
        *touchNumber = -1;
    }
    
    *number = iconTouchNumber;
    return avoidString;
}

#pragma mark -
#pragma mark 摇晃切换地图配色

- (void)GMD_SetAccelerometer:(id)delegate
{
    self.mainControllDelegate = delegate;
    /*
    CMMotionManager *motionManager = [[[CMMotionManager alloc] init] autorelease];
    if (motionManager.accelerometerAvailable)
    {
        motionManager.accelerometerUpdateInterval=0.2;
        [motionManager startAccelerometerUpdatesToQueue:[NSOperationQueue currentQueue]
                                            withHandler:^(CMAccelerometerData*accelerometerData,NSError*error)
         {
             if (error)
             {
                 [motionManager stopAccelerometerUpdates];
             }
             else
             {
                 CMAcceleration accleleration=accelerometerData.acceleration;
                 
                 [self switchTheme:accleleration.x withy:accleleration.y  withz:accleleration.z];
             }
         }];
    }
    else
    {
        [UIAccelerometer sharedAccelerometer].delegate = self;
        [UIAccelerometer sharedAccelerometer].updateInterval = 0.2f;
    }
     */
}


-(void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
    [self switchTheme:acceleration.x withy:acceleration.y  withz:acceleration.z];
}

- (void)switchTheme:(double)x withy:(double)y  withz:(double)z
{
    
    if (((UINavigationController *)self.mainControllDelegate).navigationController.topViewController != (UIViewController *)self.mainControllDelegate || ![[MWPreference sharedInstance] getValue:PREF_SHAKETOCHANGETHEME] ) {
		return;
	}
    if (fabs(x) > 1.5 || fabs(y) > 1.5 || fabs(z) > 1.5)
    {
		AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
        
		GMAPDAYNIGHTMODE eMapDayNightMode = {0};
		GDBL_GetParam(G_MAP_DAYNIGHT_MODE, &eMapDayNightMode);
		if (eMapDayNightMode == GMAP_DAYNIGHT_MODE_DAY) {
			//设置白天色盘
			GPALETTE DayPalette = {0};
			GDBL_GetParam(G_DAY_PALETTE_INDEX,&DayPalette);
            GPALETTELIST *dayPalette;
            GDBL_GetPaletteList(Gtrue,&dayPalette);
			if (DayPalette.nPaletteID == dayPalette->nNumberOfPalette - 1) {
				DayPalette.nPaletteID = 0;
                GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&DayPalette.nPaletteID);
				GDBL_SetParam(G_DAY_PALETTE_INDEX,&DayPalette.nPaletteID);
                
                
                
			}
			else {
				DayPalette.nPaletteID = DayPalette.nPaletteID + 1;
                GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&DayPalette.nPaletteID);
				GDBL_SetParam(G_DAY_PALETTE_INDEX,&DayPalette.nPaletteID);
                
                
			}
		}
		else if(eMapDayNightMode == GMAP_DAYNIGHT_MODE_NIGHT){
			//设置夜晚色盘
			GPALETTE NightPalette = {0};
			GDBL_GetParam(G_NIGHT_PALETTE_INDEX,&NightPalette);
            GPALETTELIST *nightPalette;
            GDBL_GetPaletteList(Gfalse,&nightPalette);
			if (NightPalette.nPaletteID == nightPalette->nNumberOfPalette - 1) {
				NightPalette.nPaletteID = 0;
                GDBL_SetParam(G_DAY_PALETTE_INDEX,&NightPalette.nPaletteID);
				GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&NightPalette.nPaletteID);
                
                
			}
			else {
				NightPalette.nPaletteID = NightPalette.nPaletteID +1;
                GDBL_SetParam(G_DAY_PALETTE_INDEX,&NightPalette.nPaletteID);
				GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&NightPalette.nPaletteID);
                
                
			}
		}
		else if(eMapDayNightMode == GMAP_DAYNIGHT_MODE_AUTO){
            
            GMAPDAYNIGHTMODE dayNight = {0};
			GDBL_GetParam(G_AUTO_MODE_DAYNIGHT, &dayNight);
            if (dayNight == GMAP_DAYNIGHT_MODE_DAY) {
                //设置白天色盘
                GPALETTE DayPalette = {0};
                GDBL_GetParam(G_DAY_PALETTE_INDEX,&DayPalette);
                GPALETTELIST *dayPalette;
                GDBL_GetPaletteList(Gtrue,&dayPalette);
                if (DayPalette.nPaletteID == dayPalette->nNumberOfPalette - 1) {
                    DayPalette.nPaletteID = 0;
                    GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&DayPalette.nPaletteID);
                    GDBL_SetParam(G_DAY_PALETTE_INDEX,&DayPalette.nPaletteID);
                    
                    
                }
                else {
                    DayPalette.nPaletteID = DayPalette.nPaletteID + 1;
                    GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&DayPalette.nPaletteID);
                    GDBL_SetParam(G_DAY_PALETTE_INDEX,&DayPalette.nPaletteID);
                    
                    
                }
            }
            else if(dayNight == GMAP_DAYNIGHT_MODE_NIGHT)
            {
                //设置夜晚色盘
                GPALETTE NightPalette = {0};
                GDBL_GetParam(G_NIGHT_PALETTE_INDEX,&NightPalette);
                GPALETTELIST *nightPalette;
                GDBL_GetPaletteList(Gfalse,&nightPalette);
                if (NightPalette.nPaletteID == nightPalette->nNumberOfPalette - 1) {
                    NightPalette.nPaletteID = 0;
                    GDBL_SetParam(G_DAY_PALETTE_INDEX,&NightPalette.nPaletteID);
                    GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&NightPalette.nPaletteID);
                    
                    
                }
                else {
                    NightPalette.nPaletteID = NightPalette.nPaletteID +1;
                    GDBL_SetParam(G_DAY_PALETTE_INDEX,&NightPalette.nPaletteID);
                    GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&NightPalette.nPaletteID);
                    
                    
                }
            }
		}
        
        if([[MWPreference sharedInstance] getValue:PREF_MAPDAYNIGHTMODE] == GMAP_DAYNIGHT_MODE_AUTO)
        {
            [[MWPreference sharedInstance] setValue:PREF_MAPDAYNIGHTMODE Value:GMAP_DAYNIGHT_MODE_AUTO];
        }
        
		[[MWMapOperator sharedInstance] MW_ShowMapView:GMAP_VIEW_TYPE_MAIN WithParma1:0 WithParma2:0 WithParma3:0];
    }
    
}

#pragma mark 设置色盘
- (void)setTheme:(int)themeIndex
{
    int theme = themeIndex;
    
    GMAPDAYNIGHTMODE eMapDayNightMode = {0};
    GDBL_GetParam(G_MAP_DAYNIGHT_MODE, &eMapDayNightMode);
    if (eMapDayNightMode == GMAP_DAYNIGHT_MODE_DAY) {
        
        GPALETTELIST *dayPalette;
        GDBL_GetPaletteList(Gtrue,&dayPalette);
        if (theme > (int)(dayPalette->nNumberOfPalette - 1)) {
            theme = 0;
        }
        
        //设置白天色盘
        GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&theme);
        GDBL_SetParam(G_DAY_PALETTE_INDEX,&theme);
        
        
    }
    else if(eMapDayNightMode == GMAP_DAYNIGHT_MODE_NIGHT){
        
        GPALETTELIST *nightPalette;
        GDBL_GetPaletteList(Gfalse,&nightPalette);
        if (theme > (int)(nightPalette->nNumberOfPalette - 1)) {
            theme = 0;
        }
        
        //设置夜晚色盘
        GDBL_SetParam(G_DAY_PALETTE_INDEX,&theme);
        GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&theme);
        
        
    }
    else if(eMapDayNightMode == GMAP_DAYNIGHT_MODE_AUTO){
        
        GMAPDAYNIGHTMODE dayNight = {0};
        GDBL_GetParam(G_AUTO_MODE_DAYNIGHT, &dayNight);
        if (dayNight == GMAP_DAYNIGHT_MODE_DAY) {
            
            GPALETTELIST *dayPalette;
            GDBL_GetPaletteList(Gtrue,&dayPalette);
            if (theme > (int)(dayPalette->nNumberOfPalette - 1)) {
                theme = 0;
            }
            //设置白天色盘
            GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&theme);
            GDBL_SetParam(G_DAY_PALETTE_INDEX,&theme);
            
            
        }
        else if(dayNight == GMAP_DAYNIGHT_MODE_NIGHT)
        {
            
            GPALETTELIST *nightPalette;
            GDBL_GetPaletteList(Gfalse,&nightPalette);
            if (theme > (int)(nightPalette->nNumberOfPalette - 1)) {
                theme = 0;
            }
            
            //设置夜晚色盘
            GDBL_SetParam(G_DAY_PALETTE_INDEX,&theme);
            GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&theme);
            
            
        }
    }
    
    if([[MWPreference sharedInstance] getValue:PREF_MAPDAYNIGHTMODE] == GMAP_DAYNIGHT_MODE_AUTO)
    {
        [[MWPreference sharedInstance] setValue:PREF_MAPDAYNIGHTMODE Value:GMAP_DAYNIGHT_MODE_AUTO];
    }
    
    [[MWMapOperator sharedInstance] MW_ShowMapView:GMAP_VIEW_TYPE_MAIN WithParma1:0 WithParma2:0 WithParma3:0];
}

#pragma mark- 白天黑夜色盘同步
- (void)GMD_SyncDayNightTheme
{
    int theme = 0;
    
    GMAPDAYNIGHTMODE eMapDayNightMode = {0};
    GDBL_GetParam(G_MAP_DAYNIGHT_MODE, &eMapDayNightMode);
    if (eMapDayNightMode == GMAP_DAYNIGHT_MODE_DAY) {
        
        GDBL_GetParam(G_DAY_PALETTE_INDEX,&theme);
        
        GPALETTELIST *nightPalette;
        GDBL_GetPaletteList(Gfalse,&nightPalette);
        if (theme > (int)(nightPalette->nNumberOfPalette - 1)) {
            theme = 0;
        }
        
        //设置夜晚色盘
        GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&theme);
        GDBL_SetParam(G_DAY_PALETTE_INDEX,&theme);
        
    }
    else if(eMapDayNightMode == GMAP_DAYNIGHT_MODE_NIGHT){
        
        GDBL_GetParam(G_NIGHT_PALETTE_INDEX,&theme);
        
        GPALETTELIST *dayPalette;
        GDBL_GetPaletteList(Gtrue,&dayPalette);
        if (theme > (int)(dayPalette->nNumberOfPalette - 1)) {
            theme = 0;
        }
        
        //设置白天色盘
        GDBL_SetParam(G_DAY_PALETTE_INDEX,&theme);
        GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&theme);
    }
    else if(eMapDayNightMode == GMAP_DAYNIGHT_MODE_AUTO){
        
        GMAPDAYNIGHTMODE dayNight = {0};
        GDBL_GetParam(G_AUTO_MODE_DAYNIGHT, &dayNight);
        if (dayNight == GMAP_DAYNIGHT_MODE_DAY) {
            
            GDBL_GetParam(G_DAY_PALETTE_INDEX,&theme);
            
            GPALETTELIST *nightPalette;
            GDBL_GetPaletteList(Gfalse,&nightPalette);
            if (theme > (int)(nightPalette->nNumberOfPalette - 1)) {
                theme = 0;
            }
            
            //设置夜晚色盘
            GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&theme);
            GDBL_SetParam(G_DAY_PALETTE_INDEX,&theme);
            
        }
        else if(dayNight == GMAP_DAYNIGHT_MODE_NIGHT)
        {
            GDBL_GetParam(G_NIGHT_PALETTE_INDEX,&theme);
            
            GPALETTELIST *dayPalette;
            GDBL_GetPaletteList(Gtrue,&dayPalette);
            if (theme > (int)(dayPalette->nNumberOfPalette - 1)) {
                theme = 0;
            }
            //设置白天色盘
            GDBL_SetParam(G_DAY_PALETTE_INDEX,&theme);
            GDBL_SetParam(G_NIGHT_PALETTE_INDEX,&theme);
        }
    }
    
    if([[MWPreference sharedInstance] getValue:PREF_MAPDAYNIGHTMODE] == GMAP_DAYNIGHT_MODE_AUTO)
    {
        [[MWPreference sharedInstance] setValue:PREF_MAPDAYNIGHTMODE Value:GMAP_DAYNIGHT_MODE_AUTO];
    }
}

#pragma mark 常用按钮信息添加
-(BOOL)GMD_AddCommonPOI:(MWPoi *)commonPOI
{
    NSMutableArray *commonArray = [[[NSMutableArray alloc] init] autorelease];
    NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"/address/commonPOI.plist"];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	[commonArray addObjectsFromArray:array];
    [commonArray addObject:commonPOI];
    
	if (![NSKeyedArchiver archiveRootObject:commonArray toFile:filename]){
		return NO;
	}
	else {
		return YES;
	}
    
}

#pragma mark 获取常用按钮信息
-(NSMutableArray *)GMD_GetCommonPOI
{
    NSMutableArray *commonArray = [[NSMutableArray alloc] init];
    
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"/address/commonPOI.plist"];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	
	[commonArray addObjectsFromArray:array];
	
	return [commonArray autorelease];
	
}

#pragma mark 常用按钮信息删除
- (BOOL)GMD_DeleteCommonPOIWithIndex:(int)index
{
 
    NSMutableArray *commonArray = [[[NSMutableArray alloc] init] autorelease];
    NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"/address/commonPOI.plist"];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	[commonArray addObjectsFromArray:array];
    if (index > (int)commonArray.count -1) {
        return NO;
    }
    [commonArray removeObjectAtIndex:index];
    if (![NSKeyedArchiver archiveRootObject:commonArray toFile:filename]){
		return NO;
	}
	else {
		return YES;
	}
}

#pragma mark 常用按钮信息全部删除
- (BOOL)GMD_DeleteAllCommonPOI
{
    
    NSMutableArray *commonArray = [[[NSMutableArray alloc] init] autorelease];
    NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"/address/commonPOI.plist"];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	[commonArray addObjectsFromArray:array];
    
    [commonArray removeAllObjects];
    if (![NSKeyedArchiver archiveRootObject:commonArray toFile:filename]){
		return NO;
	}
	else {
		return YES;
	}
}

#pragma mark- 组装电话区号
- (NSString *)GMD_getPhoneNumber:(NSString *)tel_string WithLon:(int)lon Lat:(int)lat
{
	if( tel_string && [tel_string length] != 0)
	{
		if ([tel_string length] >=10)
		{
			return tel_string;
		}
		NSRange range;
		range = [tel_string rangeOfString:@"-"];
		if (range.length == 0 && [tel_string length] != 11)
		{
			range.location = 0;
            Gint32 plAdminCode;
            GADAREAINFOEX pAdareaInfoEx;
            plAdminCode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:lon Lat:lat];
            if (plAdminCode == 0) {
                return tel_string;
            }
            GSTATUS res = GDBL_GetAdareaInfoEx(plAdminCode, &pAdareaInfoEx) ;
			if (res == GD_ERR_OK) {
                return [NSString stringWithFormat:@"0%d-%@",pAdareaInfoEx.nTel,tel_string];
            }
            else {
                return tel_string;
            }
		}
		else
		{
			return tel_string;
		}
		
	}
	else
	{
		return @"";
	}
}

#pragma mark- 拨打电话
- (void)GMD_telephoneCall:(NSString *)telephone Lon:(int)lon Lat:(int)lat
{
    if(telephone && [telephone length] != 0)
    {
        
        NSRange range;
        NSString* dicStr = [telephone stringByReplacingOccurrencesOfString:@"、"  withString:@";"];
        range = [dicStr rangeOfString:@";"];
        int location = range.location;
        int lenght = range.length;
        if (lenght == 0)
        {
            location = dicStr.length;
        }
        NSURL *telURL = [NSURL URLWithString:[NSString stringWithFormat:@"telprompt://%@",[self GMD_getPhoneNumber:[dicStr substringToIndex:location] WithLon:lon Lat:lat]]];
        [[UIApplication sharedApplication] openURL:telURL];
        
    }

}

#pragma mark- 白天黑夜切换,更新界面ui
- (void)GMD_SetDayNightModeCallback
{
    if ([[ANParamValue sharedInstance] isInit]) {
        static GMAPDAYNIGHTMODE currentMapDayNightMode = {0};
        
        GMAPDAYNIGHTMODE dayNight = {0};
        GDBL_GetParam(G_AUTO_MODE_DAYNIGHT, &dayNight);
        
        if (dayNight != currentMapDayNightMode) {
            currentMapDayNightMode = dayNight;
            if (dayNight == GMAP_DAYNIGHT_MODE_DAY) {
                [UIImage setImageDayNightMode:NO];
                
            }
            else{
                [UIImage setImageDayNightMode:YES];
                
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_MapDayNightModeChange] userInfo:@{@"dayNightMode": [NSNumber numberWithInt:dayNight]}];
        }
    }
}

#pragma mark- GPS信号情况播报
- (void)GMD_PlayGPS
{
    
    if ([GDBL_TTS GDBL_TTSIsPlaying]) {
        [self performSelector:@selector(GMD_PlayGPS) withObject:nil afterDelay:0.5];
    }
    else
    {
        
        if ([[MWPreference sharedInstance] getValue:PREF_DISABLE_GPS]) {
            GGPSINFO pGpsInfo = {0};
            GDBL_GetGPSInfo(&pGpsInfo);
            
            if (pGpsInfo.nValid) {
                
                [GDBL_TTS GDBL_TTSPlayByStr:STR(@"Main_GPSLocationedSound", @"Main")];
            }
            else{
                
                [GDBL_TTS GDBL_TTSPlayByStr:STR(@"Main_GPSLocatingSound", @"Main")];
            }
        }
        else{
            [GDBL_TTS GDBL_TTSPlayByStr:STR(@"Main_OpenGPSSound", @"Main")];
        }
        
        
    }
}
#pragma mark- 实时交通语音播报
- (void)GMD_TrafficPlaySound
{
    BOOL bTMCStartup = [[ANParamValue sharedInstance] GMD_isTMCOn];
    BOOL bTrafficSpeakOn = [[MWPreference sharedInstance] getValue:PREF_SPEAKTRAFFIC];
    BOOL bPath = [[ANParamValue sharedInstance] isPath];
    BOOL bSimulate = [[ANParamValue sharedInstance] isNavi];
    BOOL bLocalData = ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 0)?YES:NO;
    BOOL is_3DDemo = [ANParamValue sharedInstance].is3DDomo;//是否在进行3d模拟演示
    /*路况信息播报 修改人 高志闽  日期 2013-5-25*/
    Gint32 mapType;
    GDBL_GetCurrentMapViewType(&mapType);
    if (bTMCStartup && bTrafficSpeakOn && bPath &&!bSimulate &&bLocalData && !is_3DDemo && mapType == GMAP_VIEW_TYPE_MAIN)
    {
        [[CustomTrafficPlaySound SharedInstance] StartPlaySound];
    }
    else
    {
        [[CustomTrafficPlaySound SharedInstance] StopPlaySound];
    }
}
/**
 *	获取图片 扇形部分
 *
 *	@param	image	需要剪切的图片
 *	@param	startDegree	剪切的起始度数。以正北为基准 范围（0 - 360）
 *	@param	endDegree	剪切的结束度数。以正北为基准 范围（0 - 360）
 *
 *	@return	返回剪切后的扇形图片
 */
- (UIImage *)getImageWithImage:(UIImage *)image from:(int)startDegree to:(int)endDegree
{
    if (![image isKindOfClass:[UIImage class]])
    {
        return nil;
    }
    startDegree = startDegree - 90;
    endDegree = endDegree - 90;
    CGSize size = image.size;
    
    CGPoint center = CGPointMake(size.width/2, size.height/2);
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextMoveToPoint(context, center.x, center.y);
    CGContextAddArc(context, center.x, center.y, size.width/2, startDegree* M_PI / 180.0, endDegree* M_PI / 180.0, 0);
    CGContextClosePath(context);
    CGContextClip(context);
    CGContextTranslateCTM(context, 0,size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    CGContextDrawImage(context, CGRectMake(0, 0, size.width, size.height), image.CGImage);
    UIImage *changeImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return changeImage;
}


#pragma mark- 创建轨迹和收藏夹的存放文件夹目录
-(void)GMD_CreatTrackAndFavFolder
{
    NSError *myError;
	NSDictionary *DirectoryAttrib = [NSDictionary dictionaryWithObject:[NSNumber numberWithUnsignedLong:0777UL] forKey:NSFilePosixPermissions];
    NSString *addr_path = [NSString stringWithFormat:@"%@/address/", document_path];
	NSString *trc_path = [NSString stringWithFormat:@"%@/trc/", document_path];
   
    
	if (![[NSFileManager defaultManager] fileExistsAtPath:trc_path] ) {
        [[NSFileManager defaultManager] createDirectoryAtPath:trc_path withIntermediateDirectories:YES attributes:DirectoryAttrib error:&myError];
	}
    if (![[NSFileManager defaultManager] fileExistsAtPath:addr_path]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:addr_path withIntermediateDirectories:YES attributes:DirectoryAttrib error:&myError];
	}
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:Skin_path]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:Skin_path withIntermediateDirectories:YES attributes:DirectoryAttrib error:&myError];
	}
    if (![[NSFileManager defaultManager] fileExistsAtPath:CarOwnerService_path]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:CarOwnerService_path withIntermediateDirectories:YES attributes:DirectoryAttrib error:&myError];
	}
    if (![[NSFileManager defaultManager] fileExistsAtPath:Dialect_path]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:Dialect_path withIntermediateDirectories:YES attributes:DirectoryAttrib error:&myError];
	}

}

#pragma mark - 跳转到appstore
/*param:0 更新软件 1：评价软件*/
+(void)rateToAppStore:(int)param;
{
    if (param == 0)
    {
        [[MWPreference sharedInstance] setValue:PREF_AUTONAVIPUSH Value:0];
        NSString *str = [NSString stringWithFormat:@"http://itunes.apple.com/cn/app/gao-dao-hanghd-autonavi-navigation/id324101974?mt=8"];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    }
    else
    {
        //给个好评
        if ([ANParamValue sharedInstance].isPath) {
            [GDBL_UserBehaviorCountNew shareInstance].iLoveGD_InPath ++;
        }
        else{
            [GDBL_UserBehaviorCountNew shareInstance].iLoveGD ++;
        }
        
        [[MWPreference sharedInstance] setValue:PREF_AUTONAVIPUSH Value:0];
        NSString *str = [NSString stringWithFormat:@"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=%d",324101974];
        if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1) {
            str = [NSString stringWithFormat:@"itms-apps://itunes.apple.com/app/id%d", 324101974];
        }
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    }
}


//@return
- (void) GMD_OpenTMC
{
    if([ANParamValue sharedInstance].isPath)
    {
        GCARINFO carInfo = {0};
        GDBL_GetCarInfo(&carInfo);
        
        [MWTMCRequest sharedInstance].adminCode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:carInfo.Coord.x Lat:carInfo.Coord.y];
        
        
    }
    else
    {
        [MWTMCRequest sharedInstance].adminCode = [[ANDataSource sharedInstance] GMD_GetCurrentAdmincode];
    }
    [MWTMCRequest sharedInstance].delegate = self;
    [ANParamValue sharedInstance].isTMCRequest = YES;
    [[MWTMCRequest sharedInstance] Net_OpenTMC];
    [[MWPreference sharedInstance]  setValue:PREF_REALTIME_TRAFFIC Value:[[ANParamValue sharedInstance] GMD_isTMCOn]];
    [UMengStatistics trafficTimeBucket];
}

- (void) GMD_CloseTMC
{
    [[MWTMCRequest sharedInstance] Net_CancelRequest];
    [[MWTMCRequest sharedInstance] Net_CloseTMC];
    [ANParamValue sharedInstance].isTMCRequest = NO;
}

#pragma mark -
#pragma mark NetReqToViewCtrDelegate request 
- (void)requestToViewCtrWithRequestType:(RequestType)requestType didFinishLoadingWithResult:(id)result
{
    if(requestType == REQ_TMC)
    {
        [ANParamValue sharedInstance].isTMCRequest = NO;
      
        Gint32 mapType;
        GDBL_GetCurrentMapViewType(&mapType);
        [[MWMapOperator sharedInstance] MW_ShowMapView:mapType WithParma1:0 WithParma2:0 WithParma3:0];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_TMC] userInfo:nil];
    }
}

- (void)requestToViewCtrWithRequestType:(RequestType)requestType didFailWithError:(NSError *)error
{
    if(requestType == REQ_TMC)
    {
        [ANParamValue sharedInstance].isTMCRequest = NO;
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_TMC] userInfo:nil];
        Gint32 mapType;
        GDBL_GetCurrentMapViewType(&mapType);
        
        if (error.code == NetErrorNOTMCData)
        {
            [QLoadingView showAlertWithoutClick:STR(@"Universal_CurrentCityNoData", @"Localizable") ShowTime:2.0];     
        }
        else
        {
            [self GMD_CloseTMC];
           [QLoadingView showAlertWithoutClick:STR(@"Universal_TMCNetError", @"Localizable") ShowTime:2.0];            
        }

        
        if ( UIApplicationStateInactive != [[UIApplication sharedApplication] applicationState])
        {
            [[MWMapOperator sharedInstance] MW_ShowMapView:mapType WithParma1:0 WithParma2:0 WithParma3:0];
         }
    }
}

@end
