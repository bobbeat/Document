//
//  MPApp.m
//  AutoNavi
//
//  Created by yu.liao on 13-5-23.
//
//

#import "MPApp.h"

#import "AppDelegate_iPhone.h"
#import "AppDelegate_iPad.h"
#import "MWSkinDownloadManager.h"
#import "MWDialectDownloadManage.h"
#import "ANParamValue.h"
#import "plugin-cdm-TaskManager.h"
#import "UIApplication+Category.h"
#import "GDBL_TTS.h"
#import "VCCustomNavigationBar.h"
#import "GDBL_PCD.h"
#import "mapDataManage.h"
#import "GDBL_Location.h"
#import "CinLoggerManager.h"
#import "GDBL_SinaWeibo.h"
#import "GDBL_TCWeibo.h"
#import "GDBL_NetCounter.h"
#import "MainViewController.h"
// 消息盒子
#import "Plugin_Share.h"
#import "launchRequest.h"
#import "MWPreference.h"
#import "MWGuideOperator.h"
#import "MWMapOperator.h"
#import "ControlCreat.h"
#import "MWApp.h"
#import "MobClick.h"
#import "plugin-cdm-Task.h"
#import "GDActionSheet.h"
#import "GDAlertView.h"
#import "WarningViewController.h"
#import "GDBL_LaunchRequest.h"


static MPApp *instance = nil;
static int downloadIndex = -1;
static int skinDownloadIndex = -1;
static int dialectDownloadIndex = -1;

@interface MPApp (Private)

- (void)MyalertView:(NSString *)titletext Message:(NSString *)messagetext Canceltext:(NSString *)mycanceltext Othertext:(NSString *)myothertext alerttag:(int)mytag;
@end

@implementation MPApp

- (id) init {
	self = [super init];
	if (self != nil)
    {
        navigationController = [self navigationController];
        rootViewController   = [self rootViewController];
	}
	return self;
}

+ (MPApp *)sharedInstance
{
    if (instance == nil) {
        instance = [[MPApp alloc] init];
    }
    return instance;
}

- (void)releaseInstance
{
    if (instance != nil)
    {
        [instance release];
        instance = nil;
    }
}

#pragma mark - MPApp Private Methods

- (UINavigationController *)navigationController
{
    AppDelegate_iPhone *delegate = (AppDelegate_iPhone *)[UIApplication sharedApplication].delegate;
    return delegate.navigationController;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        AppDelegate_iPhone *delegate = (AppDelegate_iPhone *)[UIApplication sharedApplication].delegate;
        return delegate.navigationController;
    }
    else
    {
        AppDelegate_iPad *delegate = (AppDelegate_iPad *)[UIApplication sharedApplication].delegate;
        return delegate.navigationController;
    }
    
}

- (ANViewController *)rootViewController
{
    AppDelegate_iPhone *delegate = (AppDelegate_iPhone *)[UIApplication sharedApplication].delegate;
    return delegate.rootViewController;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        AppDelegate_iPhone *delegate = (AppDelegate_iPhone *)[UIApplication sharedApplication].delegate;
        return delegate.rootViewController;
    }
    else
    {
        AppDelegate_iPad *delegate = (AppDelegate_iPad *)[UIApplication sharedApplication].delegate;
        return delegate.rootViewController;
    }
   
}
-(void)stopApp
{
	[[MWApp sharedInstance] saveAppData];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:@"exitApplication" object:nil];
	exit(1);
}


- (UIView *)FindAlertOrActionsheet:(NSArray *)array
{
    if (array == nil)
    {
        return 0;
    }
   
    if ([array count] == 0)
    {
        return 0;
    }
    
    int i = 0;
    UIView *view = [array objectAtIndex:i];
    while (view != nil)
    {
        if ([view isKindOfClass:[UIAlertView class]])
        {
            NSLog(@"exist UIAlertView");
            return view;
        }
        if ([view isKindOfClass:[GDActionSheet class]])
        {
            NSLog(@"exist UIImageActionSheet");
            return view;
        }
        if ([[view subviews] count] != 0)
        {
            UIView *sub_view = [self FindAlertOrActionsheet:[view subviews]];
            if (sub_view)
            {
                return sub_view;
            }
            else
            {
                i++;
                if (i == [array count])
                {
                    view = nil;
                }
                else
                {
                    view = [array objectAtIndex:i];
                }
                
            }
        }
        else
        {
            i++;
            if (i == [array count])
            {
                view = nil;
            }
            else
            {
                view = [array objectAtIndex:i];
            }
        }
    }
    
    return view;
}

//当月流量计算
- (void)currentMonthNetCount
{
    
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"MM"];
	NSString *Datemonth = [formatter stringFromDate: [NSDate date]];
	[formatter release];
	
	if ([Datemonth intValue] != [[MWPreference sharedInstance] getValue:PREF_CURRENTMONTH])
	{
        [[GDBL_NetCounter shareInstance] ClearByteForMonth];
		[[MWPreference sharedInstance] setValue:PREF_CURRENTMONTH Value:[Datemonth intValue]];
        
	}

}

//推送通知
- (void)pushNotification:(NSDictionary *)userInfo Type:(BOOL)type
{
    if (type) {//启动导航
        //推送通知
        NSString *scNum = [[userInfo objectForKey:@"ex"] objectForKey:@"sc"];
        if ([scNum intValue] == 1) {//微享消息推送
//            [[MWPreference sharedInstance] setValue:PREF_WESHAREPUSH Value:1];
            [[MWPreference sharedInstance] setValue:PREF_POSITIONPUSH Value:1];
        }
        else if([scNum intValue] == 3){//我喜欢高德推送
            [[MWPreference sharedInstance] setValue:PREF_AUTONAVIPUSH Value:1];
            
        }
        else if([scNum intValue] == 4){//用户反馈推送
            [[MWPreference sharedInstance] MW_SetFeedbackPush:(NSMutableDictionary *)userInfo];
        }
        [self pushAction:[scNum intValue] applicationInitByPush:YES];
         [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:nil userInfo:nil];
    }
    else//已启动导航
    {
        NSString *scNum = [[userInfo objectForKey:@"ex"] objectForKey:@"sc"];
        if ([scNum intValue] == 1) {//微享消息推送
//            [[MWPreference sharedInstance] setValue:PREF_WESHAREPUSH Value:1];
            [[MWPreference sharedInstance] setValue:PREF_POSITIONPUSH Value:1];
         
        }
        else if([scNum intValue] == 3){//我喜欢高德推送
            [[MWPreference sharedInstance] setValue:PREF_AUTONAVIPUSH Value:1];
            
        }
        else if([scNum intValue] == 4){//用户反馈推送
            [[MWPreference sharedInstance] MW_SetFeedbackPush:(NSMutableDictionary *)userInfo];
        }
         [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:nil userInfo:nil];
        UIApplicationState state = [[UIApplication sharedApplication] applicationState];
        if (state == UIApplicationStateActive)
        {
            if ([[userInfo objectForKey:@"aps"] objectForKey:@"alert"]!=NULL) {
                if ([scNum intValue] == 4) {
                    [ControlCreat createAlertViewWithTitle:STR(@"Universal_software", @"Localizable") delegate:self message:[[userInfo objectForKey:@"aps"] objectForKey:@"alert"] cancelButtonTitle:STR(@"Universal_cancel", @"Localizable") otherButtonTitles:@[STR(@"Universal_view", @"Localizable")] tag:4];
                    
                }
                else{
                    [ControlCreat createAlertViewWithTitle:STR(@"Universal_software", @"Localizable") delegate:self message:[[userInfo objectForKey:@"aps"] objectForKey:@"alert"] cancelButtonTitle:STR(@"Universal_cancel", @"Localizable") otherButtonTitles:@[STR(@"Universal_view", @"Localizable")] tag:3];
                    
                }
                
                
            }
        }else{
            [self pushAction:[scNum intValue] applicationInitByPush:NO];
        }
    }
}


- (void)setDes:(NSString *)urlInfo
{
    long long called_lon,called_lat;
    NSRange start_range = [urlInfo rangeOfString:@"SetTarget:"];
    NSRange first_range = [urlInfo rangeOfString:@","];
    NSRange lon_range;
    lon_range.length = first_range.location - 21;
    lon_range.location = start_range.location + 10;
    NSString *lon_str = [urlInfo substringWithRange:lon_range];
    NSString *lat_str = [urlInfo substringFromIndex:first_range.location + 1];
    called_lon = [lon_str longLongValue];
    called_lat = [lat_str longLongValue];
    if ([[ANParamValue sharedInstance] isInit])
    {
        GMOVEMAP moveMap;
        moveMap.eOP = MOVEMAP_OP_GEO_DIRECT;
        moveMap.deltaCoord.x = called_lon;
        moveMap.deltaCoord.y = called_lat;
        
        //[[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
        
        [navigationController popToRootViewControllerAnimated:YES];
        //[rootViewController button:nil clickedWithTag:BUTTON_SET_DES];
        GPOI poi = {0};
        poi.Coord.x = called_lon;
        poi.Coord.y = called_lat;
        
        [[MWGuideOperator sharedInstance] MW_SetDesPointWithMainID:6 POI:poi];
    }
    else
    {
        GCOORD tmp;
        tmp.x = called_lon;
        tmp.y = called_lat;
        [ANParamValue sharedInstance].voiceDriveCoord = tmp;
         [[MWMapOperator sharedInstance] MW_SetMapOperateType:ProcessType_SetDes];
        //[[ANOperateMethod sharedInstance] GMD_StartWithID:0 Lon:called_lon Lat:called_lat];
        //[rootViewController button:nil clickedWithTag:BUTTON_SET_DES];
    }
}

- (void)messageMoveMap:(NSString *)urlInfo
{
    
    NSString *strSPcode = [[urlInfo CutFromNSString:@"IA"] substringToIndex:14];
    char str_temp[20];
    memset(str_temp,0x0,20);
    memcpy(str_temp,NSSTRING_TO_CSTRING(strSPcode) ,strlen( NSSTRING_TO_CSTRING(strSPcode)));
    
    GCOORD tmp = [[ANDataSource sharedInstance] GMD_SPCodeToCoord:str_temp];
    if (tmp.x != 0 && tmp.y != 0) {
        
        
        
        if ([[ANParamValue sharedInstance] isInit])
        {
            
            //关闭弹出框
            [GDAlertView dismissCurrentAlertView];
            UIView *view = [self FindAlertOrActionsheet:[UIApplication sharedApplication].windows] ;
            if ([view isKindOfClass:[GDActionSheet class]])
            {
                [(GDActionSheet *)view ShowOrHiddenActionSheet:NO Animation:NO];
            }
            
            
            if (navigationController.visibleViewController && ![navigationController.visibleViewController  isMemberOfClass:[WarningViewController class] ]) {
                [navigationController.visibleViewController dismissModalViewControllerAnimated:NO];
                
            }
            [navigationController popToRootViewControllerAnimated:NO];
            if ([ANParamValue sharedInstance].isPath && [ANParamValue sharedInstance].isNavi)
            {
                if ([rootViewController respondsToSelector:@selector(Action_simulatorNavi_Stop)]) {
                    [rootViewController Action_simulatorNavi_Stop];
                }
                
                //[[MWGuideOperator sharedInstance] MW_StopSimulationNavigation];
            }
            GMOVEMAP moveMap;
            moveMap.eOP = MOVEMAP_OP_GEO_DIRECT;
            moveMap.deltaCoord = tmp;
            [[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
            [[GDBL_Location sharedInstance] setMessageMoveMapFlag:YES];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_MessageMoveMap] userInfo:nil];
            
        }
        else
        {
            [ANParamValue sharedInstance].smsCoord = tmp;
            [[MWMapOperator sharedInstance] MW_SetMapOperateType:ProcessType_SmsMoveMap];
          
        }
    }
}

- (void)openBackgroundMode:(BOOL)state
{
//    if (state && [ANParamValue sharedInstance].isBackNavi)
//    {//开启后台线程
//        //后台开启后台线程
//        //[[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
//        UIDevice* device = [UIDevice currentDevice];
//        if ([device respondsToSelector:@selector(isMultitaskingSupported)])
//        {
//                if(device.multitaskingSupported)
//                {
//                    if (bgTaskId == UIBackgroundTaskInvalid)
//                    {
//                            
//                            bgTaskId = [[UIApplication sharedApplication]beginBackgroundTaskWithExpirationHandler:NULL];
//                            
//                    }
//                        
//                }
//        }
//            
//    }
//    else {
//        //锁屏导航，进入前台后关闭后台线程
//        if (bgTaskId != UIBackgroundTaskInvalid)
//        {
//                [[UIApplication sharedApplication] endBackgroundTask:bgTaskId];
//                bgTaskId = UIBackgroundTaskInvalid;
//        }
//        
//    }
    
}

- (void)uploadToken:(NSData *)deviceToken
{
    NSRange range;
    range.length=71;
    range.location = 1;
    NSString *deviceToken_ext = [[deviceToken description] substringWithRange:range];
//    if ([deviceTokenEx length]== 0 )
	{
		NSString *lTmp = [NSString stringWithFormat:@"%s"," "];
		NSString* dicStr = [deviceToken_ext stringByReplacingOccurrencesOfString:lTmp withString:@""];
        [MWPreference sharedInstance].deviceToken = dicStr;
	}
    
    [[launchRequest shareInstance] UploadTokenToAutonavi:deviceToken_ext];
    [[launchRequest shareInstance] UploadToken];
}
/*
 接收推送通知的函数
 bInitByPush:YES:表示启动导航 NO:表示已启动导航
 */
- (void)pushAction:(int)type applicationInitByPush:(BOOL)bInitByPush
{
    if (![[ANParamValue sharedInstance] isInit]) {
       if (4 == type|| 1 == type)
       {
            [[MWMapOperator sharedInstance] MW_SetMapOperateType:ProcessType_MessageBox];
       }
        return;
    }
    if (4 == type|| 1 == type) {//用户反馈推送
                
        [Plugin_Share enterBoxWith:navigationController];
    }
}

- (float)getSize:(int)size
{
    float _mSize = 0.0;
    
    if (size >= 1024*1024*1024) {
        
        _mSize = size*1.0/1024/1024/1024;
    }
    else if(1024*1024 <= size < 1024*1024*1024)
    {
        _mSize = size*1.0/1024/1024;
    }
    else if(size < 1024*1024){
        
        _mSize = size*1.0/1024;
    }
    
    return _mSize;
}

- (NSString *)getUnit:(int)size
{
    NSString *Unit = nil;
    
    if (size >= 1024*1024*1024) {
        Unit = @"GB";
        
    }
    else if(1024*1024 <= size < 1024*1024*1024)
    {
        Unit = @"MB";
        
    }
    else if(size < 1024*1024){
        Unit = @"KB";
        
    }
    
    return Unit;
}

#pragma mark -
#pragma mark UIAlert

- (void)MyalertView:(NSString *)titletext Message:(NSString *)messagetext Canceltext:(NSString *)mycanceltext Othertext:(NSString *)myothertext alerttag:(int)mytag
{
	
	UIAlertView *Myalert;
	
	Myalert = [[UIAlertView alloc] initWithTitle:titletext
									     message:messagetext
										delegate:self
							   cancelButtonTitle:mycanceltext
							   otherButtonTitles:myothertext,nil];
	
	Myalert.tag = mytag;
	[Myalert show];
	[Myalert release];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (alertView.tag) {
        case 0:
        {
            //默认不做任何操作
        }
            break;
        case 3:
        {
            switch (buttonIndex) {
                case 0:
                {
                    
                }
                    break;
                case 1:
                {
                    [self pushAction:4 applicationInitByPush:NO];
                }
                default:
                    break;
            }

        }
            case 4://用户反馈推送
        {
            switch (buttonIndex) {
                case 0:
                {
                    
                }
                    break;
                case 1:
                {
                    [self pushAction:4 applicationInitByPush:NO];
                }
                    break;
                default:
                    break;
            }
        }
            break;
        case 5://地图数据下载
        {
            switch (buttonIndex) {
                case 0:
                {
                    [[TaskManager taskManager] stopAllTask];
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_MapDataDownloadUpdate] userInfo:nil];
                }
                    break;
                case 1:
                {
                    [[TaskManager taskManager] start:downloadIndex];
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_MapDataDownloadUpdate] userInfo:nil];
                }
                    break;
                default:
                    break;
            }
        }
            break;
        case 6://方言数据下载
        {
            switch (buttonIndex) {
                case 0:
                {
                    [[MWDialectDownloadManage sharedInstance] stopAllTask];
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_DialectDownloadUpdate] userInfo:nil];
                }
                    break;
                case 1:
                {
                    [[MWDialectDownloadManage sharedInstance] start:dialectDownloadIndex];
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_DialectDownloadUpdate] userInfo:nil];
                }
                    break;
                default:
                    break;
            }
        }
            break;
        case 200:
        {
            [navigationController popToRootViewControllerAnimated:YES];
        }
            break;
        default:
            break;
    }
}
#pragma mark -
#pragma mark MPApp lifecycle

- (void)launchImage:(UIWindow *)window
{
    [[GDBL_LaunchRequest sharedInstance] NET_LaunchImage:window];
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    if (IOS_7) {
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
#if   PROJECTMODE
    [CinLoggerManager SharedInstance];            //打印死机log
#endif
    [[MWApp sharedInstance] restoreAppData]; //读取保存参数
    
    [[AVAudioSession sharedInstance]  setActive:NO error:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(stopApp) name: @"exitApplication" object: nil];
    
	[[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound)];
    
    [UIApplication sharedApplication].idleTimerDisabled = YES;
	
	[self pushNotification:[launchOptions objectForKey:@"UIApplicationLaunchOptionsRemoteNotificationKey"] Type:YES];//推送通知
	
    [self currentMonthNetCount]; //当月流量统计
    
    [MobClick setLogEnabled:NO];  // 打开友盟sdk调试，注意Release发布时需要注释掉此行,减少io消耗
    [MobClick setAppVersion:XcodeAppVersion]; //参数为NSString * 类型,自定义app版本信息，如果不设置，默认从CFBundleVersion里取
    //
    [MobClick startWithAppkey:UMAppKey];
    
    return YES;

}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [[MWPreference sharedInstance] setValue:PREF_BACKGROUND_MODE Value:0];
    
    [UIApplication sharedApplication].idleTimerDisabled = YES;
    [[GDBL_SinaWeibo shareSinaWeibo].sinaweibo applicationDidBecomeActive];//新浪微博，应用从后台唤起时，应调用此方法，需要完成退出当前登录状态的功能
    if (![[MWPreference sharedInstance] getValue:PREF_BACKGROUNDNAVI]){
        [rootViewController startSimulationWhenBackground];
    }
    
    if (![[MWPreference sharedInstance] getValue:PREF_BACKGROUNDDOWNLOAD]) {//后台数据下载
        if (downloadIndex > 0) {
            if (NetWorkType == 2) {
                
                [[TaskManager taskManager] start:downloadIndex];
            }
            else if (NetWorkType == 1){
                Task *temp = [[TaskManager taskManager].taskList objectAtIndex:downloadIndex];
                NSString * strTitle;
                TaskManager *taskmanager = [TaskManager taskManager];
                long long totalsize = [taskmanager getNeedSize] + temp.total - temp.current;
                
                NSString *Unit = [self getUnit:totalsize];
                float size = [self getSize:totalsize];
                
                strTitle = [NSString stringWithFormat:STR(@"CityDownloadManage_startDownloadAlert", @"CityDownloadManage"),size,Unit];
                [ControlCreat createAlertViewWithTitle:nil delegate:self message:strTitle cancelButtonTitle:STR(@"Universal_no", @"Localizable") otherButtonTitles:@[STR(@"Universal_yes", @"Localizable")] tag:5];
            }
            
        }
        
        if (skinDownloadIndex > 0) {
            
            [[MWSkinDownloadManager sharedInstance] start:skinDownloadIndex];
        }
        
        if (dialectDownloadIndex > 0) {
            
            if (NetWorkType == 2) {
                
                [[MWDialectDownloadManage sharedInstance] start:dialectDownloadIndex];
            }
            else if (NetWorkType == 1){
                
                MWDialectDownloadTask *temp = [[MWDialectDownloadManage sharedInstance].dialectTaskList objectAtIndex:dialectDownloadIndex];
                
                NSString * strTitle;
                
                long long totalsize = [[MWDialectDownloadManage sharedInstance] getNeedSize] + temp.total - temp.current;
                
                NSString *Unit = [self getUnit:totalsize];
                float size = [self getSize:totalsize];
                
                NSString *title = [[MWDialectDownloadManage sharedInstance] getDialectTitle:temp.title];
                strTitle = [NSString stringWithFormat:STR(@"Universal_downloadDialectWithNoWIFI",@"Localizable"),title,size,Unit];
                [ControlCreat createAlertViewWithTitle:nil delegate:self message:strTitle cancelButtonTitle:STR(@"Universal_no", @"Localizable") otherButtonTitles:@[STR(@"Universal_yes", @"Localizable")] tag:6];
            }
        }
    }
    [self openBackgroundMode:NO];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    
    if (![[MWPreference sharedInstance] getValue:PREF_BACKGROUNDNAVI]){//进入后台后停止模拟导航和语音播报
        [(MainViewController *)rootViewController stopSimulationWhenBackground];
        [GDBL_TTS GDBL_TTSStop];
        
        [[GDBL_PCD sharedInstance] GDBL_PCD_Cleanup];
        
    }
    if (![[MWPreference sharedInstance] getValue:PREF_BACKGROUNDDOWNLOAD]) {//后台数据下载
        downloadIndex = [[TaskManager taskManager] _firstIndexWithStatus:TASK_STATUS_RUNNING];
        if (downloadIndex > 0) {
            [[TaskManager taskManager] stopCurrent:downloadIndex];
        }
        
        skinDownloadIndex = [[MWSkinDownloadManager sharedInstance] _firstIndexWithStatus:TASK_STATUS_RUNNING];
        if (skinDownloadIndex > 0) {
            [[MWSkinDownloadManager sharedInstance] stopCurrent:skinDownloadIndex];
        }
        
        dialectDownloadIndex = [[MWDialectDownloadManage sharedInstance] _firstIndexWithStatus:TASK_STATUS_RUNNING];
        if (dialectDownloadIndex > 0) {
            [[MWDialectDownloadManage sharedInstance] stopCurrent:dialectDownloadIndex];
        }
    }
    [self openBackgroundMode:YES];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    [[GDBL_SinaWeibo shareSinaWeibo].sinaweibo handleOpenURL:url];//新浪微博客户端回调
    [[GDBL_TCWeibo shareTCWeibo].weiboEngine handleOpenURL:url];//腾讯微博客户端回调
    [[ANOperateMethod sharedInstance] GMD_ClosePlainMap];
    // Are we being launched by Maps to show a route?
	NSString* urlInfo = [[url absoluteString] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"url==%@",urlInfo);
	if([urlInfo rangeOfString:@"SetTarget"].length > 0)//url格式:autonavi://SetTarget:xxxxxxxxx,xxxxxxxx 备注：经度9位，纬度8位
	{
		
        [self setDes:urlInfo];
	}
	
	else if([urlInfo rangeOfString:@"IA"].length > 0 &&[urlInfo CutFromNSString:@"IA"].length >= 14 )
	{
        
		[self messageMoveMap:urlInfo];
		
	}
	else
	{
        return YES;
		
	}    
    return YES;
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
    
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
    
    [[MWApp sharedInstance] saveAppData];  //保存系统数据
    [[MWPreference sharedInstance] setValue:PREF_BACKGROUND_MODE Value:1];//设置未后台模式
    
}
- (void)applicationWillEnterForeground:(UIApplication *)application
{
    
    
    
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    [self uploadToken:deviceToken];
}
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
     //   NSLog(@"Error in registration. Error: %@", error);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    [self pushNotification:userInfo Type:NO];
 
}


@end
