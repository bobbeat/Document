//
//  AroundSearchService.h
//  AutoNavi
//
//  Created by lin jingjie on 11-12-23.
//  Copyright 2011 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constants.h"

@protocol AroundSearchServiceDelegate

-(void)searchResult:(GPOI *)pPOI count:(int)POICount;

@end


@interface AroundSearchService : NSObject 
{
	UIActivityIndicatorView * indicatorView;

	id <AroundSearchServiceDelegate>delegate;
}
@property(nonatomic,retain)UIActivityIndicatorView * indicatorView;
@property(nonatomic,assign)id <AroundSearchServiceDelegate>delegate;
-(void)startByClassType:(int)classType Lon:(long)lon Lat:(long)lat IndicatorView:(UIActivityIndicatorView *)IndicatorView object:(id)object;
-(void)searchDidFinish;
+(AroundSearchService *)sharedAroundSearch;
@end
