//
//  AroundSearchService.m
//  AutoNavi
//
//  Created by lin jingjie on 11-12-23.
//  Copyright 2011 autonavi. All rights reserved.
//

#import "AroundSearchService.h"



@implementation AroundSearchService
@synthesize indicatorView,delegate;
static AroundSearchService* instance;
static GPOI *mPPOI = nil;
static int mPOICount = 0;
+(AroundSearchService *)sharedAroundSearch
{
	@synchronized(self)
	{
		if(instance == nil)
		{
			[[self alloc] init];
			//resultArray = [[NSMutableArray alloc] init];
		}
	}
	return instance;
}
+(id)allocWithZone:(NSZone *)zone
{
	@synchronized(self)
	{
		if(instance == nil)
		{
			instance = [super allocWithZone:zone];
			return instance;
		}
	}
	return nil;
}
- (id)copyWithZone:(NSZone *)zone
{
	return self;
}
-(id)retain
{
	return self;
}
-(unsigned)retainCount
{
	return UINT_MAX;
}
-(void)release
{
	return;
}
-(id)autorelease
{
	return self;
}

-(void)startByClassType:(int)classType Lon:(long)lon Lat:(long)lat IndicatorView:(UIActivityIndicatorView *)IndicatorView object:(id)object
{
	//KKK
	//UI_ChangePoiListType(1,0);
//	delegate = object;
//	long Admin_code;
//	Admin_code = UI_GetAdminCode(lon,lat);
//	Admin_code = Admin_code /100 * 100;
//	int ret = 0;
//	if(Admin_code != 0)
//	{
//		ret = UI_SetCurrentAdminCode(Admin_code);
//	}
//	ret = UI_SetClassType(SEARCH_TYPE_AROUND, classType);
//	ret = UI_SetReferencePoint(lon,lat);
//	ret = UI_SetAroundSearchRange(10000);
//	mPPOI = nil;
//	mPOICount = 0;
	if(IndicatorView != nil)
	{
		indicatorView = IndicatorView;
		[indicatorView startAnimating];
	}
	[NSThread detachNewThreadSelector:@selector(searchThreadTaskAround) toTarget:self withObject:nil];
}
void searchCallBack(GPOI **pPOI, int *num)
{
	if (*pPOI != NULL && *num > 0)
	{
		mPPOI = *pPOI;
		mPOICount = *num;
	}
	return ;
}
- (void)searchThreadTaskAround
{
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	[NSThread sleepForTimeInterval:0.1];
	//kkk
	//POICALLBACK PoiCallBack;
//	memset(&PoiCallBack, 0, sizeof(POICALLBACK));
//	PoiCallBack.GetPoiData = searchCallBack;
//	if(!UI_SearchPoi(SEARCH_TYPE_AROUND, NULL, &PoiCallBack))
//	{
//
//		UI_SetAroundSearchRange(50000);
//		if(!UI_SearchPoi(SEARCH_TYPE_AROUND, NULL, &PoiCallBack))
//		{
//			UI_SetAroundSearchRange(100000);
//			if(!UI_SearchPoi(SEARCH_TYPE_AROUND, NULL, &PoiCallBack))
//			{
//			}
//		}
//		
//	}
	[self performSelectorOnMainThread:@selector(searchDidFinish) withObject:nil waitUntilDone:NO];
	[pool release];
}



-(void)searchDidFinish
{
	if(indicatorView != nil)
	{
		[indicatorView stopAnimating];
	}
	 //kkk
	//[delegate searchResult:mPPOI count:mPOICount];
}
@end
