//  
//  ANOperateMethod.h
//  AutoNavi
//
//  功能点(例如回家，回公司，开启，关闭某个功能)
//
//  Created by GHY on 12-3-1.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin_PoiNode.h"
#import "MWPoiOperator.h"
@class MWPoi;
@protocol UIAccelerometerDelegate;
@protocol NetReqToViewCtrDelegate;

@interface ANOperateMethod : NSObject <UIAlertViewDelegate,UIAccelerometerDelegate,NetReqToViewCtrDelegate>
{
    GPOI  desPOI;
    int   localizeType;
}

@property (nonatomic,assign) int   localizeType;
#pragma mark 单例
+ (ANOperateMethod *)sharedInstance;

- (void)GMD_SetBusEndingPointWithMainID;
- (void)GMD_StartRouteCalculationWithBOOLValue:(BOOL)boolValue;
#pragma mark 回家
- (BOOL)GMD_GoHome;
#pragma mark 回公司
- (BOOL)GMD_GoCompany;

#pragma mark 通过微享编码启动导航
- (id)GMD_StartWithID:(NSInteger)ID Lon:(long long)lLon Lat:(long long)lLat;

#pragma mark 设置相应的目录不备份
- (void)GMD_BackUp;

#pragma mark 软件升级的情况一体化数据里面的资源重新解压
- (void)GMD_UnZipLogic;

#pragma mark 根据当前机型，将bundle中的Gconfig移动到document下Documents/iPhone3/GNaviRes/Gconfig.dat (或者ipad，iphone4，newpad)
- (BOOL)GMD_Gconfig_Change_Path;

#pragma mark 关闭plainmapmode
- (BOOL)GMD_ClosePlainMap;

/**********************************************************************
 * 函数名称: GMD_SetVoicePlayType
 * 功能描述: 设置地图类型
 * 输入参数: int voiceType 0：播报本地语音 1：播报网络地图语音 2:本网结合
 * 输出参数:
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2013/03/27        1.0			黄龙锋
 **********************************************************************/
- (int)GMD_SetVoicePlayType:(int)voiceType;

/**********************************************************************
 * 函数名称: GMD_GetVoicePlayType
 * 功能描述: 获取语音播报类型
 * 输入参数:
 * 输出参数: 0：播报本地语音 1：播报网络地图语音 2:本网结合
 * 返 回 值: 返回地图类型
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2013/03/27        1.0			黄龙锋
 **********************************************************************/
- (int)GMD_GetVoicePlayType;

#pragma mark 拨打95190
- (void)GMD_Call_95190:(NSString *)phone;

#pragma mark 将view转化成镜子中的view显示
- (void)GMD_ChangeTomirrorViewInView:(UIView *)view isSwitch:(BOOL)isSwitch;

#pragma mark 设置系统语言
-(BOOL)GMD_SetSystemLanguage:(BOOL)isEngineInit;

#pragma mark 切换平行道路
- (BOOL)GMD_ChangeCarRoad:(int)ParallelID;

#pragma mark 阿拉伯数字转汉字
- (NSString *)ArabToChinese:(int)num;

#pragma mark 设置本地化路径
- (NSString *)GMD_SetLocalizeKey:(NSString *)key table:(NSString *)tableName;

- (int)GMD_PassInfoToDrive;
- (void)GMD_PassInfoToHud;
#pragma mark 设置本地化路径
-(NSString *)GMD_SetLocalizeKey:(NSString *)key table:(NSString *)tableName;


#pragma mark 根据行政编码查看是否有地图数据
//flag:0 判断当前所在位置是否有地图数据 1 传入指定行政编码看是否有地图数据
-(int)GMD_checkIsExistData:(long)adminCode flag:(int)bCurrentAdminCode;

#pragma mark 判断当前点是否有数据 不判断比例尺
-(int)GMD_CheckExistDataWithLon:(long)lon Lat:(long)lat;



#pragma mark 多路线概览点击路线切换高亮,点击图标返回事件，交通流信息,参数number大于0表示点击了图标，touchNumber为－1说明未点击到路径，否则返回相应的路径规划原则
- (NSString *)GMD_guideRouteAndIconTouch:(GMAPVIEWTYPE)mapViewType TouchPoint:(CGPoint)touchPoint Elements:(GEVENTINFO **)elements EventNumber:(int *)number TouchRouteNumber:(int *)touchNumber;

#pragma mark 摇晃切换地图配色
- (void)GMD_SetAccelerometer:(id)delegate;

#pragma mark 常用按钮信息添加
-(BOOL)GMD_AddCommonPOI:(MWPoi *)commonPOI;
#pragma mark 获取常用按钮信息
-(NSMutableArray *)GMD_GetCommonPOI;
#pragma mark 常用按钮信息删除
- (BOOL)GMD_DeleteCommonPOIWithIndex:(int)index;
#pragma mark 常用按钮信息全部删除
- (BOOL)GMD_DeleteAllCommonPOI;
#pragma mark- 拨打电话
- (void)GMD_telephoneCall:(NSString *)telephone Lon:(int)lon Lat:(int)lat;
#pragma mark- 组装电话区号
- (NSString *)GMD_getPhoneNumber:(NSString *)tel_string WithLon:(int)lon Lat:(int)lat;

- (void)switchTheme:(double)x withy:(double)y  withz:(double)z;
/**
 *	获取图片 扇形部分
 *
 *	@param	image	需要剪切的图片
 *	@param	startDegree	剪切的起始度数。以正北为基准 范围（0 - 360）
 *	@param	endDegree	剪切的结束度数。以正北为基准 范围（0 - 360）
 *
 *	@return	返回剪切后的扇形图片
 */
- (UIImage *)getImageWithImage:(UIImage *)image from:(int)startDegree to:(int)endDegree;


- (void) GMD_OpenTMC;

- (void) GMD_CloseTMC;

#pragma mark- 创建轨迹和收藏夹的存放文件夹目录
-(void)GMD_CreatTrackAndFavFolder;


#pragma mark - 跳转到appstore
/*param:0 更新软件 1：评价软件*/
+(void)rateToAppStore:(int)param;

#pragma mark- 白天黑夜切换,更新界面ui
- (void)GMD_SetDayNightModeCallback;

#pragma mark 设置色盘
- (void)setTheme:(int)themeIndex;

#pragma mark- 白天黑夜色盘同步
- (void)GMD_SyncDayNightTheme;

#pragma mark- 实时交通语音播报
- (void)GMD_TrafficPlaySound;

#pragma mark- GPS信号情况播报
- (void)GMD_PlayGPS;

@end
