//  应用程序数据
//  ANDataSource.h
//  AutoNavi
//
//  Created by GHY on 12-3-31.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constants.h"

@interface ANDataSource : NSObject 
{
	NSInteger        POICategoryID;      //周边POI类别(通过GMD_SetPOICategoryIDWithMainID)
	Guint32          pNumberOfList;      //演示模型个数
    Gint32           provinceAdminCode;  //省份索引值
	Gint32           cityAdminCode;      //城市索引值
	GDEMOJOURNEYLIST *ppDemoJourneyList; //演示路线列表
	GDEMOMODELLIST   *ppDemoModelList;   //演示模型列表
    GHGUIDEROUTE     guideRouteHandle;
}

@property (nonatomic) Gint32             lAdminCode;       //当前行政编码
@property (nonatomic) GADAREALIST        *ppAdareaList;    //行政区域列表
@property (nonatomic) GADAREAINFOEX      pAdareaInfoEx;    //当前点的行政区域信息
@property (nonatomic) GPOI               *POIList;         //POI列表
@property (nonatomic) Gint32             lCategoryID;      //POI类别编号
@property (nonatomic) GPOICATEGORYLIST   *ppCategoryList;  //POI类别列表
@property (nonatomic) GPATHSTATISTICLIST *ppStatInfoList;  //路径统计信息列表
@property (nonatomic) GGUIDEROADLIST     *ppGuideRoadList; //路线详情列表
@property (nonatomic) GMANEUVERINFO      *pManeuverInfo;   //机动信息
@property (nonatomic) GSATELLITEINFO     pSatellite;       //卫星信息
@property (nonatomic) GGPSINFO           pGpsInfo;         //GPS基本信息


#pragma mark 单例
+ (ANDataSource *)sharedInstance;

#pragma mark 获取区域列表(参数MID为区域类型 SID为索引值)
- (NSArray *)GMD_GetAdareaListWithMainID:(NSInteger)MID SubID:(NSInteger)SID;
#pragma mark 设置行政区域(参数MID:为城市类型 SID:为索引值)
- (void)GMD_SetCurAdareaWithMainID:(NSInteger)MID SubID:(NSInteger)SID;
#pragma mark 获取设置区域省份行政编码
-(int)getCurrSetAdminCode;
#pragma mark 获取设置区域名称
- (NSString *)GMD_GetAdareaName;
#pragma mark 设置当前行政区域
- (void)GMD_SetCurrentAdmincode;
- (void)GMD_GetGuideRoadList;
- (void)GMD_GetDemoModelList;
- (NSArray *)GMD_GetAdareaListWithMainID:(NSInteger)MID SubID:(NSInteger)SID;
- (NSInteger)GMD_GetCurrentAdmincode;
#pragma mark 获取当前点的省,市,区名称
- (NSString *)GMD_GetCityNameWithMainID:(NSInteger)ID;
- (void)GMD_SetCurAdareaWithMainID:(NSInteger)MID WithSubID:(NSInteger)SID;
#pragma mark 设置周边POI类别
- (void)GMD_SetPOICategoryIDWithMainID:(NSInteger)ID;
#pragma mark 获取当前道路名
- (NSString *)GMD_GetCurrentRoadName:(GMAPVIEWTYPE)mapViewType;

- (void)GMD_GetManeuverInfoCurrentRoadName:(NSString **)curRoadName
                              NextRoadName:(NSString **)nextRoadName
                              NextDistance:(NSString **)nextDistance
                               DirectImage:(UIImage  **)directImage
                      TotalDistanceAndTime:(NSString **)distanceAndTime;
#pragma mark 获取机动引导信息(当前道路名，路口距离，剩余距离，耗时，下路口名称，下路口距离，转向图标，下道路名称，出现放大路口时获取距离下一路口的距离，总距离)
- (NSString *)GMD_GetManeuverInfoWithMainID:(int)mainID;
- (UIImage *)GMD_GetIconWithAmapID:(int)ID imageID:(int *)imageID;
- (UIImage *)GMD_GetIconWithMainID:(int)mainID;
- (int)GMD_GetIconID;
#pragma mark 单路线－获取路线信息
- (NSString *)GMD_GetPathStatisticInfoWithMainID:(int)mainID GuideHandel:(GHGUIDEROUTE)tmpGuideRouteHandle;
#pragma mark 多路线－获取路线信息
- (NSString *)GMD_GetPathStatisticInfoWithMainID:(int)mainID index:(int)index;

#pragma mark 传入行政编码，获取区域信息：省，市，区
- (NSDictionary *)GMD_AdminCodeToAreaInfo:(Gint32)admincode;
- (NSDictionary *)GMD_AdminCodeToAreaInfoEx:(Gint32)admincode;
#pragma mark 传入经纬度，获取区域信息：省，市，区
- (NSDictionary *)GMD_CoordToAreaInfo:(long)lon Lat:(long)lat;
- (NSDictionary *)GMD_CoordToAreaInfoEx:(long)lon Lat:(long)lat;
#pragma mark 经纬度获取sp编码
- (NSString *)GMD_CoordToSPCode:(long)lon Lat:(long)lat;

#pragma mark 经纬度获取sp编码
- (GCOORD )GMD_SPCodeToCoord:(Gchar *)spcode;

#pragma mark 获取当前点sp编码
- (NSString *)GMD_GetCurrentSPCode:(GMAPVIEWTYPE)mapViewType;

#pragma mark 经纬度转行政编码
- (Gint32)GMD_CoordToAdminCode:(long)lon Lat:(long)lat;

#pragma mark 获取导航系统,引擎,地图,电子眼版本字符串
- (NSString *)GMD_GetVersionInfoWithMainID:(NSInteger)ID;

#pragma mark 获取附近点信息
- (void)GetNearPOI:(GMAPVIEWTYPE)mapViewType;

#pragma mark 获取指定点信息
- (void)GetNearPOI:(long)lon Lat:(long)lat;

#pragma mark 经纬度 屏幕坐标 相互转换
-(GCOORD)GMD_CoordConvert:(GCOORDCONVERT)convertType Lon:(Gint32)lon Lat:(Gint32)lat HMapView:(GMAPVIEWTYPE)mapViewType;

#pragma mark 获取地图角度
- (int)GMD_GetCarDirection:(GMAPVIEWTYPE)mapViewType;

- (int)GMD_CalculateDistance;
#pragma mark 获取平行道路
- (NSMutableArray *)GMD_GetCarParallelRoads;

- (int)GMD_CalculateDistanceWithStart:(GCOORD)start Des:(GCOORD)des;

#pragma mark 获取当前车位的城市名
- (NSString *)GMD_GetCurrentLocationCityName;
#pragma mark 检测地图数据
//根据行政编码查看是否有地图数据
//flag:0 判断当前所在位置是否有地图数据 1 传入指定行政编码看是否有地图数据
//返回值：0：表示无数据 1：表示有数据
- (int)GMD_checkIsExistData:(long)adminCode flag:(int)bCurrentAdminCode;
// 根据地图类型，判断地图当前的比例尺状态 该函数暂时只用于非主地图界面（不考虑3d）
- (GZOOMLEVEL) GMD_GetMapScaleLevelWithType:(GMAPVIEWTYPE) nMapViewType;
#pragma mark UI根据规则重新整理道路列表
- (NSArray *)GMD_EncapsulateGuideRoadList;
#pragma mark 获取主要道路列表
- (NSArray *)GMD_GetMainGuideRoadList;
#pragma mark-获取指定经纬度的电话区号
- (NSString *)getPhoneNumber:(NSString *)tel_string Lon:(long)lon Lat:(long)lat;
#pragma mark 获取设备横竖屏方向
- (int)GMD_GetDeviceOrientation;
#pragma mark 获取3D仰角
-(int)GMD_Get3DScale;
#pragma mark 获取mac地址
-(NSString *)GMD_GetDeviceID;
#pragma mark 获取当前比例尺
- (NSString *)GMD_GetCurrentScale;
#pragma mark 获取系统信息，硬件名称
- (NSString*)GMD_getDeviceAndOSInfo;
#pragma mark 获取审图号
- (NSString *)GMD_ReadDataCheckNumber;
#pragma mark 获取当前放大路口图的信息(放大路口的类型 路口距离)
/**********************************************************************
 * 函数名称: GMD_GetZoomInfo
 * 功能描述: 该函数用于获取当前放大路口图的信息
 * 输入参数:
 * 输出参数:
 * 返 回 值：
 index:0:放大路口的类型 返回值: G_ZOOM_VIEW_TYPE_VECTOR:矢量放大路口 G_ZOOM_VIEW_TYPE_BITMAP:位图放大路口 G_ZOOM_VIEW_TYPE_REAL:实景放大路口
 index:1   返回值:路口距离（单位：米）
 **********************************************************************/
- (int)GMD_GetZoomInfo:(int)index;

#pragma mark 获取是否越狱：0－未越狱 1－越狱
- (int) GMD_GetIsSteal;
#pragma mark 获取地图版本号的大版本号
- (int) GMD_GetDataVersion;
- (int)GMD_GetCurrentCityName:(NSString **)cityName adminCode:(NSString  **)mAdminCode;

#pragma mark 获取当前网络类型
- (int)isNetConnecting;
#pragma mark 获取家，公司详细信息
- (BOOL)GMD_GetFavoriteInfo:(GFAVORITECATEGORY)favoriteCategory POILIST:(GFAVORITEPOILIST **)favoritePOIList;

#pragma mark 获取数组里，指定索引的周围的11个结果（正常取前5个后5个，不够的往前，往后补齐，小于11个的返回全部）
- (BOOL)GMD_GetViewMapPOI:(NSMutableArray *)oldArray oldIndex:(int)oldIndex resultPOI:(NSMutableArray **)resultPOI resultIndex:(int *)resultIndex;
#pragma mark 获取行程点信息（0-起点 6-终点 2-5途径点）
- (void)GMD_GetJourneyPointInfo:(GPOI **)point;

#pragma mark 获取行程点数组信息
- (NSMutableArray *)GMD_GetJourneyPointArray;

#pragma mark 获取当前绘制地图类型：0－离线地图 1－在线地图
-(int)GMD_GetCurDrawMapViewType;

#pragma mark 根据经纬度获取当前绘制地图类型：0－离线地图 1－在线地图 ，判断比例尺
-(int)GMD_GetCurDrawMapViewTypeWithLon:(long)lon Lat:(long)lat;

#pragma mark 获取当前引导路径路径引导颜色数组
- (NSMutableArray *)GMD_GetGuideRouteColorContent;

#pragma mark- 获取车位所在道路索引
- (int)GetCarOnRoadIndex;

#pragma mark 获取指定行政编码的城市名
- (NSString *)GMD_GetCityNameWithAdminCode:(int)nAdminCode;

#pragma mark 获取城市行政编码（对直辖市的行政编码作处理）
- (int)GMD_GetCityAdminCodeWithAdminCode:(int)nAdminCode;

#pragma mark 获取当前车位信息
- (GSTATUS)GMD_GetCarInfo:(GCARINFO *)carInfo;

#pragma mark 获取开机启动默认图片
- (UIImage *)GMD_GetDefaultImage;

@end
