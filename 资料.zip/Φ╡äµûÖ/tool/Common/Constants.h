#import "GDBL_Interface.h"
#import "GDBL_typedef.h"
#import "ANParamValue.h"
#import "MWPreference.h"
#import "ANDataSource.h"

// these are the various screen placement constants used across all the UIViewControllers
 
// padding for margins
#define kLeftMargin				20.0
#define kTopMargin				20.0
#define kRightMargin			20.0
#define kBottomMargin			20.0
#define kTweenMargin			10.0

// control dimensions
#define kStdButtonWidth			106.0
#define kStdButtonHeight		40.0
#define kSegmentedControlHeight 40.0
#define kPageControlHeight		20.0
#define kPageControlWidth		160.0
#define kSliderHeight			7.0
#define kSwitchButtonWidth		94.0
#define kSwitchButtonHeight		27.0
#define kTextFieldHeight		30.0
#define kSearchBarHeight		40.0
#define kLabelHeight			20.0
#define kProgressIndicatorSize	40.0
#define kToolbarHeight			40.0
#define kUIProgressBarWidth		160.0
#define kUIProgressBarHeight	24.0

// specific font metrics used in our text fields and text views
#define kFontName				@"Arial"
#define kTextFieldFontSize		18.0
#define kTextViewFontSize		18.0

// UITableView row heights
#define kUIRowHeight			50.0
#define kUIRowLabelHeight		22.0

// table view cell content offsets
#define kCellLeftOffset			8.0
#define kCellTopOffset			12.0





//#define g_data_path1				[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPad/"] UTF8String]
#define document_path           [NSHomeDirectory() stringByAppendingString:@"/Documents"] 
#define tts_path                [NSHomeDirectory() stringByAppendingString:@"/Documents/GPS/TTS"] 
#define sn_path                [[NSHomeDirectory() stringByAppendingString:@"/Documents/GPS/sn.dat"] UTF8String]
#define mapVersion_path        [[NSHomeDirectory() stringByAppendingString:@"/Documents/GPS/map_v.dat"] UTF8String]
#define guideRoute_path     [NSHomeDirectory() stringByAppendingString:@"/Documents/path/"]
#define route_path        [[NSHomeDirectory() stringByAppendingString:@"/Documents/path.dat"] UTF8String]
#define account_path        [NSHomeDirectory() stringByAppendingString:@"/Documents/accountInfo.plist"]
#define SOFTVERSION       [NSString stringWithFormat:@"%s","V 8.4.2010.0306"]
#define AmapKeySring       @"d64ad527ae79c6332e6748d1c58f4aa8"
#define Skin_path          [NSString stringWithFormat:@"%@/Skin/", document_path]
#define Dialect_path       [NSString stringWithFormat:@"%@/Dialect/", document_path]
#define CarOwnerService_path [NSString stringWithFormat:@"%@/CarOwnerService/", document_path]
#define CloudDetour_path     [NSString stringWithFormat:@"%@/Faviour/", document_path]

//95190手机绑定中验证码绑定标识

#define license_id_normal @"12345"

#define license_id_95190 @"95190"

#define SIM_GPS_PATH            "/Volumes/WORK/Data"
#define FILE_NAME              "AutoNavi_Mapdata.dat"







//===============================================================

#define NOTIFY_TOUCH			@"_TOUCH"//触屏
#define NOTIFY_MOVEMAP			@"_MOVEMAP"//移图
#define NOTIFY_GOTOCPP			@"_GOTOCPP"//回车位
#define NOTIFY_BEGINPOINT		@"_BEGINPOINT"//设起点
#define NOTIFY_STARTGUIDANCE	@"_STARTGUIDANCE"//开始引导
#define NOTIFY_NO_PATH          @"_NO_PATH"//将isPath置为NO
#define NOTIFY_STOPGUIDANCE     @"_STOPGUIDANCE"//去除路径
#define NOTIFY_VIEWCONDITION	@"_VIEWCONDITION"//视图显示条件
#define NOTIFY_ENDINGPOINT		@"_ENDINGPOINT"//设终点
#define NOTIFY_MAPMODE			@"_MAPMODE"//地图模式切换
#define NOTIFY_2DMAPENLARGE		@"_2DMAPENLARGE"//2D地图放大
#define NOTIFY_2DMAPNARROW		@"_2DMAPNARROW"//2D地图缩小
#define NOTIFY_3DMAPENLARGE		@"_3DMAPENLARGE"//3D仰角放大
#define NOTIFY_3DMAPNARROW		@"_3DMAPNARROW"//3D仰角缩小
#define NOTIFY_3DANGLELEFT		@"_3DANGLELEFT"//3D右旋转角度
#define NOTIFY_3DANGLERIGHT		@"_3DANGLERIGHT"//3D左旋转角度
#define NOTIFY_INSIMULATION		@"_INSIMULATION"//进入模拟导航
#define NOTIFY_EXSIMULATION		@"_EXSIMULATION"//退出模拟导航
#define NOTIFY_INVALIDPOSITION	@"_INVALIDPOSITION"//非法位置
#define NOTIFY_PASSINFOTODRIVE	@"_PASSINFOTODRIVE"//主界面传递相关信息进入导航
#define NOTIFY_PASSINFOTOHUD	@"_PASSINFOTOHUD"//主界面传递相关信息至HUD界面
#define NOTIFY_VOICESYNC        @"_VOICESYNC" //语音提示开关同步到路况播报开关
#define ALPHA_HIDEN (float)0.4//上一段，下一段按钮不可用时透明度
#define ALPHA_APEAR (float)1.0
 
//poi搜索
//-------------------------------------------------
// NSNotification对象定义：
//通知参数对象：DefineNotificationParam
//  sender =（NSObject）通知的发送者
//  flag   =（bool）0: 搜索失败 1：搜索成功
//  param  = 无
//------------------------------------------------- 
#define NOTIFY_POISEARCH	@"_POISEARCH"//获取poi搜索列表成功
//===============================================================

//新功能介绍
#define  popScrollView      @"popScrollView" 
#define  lifealterView      @"lifealterView"
#define  HideNavigation     @"HideNavigation"
#define  ShowNavigation     @"ShowNavigation"

#define ProductID_English @"com.autonavi.navigation.english"//英文版内购的商品ID
#define hasEnglishPurchase @"hasEnglishPurchaseKey"//NSUerDefault中，英文版是否已购买的key
#define has95190ServicePurchase @"has95190ServicePurchase"//NSUerDefault中，购买95190储存收据




