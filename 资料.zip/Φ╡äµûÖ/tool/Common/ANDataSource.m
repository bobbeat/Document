//
//  ANDataSource.m
//  AutoNavi
//
//  获取数据
//
//  Created by GHY on 12-3-31.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "NSString+Category.h"
#import "ANParamValue.h"
#import "ANDataSource.h"
#import "load_bmp.h"
#import "plugin_SearchPoiOperate.h"
#import "ANOperateMethod.h"
#import "DefineNotificationParam.h"
#import "GDBL_TMC.h"
#import "ANParamValue.h"
#import "Plugin_OnLineMapUtility.h"
#import "CustomRealTimeTraffic.h"
#import "MWPreference.h"
#import "MWMapOperator.h"
#import "MWGuideOperator.h"
#include <sys/types.h>
#include <sys/sysctl.h>
#import"sys/utsname.h"
#import "mapDataManage.h"
#import "PublicDefine.h"
#import "ANReachability.h"
#include <sys/param.h>
#include <sys/mount.h>
#include <mach/mach.h>
#include <mach/mach_host.h>
#import "CustomRoadInfo.h"
#import "UIDevice+Category.h"
#import "ProgressBar.h"

static ANDataSource *sharedANDataSource = nil;


@implementation ANDataSource

@synthesize lAdminCode,ppAdareaList,pAdareaInfoEx;
@synthesize POIList,lCategoryID,ppCategoryList;
@synthesize ppStatInfoList,ppGuideRoadList,pManeuverInfo;
@synthesize pSatellite,pGpsInfo;


#pragma mark 单例=============================================================================

#pragma mark 单例
+ (ANDataSource *)sharedInstance {
	
	if (nil==sharedANDataSource)
	{
		sharedANDataSource = [[ANDataSource alloc] init];
	}
	return sharedANDataSource;
}

#pragma mark 初始化(外面不需调用)
- (id)init {
	
	self = [super init];
	if (self)
	{
		;
	}
	return self;
}

#pragma mark 区域列表==============================================================================

#pragma mark 获取区域列表(参数MID为区域类型 SID为索引值)
- (NSArray *)GMD_GetAdareaListWithMainID:(NSInteger)MID SubID:(NSInteger)SID {
    
	NSMutableArray *context = [[NSMutableArray alloc] init];
	
	Gint32 index = 0;
	
	switch (MID)
	{
		case 0://获取全国省列表
		{
			index = 0;
		}
			break;
			
		case 1://获取某省市列表
		{
            index = ppAdareaList->pAdarea[SID].lAdminCode;
			provinceAdminCode = index;
            NSLog(@"code=%d",provinceAdminCode);
		}
			break;
			
		case 2://获取某市区列表
		{
			index = ppAdareaList->pAdarea[SID].lAdminCode;
			cityAdminCode = index;
        }
			break;
			
		default:
			break;
	}
    //
    if ([ANParamValue sharedInstance].netWorkMap) {
        GDBL_GetAllAdareaList(index,&ppAdareaList);
    } else {
        GDBL_GetAdareaList(index,&ppAdareaList);
    }
	
    for (int i=0; i<ppAdareaList->lNumberOfAdarea; i++)
    {
        NSString *adminName = [NSString chinaFontStringWithCString:ppAdareaList->pAdarea[i].szAdminName];
        if (adminName != nil)
		{
            [context addObject:adminName];
        }
        adminName = nil;
    }
    
	return [context autorelease];
}

#pragma mark 设置行政区域(参数MID:为城市类型 SID:为索引值)
- (void)GMD_SetCurAdareaWithMainID:(NSInteger)MID SubID:(NSInteger)SID {
	
	GADAREATYPE eAdareaType = 0;
	
	switch (MID)
	{
		case 0://全国类型
		{
			eAdareaType = ADAREA_TYPE_CHINA;
			lAdminCode = 0;
		}
			break;
            
		case 1://省类型
		{
			eAdareaType = ADAREA_TYPE_PROVINCE;
			lAdminCode = provinceAdminCode;
		}
			break;
			
		case 2://市类型
		{
			eAdareaType = ADAREA_TYPE_CITY;
			lAdminCode = cityAdminCode;
		}
			break;
			
		case 3://区县类型
		{
			eAdareaType = ADAREA_TYPE_TOWN;
			lAdminCode = ppAdareaList->pAdarea[SID].lAdminCode;
		}
			break;
            
		default:
			break;
	}
	
	GDBL_SetCurAdarea(eAdareaType, lAdminCode);
}
#pragma mark 获取设置区域省份行政编码
-(int)getCurrSetAdminCode
{
    return provinceAdminCode;
}
#pragma mark 获取设置区域名称
- (NSString *)GMD_GetAdareaName {
    
	NSMutableString *adAreaName = [[NSMutableString alloc] init];
	
	GADAREAINFOEX adareaInfoEx = {0};
	GDBL_GetAdareaInfoEx(lAdminCode, &adareaInfoEx);
	
	[adAreaName appendString:[NSString chinaFontStringWithCString:adareaInfoEx.szTownName]];
	if (0==[adAreaName length])
	{
		[adAreaName appendString:[NSString chinaFontStringWithCString:adareaInfoEx.szCityName]];
		if (0==[adAreaName length])
		{
			[adAreaName appendString:[NSString chinaFontStringWithCString:adareaInfoEx.szProvName]];
			if (0==[adAreaName length])
			{
				
                [adAreaName appendString:STR(@"CityDownloadManage_Country", @"CityDownloadManage")];
				
				
			}
		}
	}
	
	return [adAreaName autorelease];
}

#pragma mark 获取当前行政编码
- (NSInteger)GMD_GetCurrentAdmincode {
    
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        CLLocationCoordinate2D centercoord = [[Plugin_OnLineMapUtility sharedInstance] NET_GetAmapCenter];
        Gint32 adminCode = 0;
        GCOORDTEL coordTel;
        coordTel.eFlag = COORDTEL_TYPE_COORD;
        coordTel.u.Coord.x = centercoord.longitude * 1000000;
        coordTel.u.Coord.y = centercoord.latitude * 1000000;
        
        GDBL_GetAdminCode(&coordTel,&adminCode);
        return adminCode;
    }
    
	Gint32 adminCode = 0;
	GCOORDTEL coordTel;
	coordTel.eFlag = COORDTEL_TYPE_COORD;
	coordTel.u.Coord.x = -1;
	coordTel.u.Coord.y = -1;
	
	GDBL_GetAdminCode(&coordTel,&adminCode);
	
	return adminCode;
}
#pragma mark 设置当前行政区域
- (void)GMD_SetCurrentAdmincode {
    GADAREATYPE eAdareaType;
    
    long tmpAdmincode = [self GMD_GetCurrentAdmincode]/10000;
    if (tmpAdmincode == 82 || tmpAdmincode == 11 || tmpAdmincode == 50 || tmpAdmincode == 31 || tmpAdmincode == 81 || tmpAdmincode == 12) {
        eAdareaType = ADAREA_TYPE_PROVINCE;
    }
    else
    {
        eAdareaType = ADAREA_TYPE_CITY;
    }
    long adminCode = [self GMD_GetCurrentAdmincode]/100*100;
	
    GDBL_SetCurAdarea(eAdareaType,adminCode);
    
}

#pragma mark 获取当前的省,市,区名
- (NSString *)GMD_GetCityNameWithMainID:(NSInteger)ID {
	
	NSString *CityName = nil;
	
	lAdminCode = [self GMD_GetCurrentAdmincode];
	GDBL_GetAdareaInfoEx(lAdminCode, &pAdareaInfoEx);
	
	switch (ID)
	{
		case 0:
		{//当前行政区域省城名
			CityName = [NSString chinaFontStringWithCString:pAdareaInfoEx.szProvName];
		}
			break;
			
		case 1:
		{//当前行政区域城市名
			CityName = [NSString chinaFontStringWithCString:pAdareaInfoEx.szCityName];
		}
			break;
			
		case 2:
		{//当前行政区域地区名
			CityName = [NSString chinaFontStringWithCString:pAdareaInfoEx.szTownName];
		}
			break;
			
		default:
			break;
	}
	
	return CityName;
}


#pragma mark 设置区域行政编码
- (void)GMD_SetCurAdareaWithMainID:(NSInteger)MID WithSubID:(NSInteger)SID {
	
	GADAREATYPE eAdareaType = ADAREA_TYPE_CITY;
	
	switch (MID)
	{
		case 0:
		{
			eAdareaType = ADAREA_TYPE_CHINA;
		}
			break;
			
		case 1:
		{
			eAdareaType = ADAREA_TYPE_PROVINCE;
		}
			break;
			
		case 2:
		{
			eAdareaType = ADAREA_TYPE_CITY;
		}
			break;
			
		case 3:
		{
			eAdareaType = ADAREA_TYPE_TOWN;
		}
			break;
			
		default:
			break;
	}
	
	GDBL_SetCurAdarea(eAdareaType,lAdminCode);
}

#pragma mark 单路线－获取路线信息
- (NSString *)GMD_GetPathStatisticInfoWithMainID:(int)mainID GuideHandel:(GHGUIDEROUTE)tmpGuideRouteHandle{
	
	NSString *pathStatisticInfo = @"";
    
	int bDataFormNet = [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData;
    
	if (GD_ERR_OK == GDBL_GetPathStatisticInfo(tmpGuideRouteHandle,Gtrue, Gfalse, &ppStatInfoList))
	{
		switch (mainID)
		{
			case 0:// 收费站
			{
				pathStatisticInfo = [NSString stringWithFormat:@"%d",ppStatInfoList->pPathStat->nTotalTollGate];
			}
				break;
				
			case 1:// 总距离(带单位)
			{
                
                if (bDataFormNet == 1)
                {
                    pathStatisticInfo = [NSString stringWithFormat:@"%@",[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainDistance]];
                }
                else
                {
                    int dis = ppStatInfoList->pPathStat->nTotalDis;
                    if (bDataFormNet == 2) //本网数据结合时使用本地数据，剩余距离 = 网络总距离 - 本地总距离 + 本地剩余距离 （单位米）
                    {
                        int net_total = [[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_PathDistance_NS] intValue];
                        
                        dis = net_total;
                    }
                    if (dis > 1000)
                    {
                        if (dis > 1000000) {
                            pathStatisticInfo = [NSString stringWithFormat:@"%0.0f%@",(dis/1000.0),STR(@"Universal_KM", @"Localizable")];
                        }
                        else {
                            pathStatisticInfo = [NSString stringWithFormat:@"%0.1f%@",(dis/1000.0),STR(@"Universal_KM", @"Localizable")];
                        }
                        
                    }
                    else
                    {
                        pathStatisticInfo= [NSString stringWithFormat:@"%d%@",dis,STR(@"Universal_M", @"Localizable")];
                    }
                }
			}
				break;
				
			case 2://耗时(带单位)
			{
                if (bDataFormNet == 1)
                {
                    pathStatisticInfo = [NSString stringWithFormat:@"%@",[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainTime]];
                }
                else
                {
                    
                    int time = ppStatInfoList->pPathStat->nTime;
                    if (bDataFormNet == 2) //本网数据结合时使用本地数据，剩余时间 = 网络总时间 - 本地总时间 + 本地剩余距离 （单位分）
                    {
                        int net_total = [[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_PathTotalTime_NS] intValue];
                        net_total = net_total/60;
                        time = net_total;
                    }
                    
                    NSUInteger hour = (time/60);
                    NSUInteger minute = (time%60);
                    if (hour >0)
                    {
                        if (0 == minute) {//分钟为0，则不显示分钟
                            pathStatisticInfo = [NSString stringWithFormat:@"%d%@",hour,STR(@"Universal_hour", @"Localizable")];
                        }
                        else{
                            pathStatisticInfo = [NSString stringWithFormat:@"%d%@%d%@",hour,STR(@"Universal_hour", @"Localizable"),minute,STR(@"Universal_min", @"Localizable")];
                        }
                        
                    }
                    else
                    {
                        pathStatisticInfo = [NSString stringWithFormat:@"%d%@",minute,STR(@"Universal_min", @"Localizable")];
                    }
                }
                
			}
				break;
			case 3://耗时
			{
				
                if (bDataFormNet == 1) {
                    
                }
                else {
                    pathStatisticInfo = [NSString stringWithFormat:@"%d",ppStatInfoList->pPathStat->nTime];
                    
                }
				
			}
				break;
			case 4://总距离
			{
				pathStatisticInfo = [NSString stringWithFormat:@"%d",ppStatInfoList->pPathStat->nTotalDis];
			}
				break;
            case 5://收费总额
            {
                pathStatisticInfo = [NSString stringWithFormat:@"%d",ppStatInfoList->pPathStat->nTotalCharge];
            }
                break;
				
			default:
			{
				
                pathStatisticInfo = STR(@"Universal_unknown", @"Localizable");
				
			}
				break;
		}
		
	}
	else
	{
		pathStatisticInfo = STR(@"Universal_unknown", @"Localizable");
	}
	
	return pathStatisticInfo;
}

#pragma mark 多路线－获取路线信息
- (NSString *)GMD_GetPathStatisticInfoWithMainID:(int)mainID index:(int)index{
	
	NSString *pathStatisticInfo;
	
    
	if (GD_ERR_OK == GDBL_GetPathStatisticInfo(GNULL,Gtrue, Gtrue, &ppStatInfoList))
	{
        
        if(index >= ppStatInfoList->nNumberOfStat)
        {
            {
                pathStatisticInfo = STR(@"Universal_unknown", @"Localizable");
                
            }
            return pathStatisticInfo;
        }
        
		switch (mainID)
		{
			case 0:// 收费站
			{
				pathStatisticInfo = [NSString stringWithFormat:@"%d",ppStatInfoList->pPathStat[index].nTotalTollGate];
			}
				break;
				
			case 1:// 总距离
			{
                if (ppStatInfoList->pPathStat[index].nTotalDis > 1000)
                {
                    pathStatisticInfo = [NSString stringWithFormat:@"%0.1f%@",(ppStatInfoList->pPathStat[index].nTotalDis/1000.0),STR(@"Universal_KM", @"Localizable")];
                }
                else
                {
                    pathStatisticInfo = [NSString stringWithFormat:@"%d%@",ppStatInfoList->pPathStat[index].nTotalDis,STR(@"Universal_M", @"Localizable")];
                }
				
			}
				break;
			case 3://耗时
			{
				
                NSUInteger hour = (ppStatInfoList->pPathStat[index].nTime/60);
                NSUInteger minute = (ppStatInfoList->pPathStat[index].nTime%60);
                if (hour >0)
                {
                    if (0 == minute) {//如果分钟为0，则不显示分钟
                        pathStatisticInfo = [NSString stringWithFormat:@"%d%@",hour,STR(@"Universal_hour", @"Localizable")];
                    }
                    else{
                        pathStatisticInfo = [NSString stringWithFormat:@"%d%@%d%@",hour,STR(@"Universal_hour", @"Localizable"),minute,STR(@"Universal_min", @"Localizable")];
                    }
                    
                    
                }
                else
                {
                    pathStatisticInfo = [NSString stringWithFormat:@"%d%@",minute,STR(@"Universal_min", @"Localizable")];
                }
                
				
			}
				break;
                
			default:
			{
				pathStatisticInfo = STR(@"Universal_unknown", @"Localizable");
				
			}
				break;
		}
	}
	else
	{
		pathStatisticInfo = STR(@"Universal_unknown", @"Localizable");
	}
	
	return pathStatisticInfo;
}

- (void)GMD_GetManeuverInfoCurrentRoadName:(NSString **)curRoadName
                              NextRoadName:(NSString **)nextRoadName
                              NextDistance:(NSString **)nextDistance
                               DirectImage:(UIImage  **)directImage
                      TotalDistanceAndTime:(NSString **)distanceAndTime
{
    NSString  *_curRoadName = @"";
    NSString  *_nextRoadName = @"";
    NSString  *_nextDistance = @"";
    
    *curRoadName = @"";
    *nextRoadName = @"";
    *nextDistance = @"";
    *directImage = nil;
    *distanceAndTime = @"";
    
    if (![ANParamValue sharedInstance].isPath)
    {
        
        return;
    }
    
    GMANEUVERINFO *ManeuverInfo = {0};
    
    GSTATUS res = GDBL_GetManeuverInfo(&ManeuverInfo);
    
    int bDataFormNet = [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData;
    
    //if (GD_ERR_OK == res && pManeuverInfo != NULL)
    {
        //获取当前道路名
        if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
        {
            *curRoadName = [_curRoadName stringByAppendingString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_CurRoadName]] ? [_curRoadName stringByAppendingString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_CurRoadName]] : @"";
            
        }
        else
        {
            if ([ANParamValue sharedInstance].isMove) {
                *curRoadName = [_curRoadName stringByAppendingString:[self GMD_GetCurrentRoadName:GMAP_VIEW_TYPE_MAIN]] ? [_curRoadName stringByAppendingString:[self GMD_GetCurrentRoadName:GMAP_VIEW_TYPE_MAIN]] : @"";
                
            }
            else{
                if (GD_ERR_OK == res)
                    *curRoadName = [_curRoadName stringByAppendingString:[NSString chinaFontStringWithCString:ManeuverInfo->szCurRoadName]] ? [_curRoadName stringByAppendingString:[NSString chinaFontStringWithCString:ManeuverInfo->szCurRoadName]] : @"";
                
            }
            
        }
        
        //获取下一路口道路名,路口距离（单位：米)
        if (bDataFormNet == 1) {
            *nextRoadName = [_nextRoadName stringByAppendingString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_NextRoadName]] ? [_nextRoadName stringByAppendingString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_NextRoadName]] : @"";
            
            *nextDistance = [_nextDistance stringByAppendingString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainSegDistance]] ? [_nextDistance stringByAppendingString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainSegDistance]] : @"";
            
            NSString *remainDis = [[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainDistance] ? [[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainDistance] : @"";
            NSString *remainTime = [[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainTime] ? [[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainTime] : @"";
            *distanceAndTime = [NSString stringWithFormat:@"%@ / %@",remainDis,remainTime];
            
            
            *directImage = [self GMD_GetIconWithAmapID:[Plugin_OnLineMapUtility sharedInstance].m_iIcon imageID:NULL];
        }
        else {
            if (GD_ERR_OK == res)
            {
                *nextRoadName = [_nextRoadName stringByAppendingString:[NSString chinaFontStringWithCString:ManeuverInfo->szNextRoadName]] ? [_nextRoadName stringByAppendingString:[NSString chinaFontStringWithCString:ManeuverInfo->szNextRoadName]] : @"";
                
                if (ManeuverInfo->nNextDis > 1000)
                {
                    *nextDistance = [_nextDistance stringByAppendingString:[NSString stringWithFormat:@"%0.1f%@",(ManeuverInfo->nNextDis/1000.0),STR(@"Universal_KM", @"Localizable")]] ? [_nextDistance stringByAppendingString:[NSString stringWithFormat:@"%0.1f%@",(ManeuverInfo->nNextDis/1000.0),STR(@"Universal_KM", @"Localizable")]] : @"";
                }
                else
                {
                    *nextDistance = [_nextDistance stringByAppendingString:[NSString stringWithFormat:@"%d%@",ManeuverInfo->nNextDis,STR(@"Universal_M", @"Localizable")]] ? [_nextDistance stringByAppendingString:[NSString stringWithFormat:@"%d%@",ManeuverInfo->nNextDis,STR(@"Universal_M", @"Localizable")]] : @"";
                }
                
                NSString *remainDis,*remainTime;
                int dis = ManeuverInfo->nTotalRemainDis;
                if (bDataFormNet == 2) //本网数据结合时使用本地数据，剩余距离 = 网络总距离 - 本地总距离 + 本地剩余距离 （单位米）
                {
                    int net_total = [[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_PathDistance_NS] intValue];
                    int local_total = 0;
                    if (GD_ERR_OK == GDBL_GetPathStatisticInfo(GNULL,Gtrue, Gfalse, &ppStatInfoList))
                    {
                        local_total = ppStatInfoList->pPathStat->nTotalDis;
                    }
                    dis = net_total - local_total + dis;
                }
                if (dis > 1000)
                {
                    if (dis > 1000000) {
                        remainDis = [NSString stringWithFormat:@"%0.0f%@",(dis/1000.0),STR(@"Universal_KM", @"Localizable")];
                    }
                    else {
                        remainDis = [NSString stringWithFormat:@"%0.1f%@",(dis/1000.0),STR(@"Universal_KM", @"Localizable")];
                    }
                    
                }
                else
                {
                    remainDis = [NSString stringWithFormat:@"%d%@",ManeuverInfo->nTotalRemainDis,STR(@"Universal_M", @"Localizable")];
                }
                
                int time = ManeuverInfo->nTotalArrivalTime;
                if (bDataFormNet == 2) //本网数据结合时使用本地数据，剩余时间 = 网络总时间 - 本地总时间 + 本地剩余距离 （单位分）
                {
                    int net_total = [[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_PathTotalTime_NS] intValue];
                    net_total = net_total/60;
                    int local_total = 0;
                    if (GD_ERR_OK == GDBL_GetPathStatisticInfo(GNULL,Gtrue, Gfalse, &ppStatInfoList))
                    {
                        local_total = ppStatInfoList->pPathStat->nTime;
                    }
                    time = net_total - local_total + time;
                }
                
                NSUInteger hour = (time/60);
                NSUInteger minute = (time%60);
                if (hour >0)
                {
                    if (0 == minute) {//如果分钟为0，则不显示分钟
                        remainTime = [NSString stringWithFormat:@"%d%@",hour,STR(@"Universal_hour", @"Localizable")];
                    }
                    else{
                        remainTime = [NSString stringWithFormat:@"%d%@%d%@",hour,STR(@"Universal_hour", @"Localizable"),minute,STR(@"Universal_min", @"Localizable")];
                    }
                }
                else
                {
                    remainTime = [NSString stringWithFormat:@"%d%@",minute,STR(@"Universal_min", @"Localizable")];
                }
                
                *distanceAndTime = [NSString stringWithFormat:@"%@ / %@",remainDis,remainTime];
                
                if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 2)
                {
                    if (ManeuverInfo->nTurnID == 22 || ManeuverInfo->nTurnID == 99 || [Plugin_OnLineMapUtility sharedInstance].isChangingMap)
                    {
                        if ([ANParamValue sharedInstance].isPath)
                        {
                            *directImage = IMAGE(@"NetToLocal.png", IMAGEPATH_TYPE_1) ;
                        }
                    }
                }
                
            }
            
            static int turnID = 0;
            
            if (turnID != ManeuverInfo->nTurnID) {//add for hlf for 判断id不一样才去获取，降低cpu消耗
                *directImage = [[MWGuideOperator sharedInstance] MW_GetTurnIconWithID:ManeuverInfo->nTurnID flag:1];
            }
            else{
                *directImage = nil;
            }
            turnID = ManeuverInfo->nTurnID;
            
            if ([[ANParamValue sharedInstance] isNavi] && 99==ManeuverInfo->nTurnID)//模拟导航循环导航
            {
                
                GDBL_StopDemo();
                GDBL_StartDemo();
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_SimNaviStop] userInfo:nil];
                turnID = 0;
            }
            else if(([[ANParamValue sharedInstance] isPath]) && (![[ANParamValue sharedInstance] isNavi]) && 99==ManeuverInfo->nTurnID) //巡航结束删除路线
            {
                [[MWGuideOperator sharedInstance] MW_GuidanceOperateWithMainID:1 GuideHandle:NULL];
            }
        }
        
    }
    
}
#pragma mark 获取机动引导信息(当前道路名，路口距离，剩余距离，耗时，下路口名称，下路口距离，转向图标，下道路名称，出现放大路口时获取距离下一路口的距离，总距离)
- (NSString *)GMD_GetManeuverInfoWithMainID:(int)mainID {
    if (![ANParamValue sharedInstance].isPath) {
        return nil;
    }
	GSTATUS res = GDBL_GetManeuverInfo(&pManeuverInfo);
    
	int bDataFormNet = [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData;
	NSMutableString *maneuverInfo = [[NSMutableString alloc] init];
	
	switch (mainID)
	{
		case 0://当前道路名
		{
            if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
            {
                [maneuverInfo appendString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_CurRoadName]];
                
            } else {
                if ([ANParamValue sharedInstance].isMove) {
                    [maneuverInfo appendString:[self GMD_GetCurrentRoadName:GMAP_VIEW_TYPE_MAIN]];
                }
                else{
                    if (pManeuverInfo != NULL) {
                        [maneuverInfo appendString:[NSString chinaFontStringWithCString:pManeuverInfo->szCurRoadName]];
                    }
                    
                }
                
            }
            
		}
			break;
		case 1:// 路口距离（单位：米）
		{
            if (bDataFormNet == 1)
            {
                [maneuverInfo appendString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainSegDistance]];
            }
            else
            {
                if (res == GD_ERR_OK)
                {
                    if (pManeuverInfo->nNextDis > 1000)
                    {
                        [maneuverInfo appendString:[NSString stringWithFormat:@"%0.1f%@",(pManeuverInfo->nNextDis/1000.0),STR(@"Universal_KM", @"Localizable")]];
                    }
                    else
                    {
                        [maneuverInfo appendString:[NSString stringWithFormat:@"%d%@",pManeuverInfo->nNextDis,STR(@"Universal_M", @"Localizable")]];
                    }
                }
                else{
                    [maneuverInfo appendString:@""];
                }
            }
            
			
		}
			break;
		case 2://剩余距离(带单位)
		{
            if (bDataFormNet == 1)
            {
                [maneuverInfo appendString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainDistance]];
            }
            else
            {
                if (res == GD_ERR_OK)
                {
                    int dis = pManeuverInfo->nTotalRemainDis;
                    if (bDataFormNet == 2) //本网数据结合时使用本地数据，剩余距离 = 网络总距离 - 本地总距离 + 本地剩余距离 （单位米）
                    {
                        int net_total = [[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_PathDistance_NS] intValue];
                        int local_total = 0;
                        if (GD_ERR_OK == GDBL_GetPathStatisticInfo(GNULL,Gtrue, Gfalse, &ppStatInfoList))
                        {
                            local_total = ppStatInfoList->pPathStat->nTotalDis;
                        }
                        dis = net_total - local_total + dis;
                    }
                    if (dis > 1000)
                    {
                        if (dis > 1000000) {
                            [maneuverInfo appendString:[NSString stringWithFormat:@"%0.0f%@",(dis/1000.0),STR(@"Universal_KM", @"Localizable")]];
                        }
                        else {
                            [maneuverInfo appendString:[NSString stringWithFormat:@"%0.1f%@",(dis/1000.0),STR(@"Universal_KM", @"Localizable")]];
                        }
                        
                    }
                    else
                    {
                        [maneuverInfo appendString:[NSString stringWithFormat:@"%d%@",pManeuverInfo->nTotalRemainDis,STR(@"Universal_M", @"Localizable")]];
                    }
                    if ([[ANParamValue sharedInstance] isNavi] && 99==pManeuverInfo->nTurnID)//模拟导航循环导航
                    {
                        GDBL_StopDemo();
                        GDBL_StartDemo();
                    }
                    else if(([[ANParamValue sharedInstance] isPath]) && (![[ANParamValue sharedInstance] isNavi]) && 99==pManeuverInfo->nTurnID) //巡航结束删除路线
                    {
                        [[MWGuideOperator sharedInstance] MW_GuidanceOperateWithMainID:1 GuideHandle:NULL];
                    }
                }
                else{
                    [maneuverInfo appendString:@""];
                }
            }
            
		}
			break;
		case 3://剩余时间
		{
            if (bDataFormNet == 1)
            {
                [maneuverInfo appendString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainTime]];
            }
            else
            {
                if (res == GD_ERR_OK) {
                    int time = pManeuverInfo->nTotalArrivalTime;
                    if (bDataFormNet == 2) //本网数据结合时使用本地数据，剩余时间 = 网络总时间 - 本地总时间 + 本地剩余距离 （单位分）
                    {
                        int net_total = [[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_PathTotalTime_NS] intValue];
                        net_total = net_total/60;
                        int local_total = 0;
                        if (GD_ERR_OK == GDBL_GetPathStatisticInfo(GNULL,Gtrue, Gfalse, &ppStatInfoList))
                        {
                            local_total = ppStatInfoList->pPathStat->nTime;
                        }
                        time = net_total - local_total + time;
                    }
                    
                    NSUInteger hour = (time/60);
                    NSUInteger minute = (time%60);
                    if (hour >0)
                    {
                        if (0 == minute) {//如果分钟为0，则不显示分钟
                            [maneuverInfo appendString:[NSString stringWithFormat:@"%d%@",hour,STR(@"Universal_hour", @"Localizable")]];
                        }
                        else{
                            [maneuverInfo appendString:[NSString stringWithFormat:@"%d%@%d%@",hour,STR(@"Universal_hour", @"Localizable"),minute,STR(@"Universal_min", @"Localizable")]];
                        }
                    }
                    else
                    {
                        [maneuverInfo appendString:[NSString stringWithFormat:@"%d%@",minute,STR(@"Universal_min", @"Localizable")]];
                    }
                }
                else {
                    [maneuverInfo appendString:@""];
                }
            }
            
		}
			break;
		case 10://下个道路名称
		{
            if (bDataFormNet == 1) {
                [maneuverInfo appendString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_NextRoadName]];
            } else {
                if (res == GD_ERR_OK) {
                    [maneuverInfo appendString:[NSString chinaFontStringWithCString:pManeuverInfo->szNextRoadName]];
                }
                else {
                    [maneuverInfo appendString:@""];
                }
            }
			
            
		}
			break;
        case 11://剩余距离
		{
            if (bDataFormNet == 1) {
                [maneuverInfo appendString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainDistance]];
                
            } else {
                if (res == GD_ERR_OK) {
                    [maneuverInfo appendString:[NSString stringWithFormat:@"%d",pManeuverInfo->nTotalRemainDis]];
                }
                else {
                    [maneuverInfo appendString:@""];
                }
            }
			
            
		}
			break;
        case 12://出现放大路口时获取距离下一路口的距离
        {
            if (bDataFormNet == 1) {
                [maneuverInfo appendString:[[Plugin_OnLineMapUtility sharedInstance] NET_GetMapInfoWithType:NET_RemainSegDistance]];
            } else {
                int tmpDistance = [self GMD_GetZoomInfo:1];
                if (tmpDistance > 1000)
                {
                    [maneuverInfo appendString:[NSString stringWithFormat:@"%0.1f%@",(tmpDistance/1000.0),STR(@"Universal_KM", @"Localizable")]];
                }
                else
                {
                    [maneuverInfo appendString:[NSString stringWithFormat:@"%d%@",tmpDistance,STR(@"Universal_M", @"Localizable")]];
                }
            }
            
        }
            break;
            
		default:
			break;
	}
    
	return [maneuverInfo autorelease];
}


#pragma mark 获取行程点信息（0-起点 6-终点 2-5途径点）
- (void)GMD_GetJourneyPointInfo:(GPOI **)point
{
    GDBL_GetJourneyPoint(point);
}

#pragma mark 获取行程点数组信息
- (NSMutableArray *)GMD_GetJourneyPointArray
{
    NSMutableArray *journeyPointArray = [[NSMutableArray alloc] init];
    if ([ANParamValue sharedInstance].isPath) {
        GPOI *ppJourneyPoint = {0};
        GDBL_GetCurrentJourneyPoint(&ppJourneyPoint);
        //GDBL_GetJourneyPoint(&ppJourneyPoint);
        if ((ppJourneyPoint[0].Coord.x == 0 || ppJourneyPoint[0].Coord.y == 0))
        {
            
            GPOI tmpPOI = [ANParamValue sharedInstance].palellerRoadPOI;
            if (tmpPOI.Coord.x == 0 || tmpPOI.Coord.y == 0) {
                GCARINFO carInfo = {0};
                GDBL_GetCarInfo(&carInfo);
                tmpPOI.Coord.x = carInfo.Coord.x;
                tmpPOI.Coord.y = carInfo.Coord.y;
                strcpy(tmpPOI.szName, carInfo.szRoadName);
                
            }
            MWPoi *node = [[MWPoi alloc] init];
            
            node.longitude = tmpPOI.Coord.x;
            node.latitude = tmpPOI.Coord.y;
            node.lCategoryID = tmpPOI.lCategoryID;
            node.lDistance = tmpPOI.lDistance;
            node.lMatchCode = tmpPOI.lMatchCode;
            node.lHilightFlag = tmpPOI.lHilightFlag;
            node.lAdminCode = tmpPOI.lAdminCode;
            node.lPoiId = tmpPOI.lPoiId;
            node.siELonOff = tmpPOI.siELonOff;
            node.siELatOff = tmpPOI.siELatOff;
            if ([[NSString chinaFontStringWithCString:tmpPOI.szName] length] == 0)
            {
                node.szName = STR(@"Main_unNameRoad", @"Main");
            }
            else{
                node.szName = [NSString chinaFontStringWithCString:tmpPOI.szName];
            }
            
            node.szAddr = [NSString chinaFontStringWithCString:tmpPOI.szAddr];
            node.szTel = [NSString chinaFontStringWithCString:tmpPOI.szTel];
            node.lPoiIndex = tmpPOI.lPoiIndex;
            node.ucFlag = tmpPOI.ucFlag;
            node.usNodeId = tmpPOI.usNodeId;
            
            [journeyPointArray addObject:node];
            [node release];
            
        }
        
        for (int i = 0; i < 7; i++) {
            if (ppJourneyPoint[i].Coord.x != 0 || ppJourneyPoint[i].Coord.y != 0) {
                
                MWPoi *node = [[MWPoi alloc] init];
                
                node.longitude = ppJourneyPoint[i].Coord.x;
                node.latitude = ppJourneyPoint[i].Coord.y;
                node.lCategoryID = ppJourneyPoint[i].lCategoryID;
                node.lDistance = ppJourneyPoint[i].lDistance;
                node.lMatchCode = ppJourneyPoint[i].lMatchCode;
                node.lHilightFlag = ppJourneyPoint[i].lHilightFlag;
                node.lAdminCode = ppJourneyPoint[i].lAdminCode;
                node.lPoiId = ppJourneyPoint[i].lPoiId;
                node.siELonOff = ppJourneyPoint[i].siELonOff;
                node.siELatOff = ppJourneyPoint[i].siELatOff;
                node.szName = [NSString chinaFontStringWithCString:ppJourneyPoint[i].szName];
                node.szAddr = [NSString chinaFontStringWithCString:ppJourneyPoint[i].szAddr];
                node.szTel = [NSString chinaFontStringWithCString:ppJourneyPoint[i].szTel];
                node.lPoiIndex = ppJourneyPoint[i].lPoiIndex;
                node.ucFlag = ppJourneyPoint[i].ucFlag;
                node.usNodeId = ppJourneyPoint[i].usNodeId;
                
                [journeyPointArray addObject:node];
                [node release];
            }
        }
    }
    return [journeyPointArray autorelease];
}
#pragma mark 获取当前道路名
- (NSString *)GMD_GetCurrentRoadName:(GMAPVIEWTYPE)mapViewType {
	
	NSMutableString *viewTitle = [[NSMutableString alloc] init];
	
	GMAPCENTERINFO mapinfo = {0};
    
    [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:mapViewType mapCenterInfo:&mapinfo];
	
	[viewTitle appendString:[NSString chinaFontStringWithCString:mapinfo.szRoadName]];
	if(viewTitle.length == 0)
    {
        [viewTitle appendString:[NSMutableString stringWithFormat:@"%@",STR(@"Main_unNameRoad", @"Main")]] ;
    }
	return [viewTitle autorelease];
}


#pragma mark POI类别列表
- (void)GMD_GetPOICategoryList {
	
	GDBL_GetPOICategoryList(0, &ppCategoryList);
}


#pragma mark 设置POI类别
- (void)GMD_SetPOICategoryIDWithMainID:(NSInteger)ID {
	
	POICategoryID = ID;
}

- (UIImage *)GMD_GetIconWithAmapID:(int)ID imageID:(int *)imageID
{
    if (ID == 2)
    {
        ID = 78;
    }
    else if (ID == 3)
    {
        ID = 74;
    }
    else if (ID == 4)
    {
        ID = 79;
    }
    else if (ID == 5)
    {
        ID = 73;
    }
    else if (ID == 6)
    {
        ID = 77;
    }
    else if (ID == 7)
    {
        ID = 75;
    }
    else if (ID == 8)
    {
        ID = 76;
    }
    else if (ID == 9)
    {
        ID = 72;
    }
    else if (ID == 10)
    {
        ID = 86;
    }
    else if (ID == 11)
    {
        ID = 51;
    }
    else if (ID == 12)
    {
        ID = 48;
    }
    else if (ID == 13)
    {
        ID = 6;
    }
    else if (ID == 14)
    {
        ID = 85;
    }
    else if (ID == 15)
    {
        ID = 91;
    }
    else if (ID == 16)
    {
        ID = 13;
    }
    else
    {
        ID = 1;
    }
    if (imageID != NULL)
    {
        *imageID = ID;
    }
    
    return [[MWGuideOperator sharedInstance] MW_GetTurnIconWithID:ID flag:1];
}

- (UIImage *)GMD_GetIconWithMainID:(int)mainID
{
    
    if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 1)  //使用TBT导航数据
    {
        return [self GMD_GetIconWithAmapID:[Plugin_OnLineMapUtility sharedInstance].m_iIcon imageID:NULL];
    }
    else
    {
        
        GSTATUS res =  GDBL_GetManeuverInfo(&pManeuverInfo);
        if (GD_ERR_OK == res)
        {
            if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 2)
            {
                if (pManeuverInfo->nTurnID == 22 || pManeuverInfo->nTurnID == 99 || [Plugin_OnLineMapUtility sharedInstance].isChangingMap)
                {
                    if ([ANParamValue sharedInstance].isPath)
                    {
                        return IMAGE(@"NetToLocal.png", IMAGEPATH_TYPE_1) ;
                    }
                }
            }
            
            return [[MWGuideOperator sharedInstance] MW_GetTurnIconWithID:pManeuverInfo->nTurnID flag:1];
        }
    }
	
	return nil;
}

- (int)GMD_GetIconID
{
    if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 1)  //使用TBT导航数据
    {
        int ID = -1;
        [self GMD_GetIconWithAmapID:[Plugin_OnLineMapUtility sharedInstance].m_iIcon imageID:&ID];
        return ID;
    }
    else
    {
        GSTATUS res =  GDBL_GetManeuverInfo(&pManeuverInfo);
        if (GD_ERR_OK == res)
        {
            if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 2)
            {
                if (pManeuverInfo->nTurnID == 22 || pManeuverInfo->nTurnID == 99 || [Plugin_OnLineMapUtility sharedInstance].isChangingMap)
                {
                    return 100;
                }
            }
            
            return pManeuverInfo->nTurnID;
        }
    }
    
    return -1;
}

//==============================================================================


#pragma mark 传入行政编码，获取区域信息：省，市，区
- (NSDictionary *)GMD_AdminCodeToAreaInfo:(Gint32)admincode {
	GADAREAINFOEX AdareaInfoEx = {0};
	GSTATUS res = GDBL_GetAdareaInfoEx(admincode, &AdareaInfoEx);
    if (res == GD_ERR_OK) {
        NSDictionary *areaInfo = [[NSDictionary alloc] initWithObjectsAndKeys:
                                  [NSString chinaFontStringWithCString:AdareaInfoEx.szProvName],@"province",
                                  [NSString chinaFontStringWithCString:AdareaInfoEx.szCityName],@"city",
                                  [NSString chinaFontStringWithCString:AdareaInfoEx.szTownName],@"town",
                                  [ NSNumber numberWithInt:AdareaInfoEx.lAdminCode],@"admincode",nil];
        
        return [areaInfo autorelease];
    }
	else {
        return nil;
    }
}

- (NSDictionary *)GMD_AdminCodeToAreaInfoEx:(Gint32)admincode {
	
	GDBL_GetAdareaInfoExChn(admincode, &pAdareaInfoEx);
	NSDictionary *areaInfo = [[NSDictionary alloc] initWithObjectsAndKeys:
							  [NSString chinaFontStringWithCString:pAdareaInfoEx.szProvName],@"province",
							  [NSString chinaFontStringWithCString:pAdareaInfoEx.szCityName],@"city",
							  [NSString chinaFontStringWithCString:pAdareaInfoEx.szTownName],@"town",
                              [ NSNumber numberWithInt:pAdareaInfoEx.lAdminCode],@"admincode",nil];
    
	return [areaInfo autorelease];
}

#pragma mark 传入经纬度，获取区域信息：省，市，区
- (NSDictionary *)GMD_CoordToAreaInfo:(long)lon Lat:(long)lat {
    
	Gint32 adminCode = [self GMD_CoordToAdminCode:lon Lat:lat];
    if (adminCode == 0) {
        return nil;
    }
	return [self GMD_AdminCodeToAreaInfo:adminCode];
}

- (NSDictionary *)GMD_CoordToAreaInfoEx:(long)lon Lat:(long)lat {
    
	Gint32 adminCode = [self GMD_CoordToAdminCode:lon Lat:lat];
	return [self GMD_AdminCodeToAreaInfo:adminCode];
}
#pragma mark 获取当前点sp编码
- (NSString *)GMD_GetCurrentSPCode:(GMAPVIEWTYPE)mapViewType
{
    // 获得 SP 编码
    Gchar szSP[256] = {0};
    //获取地图中心信息
    GMAPCENTERINFO mapinfo = {0};
    [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:mapViewType mapCenterInfo:&mapinfo];
    //转换经纬坐标到SP编码
    GDBL_GeoCoordToSP(&(mapinfo.CenterCoord), szSP, 256);
    return [NSString chinaFontStringWithCString:szSP];
}
#pragma mark 经纬度获取sp编码
- (NSString *)GMD_CoordToSPCode:(long)lon Lat:(long)lat {
	
	GCOORD pCoord;
	pCoord.x = lon;
	pCoord.y = lat;
	
	Gchar szSP[256] = {0};//获得SP编码
	GDBL_GeoCoordToSP(&pCoord, szSP, 256);
	
	return [NSString chinaFontStringWithCString:szSP];
}
#pragma mark sp编码获取经纬度
- (GCOORD )GMD_SPCodeToCoord:(Gchar *)spcode
{
	//保存转换的经纬坐标
	GCOORD g_Coord = {0};
    GSTATUS res;
	res = GDBL_SPToGeoCoord(spcode, &g_Coord);
	//NSLog(@"x=,%ld,%ld",g_Coord.x,g_Coord.y);
	return g_Coord;
	
}
#pragma mark 经纬度转行政编码
- (Gint32)GMD_CoordToAdminCode:(long)lon Lat:(long)lat {
	
	Gint32 adminCode = 0;
	
	GCOORDTEL coordTel={0};
	coordTel.eFlag = COORDTEL_TYPE_COORD;
	coordTel.u.Coord.x = lon;
	coordTel.u.Coord.y = lat;
	GSTATUS res;
	res = GDBL_GetAdminCode(&coordTel, &adminCode);
	if (res == GD_ERR_OK) {
        return adminCode;
    }
	return 0;
}

#pragma mark 获取导航系统,引擎,地图,电子眼版本字符串
- (NSString *)GMD_GetVersionInfoWithMainID:(NSInteger)ID {
	
	GVERSION pVersion;
	
	NSMutableString *VersionInfo = [[NSMutableString alloc] init];;
	
	switch (ID)
	{
		case 0:
		{
			[VersionInfo appendFormat:@"导航系統版本:V 6.9.0406.0528"];
		}
			break;
			
		case 1:
		{
			GDBL_GetMapVersion(NULL,&pVersion);
			[VersionInfo appendFormat:@"%s",pVersion.szVersion];
		}
			break;
			
		case 2:
		{
			GDBL_GetEngineVersion(&pVersion);
			//[VersionInfo appendFormat:@"导航引擎版本:V 5.1.1110.0009"];
			[VersionInfo appendFormat:@"%s",pVersion.szVersion];
		}
			break;
			
		case 3:
		{
			[VersionInfo appendFormat:@"电子眼版本:V03.00.1142"];
		}
			break;
			
		default:
			break;
	}
	
	return [VersionInfo autorelease];
}

#pragma mark 获取附近点信息
- (void)GetNearPOI:(GMAPVIEWTYPE)mapViewType
{
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        if ([Plugin_OnLineMapUtility sharedInstance].isMove) {
            GCOORD coord = {0};
            coord.x = [Plugin_OnLineMapUtility sharedInstance].m_maMapView.centerCoordinate.longitude * 1000000;
            coord.y = [Plugin_OnLineMapUtility sharedInstance].m_maMapView.centerCoordinate.latitude * 1000000;
            GMOVEMAP moveMap;
            moveMap.eOP = MOVEMAP_OP_GEO_DIRECT;
            moveMap.deltaCoord = coord;
            
            [[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
        }
    }
	[plugin_SearchPoiOperate sharedInstance];
	//获取地图中心信息
    GMAPCENTERINFO mapinfo = {0};
    [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:mapViewType mapCenterInfo:&mapinfo];
    
    GSTATUS res = GDBL_RequestNearestPOI(mapinfo.CenterCoord);
    if (res != GD_ERR_OK) {
        DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
        msg.flag = _GD_SEARCH_RESULT_FAILED_1;
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
        [msg release];
    }
    
}
-(void)GetNearPOI:(long)lon Lat:(long)lat
{
    [plugin_SearchPoiOperate sharedInstance];
    
	GCOORD Coord;
    Coord.x = lon;
    Coord.y = lat;
    GSTATUS res = GDBL_RequestNearestPOI(Coord);
    if (res != GD_ERR_OK) {
        DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
        msg.flag = _GD_SEARCH_RESULT_FAILED_1;
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
        [msg release];
    }
}

-(GCOORD)GMD_CoordConvert:(GCOORDCONVERT)convertType Lon:(Gint32)lon Lat:(Gint32)lat HMapView:(GMAPVIEWTYPE)mapViewType
{
    
    
	GCOORD poiCoord;
	poiCoord.x = lon;
	poiCoord.y = lat;
	GCOORD g_startCoord;
	
    //转换地图中心位置给起点坐标
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        CGPoint point = [[Plugin_OnLineMapUtility sharedInstance] ConvertCoordToScreenWithLon:(double)lon/1000000.0 Lat:(double)lat/1000000.0];
        g_startCoord.x = point.x;
        g_startCoord.y = point.y;
    }
    else
    {
        GSTATUS sign;
        GHMAPVIEW mapHandle;
        GDBL_GetMapViewHandle(mapViewType,&mapHandle);
        
        if (GCC_GEO_TO_SCR == convertType) {
            sign = GDBL_CoordConvert(convertType, &g_startCoord, &poiCoord,mapHandle);
            if (sign == GD_ERR_OK)
            {
                g_startCoord.x = g_startCoord.x/[[ANParamValue sharedInstance] scaleFactor];
                g_startCoord.y = g_startCoord.y/[[ANParamValue sharedInstance] scaleFactor];
            }
            else
            {
                g_startCoord.x = 0;
                g_startCoord.y = 0;
            }
        }
        else if(GCC_SCR_TO_GEO == convertType)
        {
            sign = GDBL_CoordConvert(convertType, &poiCoord, &g_startCoord,mapHandle);
            if (sign != GD_ERR_OK)
            {
                g_startCoord.x = 0;
                g_startCoord.y = 0;
            }
            
        }
        
    }
	
	return g_startCoord;
	
}

#pragma mark 获取地图角度
- (int)GMD_GetCarDirection:(GMAPVIEWTYPE)mapViewType
{
    GMAPVIEWINFO mapViewInfo = {0};
    
    [[MWMapOperator sharedInstance] MW_GetMapViewInfo:mapViewType MapViewInfo:&mapViewInfo];
    
    return (360 - mapViewInfo.nMapAngle);
}




-(int)GMD_CalculateDistance
{
    Gint32 dis;
    GCARINFO pCarInfo;
    GDBL_GetCarInfo(&pCarInfo);
    
    //获取地图中心信息
    GMAPCENTERINFO mapinfo = {0};
    [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
    GDBL_CalcDistance (&(mapinfo.CenterCoord), &pCarInfo.Coord, &dis);
    return dis;
}
//计算两点间的距离
-(int)GMD_CalculateDistanceWithStart:(GCOORD)start Des:(GCOORD)des
{
    Gint32 dis;
    GDBL_CalcDistance (&start, &des, &dis);
    return dis;
}
#pragma mark 获取平行道路
-(NSMutableArray *)GMD_GetCarParallelRoads
{
    NSMutableArray *ParaleRoadArray = [[NSMutableArray alloc] init];
    GCARPARALLELROAD *ppCarParallelRoads;
    Guint32 nNumberOfCarParallelRoad = 0;
    GSTATUS res = GDBL_GetCarParallelRoads(&ppCarParallelRoads,&nNumberOfCarParallelRoad);
    if (res == GD_ERR_OK)
    {
        for (int i=0; i<nNumberOfCarParallelRoad; i++)
        {
            plugin_PoiNode *node = [[plugin_PoiNode alloc] init];
            
            node.lCategoryID = ppCarParallelRoads[i].nID;
            if (strlen(ppCarParallelRoads[i].szRoadName))
            {
                node.szName = [NSString chinaFontStringWithCString:ppCarParallelRoads[i].szRoadName];
            }
            else
            {
                node.szName = STR(@"Main_unNameRoad", @"Main");
            }
            
            [ParaleRoadArray addObject:node];[node release];
        }
        
    }
    return [ParaleRoadArray autorelease];
}

#pragma mark 获取指定行政编码的城市名
- (NSString *)GMD_GetCityNameWithAdminCode:(int)nAdminCode
{
    NSString *strCityName = @"";
    if ((nAdminCode/10000 == 81)||(nAdminCode/10000 == 82)||(nAdminCode/10000 == 11)||(nAdminCode/10000 == 50)||(nAdminCode/10000 == 31)||(nAdminCode/10000 == 12))
    {
        if ([[[self GMD_AdminCodeToAreaInfo:nAdminCode] objectForKey:@"province"] length] != 0)
        {
            strCityName = [[self GMD_AdminCodeToAreaInfo:nAdminCode] objectForKey:@"province"];
        }
    }
    else
    {
        strCityName = [[self GMD_AdminCodeToAreaInfo:nAdminCode] objectForKey:@"city"];
        
    }
    return strCityName;
}

#pragma mark 获取城市行政编码（对直辖市的行政编码作处理）
- (int)GMD_GetCityAdminCodeWithAdminCode:(int)nAdminCode
{
    int admincode = 0;
    if ((nAdminCode/10000 == 81)||(nAdminCode/10000 == 82)||(nAdminCode/10000 == 11)||(nAdminCode/10000 == 50)||(nAdminCode/10000 == 31)||(nAdminCode/10000 == 12))
    {
        admincode = nAdminCode/10000*10000;
    }
    else
    {
        
        admincode = nAdminCode/100*100;
    }
    return admincode;
}

#pragma mark 获取当前车位的城市名
- (NSString *)GMD_GetCurrentLocationCityName
{
    //获取地图中心信息
    GMAPCENTERINFO mapinfo = {0};
    [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
    NSString *strCityName;
    
    if ([[[self GMD_CoordToAreaInfoEx:mapinfo.CenterCoord.x Lat:mapinfo.CenterCoord.y] objectForKey:@"province"] length] != 0)
    {
        int nAdminCode = [[[self GMD_CoordToAreaInfoEx:mapinfo.CenterCoord.x Lat:mapinfo.CenterCoord.y] objectForKey:@"admincode"] intValue];
        if ((nAdminCode/10000 == 81)||(nAdminCode/10000 == 82)||(nAdminCode/10000 == 11)||(nAdminCode/10000 == 50)||(nAdminCode/10000 == 31)||(nAdminCode/10000 == 12))
        {
            if ([[[self GMD_CoordToAreaInfoEx:mapinfo.CenterCoord.x Lat:mapinfo.CenterCoord.y] objectForKey:@"province"] length] != 0)
            {
                strCityName = [[self GMD_CoordToAreaInfoEx:mapinfo.CenterCoord.x Lat:mapinfo.CenterCoord.y] objectForKey:@"province"];
                return strCityName;
            }
        }
        else
        {
            strCityName = [[self GMD_CoordToAreaInfoEx:mapinfo.CenterCoord.x Lat:mapinfo.CenterCoord.y] objectForKey:@"city"];
            return strCityName;
        }
        return nil;
    }
    else
    {
        return nil;
    }
}

#pragma mark 检测地图数据
//根据行政编码查看是否有地图数据
//flag:0 判断当前所在位置是否有地图数据 1 传入指定行政编码看是否有地图数据
//返回值：0：表示无数据 1：表示有数据
-(int)GMD_checkIsExistData:(long)adminCode flag:(int)bCurrentAdminCode
{
    GADAREAINFOEX areaInfo = {0};
	if (bCurrentAdminCode == 0) {
		long Admin_code;
		Admin_code = [[ANDataSource sharedInstance] GMD_GetCurrentAdmincode];
		if (Admin_code == 0) {
			
			return 0;
		}
        GDBL_GetAdareaInfoEx(Admin_code,&areaInfo);
		if (areaInfo.bHasData == 1) {
			
			return 1;
		}
		else {
			
			return 0;
		}
        
	}
	else if(bCurrentAdminCode == 1){
		GDBL_GetAdareaInfoEx(adminCode,&areaInfo);
		if(areaInfo.bHasData  == 1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
	}
    return 0;
}

#pragma mark 根据地图类型，判断地图当前的比例尺状态 该函数暂时只用于非主地图界面（不考虑3d）
-(GZOOMLEVEL) GMD_GetMapScaleLevelWithType:(GMAPVIEWTYPE) nMapViewType
{
    GHMAPVIEW hMapView;
    GMAPVIEWINFO stMapObjectInfo = {0};
    GZOOMLEVEL nScaleLevel=ZOOM_200_KM;
    GSTATUS nStatus;
    
    // 地图句柄
    [[MWMapOperator sharedInstance] MW_GetMapViewHandle:nMapViewType MapHandle:&hMapView];
    
    // 地图信息
    nStatus = GDMID_GetMapObjectInfo(hMapView, &stMapObjectInfo);
    
    if (nStatus == GD_ERR_OK){
        
        // 比例尺
        nScaleLevel = stMapObjectInfo.eScaleLevel;
    }
    return nScaleLevel;
}
#pragma mark UI根据规则重新整理道路列表(根据组合条件组装，有二级子列表)
- (NSArray *)GMD_EncapsulateGuideRoadList
{
    // Traffic status 4 (free, slow, crounded, nodata)
    float fFree=0.0, fSlow=0.0, fCrounded=0.0, fNoData=0.0;
    //
	NSMutableArray *RoadListInfo = [[NSMutableArray alloc] init];
	
	GDBL_GetGuideRoadList(NULL,Gtrue, &ppGuideRoadList);
    int nCarPosition = [[MWGuideOperator sharedInstance] MW_GetRoadIDCarPositon];
	/*
     组合条件：
     1 保留起点，目的地
     2 实时交通开启：四种交通情况不组合
     3 直行的道路组合到非直行的道路中，展开时显示
     4 组合的道路里面，需要包含所有道路
     5 根据4的情况，每个主道路里面至少有一个子道路
     6 从目的地开始往前合并，第一个和最后一个直接加入数组，别的需要判断
     */
    int nPreviousDirect = 0;
    int nPreviousTraffic = 0;
    int nTotalDistance = 0;
    MainRoadInfo* mainRoadInfo;
    for (int i=ppGuideRoadList->nNumberOfRoad-1; i>=0; i--)
    {
        // 道路方向
        int nDirectID = ppGuideRoadList->pGuideRoadInfo[i].nTurnID;
        // 道路距离
        NSString* szDistance;
        nTotalDistance+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
        if (ppGuideRoadList->pGuideRoadInfo[i].nNextDis < 1000)
        {
            szDistance = [NSString stringWithFormat:@"%dm",ppGuideRoadList->pGuideRoadInfo[i].nNextDis];
        }
        else
        {
            szDistance = [NSString stringWithFormat:@"%.1fkm",(ppGuideRoadList->pGuideRoadInfo[i].nNextDis)/1000.0];
        }
        // 道路名称
        NSString* szRoadName = [NSString chinaFontStringWithCString:ppGuideRoadList->pGuideRoadInfo[i].szCurRoadName];
        // 道路交通情况        // UI层只定义4个情况 1 畅通；2,3 缓行；4,5拥堵；6,7无数据
        int nTrafficStatus = 4;
        if ([[ANParamValue sharedInstance] GMD_isTMCOn]&&[[MWPreference sharedInstance] getValue:PREF_TRAFFICMESSAGE])
        {
            if (ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=1) {
                nTrafficStatus = 1;
                fFree+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
            }else if(ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=3) {
                nTrafficStatus = 2;
                fSlow+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
            }else if(ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=5) {
                nTrafficStatus = 3;
                fCrounded+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
            }else{
                fNoData+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
            }
        }
        // 第一项和最后一项不判断是否组合，别的按照交通情况和路口方向组合
        if (nTrafficStatus==nPreviousTraffic&&i>0&&i<(ppGuideRoadList->nNumberOfRoad-2)&&nDirectID<19) {
            // 详细道路信息
            SubRoadInfo* subRoadInfo = [[SubRoadInfo alloc] init];
            subRoadInfo.psnDirectID  = nDirectID;
            subRoadInfo.psnTrafficStatus = nTrafficStatus;
            subRoadInfo.psszDistance = szDistance;
            subRoadInfo.psszRoadName = szRoadName;
            subRoadInfo.psnIndexInRoadList = i;
            // 车位是否在道路上
            if (ppGuideRoadList->nNumberOfRoad-1-i==nCarPosition) {
                subRoadInfo.psbCarOnTheRoad = TRUE;
                mainRoadInfo.psbCarOnTheRoad = TRUE;
            }
            mainRoadInfo.psnCountOfSubRoadInfo++;
            [mainRoadInfo.psarraySubRoadInfo addObject:subRoadInfo];
            [subRoadInfo release];
        }
        // 主要路径信息
        else{
            // 添加原来的
            if (i<ppGuideRoadList->nNumberOfRoad-1||i==0) {
                // 重新设置距离
                nTotalDistance-=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
                if (nTotalDistance < 1000)
                {
                    mainRoadInfo.psszDistance = [NSString stringWithFormat:@"%d%@",nTotalDistance,STR(@"Universal_M", @"Localizable")];
                }
                else
                {
                    mainRoadInfo.psszDistance = [NSString stringWithFormat:@"%.1f%@",nTotalDistance/1000.0,STR(@"Universal_KM", @"Localizable")];
                }
                nTotalDistance = ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
                [RoadListInfo addObject:mainRoadInfo];
                [mainRoadInfo release];
                
            }
            // 新建
            mainRoadInfo = [[MainRoadInfo alloc]init];
            NSMutableArray* arraySubRoadInfo = [[NSMutableArray alloc]init];
            mainRoadInfo.psarraySubRoadInfo = arraySubRoadInfo;
            [arraySubRoadInfo release];
            mainRoadInfo.psnCountOfSubRoadInfo = 0;
            //
            mainRoadInfo.psnDirectID = nDirectID;
            mainRoadInfo.psnTrafficStatus = nTrafficStatus;
            mainRoadInfo.psszDistance = szDistance;
            mainRoadInfo.psszRoadName = szRoadName;
            mainRoadInfo.psnIndexInRoadList = i;
            // 详细道路信息
            SubRoadInfo* subRoadInfo = [[SubRoadInfo alloc] init];
            subRoadInfo.psnDirectID  = nDirectID;
            subRoadInfo.psnTrafficStatus = nTrafficStatus;
            subRoadInfo.psszDistance = szDistance;
            subRoadInfo.psszRoadName = szRoadName;
            subRoadInfo.psnIndexInRoadList = i;
            // 车位是否在道路上
            if (ppGuideRoadList->nNumberOfRoad-1-i==nCarPosition) {
                subRoadInfo.psbCarOnTheRoad = TRUE;
                mainRoadInfo.psbCarOnTheRoad = TRUE;
            }
            mainRoadInfo.psnCountOfSubRoadInfo++;
            [mainRoadInfo.psarraySubRoadInfo addObject:subRoadInfo];
            [subRoadInfo release];
            
            //事件状态
            GEVENTINFO *pEventInfo = {0};
            Gint32 nEventCount = 0;
            GSTATUS res;
            res = GDBL_FilterTMCEvent(GNULL,0,TRUE);//设置事件过滤
            res = GDBL_GetEventInfo(&pEventInfo, &nEventCount);//获取过滤后的所有事件
            if (GD_ERR_OK == res) {
                for (int j = 0; j < nEventCount; j++) {
                    if (pEventInfo[j].nMeshID == ppGuideRoadList->pGuideRoadInfo[i].nMeshID && pEventInfo[j].nRoadID == ppGuideRoadList->pGuideRoadInfo[i].nMeshRoadID) {
                        
                        //道路名字
                        NSString *roadName = [NSString chinaFontStringWithCString:pEventInfo[j].szOccured];
                        NSString *disFromCar;
                        NSString *streamType;
                        NSString *impactRange;
                        
                        //车辆距事件，交通流距离
                        
                        float fDistance = pEventInfo[j].nDisToCar;
                        if (fDistance>1000) {
                            fDistance = fDistance/1000;
                            disFromCar = [NSString stringWithFormat:@"%.2f%@", fDistance,STR(@"Universal_KM", @"Localizable")];
                        }else{
                            disFromCar = [NSString stringWithFormat:@"%.f%@", fDistance,STR(@"Universal_M", @"Localizable")];
                        }
                        
                        //交通流类型
                        streamType = [NSString chinaFontStringWithCString:pEventInfo[j].szDescription];
                        
                        //影响范围
                        
                        float fRange = pEventInfo[j].nEventRange;
                        if (fRange>1000) {
                            fRange = fRange/1000;
                            impactRange = [NSString stringWithFormat:@"%.2f%@", fRange,STR(@"Universal_KM", @"Localizable")];
                        }else{
                            impactRange = [NSString stringWithFormat:@"%.f%@", fRange,STR(@"Universal_M", @"Localizable")];
                        }
                        mainRoadInfo.psnEventState = pEventInfo[j].nEventID > 20 ? ((pEventInfo[j].nEventID >> 16) & 0Xff) : pEventInfo[j].nEventID;;
                        mainRoadInfo.psbEvent = TRUE;
                        mainRoadInfo.psszEventDetail = [NSString stringWithFormat:STR(@"TMC_trafficInfo", @"TMC"),disFromCar,roadName,streamType,impactRange];
                        NSLog(@"detail==%@",mainRoadInfo.psszEventDetail);
                        break;
                        
                    }
                    mainRoadInfo.psbEvent = FALSE;
                }
            }
            //if (i==0)
            {
                [RoadListInfo addObject:mainRoadInfo];
                [mainRoadInfo release];
            }
        }
        nPreviousDirect = nDirectID;
        nPreviousTraffic = nTrafficStatus;
    }
    /*
     1 calculate the persentage of the traffic status
     */
    float ftotal = fNoData+fFree+fSlow+fCrounded;
    [CustomRealTimeTraffic sharedInstance].psfFreeStatus = fFree/ftotal;
    [CustomRealTimeTraffic sharedInstance].psfSlowStatus = fSlow/ftotal;
    [CustomRealTimeTraffic sharedInstance].psfHeavyStatus = fCrounded/ftotal;
	return RoadListInfo;
}
#pragma mark 获取主要道路列表
- (NSArray *)GMD_GetMainGuideRoadList
{
    // Traffic status 4 (free, slow, crounded, nodata)
    float fFree=0.0, fSlow=0.0, fCrounded=0.0, fNoData=0.0;
    int nCarPosition = 0;
    //
	NSMutableArray *RoadListInfo = [[NSMutableArray alloc] init];
	
	GSTATUS res = GDBL_GetGuideRoadList(NULL,Gfalse, &ppGuideRoadList);
    if (GD_ERR_OK == res) {
        for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++) {
            if(ppGuideRoadList->pGuideRoadInfo[i].eFlag&0x04)
            {
                nCarPosition =  ppGuideRoadList->nNumberOfRoad-1-i;
            }
        }
        
        int nTotalDistance = 0;
        MainRoadInfo* mainRoadInfo;
        for (int i = 0; i < ppGuideRoadList->nNumberOfRoad; i++)
        {
            // 道路方向
            int nDirectID = ppGuideRoadList->pGuideRoadInfo[i].nTurnID;
            // 道路距离
            NSString* szDistance;
            nTotalDistance+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
            if (ppGuideRoadList->pGuideRoadInfo[i].nNextDis < 1000)
            {
                szDistance = [NSString stringWithFormat:@"%d%@",ppGuideRoadList->pGuideRoadInfo[i].nNextDis,STR(@"Universal_M", @"Localizable")];
            }
            else
            {
                szDistance = [NSString stringWithFormat:@"%.1f%@",(ppGuideRoadList->pGuideRoadInfo[i].nNextDis)/1000.0,STR(@"Universal_KM", @"Localizable")];
            }
            // 当前道路名称
            NSString *szRoadName = [NSString chinaFontStringWithCString:ppGuideRoadList->pGuideRoadInfo[i].szCurRoadName];
            
            // 下一道路名称
            NSString *szNextRoadName = [NSString chinaFontStringWithCString:ppGuideRoadList->pGuideRoadInfo[i].szNextRoadName];
            
            // 道路交通情况        // UI层只定义4个情况 1 畅通；2,3 缓行；4,5拥堵；6,7无数据
            int nTrafficStatus = 4;
            if ([[ANParamValue sharedInstance] GMD_isTMCOn]&&[[MWPreference sharedInstance] getValue:PREF_TRAFFICMESSAGE])
            {
                if (ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=1) {
                    nTrafficStatus = 1;
                    fFree+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
                }else if(ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=3) {
                    nTrafficStatus = 2;
                    fSlow+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
                }else if(ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=5) {
                    nTrafficStatus = 3;
                    fCrounded+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
                }else{
                    fNoData+=ppGuideRoadList->pGuideRoadInfo[i].nNextDis;
                }
            }
            NSLog(@"交通流：%d",nTrafficStatus);
            // 新建
            mainRoadInfo = [[MainRoadInfo alloc]init];
            mainRoadInfo.psnDirectID = nDirectID;
            mainRoadInfo.psnTrafficStatus = nTrafficStatus;
            mainRoadInfo.psszDistance = szDistance;
            mainRoadInfo.psszRoadName = szRoadName;
            mainRoadInfo.psszNextRoadName = szNextRoadName;
            mainRoadInfo.psnIndexInRoadList = i;
            
            // 车位是否在道路上
            if (ppGuideRoadList->nNumberOfRoad-1-i==nCarPosition) {
                
                mainRoadInfo.psbCarOnTheRoad = TRUE;
            }
            //事件状态
            GEVENTINFO *pEventInfo = {0};
            Gint32 nEventCount = 0;
            
            res = GDBL_FilterTMCEvent(GNULL,0,TRUE);//设置事件过滤
            res = GDBL_GetEventInfo(&pEventInfo, &nEventCount);//获取过滤后的所有事件
            if (GD_ERR_OK == res) {
                for (int j = 0; j < nEventCount; j++) {
                    NSLog(@"id==%d,%d,%d,%d",pEventInfo[j].nMeshID,ppGuideRoadList->pGuideRoadInfo[i].nMeshID,pEventInfo[j].nRoadID,ppGuideRoadList->pGuideRoadInfo[i].nMeshRoadID);
                    if (pEventInfo[j].nMeshID == ppGuideRoadList->pGuideRoadInfo[i].nMeshID && pEventInfo[j].nRoadID == ppGuideRoadList->pGuideRoadInfo[i].nMeshRoadID)
                    {
                        
                        //道路名字
                        NSString *roadName = [NSString chinaFontStringWithCString:pEventInfo[j].szOccured];
                        NSString *disFromCar;
                        NSString *streamType;
                        NSString *impactRange;
                        
                        //车辆距事件，交通流距离
                        
                        float fDistance = pEventInfo[j].nDisToCar;
                        if (fDistance>1000) {
                            fDistance = fDistance/1000;
                            disFromCar = [NSString stringWithFormat:@"%.2f%@", fDistance,STR(@"Universal_KM", @"Localizable")];
                        }else{
                            disFromCar = [NSString stringWithFormat:@"%.f%@", fDistance,STR(@"Universal_M", @"Localizable")];
                        }
                        
                        //交通流类型
                        int type = pEventInfo[j].nEventID > 20 ? ((pEventInfo[j].nEventID >> 16) & 0Xff) : pEventInfo[j].nEventID;
                        if (type == 2 || type == 3) {
                            streamType = STR(@"TMC_slow", @"TMC");
                        }
                        else if (type == 4 || type == 5)
                        {
                            streamType = STR(@"TMC_congest", @"TMC");
                        }
                        else if (type == 33)
                        {
                            streamType = STR(@"TMC_accident", @"TMC");
                        }
                        else if (type == 34)
                        {
                            streamType = STR(@"TMC_underConstruction", @"TMC");
                        }
                        else if (type == 35)
                        {
                            streamType = STR(@"TMC_trafficControl", @"TMC");
                        }
                        else if (type == 36)
                        {
                            streamType = STR(@"TMC_roadBarrier", @"TMC");
                        }
                        else if (type == 37)
                        {
                            streamType = STR(@"TMC_events", @"TMC");
                        }
                        else if (type == 38)
                        {
                            streamType = STR(@"TMC_disaster", @"TMC");
                        }
                        else if (type == 39)
                        {
                            streamType = STR(@"TMC_badWeather", @"TMC");
                        }
                        else{
                            streamType = @"";
                        }
                        
                        //影响范围
                        
                        float fRange = pEventInfo[j].nEventRange;
                        if (fRange>1000) {
                            fRange = fRange/1000;
                            impactRange = [NSString stringWithFormat:@"%.2f%@", fRange,STR(@"Universal_KM", @"Localizable")];
                        }else{
                            impactRange = [NSString stringWithFormat:@"%.f%@", fRange,STR(@"Universal_M", @"Localizable")];
                        }
                        mainRoadInfo.psszEventName = streamType;
                        mainRoadInfo.psnEventState = type;
                        mainRoadInfo.psbEvent = TRUE;
                        if (type > 20) {
                            mainRoadInfo.psszEventDetail = [NSString stringWithFormat:STR(@"TMC_eventInfo", @"TMC"),disFromCar,roadName,streamType];
                        }
                        else{
                            mainRoadInfo.psszEventDetail = [NSString stringWithFormat:STR(@"TMC_trafficInfo", @"TMC"),disFromCar,roadName,streamType,impactRange];
                        }
                        NSLog(@"detail==%@",mainRoadInfo.psszEventDetail);
                        break;
                        
                    }
                    mainRoadInfo.psbEvent = FALSE;
                }
            }
            
            [RoadListInfo addObject:mainRoadInfo];
            [mainRoadInfo release];
            
        }
        
        
        /*
         1 calculate the persentage of the traffic status
         */
        float ftotal = fNoData+fFree+fSlow+fCrounded;
        [CustomRealTimeTraffic sharedInstance].psfFreeStatus = fFree/ftotal;
        [CustomRealTimeTraffic sharedInstance].psfSlowStatus = fSlow/ftotal;
        [CustomRealTimeTraffic sharedInstance].psfHeavyStatus = fCrounded/ftotal;
        return RoadListInfo;
        
    }
    
	return nil;
    
}

#pragma mark- 获取车位所在道路索引
- (int)GetCarOnRoadIndex
{
    GSTATUS res = GDBL_GetGuideRoadList(NULL,Gfalse, &ppGuideRoadList);
    if (GD_ERR_OK == res) {
        for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++) {
            if(ppGuideRoadList->pGuideRoadInfo[i].eFlag&0x04)
            {
                return i;
            }
        }
    }
    return 0;
    
}

#pragma mark-获取指定经纬度的电话区号
- (NSString *)getPhoneNumber:(NSString *)tel_string Lon:(long)lon Lat:(long)lat
{
	if( [tel_string length] != 0)
	{
		if ([tel_string length] >=10)
		{
			return tel_string;
		}
		NSRange range;
		range = [tel_string rangeOfString:@"-"];
		if (range.length == 0 && [tel_string length] != 11)//@mod by ly 11.3.28
		{
			range.location = 0;
            Gint32 plAdminCode;
            GADAREAINFOEX pAdareaInfo;
            plAdminCode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:lon Lat:lat];
            if (plAdminCode == 0) {
                return tel_string;
            }
            GSTATUS res = GDBL_GetAdareaInfoEx(plAdminCode, &pAdareaInfo) ;
			if (res == GD_ERR_OK) {
                return [NSString stringWithFormat:@"0%d-%@",pAdareaInfo.nTel,tel_string];
            }
            else {
                return tel_string;
            }
		}
		else
		{
			return tel_string;
		}
		
	}
	else
	{
		return @"";
	}
}

#pragma mark 获取设备横竖屏方向
- (int)GMD_GetDeviceOrientation
{
    int value = 0;
    UIInterfaceOrientation ori = [[UIApplication sharedApplication] statusBarOrientation];
    if (ori == UIInterfaceOrientationPortrait || ori == UIInterfaceOrientationPortraitUpsideDown)
    {
        value = 0;
    }
    else  if (ori == UIInterfaceOrientationLandscapeLeft || ori == UIInterfaceOrientationLandscapeRight)
    {
        value = 1;
    }
    return value;
    
}

#pragma mark 获取开机启动默认图片
- (UIImage *)GMD_GetDefaultImage
{
    UIImage *defaultImage = nil;
    
    if (isiPhone) {
        if ([UIDevice currentResolution] == UIDevice_iPhoneTallerHiRes) {
            defaultImage = [UIImage imageNamed:@"Default-568h.png"];
        }
        else{
            defaultImage = [UIImage imageNamed:@"Default.png"];
        }
    }
    else{
        if ([self GMD_GetDeviceOrientation] == 0) {
            defaultImage = [UIImage imageNamed:@"Default-Portrait.png"];
        }
        else{
            defaultImage = [UIImage imageNamed:@"Default-Landscape.png"];
        }
        
    }
    
    if (!defaultImage) {
        defaultImage = [UIImage imageNamed:@"Default.png"];
    }
    
    return defaultImage;
}

#pragma mark 获取当前比例尺

- (NSString *)GMD_GetCurrentScale {
	
	NSString *CurrentScale;
    
	GZOOMLEVEL pValue;
	GDBL_GetParam(G_MAP_SCALE_LEVEL_2D, &pValue);
	
	switch (pValue)
	{
		case 0:
		{
			CurrentScale = @"500km";
		}
			break;
			
		case 1:
		{
			CurrentScale = @"200km";
		}
			break;
			
		case 2:
		{
			CurrentScale = @"50km";
		}
			break;
			
		case 3:
		{
			CurrentScale = @"10km";
		}
			break;
			
		case 4:
		{
			CurrentScale = @"5km";
		}
			break;
			
		case 5:
		{
			CurrentScale = @"2km";
		}
			break;
			
		case 6:
		{
			CurrentScale = @"1km";
		}
			break;
			
		case 7:
		{
			CurrentScale = @"500m";
		}
			break;
			
		case 8:
		{
			CurrentScale = @"200m";
		}
			break;
			
		case 9:
		{
			CurrentScale = @"100m";
		}
			break;
			
		case 10:
		{
			CurrentScale = @"50m";
		}
			break;
			
		case 11:
		{
			CurrentScale = @"25m";
		}
			break;
			
		default:
            CurrentScale = @"25m";
			break;
	}
	
	return CurrentScale;
}

#pragma mark 获取mac地址
-(NSString *)GMD_GetDeviceID
{
    NSString *tmpID = [[UIDevice currentDevice] uniqueDeviceIdentifier];
    NSLog(@"GMD_GetDeviceID %@",tmpID);
    return tmpID;
}

#pragma mark 获取3D仰角
-(int)GMD_Get3DScale
{
    GZOOMLEVEL pValue;
	GDBL_GetParam(G_MAP_ELEVATION, &pValue);
    return pValue;
}

#pragma mark 获取系统信息，硬件名称
- (NSString*)GMD_getDeviceAndOSInfo;
{
    //here use sys/utsname.h
    struct utsname systemInfo;
    uname(&systemInfo);
    //get the device model and the system version,iPad1,1
    return [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
}

#pragma mark 获取审图号
- (NSString *)GMD_ReadDataCheckNumber
{
    // 修改审图号lyh10－16
    NSString *mapVersion = nil;
    FILE *fp1 = nil;
    char temp_str[256] = {0};
    long nSizeOfFile = 0;
    
    // 文件名
    if ([mapDataManage getMapDataType] == 2)
    {
        fp1 = fopen(mapVersion_path,"rb");
        if (NULL!=fp1) {
            fseek(fp1,0,SEEK_END);
            nSizeOfFile = ftell(fp1);
            fseek(fp1, 0, SEEK_SET);
        }
    }
    else if ([mapDataManage getMapDataType] == 1)
    {
        fp1 = navi_fopen(gpsPath[gpsIndexCount-1],"rb");
        if(fp1 != NULL)
        {
            nSizeOfFile = gpsSize[gpsIndexCount-1];
        }
    }
    // 读取数据
    if(fp1 != NULL)
    {
        // 根据文件大小判断1 只有中文(就版本);2有中 繁 英;
        if (256 > nSizeOfFile)
        {
            fread(temp_str,256,1,fp1);
            NSString *name = CSTRING_TO_NSSTRING(temp_str);
            mapVersion = [NSString stringWithFormat:@"%@",name];
            fclose(fp1);
        }
        else
        {
            // 过滤文件头
            char temp_str_oneLine[256] = {0};
            switch (fontType)
            {
                case 1:
                {
                    for (int i=0; i<6; i++) {
                        fgets(temp_str_oneLine, 256, fp1);
                    }
                }
                    break;
                    
                case 2:
                {
                    for (int i=0; i<12; i++) {
                        fgets(temp_str_oneLine, 256, fp1);
                    }
                }
                    break;
            }
            //读取正确得五行数据
            for (int i=0; i<5; i++) {
                memset(temp_str_oneLine, 0, 256);
                fgets(temp_str_oneLine, 256, fp1);
                memcpy(temp_str+strlen(temp_str), temp_str_oneLine, strlen(temp_str_oneLine));
            }
            //
            NSString *name = CSTRING_TO_NSSTRING(temp_str);
            mapVersion = [NSString stringWithFormat:@"%@",name];
            fclose(fp1);
        }
    }
    return mapVersion;
    
}

#pragma mark 获取当前放大路口图的信息(放大路口的类型 路口距离)
-(int)GMD_GetZoomInfo:(int)index
{
    GZOOMVIEWINFO pViewInfo;
    GSTATUS flag = GDBL_GetCurrentZoomViewInfo(&pViewInfo);
    if (flag == 0)
    {
        if (index == 0) {
            return pViewInfo.eViewType;
        }
        else if (index == 1)
        {
            return pViewInfo.nNextDis;
        }
    }
    return 0;
    
}

#pragma mark 获取是否越狱：0－未越狱 1－越狱
- (int)GMD_GetIsSteal
{
    int jailbroken = 0;
    NSString *cydiaPath = @"/Applications/Cydia.app";
    NSString *aptPath = @"/private/var/lib/apt/";
    if ([[NSFileManager defaultManager] fileExistsAtPath:cydiaPath]) {
        jailbroken = 1;
    }
    if ([[NSFileManager defaultManager] fileExistsAtPath:aptPath]) {
        jailbroken = 1;
    }
    int res = system("ls");
    if (res == 0)
        jailbroken = 1;
    return jailbroken;
}


#pragma mark 获取地图版本号的大版本号
- (int) GMD_GetDataVersion
{
    int version = 0;
    GVERSION   m_stMapVersion = {0};
	
	GSTATUS res = GDBL_GetMapVersion(NULL, &m_stMapVersion);
    
    if (res == GD_ERR_OK)
    {
        NSString *mapVersion = [NSString stringWithFormat:@"%s",m_stMapVersion.szVersion];
        NSString *tmp = [mapVersion substringFromIndex:2];
        NSString *findString = @".";
        NSRange range = [tmp rangeOfString:findString];
        if (range.length > 0) {
            NSString *tmpString = [tmp substringToIndex:range.location];
            version = [tmpString intValue];
        }
        
    }
    
    return version;
}

#pragma mark 获取当前城市名和行政编码(直辖市获取)
- (int)GMD_GetCurrentCityName:(NSString **)cityName adminCode:(NSString  **)mAdminCode
{
    //获取地图中心信息
    GMAPCENTERINFO mapinfo = {0};
    GSTATUS res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(GMAP_VIEW_TYPE_MAIN,&mapHandle);
    if (GD_ERR_OK == res) {
        res = GDBL_GetMapViewCenterInfo(mapHandle,&mapinfo);
    }
    
    Gint32 adminCode = 0;
	GADAREAINFOEX pAdareaInfoEx1;
	GCOORDTEL coordTel={0};
	coordTel.eFlag = COORDTEL_TYPE_COORD;
	coordTel.u.Coord.x = mapinfo.CenterCoord.x;
	coordTel.u.Coord.y = mapinfo.CenterCoord.y;
	
	res = GDBL_GetAdminCode(&coordTel, &adminCode);
	GDBL_GetAdareaInfoExChn(adminCode, &pAdareaInfoEx1);
    
    if (strlen(pAdareaInfoEx1.szProvName) > 0 )
    {
        
        if ((adminCode/10000 == 81)||(adminCode/10000 == 82)||(adminCode/10000 == 11)||(adminCode/10000 == 50)||(adminCode/10000 == 31)||(adminCode/10000 == 12))
        {
            *mAdminCode = [NSString stringWithFormat:@"%d",adminCode/10000*10000];
            *cityName = [NSString stringWithCString:pAdareaInfoEx1.szProvName encoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000)];
            return res;
            
        }
        else
        {
            if (strlen(pAdareaInfoEx1.szCityName) > 0) {
                *mAdminCode = [NSString stringWithFormat:@"%d",adminCode/100*100];
                *cityName = [NSString stringWithCString:pAdareaInfoEx1.szCityName encoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000)];
            }
            else{
                *mAdminCode = @"86";
                *cityName = @"全国";
            }
            return res;
        }
        
    }
    *mAdminCode = @"86";
    *cityName = @"全国";
    return res;
}

#pragma mark 获取当前网络类型
- (int)isNetConnecting
{
	ANReachability *r = [ANReachability reachabilityForInternetConnection];
    switch ([r currentReachabilityStatus]) {
        case NotReachable:
            // 没有网络连接
            return 0;
            break;
        case ReachableViaWWAN:
            // 使用3G网络
            return 1;
            break;
        case ReachableViaWiFi:
            // 使用WiFi网络
            return 2;
            break;
    }
}

#pragma mark 获取剩余空间
+(float)getCurDiskSpaceInBytes
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    struct statfs tStats;
    statfs([[paths lastObject] cString], &tStats);
    float totalSpace = (float)(tStats.f_bsize * tStats.f_bfree);
    if (totalSpace > 206715200) {
        totalSpace = totalSpace - 206715200;
    }
    return totalSpace;
}

#pragma mark 获取家，公司详细信息
- (BOOL)GMD_GetFavoriteInfo:(GFAVORITECATEGORY)favoriteCategory POILIST:(GFAVORITEPOILIST **)favoritePOIList
{
    GSTATUS res;
	res = GDBL_GetFavoriteList(favoriteCategory, favoritePOIList);
	if (GD_ERR_OK == res)
	{
		return YES;
	}
    return NO;
}

#pragma mark 获取数组里，指定索引的周围的11个结果（正常取前5个后5个，不够的往前，往后补齐，小于11个的返回全部）
- (BOOL)GMD_GetViewMapPOI:(NSMutableArray *)oldArray oldIndex:(int)oldIndex resultPOI:(NSMutableArray **)resultPOI resultIndex:(int *)resultIndex
{
    if (oldArray && [oldArray count] > 0) {
        if ([oldArray count] > 11) {//数组大于11个，则取前5个，后5个填充，前5个不够，则往后多取几个，后5个不够，则往前多取几个
            NSRange range;
            if (oldIndex < 5) {
                range = NSMakeRange(0, 11);
                *resultIndex = oldIndex;
            }
            else if (oldIndex > ([oldArray count] - 6)){
                range = NSMakeRange([oldArray count] - 11, 11);
                *resultIndex = oldIndex+11-[oldArray count];
            }
            else{
                range = NSMakeRange(oldIndex-5, 11);
                *resultIndex = 5;
            }
            *resultPOI = (NSMutableArray *)[oldArray objectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:range]];
        }
        else{//数组小于等于11个，则全部返回
            *resultPOI = oldArray;
            *resultIndex = oldIndex;
        }
        return YES;
    }
    return NO;
}

#pragma mark获取当前绘制地图类型：0－离线地图 1－在线地图
-(int)GMD_GetCurDrawMapViewType
{
    //当比例尺大于某个层级时判断
    
    if ([mapDataManage getMapDataType] == 1)//一体化数据
    {
        return 0;
    }
    else if ([mapDataManage getMapDataType] == 2){//分城市数据
        long curLon = 0;
        long curLat = 0;
        //调用接口获取当前中心点经纬度
        //curLon = ;
        //curLat = ;
        int admincode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:curLon Lat:curLat];
        if ( [[ANOperateMethod sharedInstance] GMD_checkIsExistData:admincode flag:1] == 1) {//当前区域无数据
            return 1;
        }
        else
        {
            return 0;
        }
    }
    return 0;
}

#pragma mark 根据经纬度获取当前绘制地图类型：0－离线地图 1－在线地图 ，判断比例尺
-(int)GMD_GetCurDrawMapViewTypeWithLon:(long)lon Lat:(long)lat
{
    if ([mapDataManage getMapDataType] == 1)//一体化数据
    {
        return 0;
    }
    else if ([mapDataManage getMapDataType] == 2)
    {//分城市数据
        //当比例尺大于某个层级时判断
        if (![ANParamValue sharedInstance].isUseNETMap)
        {
            if ([ANParamValue sharedInstance].isMove)
            {
                if ([[ANParamValue sharedInstance] GMD_CurrentScaleIs_5KM])
                {
                    return 0;
                }
            }
        }
        
        int admincode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:lon Lat:lat];
        int sign = [[ANOperateMethod sharedInstance] GMD_checkIsExistData:admincode flag:1];
        if (sign  == 0)
        {//当前区域无数据
            return 1;
        }
        else if (sign == 2)
        {//当前区域处于海
            return 2;
        }
        else
        {
            return 0;
        }
    }
    return 0;
}

#pragma mark 获取当前引导路径路径引导颜色数组
- (NSMutableArray *)GMD_GetGuideRouteColorContent
{
    int totalDistance = 0;
    float percent = 0.0;
    float tmpPercent = 0.0;
    NSMutableArray *colorArray = [[NSMutableArray alloc] init];
    
    if ([[ANParamValue sharedInstance] GMD_isTMCOn])
    {
        GGUIDEROADTMCLIST pList = {0};
        GSTATUS nStatus = GDBL_GetGuideRoadTMCList(&pList);
        
        if (nStatus==GD_ERR_OK) {
            totalDistance = pList.nTotalDis;
            if (totalDistance<0) {
                return nil;
            }
            //走过的
            tmpPercent = pList.nCarDisFromStart/(totalDistance*1.0f);
            percent = percent + tmpPercent;
            
            ProgressInfo *colorInfo = [[ProgressInfo alloc] init];
            colorInfo.percent = tmpPercent;
            colorInfo.status = CompleteStatus;
            [colorArray addObject:colorInfo];
            [colorInfo release];
            //未走过的
            for (int i=0; i<pList.nNumberOfItem; i++) {
                int itemDisFromStart = pList.pItem[i].nDisFromStart;
                int itemDis = pList.pItem[i].nDis;
                int itemCarDisFromStart = pList.nCarDisFromStart;
                int itemState = pList.pItem[i].eTrafficStream;
                int state = 0;
                
                if (itemState == 1) {
                    state = UnblockedStatus;
                }
                else if (itemState == 2 || itemState == 3)
                {
                    state = SlowlyStaus;
                }
                else if (itemState == 4 || itemState == 5)
                {
                    state = StopStatus;
                }
                else{
                    state = UnfinishStatus;
                }
                
                //车位到起点的距离大于该点到起点的距离的项抛弃
                if (itemDisFromStart+itemDis < itemCarDisFromStart ) {
                    continue;
                }
                else if (itemDisFromStart > itemCarDisFromStart)
                {
                    tmpPercent = itemDis/(totalDistance*1.0f);
                    percent = percent + tmpPercent;
                    
                    ProgressInfo *colorInfo = [[ProgressInfo alloc] init];
                    colorInfo.percent = tmpPercent;
                    colorInfo.status = state;
                    [colorArray addObject:colorInfo];
                    [colorInfo release];
                }
                else{
                    tmpPercent = (itemDisFromStart + itemDis - itemCarDisFromStart)/(totalDistance*1.0f);
                    percent = percent + tmpPercent;
                    
                    ProgressInfo *colorInfo = [[ProgressInfo alloc] init];
                    colorInfo.percent = tmpPercent;
                    colorInfo.status = state;
                    [colorArray addObject:colorInfo];
                    [colorInfo release];
                    
                }
                
            }
            
            if (percent < 1) {
                ProgressInfo *colorInfo = [[ProgressInfo alloc] init];
                colorInfo.percent = 1.0 - percent;
                colorInfo.status = UnblockedStatus;
                [colorArray addObject:colorInfo];
                [colorInfo release];
            }
            
        }
        
    }
    else{
        totalDistance = [[self GMD_GetPathStatisticInfoWithMainID:4 GuideHandel:GNULL] intValue];
        unsigned int unCompleteDistance = [[self GMD_GetManeuverInfoWithMainID:11] intValue];
        unsigned int completeDistance = totalDistance - unCompleteDistance;
        
        ProgressInfo *colorInfo = [[ProgressInfo alloc] init];
        colorInfo.percent = completeDistance/(totalDistance*1.0f);
        colorInfo.status = CompleteStatus;
        [colorArray addObject:colorInfo];
        [colorInfo release];
        
        ProgressInfo *colorInfo1 = [[ProgressInfo alloc] init];
        colorInfo1.percent = 1.0 - colorInfo.percent ;
        colorInfo1.status = UnfinishStatus;
        [colorArray addObject:colorInfo1];
        [colorInfo1 release];
    }
    
    return [colorArray autorelease];
    
}

#pragma mark 获取当前车位信息
- (GSTATUS)GMD_GetCarInfo:(GCARINFO *)carInfo
{
    GSTATUS res = GD_ERR_FAILED;
    
    res = GDBL_GetCarInfo(carInfo);
    
    return res;
}

@end
