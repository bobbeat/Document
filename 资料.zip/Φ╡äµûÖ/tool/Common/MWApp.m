//
//  MWApp.m
//  AutoNavi
//
//  Created by yu.liao on 13-7-29.
//
//

#import "MWApp.h"
#import "GDBL_TTS.h"
#import "MWPreference.h"
#import "plugin-cdm-TaskManager.h"
#import "mapDataManage.h"
#import "GDBL_NetCounter.h"
#import "Plugin_GresourseManager.h"
#import "MWGuideOperator.h"
#import "Plugin_OnLineMapUtility.h"
#import "PublicDefine.h"
#import "Constants.h"
#import "MWPoiOperator.h"
#import "UIDevice+Category.h"
#import "GDBL_SinaWeibo.h"
#import "GDBL_TCWeibo.h"
#import "GDMID_Interface.h"
#import "POISearchHistory.h"
#import "MWSkinDownloadManager.h"
#import "launchRequest.h"
#import "GDCacheManager.h"
#import "CarServiceDefine.h"
#import "MWDialectDownloadTask.h"
#import "MWDialectDownloadManage.h"
#import "MWAccountOperator.h"
#import "GDBL_Account.h"

static MWApp *instance = nil;

@implementation MWApp

+(MWApp*)sharedInstance
{
    @synchronized(self)
    {
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    }
    return instance;
}

+(void)releaseInstance
{
    @synchronized(self)
    {
        if (instance != nil)
        {
            [instance release];
            instance = nil;
        }
    }
}

- (id)init
{
    self = [super init];
    if(self)
    {
    }
	
    return self;
}

- (BOOL)loadTTS
{
    int ttsIndex = [[MWPreference sharedInstance] getValue:PREF_IS_LZLDIALECT];
    
    if ((ttsIndex > 0) && ((ttsIndex - 1) <= [MWDialectDownloadManage sharedInstance].serviceDialectTaskList.count)) {
        
        
        MWDialectDownloadTask *_task = [[MWDialectDownloadManage sharedInstance].serviceDialectTaskList objectAtIndex:(ttsIndex-1)];
        
        MWDialectDownloadTask *task = [[MWDialectDownloadManage sharedInstance] getTaskWithTaskID:_task.taskId];
        
        if (task && task.status == TASK_STATUS_FINISH && [[NSFileManager defaultManager] fileExistsAtPath:[Dialect_path stringByAppendingString:task.folderName]]) {
            
            [GDBL_TTS GDBL_TTSStartUpWithResourcePath:Dialect_path];//语音库初始化
            [GDBL_TTS GDBL_TTSSetSpeed:task.dialectPlaySpeed];
            [GDBL_TTS GDBL_TTSSetPrompts:task.dialectHasRecord];
            [GDBL_TTS GDBL_TTSSetResourseFolderName:task.folderName];
            [[MWPreference sharedInstance] setValue:PREF_TTSROLEINDEX Value:task.dialectRoleID];
            
        }
        else
        {
            [[MWDialectDownloadManage sharedInstance] removeTaskId:task.taskId];
            
            [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];//语音库初始化
            [[MWPreference sharedInstance] setValue:PREF_TTSROLEINDEX Value:0];
        }
        
    }
    else{
        
        [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];//语音库初始化
    }
    
    return YES;
}

- (BOOL)loadAccount
{
    if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@",account_path]])
    {//主要为了处理老版本包含的内容不一样，升级会造成死机的问题
        NSMutableArray *array=[[NSMutableArray alloc] initWithContentsOfFile:[NSString stringWithFormat:@"%@",account_path]];
        if ([array count] < 7)
        {
            [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@",account_path] error:nil];
        }
        [array release];
    }
    
    NSArray *tmpArray;
    GDBL_GetAccountInfo(&tmpArray);
    int login = [[tmpArray objectAtIndex:0] intValue];
    if (login == 0)
    {
        NSURL *deleteURL = [NSURL URLWithString:kNetDomain];
        NSHTTPCookieStorage *allCookie = [NSHTTPCookieStorage sharedHTTPCookieStorage];
        NSArray *cookieArray=[allCookie cookiesForURL:deleteURL];
        //deleteURL即为请求的源地址,删除对应源地址产生的cookie
        for(id obj in cookieArray)
        {
            [allCookie deleteCookie:obj];
        }
    }
    //兼容已登入没有用户ID
    if (tmpArray.count>7) {
        
        NSString *userId =[tmpArray objectAtIndex:7];
        if (userId.length==0) {
            NSString * loginType=nil;
            if (login==1||login==2) {
                //高德登入
                
                loginType = [NSString checkPhoneStandardWith:[tmpArray objectAtIndex:1]]?@"2":@"1";
                [MWAccountOperator accountLoginWith:REQ_LOGIN phone:[tmpArray objectAtIndex:1] password:[tmpArray objectAtIndex:2] type:loginType delegate:self];
            }
            else if (login>2){
                
                if (login==3||login==5) {
                    loginType=@"1";
                }
                else
                {
                    loginType=@"2";
                }
                [MWAccountOperator accountThirdLoginWith:REQ_LOGIN tpuserid:[tmpArray objectAtIndex:5] tpusername:[tmpArray objectAtIndex:6] tptype:loginType delegate:self];
                
            }
        }
    }
    
    
    return YES;
}



/***
 * @name    加载皮肤类型
 * @param
 * @author  by bazinga
 ***/
- (void)loadSkin
{
    //复制皮肤加载plist
    NSError *error = nil;
    if(![[NSFileManager defaultManager] fileExistsAtPath:skinConfigDocumentPath])
    {
        if([[NSFileManager defaultManager] fileExistsAtPath:skinConfigBundlePath])
        {
            [[NSFileManager defaultManager] copyItemAtPath:skinConfigBundlePath toPath:skinConfigDocumentPath error:&error];
        }
    }
    //加载皮肤数据
    NSString *stringFolder = [[GDSkinColor sharedInstance] getFolderByID:[[MWPreference sharedInstance] getValue:PREF_SKINTYPE]];
    
    if([[MWPreference sharedInstance] getValue:PREF_SKINTYPE] != 0 && [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@%@",Skin_path,stringFolder]])
    {
        NSString *pathstring = [NSString stringWithFormat:@"%@%@",Skin_path,stringFolder];
        [UIImage setImageSkinType:YES SkinPath:pathstring];
        [[GDSkinColor sharedInstance] refresh:[NSString stringWithFormat:@"%@%@%@",Skin_path,stringFolder,SKIN_PLIST_NAME]];
    }
    else
    {
        [[MWPreference sharedInstance] setValue:PREF_SKINTYPE Value:[SKIN_DEFAULT_ID intValue]];
        [UIImage setImageSkinType:NO SkinPath:nil];
        [[GDSkinColor sharedInstance] refresh:[[NSBundle mainBundle] pathForResource:@"colorConfig" ofType:@"plist"]];
    }
    
    [MWSkinDownloadManager sharedInstance];
}

/***
 * @name    加载方言类型
 * @param
 * @author  by bazinga
 ***/
- (void)loadDialect
{
    //自动切换方言
    [[MWDialectDownloadManage sharedInstance] autoSwitchTTSPath];
    
}

/***
 * @name    加载车主服务信息
 * @param
 ***/
- (void)loadCarOwnerService
{
    //车主服务信息拷贝
    NSError *error = nil;
    if(![[NSFileManager defaultManager] fileExistsAtPath:CAR_SERVICE_DOCUMENT_PATH])
    {
        if([[NSFileManager defaultManager] fileExistsAtPath:CAR_SERVICE_BUNDLE_PATH])
        {
            [[NSFileManager defaultManager] copyItemAtPath:CAR_SERVICE_BUNDLE_PATH toPath:CAR_SERVICE_DOCUMENT_PATH error:&error];
        }
    }
    
}

/***
 * @name    开机语音播报
 * @param
 * @author  by bazinga
 ***/
-(void) openSound
{
    NSString *wavPath = nil;
    //是否开启开机语音播报
    if ([[MWPreference sharedInstance] getValue:PREF_SWITCHEDVOICE]) {
        
        
        BOOL hasCache = [[GDCacheManager globalCache] hasCacheForKey:GDCacheType_PowerVoice];
        
        if (hasCache && ![[MWPreference sharedInstance] getValue:PREF_IS_POWERVOICE_PLAY]) {//有下载的开机语音，而且没过期则播报下载的开机语音，否则播报本地语音
            
            
            wavPath = [[GDCacheManager globalCache] pathWithKey:GDCacheType_PowerVoice];
            
            [[MWPreference sharedInstance] setValue:PREF_IS_POWERVOICE_PLAY Value:YES];
        }
        else {
            //判断是否是第一次进入程序
            if([[MWPreference sharedInstance] getValue:PREF_FIRSTSTART])
            {
                //第一次进入，播放的语音
                wavPath = [[NSBundle mainBundle] pathForResource:@"Welcome" ofType:@"mp3"];
            }
            else
            {
                //第二次之后进入，播放的语音
                wavPath = [[NSBundle mainBundle] pathForResource:@"Welcome1" ofType:@"mp3"];
            }
            
        }
        
        [GDBL_TTS GDBL_TTSPlayWavPath:[wavPath UTF8String]];
        
        
        
    }
}

- (int)loadEngine
{
    NSLog(@"loadEngine");
    NSMutableString	*tmp;
    
    tmp= [[NSMutableString alloc] initWithUTF8String:g_data_path];
	if ([tmp hasSuffix:@"/"]==NO)
	{
		[tmp appendString:@"/"];
	}
	[self mapDataRegister:tmp];
    
	int res = GDBL_StartupEx((Gchar *)([tmp UTF8String]));[tmp release];tmp = nil;
	if (0 == res)
	{
        [ANParamValue sharedInstance].isInit = YES;
        
        [self initEngine];
		
        if ([[TaskManager taskManager].taskList count]  == 0)
        {
            [[TaskManager taskManager] restore];
        }
		
		NSLog(@"Init Success!");
        return res;
	}
	NSLog(@"Init Fail!");
	
    
	return res;
}

- (void)unloadEngine {
	GDBL_DestroyView();
	GDBL_Cleanup();
}

- (BOOL)initEngine
{
    int res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(GMAP_VIEW_TYPE_MAIN,&mapHandle);
    GDBL_CreateView(mapHandle);
    
    [[MWPreference sharedInstance] setValue:PREF_TRACK_RECORD Value:0];//每次开机手动关闭自动纪录轨迹开关
    
    GNAVIMODE eWalkFlag = GNAVI_MODE_CAR;
    GDBL_SetParam(G_NAVI_MODE, &eWalkFlag);
    
    [[MWPreference sharedInstance] setValue:PREF_DISABLE_GPS Value:SWITCH_OPEN];
    
    //设置tmc显示为城市tmc
    int isShow = 0;
    GDBL_SetParam(G_MAP_SHOW_TMC, &isShow);
    
    //设置多路线演算后是显示一条路径还是全部显示
    int value = 0;
    GDBL_SetParam(G_MAP_SHOW_ALL_MULTI_ROUTE, &value);
    
    [[MWPreference sharedInstance] setValue:PREF_SHOW_MAP_GRAY_BKGND Value:NO];
    [[MWPreference sharedInstance] setValue:PREF_MAP_TMC_SHOW_OPTION Value:NO];
    [[MWPreference sharedInstance] setValue:PREF_SHOW_TMCSTREAM Value:YES];//控制路径tmc显示
    
    int i = 1;
	GDMID_SetParam(G_MAP_SHOW_TRACK, &i);
    
    //使用新色盘
    if (1 == [[MWPreference sharedInstance] getValue:PREF_MAP_CONTENT])
    {
        [[MWPreference sharedInstance] setValue:PREF_MAP_CONTENT Value:2];
    }
    
    NSString *tmpID = [[UIDevice currentDevice] uniqueDeviceIdentifier];
    GDBL_SetParamExt(MACADDRESS, (Gvoid *)[tmpID UTF8String]);
    
    BOOL trafficEvent = [[MWPreference sharedInstance] getValue:PREF_TRAFFICEVENT];
    [[MWPreference sharedInstance] setValue:PREF_SHOW_TMCEVENT Value:trafficEvent];
    
    //同步白天黑夜色盘
    [[ANOperateMethod sharedInstance] GMD_SyncDayNightTheme];
    
    if (![[MWPreference sharedInstance] getValue:PREF_MUTE]) {
        [[MWPreference sharedInstance] setValue:PREF_SWITCHEDVOICE Value:NO];
    }
    
    return YES;
}

- (void)mapDataRegister:(NSString *)path
{
    
    if (GDBL_IsValidateUserEx((Gchar *)[path UTF8String])) {
        char tem[25] = {0};
        char tem1[25] = {0};
		memcpy(tem,"024001600001100130000001",24);
        GDBL_GetInstallCode(tem,tem1,25);
        if ([mapDataManage getMapDataType] == 2)
		{
			FILE *fp1 = fopen(sn_path,"rb");
			char temp_str[30] = {0};
			if(fp1 != NULL)
			{
				fread(temp_str,30,1,fp1);
				memcpy(tem,temp_str,24);
				fclose(fp1);
				
			}
		}
		else if ([mapDataManage getMapDataType] == 1)
		{
			memcpy(tem,captcha,24);
		}
        // memcpy(tem,"4PZTVPXSNZZLBNT3GCQKHW4T",24);
        GSTATUS res = GDBL_Register((Gint8 *)tem);
        NSLog(@"res = %d",res);
    }
}



-(BOOL)saveAppData
{
    [[GDBL_UserBehaviorCountNew shareInstance] saveData];//保存用户行为统计
    
    [[Plugin_GresourseManager sharedInstance] store];//保存gresource下载列表
    
	[[TaskManager taskManager] store];     //保存数据下载列表
    
	[[MWPreference sharedInstance] savePreference];
    
    if ([ANParamValue sharedInstance].isPath == 1 && [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 0 && [ANParamValue sharedInstance].is3DDomo == NO)
    {
        [[MWGuideOperator sharedInstance] MW_SaveGuideRoute:GNULL Type:1];
    }
    if ([[ANParamValue sharedInstance] isInit]) {
        GDBL_SaveUserConfig();
    }
    
    [[GDBL_NetCounter shareInstance] saveData];
    
    [[MWSkinDownloadManager sharedInstance] store];//皮肤保存
    [[MWSkinDownloadManager sharedInstance] storeSkinUpdateVersion];//皮肤更新的版本号
    
    [[MWDialectDownloadManage sharedInstance] store];  //方言下载列表保存
    [[MWDialectDownloadManage sharedInstance] Servicestore]; //后台方言列表保存
    
    return YES;
}

- (BOOL)restoreAppData
{
    
    [[MWPreference sharedInstance] loadPreference];
    
    [self loadTTS];            //加载语音库
    
    [self loadAccount];        //加载帐户信息
    
    [[ANOperateMethod sharedInstance] GMD_SetSystemLanguage:NO];//根据系统语言设置本地化语言
    
    [self loadSkin];           //加载皮肤
    
    [self loadDialect];       //加载方言类型
    
    if (NSFoundationVersionNumber < NSFoundationVersionNumber_iOS_6_0) {
        if (Orientation==UIInterfaceOrientationLandscapeLeft||Orientation==UIInterfaceOrientationLandscapeRight) {
            [[MWPreference sharedInstance] setValue:PREF_INTEFACEORIENTATION Value:UIInterfaceOrientationPortrait];
        }
    }
    
    return YES;
}




-(void)ClearAllEngineData
{
    [MWPoiOperator clearFavoriteWith:GFAVORITE_CATEGORY_DEFAULT];
    [MWPoiOperator clearFavoriteWith:GFAVORITE_CATEGORY_HOME];
    [MWPoiOperator clearFavoriteWith:GFAVORITE_CATEGORY_COMPANY];
    [MWPoiOperator clearFavoriteWith:GFAVORITE_CATEGORY_HISTORY];
    [MWPoiOperator clearSmartEyesWith:GSAFE_CATEGORY_ALL ];
    [[ANOperateMethod sharedInstance] GMD_DeleteAllCommonPOI];//删除常用保存点
    [[GDBL_SinaWeibo shareSinaWeibo] logOut];//新浪微博登出
    [[GDBL_TCWeibo shareTCWeibo] logOut];//腾讯微博登出
    [POISearchHistory removeAllHistory];//历史搜索纪录
    
}

-(void)executeLogicAfterWarningViewAndNewFunction:(id)viewController
{
    [ANParamValue sharedInstance].isWarningView  = NO;
    [Plugin_OnLineMapUtility sharedInstance].isEnterMap = YES;
    [Plugin_OnLineMapUtility sharedInstance].isEnterNewView = NO;
    [[Plugin_OnLineMapUtility sharedInstance] ShowMapMode];
    [[launchRequest shareInstance] softWareVersionUpdateRequest];//软件版本更新检测
    [viewController ContinueNavi]; //续航
    
    if ([[MWPreference sharedInstance] getValue:PREF_STARTUPWARNING]) {
        [self openSound];
    }
    else{
        [self performSelector:@selector(openSound) withObject:nil afterDelay:3.0];
    }
    
    //将第一次进入程序的标志位置为0，
    //---   [self openSound];  这个函数都用到第一次进入程序的判断  ---
    [[MWPreference sharedInstance] setValue:PREF_FIRSTSTART Value:0];
}

@end
