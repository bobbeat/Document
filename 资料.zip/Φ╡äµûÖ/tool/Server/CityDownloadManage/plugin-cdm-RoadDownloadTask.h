//
//  plugin-cdm-RoadDownloadTask.h
//  plugin-CityDataManager
//
//  Created by GHY on 11-12-12.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-DownloadTask.h"


@interface plugin_cdm_RoadDownloadTask : DownloadTask 
{

}

@end
