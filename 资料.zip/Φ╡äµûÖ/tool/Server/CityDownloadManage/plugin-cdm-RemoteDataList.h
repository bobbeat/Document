//
//  RemoteDataList.h
//  plugin-CityDataManager
//
//  Created by mark on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-DataList.h"


/*
 1、从服务器获取数据下载清单
 2、解析清单到成员变量
 */

@protocol RemoteDataListDelegate <NSObject>

- (void)dataparseDone;//通知客户，数据解析完毕
- (void)dataparseFail:(NSError*)error;//通知客户数据解析失败

@end


@interface RemoteDataList : DataList
{
	id<RemoteDataListDelegate> delegate;
	
	int status;//获取数据状态
    NSURLConnection* connection;
	NSMutableData* resultData;//服务器返回的有用数据信息

    NSMutableArray* foundlist;//基础数据信息
    NSMutableArray* tmpfoundList;
	NSMutableArray* cityValidFlag;//存有分城市标志,一体化标志,客户端标志
}

@property (nonatomic ,assign) id<RemoteDataListDelegate> delegate;

+(DataList*)remoteDataList;//单例模式
+(void)releaseInstance;

// 获取基础列表（Item数组）
-(NSArray*)getfoundList;
// 获取分城市标志,一体化标志,客户端标志
- (NSArray*)getCityValid;
// 执行获取服务器数据任务，返回值不做任何的用途
- (BOOL)parse:(int)type mapVersion:(NSString *)version;

@end
