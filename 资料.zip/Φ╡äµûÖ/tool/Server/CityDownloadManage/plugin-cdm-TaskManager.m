//
//  TaskManager.m
//  plugin-CityDataManager
//
//  Created by mark on 11-11-3.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "plugin-cdm-TaskManager.h"
#import "plugin-cdm-Task.h"
#import "ANParamValue.h"
#import "plugin-cdm-IntegratedDownLoadTask.h"
#import "plugin-cdm-RoadDownloadTask.h"
#import "NSString+Category.h"
#import "GDBL_Interface.h"
#import "mapDataManage.h"

static TaskManager* instance;

@implementation TaskManager

@synthesize delegate,taskList,TravelTaskList;

+(TaskManager*)taskManager
{
    if(instance==nil)
    {
        instance = [[TaskManager alloc]init];
    }
    return instance;
}

+(void)releaseInstance
{
    if(instance!=nil)
    {
        [instance release];
        instance = nil;
    }
}

-(void)dealloc
{
    [taskList release];
    [TravelTaskList release];
    //[mTaskStatusList release];
    [super dealloc];
}

-(id)init
{
    self = [super init];
    if(self!=nil)
    {
        //mTaskStatusList = [[NSMutableArray alloc]init];
        taskList = [[NSMutableArray alloc]init];
        TravelTaskList = [[NSMutableArray alloc]init];
    }
    return self;
}


// 返回任务队列中的任务id列表
//-(NSArray*)getTaskId
//{
//    NSMutableArray* idlist = nil;
//    int count = [mTaskList count];
//    if (count>0) {
//        idlist = [[NSMutableArray alloc]init];
//        for(int i=0;i<count;i++)
//        {
//            [idlist addObject:[NSNumber numberWithInt:[[mTaskList objectAtIndex:i] taskId]]];
//        }
//    }
//    return [idlist autorelease];
//}

// 返回-1表示加入失败，>=0表示成功加入后在TaskManager中的索引
-(int)addTask:(Task*) task atFirst:(BOOL) first
{
    if(NO==[self _taskExisted:task])
    {
        task.delegate = self;
        task.status = TASK_STATUS_READY;
        //NSNumber* s = [NSNumber numberWithInt:TASK_STATUS_READY];
        if(first)
        {
            [taskList insertObject:task atIndex:0];
            //[mTaskStatusList insertObject:s atIndex:0];
            return 0;
        }
        else
        {
            [taskList addObject:task];
            //[mTaskStatusList addObject:s];
            return [taskList count]-1; 
        }
    }
    else
    {
        return -1;
    }
}

//将本地存在的地图数据添加到下载队列中，并把状态置为完成
-(int)addLocalTask:(Task*) task atFirst:(BOOL) first
{
    if(NO==[self _taskExisted:task])
    {
        task.delegate = self;
        task.status = TASK_STATUS_FINISH;
        //NSNumber* s = [NSNumber numberWithInt:TASK_STATUS_READY];
        if(first)
        {
            [taskList insertObject:task atIndex:0];
            //[mTaskStatusList insertObject:s atIndex:0];
            return 0;
        }
        else
        {
            [taskList addObject:task];
            //[mTaskStatusList addObject:s];
            return [taskList count]-1; 
        }
    }
    else if(YES==[self _taskExisted:task] )
    {
	  for (DownloadTask *t in taskList) 
      {
        if (t.taskId == task.taskId) 
        {
			if (t.status != TASK_STATUS_FINISH)//若用户拖入完整的城市数据，则删除对应未下载完成的文件
            {
                NSString *stringt = @"/";
				NSRange range = [t.url rangeOfString:stringt options:NSBackwardsSearch];
				if (range.length != 0) 
                {
					NSString *name = [t.url substringFromIndex:range.location+1]; 
                 //   NSString *name = [NSString stringWithFormat:@"%@",[t.url CutFromNSString:@"cityupdatedata/"]];
				NSFileManager *fileManager = [NSFileManager defaultManager];
				NSArray *paths;
				NSError *error;
				NSString *documentsDirectory;
				paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
				documentsDirectory = [[NSString alloc] initWithFormat:@"%@", [paths objectAtIndex:0]];
				NSString *filePath = [NSString stringWithFormat:@"%@/%@.tmp",documentsDirectory,name];
                    [documentsDirectory release];
                    if([fileManager fileExistsAtPath:filePath]) 
                    {
					[[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
					
				}
			}
			}
		   t.status = TASK_STATUS_FINISH;
		}
	    }
        return 0;
    }
	else 
    {
		return -1;
	}

}

// 移除索引为index处的任务，该操作会删除该任务。
// 如果恰好该任务处于运行状态，removeTask后，整个TaskManager中将无任务在执行
-(BOOL)removeTask:(int) index
{
    NSLog(@"removeTask:index");
    int count = [taskList count];
    if(index>=0 && index < count)
    {
        Task* t = [taskList objectAtIndex:index];
        [t erase];
        [taskList removeObjectAtIndex:index];
        //[mTaskStatusList removeObjectAtIndex:index];
        return  YES;
    }
    return NO;
}

// 移除任务id的任务，该操作会删除该任务。
// 如果恰好该任务处于运行状态，removeTaskId后，整个TaskManager中将无任务在执行
-(BOOL)removeTaskId:(long) taskId
{
     NSLog(@"removeTaskId:taskid");
    int count = [taskList count];
	for (int i = 0; i < count; i++)
	{
		 Task* t = [taskList objectAtIndex:i]; 
		if (taskId == t.taskId) {
			if (taskId == 0) {
				[t erase];
				[taskList removeAllObjects];
			}
			else {
				[t erase];
				[taskList removeObjectAtIndex:i];
			}
			return YES;
		}
	}
    return NO;
}

// 移除所有状态为status的任务，返回移除的个数
-(int)removeTasksForStatus:(int) status
{
    NSLog(@"removeTasksForStatus");
    int count = 0;
    while (1) {
        int index = [self _firstIndexWithStatus:status];
        if(index>=0)
        {
            [self removeTask:index];
            ++count;
        }
        else
        {
            break;
        }
    }
    return count;
}

// 移除所有任务
- (void)removeAllTask
{
    for (Task *_task in taskList) {
        [_task erase];
    }
    
    [taskList removeAllObjects];
    
    NSString *filename = [document_path stringByAppendingPathComponent:@"DataDownloadList.plist"];
	[NSKeyedArchiver archiveRootObject:taskList toFile:filename];
}

//勾选所有任务
- (void)selectAllTask:(BOOL)flag
{
    if (flag) {
        for (Task *task in taskList) {
            task.selected = YES;
        }
    }
    else{
        for (Task *task in taskList) {
            task.selected = NO;
        }
    }
    
}

//移除所选项目
- (void)removeSelectedTask
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    for (Task *task in taskList) {
        if (task.selected) {
            [task erase];
            [array addObject:task];
        }
    }
    
    if (array.count > 0) {
        [taskList removeObjectsInArray:array];
    }
    
    [array release];
}

// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按某种策略选择一个任务来执行
// 2、有任务在执行：直接返回
-(BOOL)start
{
    if([self isRunning])
    {
        return NO;
    }
    else
    {
        int index = [self _selectOneTaskToRun];
        if(index<0)
        {
            return NO;
        }
        else
        {
            return [self start:index];
        }
    }
}

// 停止TaskManager中正在执行的任务，整个TaskManager处于停止状态
-(BOOL)stop
{
    int index = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (index>=0) {
        return [self stop:index];
    }
    return NO;
}

- (BOOL)stopRunning
{
    int index = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (index>=0) {
        return [self stopCurrent:index];
    }
    return NO;
}
// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按index来选择任务
// 2、有任务在执行：
//      分两种情况：
//      1、正在执行的任务就是index，那么直接返回；
//      2、正在执行的任务不是index，那么让正在执行的任务变为等待，转而执行index指定的任务
-(BOOL)start:(int)index
{
    int indexRunning = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (indexRunning == index || index > (int)(taskList.count -1)) {
        return NO;
    }
    else 
    {
        // 先停止正在执行的任务
        if (indexRunning >= 0)
        {
            Task* t = [taskList objectAtIndex:indexRunning];
            t.status = TASK_STATUS_READY;
            [t stop];
         //   return YES;
//            Task* t = [taskList objectAtIndex:indexRunning];
//            t.status = TASK_STATUS_READY;
//            [t stop];
        }
        
        Task* t = [taskList objectAtIndex:index];
        t.status = TASK_STATUS_RUNNING;
        [t run];
        
        return YES;
    }
}

- (BOOL)firstStart:(int)index
{
    if (index > (int)(taskList.count -1)) {
        return NO;
    }
    Task* t = [taskList objectAtIndex:index];
    t.status = TASK_STATUS_RUNNING;
    [t run];
    return YES;
}
- (void)startWithTaskID:(int)taskID
{
    
    for (int i = 0; i < taskList.count; i++) {
        Task *tmp = [taskList objectAtIndex:i];
        if (tmp.taskId == taskID) {
            [self start:i];
            return;
        }
    }
}

- (void)stopWithTaskID:(int)taskID
{
    
    for (int i = 0; i < taskList.count; i++) {
        Task *tmp = [taskList objectAtIndex:i];
        if (tmp.taskId == taskID) {
            [self stop:i];
            return;
        }
    }
}
// 停止TaskManager中index对应的任务：注意：只有状态为TASK_STATUS_RUNNING的任务才能被stop
// 1、index对应的任务处于等待状态，那么直接返回
// 2、index对应的任务处于执行状态，那么让正在执行的任务变为等待
-(BOOL)stop:(int)index
{
    int count = [taskList count];
    if(index>=0 && index<count)
    {
        
        Task* t = [taskList objectAtIndex:index];
        if(t.status==TASK_STATUS_RUNNING || t.status==TASK_STATUS_READY)
        {
            
            t.status = TASK_STATUS_BLOCK;
            [t stop];
            
            [self start];
            return YES;
        }
    }
    return NO;
}

//只暂停指定索引的任务，不自动下载等待的任务
- (BOOL)stopCurrent:(int)index
{
    int count = [taskList count];
    if(index>=0 && index<count)
    {
        
        Task* t = [taskList objectAtIndex:index];
        if(t.status==TASK_STATUS_RUNNING)
        {
            
            t.status = TASK_STATUS_BLOCK;
            [t stop];
        
            return YES;
        }
    }
    return NO;
}
//暂停所有的任务
- (void)stopAllTask
{
    int indexRunning = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (indexRunning >= 0) {
        Task* t = [taskList objectAtIndex:indexRunning];
        [t stop];
    }
    for (Task *task in taskList) {
        if (task.status == TASK_STATUS_RUNNING || task.status == TASK_STATUS_READY) {
            task.status = TASK_STATUS_BLOCK;
        }
    }
}

//开始所有的任务
- (void)startAllTask
{
    
    for (Task *task in taskList) {
        if (task.status == TASK_STATUS_BLOCK) {
            task.status = TASK_STATUS_READY;
        }
    }
    
    [self start];
}

// 返回YES表示TaskManager中有任务正在运行
-(BOOL)isRunning
{
    return [self _firstIndexWithStatus:TASK_STATUS_RUNNING]<0?NO:YES;
}

//是否全部都在下载，等待下载，或者都已完成
- (BOOL)isAllRunning
{
    for (Task *task in taskList) {
        
        if (task.status == TASK_STATUS_BLOCK) {
            return NO;
        }
    }
    
    return YES;
}

//是否全部暂停
- (BOOL)isAllStop
{
    for (Task *task in taskList) {
        
        if (task.status == TASK_STATUS_READY || task.status == TASK_STATUS_RUNNING) {
            return NO;
        }
    }
    
    return YES;
}

//是否有任务选中
- (BOOL)isSelectedTask
{
    for (Task *task in taskList) {
        
        if (task.selected) {
            return YES;
        }
    }
    
    return NO;
}

//是否全部选中
- (BOOL)isAllSelected
{
    for (Task *task in taskList) {
        
        if (!task.selected) {
            return NO;
        }
    }
    
    return YES;
}

// 把TaskManager中的所有任务信息保存到文件系统，一般是在退出程序时调用
-(BOOL)store
{
    /*
     1、序列化整个mTaskList
     */
    if ([taskList count] <= 0) {
        return NO;
    }
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"DataDownloadList.plist"];
	if (![NSKeyedArchiver archiveRootObject:taskList toFile:filename]){
		return NO;
	}
	else {
		return YES;
	}
	
//	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults] ;
//	NSData *data = [NSKeyedArchiver archivedDataWithRootObject:taskList];
//	[defaults setObject:data forKey:@"theKey"];
//	[defaults synchronize];
//	return YES;
    
}

//删除一体化时保存tasklist到任务列表文件中
-(BOOL)removeCountryTaskList
{
    
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"DataDownloadList.plist"];
	if (![NSKeyedArchiver archiveRootObject:taskList toFile:filename]){
		return NO;
	}
	else {
		return YES;
	}
    
}
// 从文件系统还原通过save保存的所有任务信息，一般是在进入程序时调用，该方法调用将把TaskManager中的所有任务更新为最后一次调用save保存的任务
-(BOOL)restore
{
    /*
     1、反序列化各个Task对象，构建处mTaskList
     2、遍历mTaskList，把task.delegate = self;
     */
	
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"DataDownloadList.plist"];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	[taskList removeAllObjects];
	[taskList addObjectsFromArray:array];
	[self addLocalDataToList];
	return YES;
	
	
	//NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//	NSData *data = [defaults objectForKey:@"theKey"];
//	if (data == nil) {
//		[self addLocalDataToList];
//		return;
//	}
//	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithData:data];
//	[taskList removeAllObjects];
//	[taskList addObjectsFromArray:array];
//	
//	[self addLocalDataToList];
//	
//	return YES;
	
	
}

//将本地数据添加到任务列表中
-(void)addLocalDataToList
{
	
	
	//不是一体化数据－对比本地已存在的完整地图数据和下载列表中的地图数据，若本地已存在的地图数据不在下载列表中，则添加到下载列表中
	if ([mapDataManage getMapDataType] != 1) {
		int count = [taskList count];
		int i;
		for (i = 0;i < count ; i++) {
			DownloadTask* task = [taskList objectAtIndex:i];
			
			
			//一体化数据被删除后要把任务列表中的任务项删除
			if (task.taskId == 86 && task.status == TASK_STATUS_FINISH) {
				
				[task erase];
				[taskList removeObjectAtIndex:i];
			}
			//数据还未下载完成，用户通过电脑把数据删除－把任务从任务列表中清除
			if (task.status != TASK_STATUS_FINISH && task.current != 0) {
				NSString *stringt = @"/";
				NSRange range = [task.url rangeOfString:stringt options:NSBackwardsSearch];
				
				if (range.length != 0) {
					NSString *name = [task.url substringFromIndex:range.location+1]; 
					NSFileManager *fileManager = [NSFileManager defaultManager];
					NSArray *paths;
					NSString *documentsDirectory;
					paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
					documentsDirectory = [[NSString alloc] initWithFormat:@"%@", [paths objectAtIndex:0]];
					NSString *filePath = [NSString stringWithFormat:@"%@/%@.tmp",documentsDirectory,name];
                    GADAREALIST *ppAdareaList1;
                    GSTATUS temAreaNum1 = GDBL_GetAdareaWithDataList(task.taskId,&ppAdareaList1);
					if(temAreaNum1 == GD_ERR_OK && ![fileManager fileExistsAtPath:filePath] && ppAdareaList1->lNumberOfAdarea == 0) {
						[task erase];
						[taskList removeObjectAtIndex:i];
						i--;
					}
				}
				
			}
			
			//用户删除GPS目录，如果基础资源下载完成，则把所有任务清空。
            Gbool bAvailable = Gtrue;
            NSString *documentsDirectory =[[NSString alloc] initWithFormat:@"%@",[NSHomeDirectory() stringByAppendingFormat:@"/Documents/GPS/"]];
            GDBL_IsGlobalDataAvailable((Gchar *)NSSTRING_TO_CSTRING(documentsDirectory),&bAvailable);
            [documentsDirectory release];
            documentsDirectory  = nil;
			if (task.taskId == 0 && task.status == TASK_STATUS_FINISH && !bAvailable)
			{
				[self removeTasksForStatus:TASK_STATUS_READY];
                [self removeTasksForStatus:TASK_STATUS_BLOCK];
			    [taskList removeAllObjects];
				return;
			}
			count = [taskList count];
			//一体化数据未下载完成
			if (task.taskId == 86 && task.status != TASK_STATUS_FINISH) {
				return;
			}
		}
		if ([mapDataManage getMapDataType] == 2) {
			//将基础资源添加到任务列表中
			plugin_cdm_RoadDownloadTask *baseTask = [[plugin_cdm_RoadDownloadTask alloc] init];
			
            baseTask.title = STR(@"CityDownloadManage_baseResources", @"CityDownloadManage");
			baseTask.taskId = 0;
			baseTask.url = nil;
			[self addLocalTask:baseTask atFirst:NO];
			[baseTask release];
			
			
			//添加本地分城市数据到任务列表中
            GADAREALIST *ppAdareaList;
            GSTATUS temAreaNum = GDBL_GetAdareaWithDataList(0,&ppAdareaList);
			//ADMININFO *pAdminInfo = malloc(iBufCount*sizeof(ADMININFO));
			//int dataCount = MEK_GetHasDBAdareaList(pAdminInfo,iBufCount,iAdaLevel);
            int dataCount;
            if (temAreaNum == GD_ERR_OK) 
            {
                dataCount = ppAdareaList->lNumberOfAdarea;
            }
            else 
            {
                dataCount = 0;
            }
           
            
            
		//pc端删除documents目录的全部文件，又通过pc端重新拖入数据
		for(int i = 0;i < [taskList count]; i++)
		{
			DownloadTask* task = [taskList objectAtIndex:i];
			if (task.taskId != 0 && task.status == TASK_STATUS_FINISH) 
			{
				if (dataCount == 0) 
				{
					[task erase];
					[taskList removeObjectAtIndex:i];
					i--;
				}
				else {
					BOOL bData = NO;
					for (int j=0; j<dataCount; j++)
					{
						switch (ppAdareaList->pAdarea[j].lAdminCode) {
                            case 110000:
                            case 120000:
                            case 310000:
                            case 500000:
                            case 810000:
                            case 820000:
                            {
                                if (task.taskId ==ppAdareaList->pAdarea[j].lAdminCode ) {
                                    bData = YES;
                                }
                            }
                                break;
                            default:
                            {
                                for (int k = 0; k < ppAdareaList->pAdarea[j].lNumberOfSubAdarea; k++) {
                                    if (task.taskId ==ppAdareaList->pAdarea[j].pSubAdarea[k].lAdminCode ) {
                                        bData = YES;
                                    }
                                }
                            }
                                break;
                        }
						//if (task.taskId ==pAdminInfo[j].lAdminCode ) {
                     //   if (task.taskId ==ppAdareaList->pAdarea[j].lAdminCode ) {
					//		bData = YES;
					//	}
						
					}
					if (bData == NO) {
						[task erase];
						[taskList removeObjectAtIndex:i];
						i--;
					}
				}

			}
		}
		for (int i=0; i<dataCount; i++) {
            switch (ppAdareaList->pAdarea[i].lAdminCode) {
                case 110000:
                case 120000:
                case 310000:
                case 500000:
                case 810000:
                case 820000:
                {
                    DownloadTask *task = [[DownloadTask alloc] init];
                    task.taskId =ppAdareaList->pAdarea[i].lAdminCode;
                    NSString *name =  CSTRING_TO_NSSTRING(ppAdareaList->pAdarea[i].szAdminName) ;
                    task.title = name;
                    task.total = 0;
                    task.url = nil;
                    [self addLocalTask:task atFirst:NO];
                    [task release];
                }
                    break;
                default:
                {
                    for (int j = 0; j < ppAdareaList->pAdarea[i].lNumberOfSubAdarea; j++) 
                    {
                        DownloadTask *task = [[DownloadTask alloc] init];
                        task.taskId = ppAdareaList->pAdarea[i].pSubAdarea[j].lAdminCode;
                        NSString *name = CSTRING_TO_NSSTRING(ppAdareaList->pAdarea[i].pSubAdarea[j].szAdminName) ;
                        task.title = name;
                        task.total = 0;
                        task.url = nil;
                        [self addLocalTask:task atFirst:NO];
                        [task release];
                    }
                }
                    break;
            }
			//	task.taskId = pAdminInfo[i].lAdminCode;
				
			}
		//	free(pAdminInfo);
		}
		
	}
	else {
		
		[taskList removeAllObjects];
		IntegratedDownloadTask *task = [[IntegratedDownloadTask alloc] init];
		
        task.title = STR(@"CityDownloadManage_Country", @"CityDownloadManage");
		task.taskId = 86;
		task.total = 0;
		task.url = @"/AutoNavi_Mapdata.dat";
		[self addLocalTask:task atFirst:YES];
		[task release];
		
	}
	

}

//通过taskid获取任务
- (Task *)getTaskWithTaskID:(int)taskID
{
    for (Task *temp in taskList) {
        if (temp.taskId == taskID) {
            
            return temp;
        }
        
    }
    return nil;
}

//获取相应类型的对应索引的任务,taskStatus传入yes则获取完成的任务，否则获取非完成的。
- (Task *)getTaskWithIndex:(int)index taskStatus:(BOOL)taskStatus
{
    
    int taskIndex = 0;
    if (taskStatus) {
        for (Task *temp in taskList) {
            if (temp.status == TASK_STATUS_FINISH) {
                if (index == taskIndex) {
                    return temp;
                }
                taskIndex ++;
            }
            
        }

    }
    else{
        for (Task *temp in taskList) {
            if (temp.status != TASK_STATUS_FINISH) {
                if (index == taskIndex) {
                    return temp;
                }
                taskIndex ++;
            }
            
        }
    }
    return nil;
}

//获取完成的任务个数
- (int)getFinishTaskNumber
{
    int finishNumber = 0;
    for (Task *task in taskList) {
        if (task.status == TASK_STATUS_FINISH) {
            finishNumber ++;
        }
    }
    return finishNumber;
}

//-(BOOL)moveUp:(int)index;
//-(BOOL)moveDown:(int)index;

//获取任务列表中所有任务需要的空间大小
-(long long)getNeedSize
{
	long long size;
	size = 0;

	int count = [taskList count];
    for (int i=0;i<count;i++) { 
	   Task* t = [taskList objectAtIndex:i];
        if(t.status == TASK_STATUS_READY || t.status == TASK_STATUS_RUNNING )
        {
		//	long long tmp = [t getNeedSize];
            size += (t.total - t.current);
        }
        
    }
    
    return size;
}
#pragma mark - 私有方法

// 从头开始向尾扫描mTaskList列表，直到遇到一个状态为TASK_STATUS_READY的任务对象
// 返回指<0则表示没找到可被执行的任务，否则表示所选任务的索引
-(int)_selectOneTaskToRun
{
    return [self _firstIndexWithStatus:TASK_STATUS_READY];
}


// 返回队列中，状态为status的第一个任务的索引
// 返回指<0则表示没找到可被执行的任务，否则表示任务的索引
-(int)_firstIndexWithStatus:(int)status
{
    int count = [taskList count];
    for (int i=0;i<count;i++) {
        
        if(((Task*)[taskList objectAtIndex:i]).status == status)
        {
            return i;
        }
    }
    return -1;
}

//返回队列中，任务id为taskID的任务索引
- (int)_indexWithTaskID:(int)taskID
{
    int count = [taskList count];
    for (int i=0;i<count;i++) {
        
        if(((Task*)[taskList objectAtIndex:i]).taskId == taskID)
        {
            return i;
        }
    }
    return 0;
}
// 根据taskId来判断task是否已经存在队列中
-(BOOL)_taskExisted:(Task*)task
{
    for (Task* t in taskList) {
        // 用任务id来比较
        if(t.taskId == task.taskId)
        {
            return YES;
        }
    }
    return NO;
}



#pragma mark - TaskStatusDelegate委托回调

-(void)progress:(Task*)sender current:(long long)current total:(long long)total
{

    NSLog(@"DownLoadData:%lld,%lld",current,total);
	if ([delegate respondsToSelector:@selector(progress:current:total:)]) {
        [delegate progress:sender current:current total:total];
	}
}

-(void)finished:(Task*)sender
{
	sender.status = TASK_STATUS_FINISH;
	
    [self store];
    [self start];
	
    if ([delegate respondsToSelector:@selector(finished:)]) {
	    [delegate finished:sender];
	}
}

-(void)exception:(Task*)sender exception:(id)exception
{
    if (((NSError *)exception).code == DOWNLOADHANDLETYPE_CURRENTLAGERTOTAL || ((NSError *)exception).code == DOWNLOADHANDLETYPE_NOSPACE ||((NSError *)exception).code == DOWNLOADHANDLETYPE_UPZIPFAIL || ((NSError *)exception).code == DOWNLOADHANDLETYPE_CURRENTSMALLTOTAL) {
        [self removeTaskId:sender.taskId];
    }
    
    [self stopRunning];
    [self store];	if ([delegate respondsToSelector:@selector(exception:exception:)]) {
	    [delegate exception:sender exception:exception];
	}
}
- (void)unZipFinish:(Task*)sender
{
    if ([delegate respondsToSelector:@selector(unZipFinish:)]) {
        [delegate unZipFinish:sender];
    }

}


@end
