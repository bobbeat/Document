//
//  plugin-cdm-IntegratedDownloadTask.h
//  plugin-CityDataManager
//
//  Created by GHY on 11-12-9.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-DownloadTask.h"

@interface IntegratedDownloadTask : DownloadTask 
{

}

@end
