//
//  RemoteDataList.m
//  plugin-CityDataManager
//
//  Created by mark on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "plugin-cdm-RemoteDataList.h"
#import "plugin-cdm-XmlParser.h"
#import "GDBL_NetCounter.h"

static RemoteDataList* instance;

@implementation RemoteDataList

@synthesize delegate;


+(DataList*)remoteDataList
{
    if(instance==nil)
    {
        instance = [[RemoteDataList alloc] init];
    }
	
    return instance;
}


+(void)releaseInstance
{
    if(instance!=nil)
    {
        [instance release];
        instance = nil;
    }
}


- (id)init
{
	if (self = [super init]) 
	{
		foundlist = [[NSMutableArray alloc] init];
        tmpfoundList = [[NSMutableArray alloc] init];
		cityValidFlag = [[NSMutableArray alloc] init];
		status = 1;
	}
	
	return self;
}


// 执行获取服务器数据任务，返回值不做任何的用途
- (BOOL)parse:(int)type mapVersion:(NSString *)version
{
	[version retain];
	if (status==0) 
	{
		return NO;
	}
	
	status = 0;
	resultData = [[NSMutableData alloc] init];
	
	NSString *url;
   
	if(type == 1){  //一体化
        url = [NSString stringWithFormat:@"%@annex/cityupdate?client=%0.1f&country=%@",kNetDomain,SOFTVERSIONNUM,version];
	}
	else if(type == 2){ //分城市
        url = [NSString stringWithFormat:@"%@annex/cityupdate?client=%0.1f&city=%@",kNetDomain,SOFTVERSIONNUM,version];
	}
	else {  //无数据
        url = [NSString stringWithFormat:@"%@annex/cityupdate?client=%0.1f",kNetDomain,SOFTVERSIONNUM];
	}
    NSLog(@"省市列表：%@",url);
    
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    [request setTimeoutInterval:20];
	connection = [NSURLConnection connectionWithRequest:request delegate:self];
    
    return YES;
}


// 解析xml数据到成员变量数组
- (void)parserResult:(NSMutableData *)result
{
	// 解析服务器返回的xml内容，获取有用信息
	if (result) 
	{
		NSString *string = [[NSString alloc] initWithData:result  encoding:NSUTF8StringEncoding];
		NSString *stringt = @"opg";
		
		NSRange range = [string rangeOfString:stringt];
		if (range.length!=0) 
		{
			NSString *strdata = [string substringFromIndex:range.location-1];//去除前面的无关信息
			[strdata retain];
		
			NSData *data = [strdata dataUsingEncoding:NSUTF8StringEncoding];
			[strdata release];
			strdata = nil;
			[list removeAllObjects];
            [foundlist removeAllObjects];
            [cityValidFlag removeAllObjects];
			XmlParser *xmlParser = [[XmlParser alloc] initWitharray:list Withfound:foundlist WithCityFlag:cityValidFlag];
			BOOL xmlresult = [xmlParser parser:data];
			[xmlParser release];
			if (xmlresult) 
			{
                if (delegate && [(NSObject *)delegate respondsToSelector:@selector(dataparseDone)]) {
                    [delegate dataparseDone];
                }
				
				status = 1;
			}
			else 
			{
                if (delegate && [(NSObject *)delegate respondsToSelector:@selector(dataparseDone)]) {
			        [delegate dataparseFail:nil];
                }
			    status = 1;
			    return;
		}
		}
		else 
		{
            if (delegate && [(NSObject *)delegate respondsToSelector:@selector(dataparseDone)]) {
			    [delegate dataparseFail:nil];
            }
			status = 1;
			return;
		}
		
		[string release];
	}
	else 
	{
        if (delegate && [(NSObject *)delegate respondsToSelector:@selector(dataparseDone)]) {
		    [delegate dataparseFail:nil];
        }
		status = 1;
		return;
	}
}

#pragma mark NSURLConnection Delegate methods

- (void)connection:(NSURLConnection *)aconnection didReceiveResponse:(NSURLResponse *)response
{
	[resultData setLength:0];
}


// 连接失败
- (void)connection:(NSURLConnection *)aconnection didFailWithError:(NSError *)error 
{
	//发送失败消息委托
	status=1;
    if (delegate && [delegate respondsToSelector:@selector(dataparseDone)]) {
	    [delegate dataparseFail:error];
    }
    [resultData setLength:0];
}


// 接收数据
- (void)connection:(NSURLConnection *)aconnection didReceiveData:(NSData *)data 
{
    [resultData appendData:data];
    [GDBL_NetCounter shareInstance].byte = data.length;
}


// 接收数据完成，取消任务，准备解析xml
- (void)connectionDidFinishLoading:(NSURLConnection *)aconnection 
{
    [aconnection cancel];
	[self parserResult:resultData];
}


// 获取基础数据列表（Item数组）
- (NSArray*)getfoundList
{
    [tmpfoundList removeAllObjects];
    int count = [foundlist count];
    for(int i=0;i<count;i++)
    {
        [tmpfoundList addObject:[foundlist objectAtIndex:i]];
    }
	
    return tmpfoundList;
}

// 获取分城市标志,一体化标志,客户端标志
- (NSArray*)getCityValid
{
    [tmpfoundList removeAllObjects];
    int count = [cityValidFlag count];
    for(int i=0;i<count;i++)
    {
        [tmpfoundList addObject:[cityValidFlag objectAtIndex:i]];
    }
	
    return tmpfoundList;
}

- (void)dealloc
{
	if (foundlist) 
	{
		[foundlist release];
		foundlist = nil;
	}
	
	if (tmpfoundList) 
	{
		[tmpfoundList release];
		tmpfoundList = nil;
	}
	
	if (cityValidFlag) {
		[cityValidFlag release];
		cityValidFlag = nil;
	}
    
	
	if (resultData) 
	{
		[resultData release];
		resultData = nil;
	}
	
	[super dealloc];
}


@end
