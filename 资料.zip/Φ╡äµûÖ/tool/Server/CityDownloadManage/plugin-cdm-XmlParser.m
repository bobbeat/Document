//
//  plugin-cdm-XmlParser.m
//  plugin-CityDataManager
//
//  Created by GHY on 11-11-14.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import "plugin-cdm-XmlParser.h"
#import "plugin-cdm-DataList.h"
#import "ANParamValue.h"

@implementation XmlParser


- (id)initWitharray:(NSMutableArray *)parray Withfound:(NSMutableArray *)farray WithCityFlag:(NSMutableArray *)pcityflag 
{
	if (self = [super init]) 
	{
		optiondata = parray;
		founddata = farray;
		cityflag = pcityflag;
	}
	
	return self;
}


- (BOOL)parser:(NSData *)data
{
	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
    [parser parse]; 
	if ([parser parserError]) 
	{
        GDAlertView *alertView = [[GDAlertView alloc] initWithTitle:STR(@"CityDownloadManage_xmlParserFail",@"CityDownloadManage") andMessage:STR(@"CityDownloadManage_xmlDataError",@"CityDownloadManage")] ;
        
        [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeCancel handler:nil];
        [alertView show];
        [alertView release];
        
		return NO;
	}
	
    [parser release];
	return YES;
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict 
{
    if (qName) 
	{
        elementName = qName;
	}
	
	if (city)
	{
        if ([elementName isEqualToString:@"adcode"] || [elementName isEqualToString:@"size"] || [elementName isEqualToString:@"suburl"]) 
		{
            currentProperty = [NSMutableString string];
        }
    }
	else if (province)
	{
		if ([elementName isEqualToString:@"adcode"] || [elementName isEqualToString:@"suburl"] || [elementName isEqualToString:@"size"]) 
		{
            currentProperty = [NSMutableString string];
        }
		else if ([elementName isEqualToString:@"city"]) 
		{
            cname = [[NSDictionary alloc] initWithDictionary:attributeDict];
			city = [[Item alloc] init];
        }
	}
	else if (optional) 
	{
        if ([elementName isEqualToString:@"item"]) 
		{
			pname = [[NSDictionary alloc] initWithDictionary:attributeDict];
			province = [[Item alloc] init];
			citydata = [[NSMutableArray alloc] init];
			[citydata addObject:province];
        }
    } 
    else if (found)
	{
        if ([elementName isEqualToString:@"suburl"] || [elementName isEqualToString:@"size"]) 
		{
            currentProperty = [NSMutableString string];
        }
    }  
	else if (required) 
	{
        if ([elementName isEqualToString:@"item"]) 
		{
            fname = [[NSDictionary alloc] initWithDictionary:attributeDict];
			found = [[Item alloc] init];
        }
    } 
	else if (infoD) 
	{
        if ([elementName isEqualToString:@"required"]) 
		{
            required = [[Item alloc] init]; // Create the element
        }
		else if ([elementName isEqualToString:@"optional"])
		{
            optional = [[Item alloc] init]; // Create the element
        }
    } 
	else if (opg) 
	{
        if ([elementName isEqualToString:@"info"]) 
		{
			baseurl = [attributeDict valueForKey:@"baseurl"];
			[baseurl retain];
			version = [attributeDict valueForKey:@"version"];
			[version retain];
            infoD = [[Item alloc] init]; 
        }
		else if ([elementName isEqualToString:@"cityvalid"]) 
		{
			cityValid = [[Item alloc] init];// Create the element
			currentProperty = [NSMutableString string];
			
        }
        else if ([elementName isEqualToString:@"countryvalid"])
		{
			countryValid = [[Item alloc] init];// Create the element
			currentProperty = [NSMutableString string];
			
        }
        else if ([elementName isEqualToString:@"clientvalid"])
        {
            clientValid = [[Item alloc] init];// Create the element
            currentProperty = [NSMutableString string];
            
        }
    

    } 
	
	else 
	{
        if ([elementName isEqualToString:@"opg"]) 
		{
            opg = [[Item alloc] init];// Create the element
        }
    }
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    NSLog(@"%@",string);
    if (currentProperty) 
	{
        [currentProperty appendString:string];
    }
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName 
{
    if (qName) 
	{
        elementName = qName;
    }
	
	if (city) 
	{
		if ([elementName isEqualToString:@"adcode"]) 
		{
			city.adminCode = [currentProperty intValue];
        }
        else if ([elementName isEqualToString:@"suburl"]) 
		{
            city.url = [baseurl stringByAppendingString:currentProperty];
        } 
		else if ([elementName isEqualToString:@"size"]) 
		{
            city.totalSize = [currentProperty longLongValue];
        }
		else if ([elementName isEqualToString:@"city"]) 
		{
			city.nameDic = cname;
			[cname release];
			cname = nil;
			
			[citydata addObject:city];
			[city release];
			city = nil;
        }
    }
	else if (province) 
	{
		if ([elementName isEqualToString:@"adcode"]) 
		{
			province.adminCode = [currentProperty intValue];
        }
        else if ([elementName isEqualToString:@"suburl"]) 
		{
            province.url = [baseurl stringByAppendingString:currentProperty];
        } 
		else if ([elementName isEqualToString:@"size"]) 
		{
            province.totalSize = [currentProperty longLongValue];
        }
		else if ([elementName isEqualToString:@"item"]) 
		{
			province.nameDic = pname;
            
            //将省份放到子列表的第一个
            if (!province.url) {
                [citydata insertObject:province atIndex:0];
            }
            
			[pname release];
			pname = nil;
			[province release];
			province = nil;
			
            //全国数据放到列表最后面
            if (province.adminCode == 86) {
                
                [optiondata addObject:citydata];
            }
            else
            {
                
                int index = [optiondata count] - 1;
                if (index < 0) {
                    index = 0;
                }
                [optiondata insertObject:citydata atIndex:index];
            }
			
			[citydata release];
			citydata=nil;
        }
    }
	else if (optional) 
	{
        if ([elementName isEqualToString:@"optional"]) 
		{
			[optional release];
			optional = nil;
        }
    }
	else if (found) 
	{
		if ([elementName isEqualToString:@"suburl"]) 
		{
            found.url = [baseurl stringByAppendingString:currentProperty];
        }
		else if ([elementName isEqualToString:@"size"]) 
		{
            found.totalSize = [currentProperty intValue];
        }
        else if ([elementName isEqualToString:@"item"]) 
		{
			found.nameDic = fname;
			[fname release];
			fname = nil;
			[founddata addObject:found];
			
            [found release];
			found = nil;
        }
    }
	else if (required) 
	{
        if ([elementName isEqualToString:@"required"]) 
		{
			[required release];
			required = nil;
        }
    }
	else if (infoD) 
	{
        if ([elementName isEqualToString:@"info"]) 
		{
			infoD.name = version;
			[founddata addObject:infoD];
			[infoD release];
			infoD = nil;
        }
		
    }
	else if (cityValid) 
	{
        if ([elementName isEqualToString:@"cityvalid"]) 
		{
			cityValid.adminCode = [currentProperty intValue];
            if ([cityflag count] >= 3)
            {
                [cityflag insertObject:cityflag atIndex:2];
            }
            else
            {
                [cityflag addObject:cityValid];
            }
			
			[cityValid release];
			cityValid = nil;
        }
    }
    else if (clientValid)
    {
        if ([elementName isEqualToString:@"clientvalid"])
		{
			clientValid.adminCode = [currentProperty intValue];
            if ([cityflag count] >= 1)
            {
                [cityflag insertObject:clientValid atIndex:0];
            }
            else
            {
                [cityflag addObject:clientValid];
            }
			[clientValid release];
			clientValid = nil;
        }
    }
    else if (countryValid)
    {
        if ([elementName isEqualToString:@"countryvalid"])
		{
			countryValid.adminCode = [currentProperty intValue];
            if ([cityflag count] >= 2)
            {
                [cityflag insertObject:countryValid atIndex:1];
            }
            else
            {
                [cityflag addObject:countryValid];
            }
			
			[countryValid release];
			countryValid = nil;
        }
    }
	else if (opg)
	{
        if ([elementName isEqualToString:@"opg"])
		{
			[opg release];
			opg = nil;
        }
    }
	
	currentProperty = nil;
}


- (void)dealloc
{	
	if (baseurl) 
	{
		[baseurl release];
		baseurl = nil;
	}
	
	if (version) 
	{
		[version release];
		version = nil;
	}
	
	[citydata release];
	[super dealloc];
}

@end
