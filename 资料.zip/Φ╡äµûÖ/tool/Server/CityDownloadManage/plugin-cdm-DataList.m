//
//  DataList.m
//  plugin-CityDataManager
//
//  Created by mark on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "plugin-cdm-DataList.h"

@implementation Item

@synthesize nameDic;
@synthesize name;
@synthesize url;
@synthesize totalSize;
@synthesize adminCode;

- (void)dealloc
{
    self.nameDic = nil;
    self.name = nil;
    self.url = nil;
    [super dealloc];
}

@end


@implementation DataList

-(id)init
{
    self = [super init];
    if(self!=nil)
    {
        list = [[NSMutableArray alloc]init];
        tmpList = [[NSMutableArray alloc]init];
    }
    return self;
}

// 解析数据
-(BOOL)parse
{
    return NO;
}

// 获取父列表（Item数组）
-(NSArray*)getList
{
    [tmpList removeAllObjects];
    int count = [list count];
    for(int i=0;i<count;i++)
    {
        [tmpList addObject:[(NSMutableArray*)[list objectAtIndex:i] objectAtIndex:0]];
    }
    return tmpList;
}

// 获取父列表中，某个索引的孩子列表（Item数组）
-(NSArray*)getList:(int)index
{
    [tmpList removeAllObjects];
    NSMutableArray* father = (NSMutableArray*)[list objectAtIndex:index];
    int count = [father count];
    for(int i=1;i<count;i++)
    {
        [tmpList addObject:[father objectAtIndex:i]];
    }
    return tmpList;
}

-(void)dealloc
{

    [list release];
    [tmpList release];
    [super dealloc];
}

@end
