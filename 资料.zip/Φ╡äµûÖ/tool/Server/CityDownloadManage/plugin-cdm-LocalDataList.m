//
//  LocalDataList.m
//  plugin-CityDataManager
//
//  Created by  on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "plugin-cdm-LocalDataList.h"

static LocalDataList* instance;

@implementation LocalDataList

+(DataList*)localDataList
{
    if(instance==nil)
    {
        instance = [[LocalDataList alloc]init];
    }
    return instance;
}

+(void)releaseInstance
{
    if(instance!=nil)
    {
        [instance release];
        instance = nil;
    }
}

-(BOOL)parse
{
    /*
     1、调用本地MEK函数获取省、市列表，组装出Item对象，解析到list成员中，注意list的数据结构
     2、成功返回YES，失败返回NO
     */
    return NO;
}

@end
