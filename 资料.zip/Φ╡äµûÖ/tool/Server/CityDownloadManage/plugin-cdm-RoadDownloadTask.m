//
//  plugin-cdm-RoadDownloadTask.m
//  plugin-CityDataManager
//
//  Created by GHY on 11-12-12.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import "plugin-cdm-RoadDownloadTask.h"

#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]//文件最终存放目录

@implementation plugin_cdm_RoadDownloadTask


// 删除任务以及任务相关的资源
- (void)erase   
{
	// 停止下载任务
	[self stopconnection];
	
		NSString* GPSPath = [[NSString alloc] initWithString:[DOCUMENTS_FOLDER stringByAppendingFormat:@"/GPS"]];
		
		// 删除临时文件并初始化下载数据
		NSError *error;
		if([[NSFileManager defaultManager] fileExistsAtPath:GPSPath])
		{
			[[NSFileManager defaultManager] removeItemAtPath:GPSPath error:&error];
		}
	
    [GPSPath release];
	// 删除临时文件并初始化下载数据
	if (tmpPath!=nil && [tmpPath length]!=0) 
	{
		if([[NSFileManager defaultManager] fileExistsAtPath:tmpPath])
		{
			[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:&error];
		}
		
		[tmpPath release];
		tmpPath = nil;
	}
	
	current=0;
	total=0;
}

@end
