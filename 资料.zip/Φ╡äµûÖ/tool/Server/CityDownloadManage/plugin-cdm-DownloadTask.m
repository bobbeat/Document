//
//  DownloadTask.m
//  plugin-CityDataManager
//
//  Created by mark on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "plugin-cdm-DownloadTask.h"
#import "ZipArchive.h"
#import "ANParamValue.h"
#import "Utility.h"
#import "ANReachability.h"
#import "GDBL_NetCounter.h"
#include "DelMapData.h"
#import "Plugin_OnLineMapUtility.h"
#import "ANOperateMethod.h"
#import "MWGuideOperator.h"
#import "GDAlertView.h"

static NSString* KB = @"KB";
static NSString* MB = @"MB";

#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]//文件最终存放目录


@implementation DownloadTask

@synthesize url;


/*
 NSCoding协议内容(由龙峰填充)
 */

- (void)encodeWithCoder:(NSCoder *)encoder 
{
	[encoder encodeObject:title forKey:@"tasklist1key"];
	[encoder encodeInt:taskId forKey:@"tasklist2key"];
	[encoder encodeInt64:current forKey:@"tasklist3key"];
	[encoder encodeInt64:total forKey:@"tasklist4key"];
	[encoder encodeInt:status forKey:@"tasklist5key"];
	[encoder encodeObject:url forKey:@"tasklist6key"];
}


- (id)initWithCoder:(NSCoder *) decoder 
{
	if (self = [super init]) 
	{
		self.title = [decoder decodeObjectForKey:@"tasklist1key"];
		self.taskId = [decoder decodeIntForKey:@"tasklist2key"];
		self.current = [decoder decodeInt64ForKey:@"tasklist3key"];
		self.total = [decoder decodeInt64ForKey:@"tasklist4key"];
		self.status = [decoder decodeIntForKey:@"tasklist5key"];
		self.url = [decoder decodeObjectForKey:@"tasklist6key"];
	}
	
	return self;
}


// 获取文件名，从后往后找“/”定位
- (NSString *)getFilename
{
	NSString *stringt = @"/";
	
	NSRange range = [url rangeOfString:stringt options:NSBackwardsSearch];
	if (range.length==0) 
	{
		return nil;//即下载地址是错误的，后面处理
	}
	
	NSString *strdata = [url substringFromIndex:range.location+1];//去除前面的无关信息
	return strdata;
}


// 获取文件存储路径
- (void)createFilepath
{
	if (![[NSFileManager defaultManager] fileExistsAtPath:DOCUMENTS_FOLDER]) //要是文件目录不存在，创建目录
	{
		[[NSFileManager defaultManager] createDirectoryAtPath:DOCUMENTS_FOLDER withIntermediateDirectories:NO attributes:nil error:nil];
	}
	
	// 公司内部协议，未完成下载的文件统一未.tmp文件
	filePath = [[NSString alloc] initWithString:[DOCUMENTS_FOLDER stringByAppendingFormat:@"/%@.tmp",filename]];
}


// 执行下载任务
- (void)run
{
    NSLog(@"url=%@",url);
	//判断url是否为空，如果为空，提示。
	if (url == nil) 
	{
        GDAlertView *alertView = [[GDAlertView alloc] initWithTitle:@"Cannot Open the Request!" andMessage:STR(@"CityDownloadManage_urlEmpty",@"CityDownloadManage")] ;
        
        [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeCancel handler:nil];
        [alertView show];
        [alertView release];
        
		return;
	}
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(donetMethod) name:kReachabilityChangedNotification object: nil];
	
	NSString* integratedPath = [[NSString alloc] initWithString:[DOCUMENTS_FOLDER stringByAppendingFormat:@"AutoNavi_Mapdata.dat"]];
	if([[NSFileManager defaultManager] fileExistsAtPath:integratedPath])//若选择重新下载任务，会删除之前的临时文件
	{
		[[NSFileManager defaultManager] removeItemAtPath:integratedPath error:nil];
	}
	[integratedPath release];
	integratedPath = nil;
	
	// 获取文件名，若文件名未空即下载地址是错误的
    if (filename)
    {
        [filename release];
        filename = nil;
    }
	filename = [[NSString alloc] initWithString:[self getFilename]];
	if (filename == nil) 
	{
		GDAlertView *alertView = [[GDAlertView alloc] initWithTitle:@"Cannot Open the Request!" andMessage:STR(@"CityDownloadManage_urlError",@"CityDownloadManage")] ;
        
        [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeCancel handler:nil];
        [alertView show];
        [alertView release];
		return;
	}
	
	// 创建文件存储路径
	[self createFilepath];
	if (tmpPath) 
	{
		[tmpPath release];
		tmpPath = nil;
	}
	tmpPath = [[NSString alloc] initWithString:filePath];
	
	if([[NSFileManager defaultManager] fileExistsAtPath:filePath])//若选择重新下载任务，会删除之前的临时文件
	{
		NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:filePath error:nil];
		current = [fileAttributes fileSize];
	}
	else 
	{
		current = 0;
	}
	
	// 判断是新下载还是继续下载，current＝0未新下载，否则为续传（若临时文件不存在统一做重新下载）
	if (current==0) 
	{
		if([[NSFileManager defaultManager] fileExistsAtPath:filePath])//若选择重新下载任务，会删除之前的临时文件
		{
			[[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
		}
		
		fileStream = [NSOutputStream outputStreamToFileAtPath:filePath append:NO];
		[fileStream retain];
		assert(fileStream != nil);
		[fileStream open];//打开文件流准备接受数据
		
		NSURL* turl = [NSURL URLWithString:url];
		NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:turl];
        //[request setNetworkServiceType:NSURLNetworkServiceTypeVoice];
		assert(request != nil);
		URLConnection = [NSURLConnection connectionWithRequest:request delegate:self];
        
	}
	else 
	{
		if(![[NSFileManager defaultManager] fileExistsAtPath:filePath])
		{//判断继续下载的时候临时文件是否还存在，不存在就重新下载，并修改相应的参数
			current = 0;
			total = 0;
			
			fileStream = [NSOutputStream outputStreamToFileAtPath:filePath append:NO];
			[fileStream retain];
			assert(fileStream != nil);
			[fileStream open];
			
			NSURL* turl = [NSURL URLWithString:url];
			NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:turl];
            //[request setNetworkServiceType:NSURLNetworkServiceTypeVoice];
			assert(request != nil);
			URLConnection = [NSURLConnection connectionWithRequest:request delegate:self];
		}
		else //续传的实现
		{
			fileStream = [NSOutputStream outputStreamToFileAtPath:filePath append:YES];
			[fileStream retain];
			assert(fileStream != nil);
			[fileStream open];
			
			NSURL* turl = [NSURL URLWithString:url];
			NSMutableURLRequest* request = [[NSMutableURLRequest alloc] initWithURL:turl];
			//[request setNetworkServiceType:NSURLNetworkServiceTypeVoice];
			NSString* contentRang = [[NSString alloc] initWithFormat:@" bytes=%lld-%lld",current,total];
			[request addValue:contentRang forHTTPHeaderField:@"Range"];
			[request setValue:contentRang forHTTPHeaderField:@"Range"];
			[contentRang release];
			assert(request != nil);
			URLConnection = [NSURLConnection connectionWithRequest:request delegate:self];
            
			[request release];
		}
	}

}


- (void)donetMethod
{
	int netflag = NetWorkType;
	
	switch (netflag) 
	{
		case 2:
		{
			[self stopconnection];
			[self run];
		}
			break;
			
		default:
			break;
	}
}


// 停止任务的实现
- (void)stopconnection  
{
	if (filePath != nil) 
	{
		[filePath release];
		filePath = nil;
	}
	
	if (URLConnection != nil) 
	{
        @try {
            
            [URLConnection cancel];
            URLConnection = nil;
        }
        @catch (NSException *exception) {
            
        }
        
	}
	
	if (fileStream != nil) 
	{
		[fileStream close];
		[fileStream release];
		fileStream = nil;
	}
}


// 执行停止任务
- (void)stop
{
    
	[self stopconnection];
}


// 删除任务以及任务相关的资源
- (void)erase   
{
	// 停止下载任务
	[self stopconnection];
	
	if ([NSThread isMultiThreaded]) 
	{
		if (mythread!=nil) 
		{
			[mythread cancel];
            mythread = nil;
		}
	}

	NSString *info_path = [[NSString alloc] initWithString:[document_path stringByAppendingFormat:@"/GPS/CityAreaInfo.dat"]];
	NSString *data_path = [[NSString alloc] initWithString:[document_path stringByAppendingFormat:@"/GPS"]];
	DMD_set_info_path([info_path UTF8String]);
    DMD_set_data_path([data_path UTF8String]);
	
    [info_path release];
    [data_path release];
	//unzip_path* unzip = NULL;
	DMD_PATH* unzip = NULL;
		int file_num;
		if (url!=nil) 
		{
		//file_num = getUnzipPaths([url UTF8String], &unzip);
		
		file_num = DMD_get_del_paths_byzip([url UTF8String], &unzip);
		}
		else 
		{
		//file_num = getDataPaths(taskId, &unzip);
		
		file_num = DMD_get_del_paths(taskId, &unzip);
		}
		
		if (file_num>0) 
		{
			for (int i=0; i<file_num; i++) 
			{
				NSString* Path = [[NSString alloc] initWithCString:unzip[i].name encoding:NSUTF8StringEncoding];
				
				if (Path == nil || [Path length] == 0 ) 
				{
				[Path release];
				Path = nil;
					continue;
				}
			
				NSString* dPath = [DOCUMENTS_FOLDER stringByAppendingFormat:@"/%@",Path];
				[dPath retain];
				[Path release];
				Path = nil;
				
				NSError *error;
					if([[NSFileManager defaultManager] fileExistsAtPath:dPath])
					{
						[[NSFileManager defaultManager] removeItemAtPath:dPath error:&error];
					}
				[dPath release];
				dPath = nil;
			}
		}
		
		free(unzip);
	
		NSError *error;
	
	if (url!=nil && [url length]!=0) 
	{
		NSString *gdtmpPath = [[NSString alloc] initWithString:[self getFilename]];
		if([[NSFileManager defaultManager] fileExistsAtPath:gdtmpPath])
		{
			[[NSFileManager defaultManager] removeItemAtPath:gdtmpPath error:&error];
	    }
		
		NSString *gdPath = [[NSString alloc] initWithString:[DOCUMENTS_FOLDER stringByAppendingFormat:@"/%@.tmp",gdtmpPath]];
		if([[NSFileManager defaultManager] fileExistsAtPath:gdPath])
		{
			[[NSFileManager defaultManager] removeItemAtPath:gdPath error:&error];
		}
		[gdPath release];
		gdPath = nil;
		
		[gdtmpPath release];
		gdtmpPath = nil;
	}
	
	current=0;
	total=0;
}


// 返回任务的进度百分比[0~100]
- (int)percent 
{
    return (current*100.0/total);
}


// 某个任务的进度描述
- (NSString*)description 
{
    /*
     1、字节>=1MB的，以MB为单位，保留2位小数
     2、字节<1MB的，以KB为单位，保留2位小数
     */
    float cur,tot;
    NSString* unit1,*unit2;
    int mb = 1024*1024;
    int kb = 1024;
    if(current<mb)
    {
        cur = current*1.0f/kb;
        unit1 = KB;
    }
    else
    {
        cur = current*1.0f/mb;
        unit1 = MB;
    }
    if(total<mb)
    {
        tot = total*1.0f/kb;
        unit2 = KB;
    }
    else
    {
        tot = total*1.0f/mb;
        unit2 = MB;
    }
	
    return [NSString stringWithFormat:@"%.2f%@/%.2f%@",cur,unit1,tot,unit2];
}


// 获取文件还未下载的大小，即所需空间大小
- (long long)getNeedSize
{
	return (total-current);
}


// 下载任务联网响应，主要是返回的任务大小
- (void)connection:(NSURLConnection *)aconnection didReceiveResponse:(NSURLResponse *)response 
{
	flag=0;
	if (total==0) //保证total在有值的时候不被改变（主要用于续传的情况）
	{
		total = [response expectedContentLength];
	}
	
	// Check for bad connection
	if ([response expectedContentLength] < 0)
	{
		// 警告提示信息，由产品定义
/*		UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"无法下载任务" 
															message:@"无法正常下载任务，有可能文件已不存在，或地址错误！" 
														   delegate:nil 
												  cancelButtonTitle:@"OK" 
												  otherButtonTitles:nil];
		[alertView show];
		[alertView release];*/
		[self stopconnection];
        [delegate exception:self exception:[NSError errorWithDomain:@"error_currensize" code:DOWNLOADHANDLETYPE_CURRENTSMALLTOTAL userInfo:nil]];
		return;
	}
}


// 开始接收服务器的数据
- (void)connection:(NSURLConnection *)aconnection didReceiveData:(NSData *)data 
{
    [GDBL_NetCounter shareInstance].byte = data.length;
   
	long long disksize = [Utility getCurDiskSpaceInBytes];
	if (disksize<(long long)[data length]) 
	{
		[self stopconnection];
		[delegate exception:self exception:[NSError errorWithDomain:@"error_storage" code:DOWNLOADHANDLETYPE_NOSPACE userInfo:nil]];
		return;
	}
	current = current + (long long)[data length];
	
	if (current>total) 
	{
		[self stopconnection];
		[delegate exception:self exception:[NSError errorWithDomain:@"error_currensize" code:DOWNLOADHANDLETYPE_CURRENTLAGERTOTAL userInfo:nil]];
		return;
	}
	// 写入内容
	NSInteger dataLength;
	const uint8_t *dataBytes;
	NSInteger bytesWrittenSoFar;
	NSInteger bytesWritten;
	
	dataLength = [data length];
	dataBytes = [data bytes];
	bytesWrittenSoFar = 0;
	
	do 
	{
		bytesWritten = [fileStream write:&dataBytes[bytesWrittenSoFar] maxLength:dataLength - bytesWrittenSoFar];
		
		//assert(bytesWritten != 0);
		if (bytesWritten == 0) 
		{
			break;
		}
		
		if (bytesWritten == -1) 
		{
			break;
		}
		else 
		{
			bytesWrittenSoFar += bytesWritten;
		}
		
	} 
	while ( bytesWrittenSoFar != dataLength);	
	// 通知相应的界面做相应的进度的更新
	[delegate progress:self current:current total:total];
}


// 联网失败
- (void)connection:(NSURLConnection *)aconnection didFailWithError:(NSError *)error 
{
	[delegate exception:self exception:error];
}


// 数据接收完成
- (void)connectionDidFinishLoading:(NSURLConnection *)aconnection
{
    if (current < total)
	{
		[self stopconnection];
		[delegate exception:self exception:[NSError errorWithDomain:@"error_currensize" code:DOWNLOADHANDLETYPE_CURRENTSMALLTOTAL userInfo:nil]];
		return;
	}
	// 通知相应的界面做相应的进度的更新
	[delegate finished:self];

	NSString* destinctionPath = [DOCUMENTS_FOLDER stringByAppendingFormat:@"/%@",filename];
	[destinctionPath retain];
	if ([[NSFileManager defaultManager] fileExistsAtPath:DOCUMENTS_FOLDER]) 
	{
		if ([[NSFileManager defaultManager] fileExistsAtPath:destinctionPath])
		{// 移除之前的旧版本数据
			[[NSFileManager defaultManager] removeItemAtPath:destinctionPath error:nil];
		}
		
		// 移动文件
		NSError* err = nil;
        if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]){
		    [[NSFileManager defaultManager] moveItemAtPath:filePath toPath:destinctionPath error:&err];
        }
		
		// 停止任务，做解压的准备
		[self stopconnection];
		
		NSMutableDictionary* threadDict = [[NSThread currentThread] threadDictionary];// 线程传参
		[threadDict setValue:destinctionPath forKey:@"destinctionPath"];
		NSString  *admincode = [NSString stringWithFormat:@"%d",taskId];
		[threadDict setValue:admincode forKey:@"admincode"];
		//[NSThread detachNewThreadSelector:@selector(ZipArchive) toTarget:self withObject:nil];
		mythread = [[NSThread alloc] initWithTarget:self  selector:@selector(ZipArchive) object:nil ];
		[mythread start];//开始启动线程
	}
	
	if (destinctionPath) 
	{
		[destinctionPath release];
		destinctionPath=nil;
	}
}


// 解压线程
- (void)ZipArchive
{
	NSAutoreleasePool* pool =[[NSAutoreleasePool alloc] init];
	
	NSMutableDictionary* threadDict = [[NSThread mainThread] threadDictionary];
	NSString* destinctionPath = [[NSString alloc] initWithString:[threadDict valueForKey:@"destinctionPath"]];
	int admincode = [[threadDict valueForKey:@"admincode"] intValue];
	
	BOOL result = YES;//判断是否解压成功
    ZipArchive* za = [[ZipArchive alloc] init];
	
	
	if ([za UnzipOpenFile:destinctionPath]) 
	{
		int ret = [za getRetValue];
		if( ret!=UNZ_OK )
		{
			[za OutputErrorMessage:@"Failed"];
		}
		
		do
		{
			if([[NSThread currentThread] isCancelled])
			{
				result = NO;
                if([[NSFileManager defaultManager] fileExistsAtPath:destinctionPath])
                {
				     [[NSFileManager defaultManager] removeItemAtPath:destinctionPath error:nil];// 解压成功后删除压缩文件
                }
				[NSThread exit];//终止线程
			}
			
			long long disksize = [Utility getCurDiskSpaceInBytes];
			NSDictionary *dic = [[NSFileManager defaultManager] attributesOfItemAtPath:destinctionPath error:nil];
            unsigned long long  size = [dic fileSize];
            if (disksize < size) {
                
                [delegate exception:self exception:[NSError errorWithDomain:@"error_storage" code:DOWNLOADHANDLETYPE_NOSPACE userInfo:nil]];
                
                result = NO;
                break;
            }
			int zaResult = [za UnzipFileTo:DOCUMENTS_FOLDER overWrite:YES retValue:&ret filesize:disksize];
			if (zaResult!=2) 
			{
				if (zaResult==1) 
                {
                    [delegate exception:self exception:[NSError errorWithDomain:@"error_storage" code:DOWNLOADHANDLETYPE_NOSPACE userInfo:nil]];
				}
				else 
				{
					[delegate exception:self exception:[NSError errorWithDomain:@"error_ziparchive" code:DOWNLOADHANDLETYPE_UPZIPFAIL userInfo:nil]];
				}
                
				result = NO;
				break;
			}
		}while (ret==UNZ_OK && UNZ_OK!=UNZ_END_OF_LIST_OF_FILE) ;
		
		[za UnzipCloseFile];
	}
	[za release];
	
	if (result) 
	{
		NSError *error;
        if([[NSFileManager defaultManager] fileExistsAtPath:destinctionPath])
        {
		    [[NSFileManager defaultManager] removeItemAtPath:destinctionPath error:&error];// 解压成功后删除压缩文件
        }
		if (admincode != 0 &&[ANParamValue sharedInstance].isInit) {
			GSTATUS res = GDBL_SetAdareaDataStatus(admincode,1);
            [self performSelectorOnMainThread:@selector(DeleteRouteLine) withObject:nil waitUntilDone:NO];
		}
        if ([delegate respondsToSelector:@selector(unZipFinish:)]) {
            [delegate unZipFinish:self];
        }
    
	}
	
	[destinctionPath release];
	[NSThread exit];
	
	[pool release];
}

- (void)DeleteRouteLine
{
    if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData)
    {
        [[MWGuideOperator sharedInstance] MW_GuidanceOperateWithMainID:1 GuideHandle:NULL];
    }
}

- (void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	if (tmpPath) 
	{
		[tmpPath release];
		tmpPath = nil;
	}
	
	if (URLConnection != nil) 
	{
        @try {
            
            [URLConnection cancel];
            URLConnection = nil;
        }
        @catch (NSException *exception) {
            
        }
        
	}
	
	if (filePath != nil) 
	{
		[filePath release];
		filePath = nil;
	}
	
	if (fileStream != nil) 
	{
		[fileStream close];
		[fileStream release];
		fileStream = nil;
	}
    if (filename)
    {
        [filename release];
        filename = nil;
    }
    if (mythread)
    {
        [mythread cancel];
        mythread = nil;
    }
	[super dealloc];
}


@end

