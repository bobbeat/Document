//
//  DataList.h
//  plugin-CityDataManager
//
//  Created by mark on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Item : NSObject 
{
@public
    NSString* name;
    NSString* url;
    long long totalSize;
    int adminCode;
}

@property (nonatomic, retain) NSDictionary* nameDic;    //中，英，繁
@property (nonatomic, copy) NSString* name; 
@property (nonatomic, copy) NSString* url;
@property (nonatomic, assign) long long totalSize;
@property (nonatomic, assign) int adminCode;

@end


/*
 1、
 */
@interface DataList : NSObject
{
@protected
    // [list objectAtIndex:n]仍然是一个NSMutableArray，其值为Item对象，首个Item对象为父节点，随后的均为孩子节点
    NSMutableArray* list;
    
    // 数组值是Item对象，用于返回Item列表给客户
    NSMutableArray* tmpList;
}

// 解析数据到list成员中
-(BOOL)parse;

// 获取父列表（Item数组）
-(NSArray*)getList;

// 获取父列表中，某个索引的孩子列表（Item数组）
-(NSArray*)getList:(int)index;


@end
