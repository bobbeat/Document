//
//  plugin-cdm-XmlParser.h
//  plugin-CityDataManager
//
//  Created by GHY on 11-11-14.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Item;

@interface XmlParser : NSObject <NSXMLParserDelegate>
{
	NSMutableArray  *optiondata;//可选数据
	NSMutableArray  *founddata;//基础数据
	NSMutableArray  *cityflag;//分城市标志
	NSMutableArray  *citydata;//城市数据,一体化标志,客户端版本号标志
    
	NSMutableString *baseurl;//基地址
	NSMutableString *version;
	NSDictionary *fname;//省份名
	NSDictionary *cname;//城市名
	NSDictionary *pname;//省份名
	
	NSMutableString *currentProperty;//信息
	
	Item *city;//城市
	Item *province;//省份或直辖市
	Item *optional;
	
	Item *found;//基础数据
	Item *required;
	
	Item *infoD;//版本信息
	Item *opg;//状态信息
	Item *cityValid;//分城市标志
    Item *countryValid;//一体化标志
    Item *clientValid;//客户端标志
}

- (id)initWitharray:(NSMutableArray *)parray Withfound:(NSMutableArray *)farray WithCityFlag:(NSMutableArray *)pcityflag;
- (BOOL)parser:(NSData *)data;

@end
