//
//  DialectDownloadManage.m
//  AutoNavi
//
//  Created by longfeng.huang on 14-1-15.
//
//

#import "MWDialectDownloadManage.h"
#import "plugin-cdm-Task.h"
#import "GDStatusBarOverlay.h"
#import "SkinDownLoadViewController.h"
#import "MWPreference.h"
#import "XMLDictionary.h"
#import "GDAlertView.h"
#import "GDBL_TTS.h"

#define kDialectURL                    @"download_source/localism/?"
#define kDialectPlist                  @"/Dialect/dialectDownloadList.plist"
#define kDialectUnZipType              @".zip"

#define DialectTitle                   @"林志玲,林誌玲,Lin Chi-ling";
#define DialectState                   3
#define DialectID                      1
#define DialectVersion                 @"1.0"
#define DialectFolderName              @"XiaoYan"
#define DialectTotal                   16596117
#define DialectCurrent                 0
#define DialectRoleID                  99
#define DialectPlaySpeed               0
#define DialectBeNeedUpdate            0
#define DialectHasRecord               0
#define DialectUrl                     @""

static MWDialectDownloadManage *instance;

@implementation MWDialectDownloadManage

@synthesize dialectTaskList,serviceDialectTaskList,delegate,dialectDownloadURL,dialectMatchVersion,dialectSize,cancelDialectCheck,dialectName,dialectID,isRequest;

+ (MWDialectDownloadManage *)sharedInstance
{
    if (instance == nil) {
        instance = [[MWDialectDownloadManage alloc] init];
        [instance restore];
        [instance addLocalTaskToDialectPlist];
    }
    return instance;
}

- (id)init
{
    if (self = [super init]) {
        dialectTaskList = [[NSMutableArray alloc] init];
        serviceDialectTaskList = [[NSMutableArray alloc] init];
    }
    return self;
}

/*!
  @brief 请求皮肤下载链接
  */
- (void)RequestDialectURLWithID:(int)index requestType:(RequestType)requestType
{
    if (requestType != RT_DialectUpdate && isRequest) {
        
        [self addTaskToListWithIndex:index requestType:requestType];
        
        return;
    }
    self.dialectID = index;
    
    
	NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
    [urlParams setValue:[NSString stringWithFormat:@"%.1f",SOFTVERSIONNUM] forKey:@"client"];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain stringByAppendingString:kDialectURL];
    condition.requestType = requestType;
    condition.httpMethod = @"GET";
    condition.urlParams = urlParams;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [urlParams release];
    
}


/*!
  @brief 皮肤下载网络状态判断处理
  */
- (void)newFuntionDialectNetWorkHandle:(MWDialectDownloadTask *)sender Type:(RequestType)requestType
{
    
    int netType = NetWorkType;
    
    int taskID = 0;
    
    if (sender) {
        taskID = sender.taskId;
    }
    else{
        taskID = DialectID;
    }
    
    if (netType == 2) {
        
        if ([self isRunningWithTaskID:taskID]) {
            [self stopWithTaskID:taskID];
        }
        
        [self startWithTaskID:taskID];
        
        if (requestType == RT_DialectNewFuntionRequest) {
            
            [[MWPreference sharedInstance] setValue:PREF_AUTOSWITCHDIALECT Value:YES];
            
            NSString *title = [self getDialectTitle:sender.title];
            GDAlertView *alertView = [[GDAlertView alloc] initWithTitle:nil andMessage:[NSString stringWithFormat:STR(@"Universal_DialectDownloading",@"Localizable"),title,title] ];
            
            [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView){
                
                
            }];
            [alertView addButtonWithTitle:STR(@"Universal_DialectViewProgress", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView){
                
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_DialectViewProgredd] userInfo:nil];
            }];
            [alertView show];
            [alertView release];
        }
        
    }
    else if(netType == 1){
        
        if ([self isRunningWithTaskID:taskID]) {
            [self stopWithTaskID:taskID];
        }
        
        long long totalsize = sender.total - sender.current;
        
        NSString *title = [self getDialectTitle:sender.title];
        NSString *Unit = @"";
        float size;
        if (totalsize >= 1024*1024*1024) {
            Unit = @"GB";
            size = totalsize*1.0/1024/1024/1024;
        }
        else if(1024*1024 <= totalsize < 1024*1024*1024)
        {
            Unit = @"MB";
            size = totalsize*1.0/1024/1024;
        }
        else if(totalsize < 1024*1024){
            Unit = @"KB";
            size = totalsize*1.0/1024;
        }
        
        GDAlertView *alertView = [[GDAlertView alloc] initWithTitle:nil andMessage:[NSString stringWithFormat:STR(@"Universal_downloadDialectWithNoWIFI",@"Localizable"),title,size,Unit] ];
        
        [alertView addButtonWithTitle:STR(@"Universal_no", @"Localizable") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView){
            
           if (requestType == RT_DialectNewFuntionRequest || sender.current == 0) {
               [self removeTaskId:sender.taskId];
           }
            if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
                [delegate exception:sender exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_3GDOWNLOAD]];
            }
            
        }];
        [alertView addButtonWithTitle:STR(@"Universal_yes", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView){
        
            
            [self startWithTaskID:taskID];
            
            if (requestType == RT_DialectNewFuntionRequest) {
                
                [[MWPreference sharedInstance] setValue:PREF_AUTOSWITCHDIALECT Value:YES];
                
                GDAlertView *alertView1 = [[GDAlertView alloc] initWithTitle:nil andMessage:[NSString stringWithFormat:STR(@"Universal_DialectDownloading",@"Localizable"),title,title] ];
                
                [alertView1 addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView1){
                    
                    
                }];
                [alertView1 addButtonWithTitle:STR(@"Universal_DialectViewProgress", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView1){
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_DialectViewProgredd] userInfo:nil];
                }];
                [alertView1 show];
                [alertView1 release];
            }
            
            if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
                [delegate exception:sender exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_3GDOWNLOAD]];
            }
            
        }];
        [alertView show];
        [alertView release];
        
        
    }
    else {
        
        if ([self isRunningWithTaskID:taskID]) {
            [self stopWithTaskID:taskID];
        }
        
        if (requestType == RT_DialectNewFuntionRequest) {
            
            GDAlertView *alertView = [[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Universal_DialectWithoutNetwork",@"Localizable")];
            
            [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView){
                
            }];
            [alertView show];
            [alertView release];
        }
        else{
            if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
                [delegate exception:sender exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_NONETWORK]];//无网络连接
            }
        }
        
        
    }
}

/*!
  @brief 皮肤下载网络状态判断处理
  */
- (void)dialectNetWorkHandle:(MWDialectDownloadTask *)sender
{
    int netType = NetWorkType;
    
    int taskID = 0;
    
    if (sender) {
        taskID = sender.taskId;
    }
    else{
        taskID = DialectID;
    }
    
    if (netType == 2) {
        
        
    }
    else if(netType == 1){
        
        long long totalsize = sender.total - sender.current;
        
        NSString *title = [self getDialectTitle:sender.title];
        NSString *Unit = @"";
        float size;
        if (totalsize >= 1024*1024*1024) {
            Unit = @"GB";
            size = totalsize*1.0/1024/1024/1024;
        }
        else if(1024*1024 <= totalsize < 1024*1024*1024)
        {
            Unit = @"MB";
            size = totalsize*1.0/1024/1024;
        }
        else if(totalsize < 1024*1024){
            Unit = @"KB";
            size = totalsize*1.0/1024;
        }
        
        GDAlertView *alertView = [[GDAlertView alloc] initWithTitle:nil andMessage:[NSString stringWithFormat:STR(@"Universal_downloadDialectWithNoWIFI",@"Localizable"),title,size,Unit] ];
        
        [alertView addButtonWithTitle:STR(@"Universal_no", @"Localizable") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView){
            
            if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
                [delegate exception:sender exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_3GDOWNLOAD]];
            }
            
        }];
        [alertView addButtonWithTitle:STR(@"Universal_yes", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView){
            
            
            
            if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
                [delegate exception:sender exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_3GDOWNLOAD]];
            }
            
        }];
        [alertView show];
        [alertView release];
        
        
    }
    else {
        
            if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
                [delegate exception:sender exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_NONETWORK]];//无网络连接
            }
        
        
    }
}

/*!
  @brief 开始皮肤检测
  @return
  */
- (void)dialectCheckContinue
{
    MWDialectDownloadTask *task = [self getTaskWithTaskID:[[MWPreference sharedInstance] getValue:PREF_SKINTYPE]];
    
    if (task && task.status != TASK_STATUS_FINISH) {
        [self newFuntionDialectNetWorkHandle:task Type:RT_DialectRequest];
        return;
    }
    
    [self RequestDialectURLWithID:1 requestType:RT_DialectUpdate];
}

/*!
  @brief 开始皮肤检测
  @return
  */
- (void)dialectCheckStart
{
    
    if (0 == NetWorkType) {
        
        //[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_SkinCheckResult object:[NSNumber numberWithInt:2]];
        
    }
    else {
        
        [self dialectCheckContinue];
        
    }
}

/*!
  @brief 把默认方言下载写入plist
  @return
  */
- (void)addLocalTaskToDialectPlist
{
    if ([[NSFileManager defaultManager] fileExistsAtPath:dialectConfigDocumentPath]) {
        
        
        NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        NSString *filename = [Path stringByAppendingPathComponent:dialectConfigDocumentPath];
        NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
        if (!array || array.count == 0) {
        
            
            MWDialectDownloadTask *task = [[MWDialectDownloadTask alloc] init];
            task.url = DialectUrl;
            task.title = DialectTitle;
            task.status = DialectState;
            task.taskId = DialectID;
            task.version = DialectVersion;
            task.folderName = DialectFolderName;
            task.total = DialectTotal;
            task.current = DialectCurrent;
            task.dialectPlaySpeed = DialectPlaySpeed;
            task.dialectRoleID = DialectRoleID;
            task.beNeedUpdate = DialectBeNeedUpdate;
            task.dialectHasRecord = DialectHasRecord;
            
            [serviceDialectTaskList removeAllObjects];
            [serviceDialectTaskList addObject:task];
            
            [NSKeyedArchiver archiveRootObject:serviceDialectTaskList toFile:dialectConfigDocumentPath];
            
            [task release];
                
            
        }
        else{
            [serviceDialectTaskList removeAllObjects];
            [serviceDialectTaskList addObjectsFromArray:array];
        }
        
    }
    else
    {
        
        MWDialectDownloadTask *task = [[MWDialectDownloadTask alloc] init];
        
        task.url = DialectUrl;
        task.title = DialectTitle;
        task.status = DialectState;
        task.taskId = DialectID;
        task.version = DialectVersion;
        task.folderName = DialectFolderName;
        task.total = DialectTotal;
        task.current = DialectCurrent;
        task.dialectPlaySpeed = DialectPlaySpeed;
        task.dialectRoleID = DialectRoleID;
        task.beNeedUpdate = DialectBeNeedUpdate;
        task.dialectHasRecord = DialectHasRecord;
        
        [serviceDialectTaskList removeAllObjects];
        [serviceDialectTaskList addObject:task];
        
        [NSKeyedArchiver archiveRootObject:serviceDialectTaskList toFile:dialectConfigDocumentPath];
        
        [task release];
       
    }
    
}

/*!
  @brief 获取本地方言列表
  @return
  */
- (MWDialectDownloadTask *)getLocalDialectTask:(int)index
{
    if (index > (int)(serviceDialectTaskList.count - 1)) {
        return nil;
    }
    
    MWDialectDownloadTask *task = [serviceDialectTaskList objectAtIndex:index];
    
    if ([self _taskExisted:task]) {
        
        MWDialectDownloadTask *downTask = [self getTaskWithTaskID:task.taskId];
        if (![downTask.version isEqualToString:task.version])
        {
            downTask.beNeedUpdate = YES;
        }
        else{
            downTask.beNeedUpdate = NO;
        }
        return downTask;
        
    }
    else{
        return task;
    }

}

/*!
  @brief 获取服务器方言列表
  @return
  */
- (NSMutableArray *)getServiceDialectList
{
    NSMutableArray *dialectList = [[NSMutableArray alloc] init];
    
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:dialectConfigDocumentPath];
	
	
	
    if (array && array.count > 0) {
        
        [dialectList addObjectsFromArray:array];
        
    }
    else{
        
        MWDialectDownloadTask *task = [[MWDialectDownloadTask alloc] init];
        
        task.url = DialectUrl;
        task.title = DialectTitle;
        task.status = DialectState;
        task.taskId = DialectID;
        task.version = DialectVersion;
        task.folderName = DialectFolderName;
        task.total = DialectTotal;
        task.current = DialectCurrent;
        task.dialectPlaySpeed = DialectPlaySpeed;
        task.dialectRoleID = DialectRoleID;
        task.beNeedUpdate = DialectBeNeedUpdate;
        task.dialectHasRecord = DialectHasRecord;
        
        [dialectList addObject:task];
        
        [task release];
        
    }
    
    for (MWDialectDownloadTask *task in dialectList) {
		task.delegate = self;
	}
    
    return [dialectList autorelease];
    
}

- (MWDialectDownloadTask *)getTaskFromDictionary:(NSDictionary *)dic
{
    if (!dic) {
        return nil;
    }
    
    MWDialectDownloadTask *task = [[MWDialectDownloadTask alloc] init];
    
    task.title = [dic objectForKey:@"name"] ? [dic objectForKey:@"name"] : @"";
    task.url = [dic objectForKey:@"downloadUrl"];
    task.status = DialectState;
    task.taskId = [[dic objectForKey:@"id"] intValue];
    task.version = [dic objectForKey:@"version"];
    task.folderName = [dic objectForKey:@"folder"];
    task.total = [[dic objectForKey:@"size"] intValue];
    task.current = DialectCurrent;
    task.dialectHasRecord = [[dic objectForKey:@"has_tape"] boolValue];
    task.dialectPlaySpeed = [[dic objectForKey:@"speed"] intValue];
    task.dialectRoleID = [[dic objectForKey:@"role_id"] intValue];
    task.beNeedUpdate = NO;
    
    return [task autorelease];
}

/*!
  @brief 同步网络方言列表到本地
  @return
  */
- (BOOL)addDialectListFromNetToLocal:(NSData *)dialectData
{
    NSDictionary *dialectDic = [NSDictionary dictionaryWithXMLData:dialectData];
    
    id dialectArr = [[dialectDic objectForKey:@"localismList"] objectForKey:@"voice"];
    
    
    
    if ([dialectArr isKindOfClass:[NSDictionary class]]) {
        
        
        MWDialectDownloadTask *task = [self getTaskFromDictionary:dialectArr];
        
        if (task) {
            
            MWDialectDownloadTask *_task = [self getTaskWithTaskID:task.taskId];
            
            if (_task && ![_task.version isEqualToString:task.version])
            {
                _task.beNeedUpdate = YES;
            }
            
            [serviceDialectTaskList removeAllObjects];
            [serviceDialectTaskList addObject:task];
        }
        
        
    }
    else if ([dialectArr isKindOfClass:[NSArray class]]){
        
        [serviceDialectTaskList removeAllObjects];
        
        for (NSDictionary *dic in dialectArr) {
            
            MWDialectDownloadTask *task = [self getTaskFromDictionary:dic];
            
            if (task) {
                [serviceDialectTaskList addObject:task];
            }
        }
    }
    
    
    if ([NSKeyedArchiver archiveRootObject:serviceDialectTaskList toFile:dialectConfigDocumentPath]) {
        self.isRequest = YES;
    }
    
    
    return YES;
}

/*!
  @brief 切换语音播报
  @return
  */
- (BOOL)switchTTSPath:(int)index
{
    if (fontType == 2) {
        
        [[MWPreference sharedInstance] setValue:PREF_AUTOSWITCHDIALECT Value:NO];
        [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];
        [[MWPreference sharedInstance] setValue:PREF_IS_LZLDIALECT Value:0];
        
        [[MWPreference sharedInstance] setValue:PREF_TTSROLEINDEX Value:index];
        return YES;
    }
    
    
    if (index < (int)serviceDialectTaskList.count ) {
        
        MWDialectDownloadTask *task = [serviceDialectTaskList objectAtIndex:index];
        
        MWDialectDownloadTask *_mTask = [self getTaskWithTaskID:task.taskId];
        if (_mTask) {
            if (_mTask.status == TASK_STATUS_FINISH) {
                
                if (_mTask.beNeedUpdate) {
                    
                    isRequest = NO;
                    
                    [self RequestDialectURLWithID:index requestType:RT_DialectRequest];
                    
                    
                }
                else{
                    
                    
                    [GDBL_TTS GDBL_TTSStartUpWithResourcePath:Dialect_path];
                    [GDBL_TTS GDBL_TTSSetSpeed:_mTask.dialectPlaySpeed];
                    [GDBL_TTS GDBL_TTSSetPrompts:_mTask.dialectHasRecord];
                    [GDBL_TTS GDBL_TTSSetResourseFolderName:_mTask.folderName];
                    
                    [[MWPreference sharedInstance] setValue:PREF_TTSROLEINDEX Value:_mTask.dialectRoleID];
                    [[MWPreference sharedInstance] setValue:PREF_IS_LZLDIALECT Value:(index+1)];
                }
                
                [[MWPreference sharedInstance] setValue:PREF_AUTOSWITCHDIALECT Value:NO];
                
                
            }
            else{
                if (_mTask.status == TASK_STATUS_BLOCK || _mTask.status == TASK_STATUS_READY) {
                    [self newFuntionDialectNetWorkHandle:_mTask Type:RT_DialectRequest];
                }
                else{
                    [self stop:index];
                }
                
                return NO;
            }
        }
        else{
            
            [self RequestDialectURLWithID:index requestType:RT_DialectRequest];
            return NO;
        }
        
        
    }
    else{
        
        [[MWPreference sharedInstance] setValue:PREF_TTSROLEINDEX Value:(int)(index-serviceDialectTaskList.count)];
        [[MWPreference sharedInstance] setValue:PREF_AUTOSWITCHDIALECT Value:NO];
        [[MWPreference sharedInstance] setValue:PREF_IS_LZLDIALECT Value:0];
        [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];
        
    }
    
    return YES;
}

/*!
  @brief 自动切换语音播报
  @return
  */
- (void)autoSwitchTTSPath{
    
    MWDialectDownloadTask *task = [self getTaskWithTaskID:DialectID];
    
    //如果需要切换方言，并且当前的语音不是林志玲，并且任务已完成，没有路径则切换tts资源路径
    if (fontType != 2 && [[MWPreference sharedInstance] getValue:PREF_IS_LZLDIALECT] == 0 && [[MWPreference sharedInstance] getValue:PREF_AUTOSWITCHDIALECT] && ![ANParamValue sharedInstance].isPath && task && task.status == TASK_STATUS_FINISH) {
        
        [[MWPreference sharedInstance] setValue:PREF_AUTOSWITCHDIALECT Value:NO];
        
        [GDBL_TTS GDBL_TTSStartUpWithResourcePath:Dialect_path];//语音库初始化
        [GDBL_TTS GDBL_TTSChangeRole:task.dialectRoleID];
        [GDBL_TTS GDBL_TTSSetSpeed:task.dialectPlaySpeed];
        [GDBL_TTS GDBL_TTSSetPrompts:task.dialectHasRecord];
        [GDBL_TTS GDBL_TTSSetResourseFolderName:task.folderName];
        [[MWPreference sharedInstance] setValue:PREF_IS_LZLDIALECT Value:1];
    }
    
}

/*!
  @brief 把skinTaskList中的所有任务信息保存到文件系统，一般是在退出程序时调用
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)Servicestore
{
    /*
     1、序列化整个skinTaskList
     */
    
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:dialectConfigDocumentPath];
	if (![NSKeyedArchiver archiveRootObject:serviceDialectTaskList toFile:filename]){
		return NO;
	}
	else {
		return YES;
	}
    
}

/*!
  @brief 把skinTaskList中的所有任务信息保存到文件系统，一般是在退出程序时调用
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)store
{
    /*
     1、序列化整个skinTaskList
     */
    
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:kDialectPlist];
	if (![NSKeyedArchiver archiveRootObject:dialectTaskList toFile:filename]){
		return NO;
	}
	else {
		return YES;
	}
    
}

/*!
  @brief 从文件系统还原通过save保存的所有任务信息，一般是在进入程序时调用，该方法调用将把skinTaskList中的所有任务更新为最后一次调用save保存的任务
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)restore
{
    /*
     1、反序列化各个Task对象，构建处skinTaskList
     2、遍历skinTaskList，把task.delegate = self;
     */
	
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:kDialectPlist];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	[dialectTaskList removeAllObjects];
	[dialectTaskList addObjectsFromArray:array];
	
    for (MWDialectDownloadTask *task in dialectTaskList) {
        
        if (task.status == TASK_STATUS_RUNNING) {//如果上次退出时是运行状态，恢复的时候置为暂停
            task.status = TASK_STATUS_BLOCK;
        }
		task.delegate = self;
	}
    
    [self unZipFileInPath:Dialect_path MatchContent:kDialectUnZipType];
	return YES;
	
}

/*!
  @brief 获取方言名称
  */
- (NSString *)getDialectTitle:(NSString *)arrayString
{
    NSArray *stringArray = [arrayString componentsSeparatedByString:@","];
    NSString *returnTitle = @"";
    if(stringArray.count >= 3)
    {
        returnTitle = [stringArray objectAtIndex:fontType];
    }
    return returnTitle;
}

#pragma mark - 下载管理

/*!
  @brief 将任务添加到任务列表中
  */
-(BOOL)addTaskToListWithIndex:(int)index requestType:(RequestType)type
{
    
    if (!serviceDialectTaskList || index > (int)(serviceDialectTaskList.count -1) || index < 0) {
        
        return NO;
    }
    
    MWDialectDownloadTask *dialectTask = [serviceDialectTaskList objectAtIndex:index];
    
    MWDialectDownloadTask *tmpTask = [[[MWDialectDownloadTask alloc] init] autorelease];
    tmpTask.url = dialectTask.url;
    tmpTask.status = dialectTask.status;
    tmpTask.current = dialectTask.current;
    tmpTask.total = dialectTask.total;
    tmpTask.dialectHasRecord = dialectTask.dialectHasRecord;
    tmpTask.dialectPlaySpeed = dialectTask.dialectPlaySpeed;
    tmpTask.title = dialectTask.title;
    tmpTask.beNeedUpdate = dialectTask.beNeedUpdate;
    tmpTask.folderName = dialectTask.folderName;
    tmpTask.dialectRoleID = dialectTask.dialectRoleID;
    tmpTask.taskId = dialectTask.taskId;
    tmpTask.version = dialectTask.version;
    
        
    int _index = [self addTask:tmpTask atFirst:NO];
    
    if (_index >= 0) {
        
        MWDialectDownloadTask *task = [dialectTaskList objectAtIndex:_index];
        
        [self newFuntionDialectNetWorkHandle:task Type:type];
        return YES;
    }
    
    
    [self store];
    
    
    return NO;
}

/*!
  @brief 添加任务到任务队列
  @return 返回-1表示加入失败，>=0表示成功加入后在skinTaskList中的索引
  */
-(int)addTask:(MWDialectDownloadTask*) task atFirst:(BOOL) first
{
    if(NO==[self _taskExisted:task])
    {
        task.delegate = self;
        task.status = TASK_STATUS_BLOCK;
        if(first)
        {
            [dialectTaskList insertObject:task atIndex:0];
            return 0;
        }
        else
        {
            [dialectTaskList addObject:task];
            return [dialectTaskList count]-1;
        }
    }
    else
    {
        [self removeTaskId:task.taskId];
        
        task.delegate = self;
        task.status = TASK_STATUS_BLOCK;
        
        [dialectTaskList addObject:task];
        
        return [dialectTaskList count]-1;
    }
}

/*!
  @brief 将本地存在的地图数据添加到下载队列中，并把状态置为完成
  @return 返回相对应的索引
  */
-(int)addLocalTask:(MWDialectDownloadTask*)task atFirst:(BOOL) first
{
    if(NO==[self _taskExisted:task])//任务列表中无，则添加
    {
        task.delegate = self;
        task.status = TASK_STATUS_FINISH;
        if(first)
        {
            [dialectTaskList insertObject:task atIndex:0];
            return 0;
        }
        else
        {
            [dialectTaskList addObject:task];
            return [dialectTaskList count]-1;
        }
    }
    else if(YES==[self _taskExisted:task] )
    {
        for (MWDialectDownloadTask *t in dialectTaskList)
        {
            if (t.taskId == task.taskId)
            {
                if (t.status != TASK_STATUS_FINISH)//若用户拖入完整的城市数据，则删除对应未下载完成的文件
                {
                    NSString *stringt = @"/";
                    NSRange range = [t.url rangeOfString:stringt options:NSBackwardsSearch];
                    if (range.length != 0)
                    {
                        NSString *name = [t.url substringFromIndex:range.location+1];
                        //   NSString *name = [NSString stringWithFormat:@"%@",[t.url CutFromNSString:@"cityupdatedata/"]];
                        NSFileManager *fileManager = [NSFileManager defaultManager];
                        NSArray *paths;
                        NSError *error;
                        NSString *documentsDirectory;
                        paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                        documentsDirectory = [[NSString alloc] initWithFormat:@"%@", [paths objectAtIndex:0]];
                        NSString *filePath = [NSString stringWithFormat:@"%@/%@.tmp",documentsDirectory,name];
                        [documentsDirectory release];
                        if([fileManager fileExistsAtPath:filePath])
                        {
                            [[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
                            
                        }
                    }
                }
                t.status = TASK_STATUS_FINISH;
            }
	    }
        return 0;
    }
	else
    {
		return -1;
	}
    
}

/*!
  @brief TaskManager可能处于两种状态：1、无任何任务在执行：TaskManager按某种策略选择一个任务来执行 2、有任务在执行：直接返回
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)start
{
    if([self isRunning])
    {
        return NO;
    }
    else
    {
        int index = [self _selectOneTaskToRun];
        if(index<0)
        {
            return NO;
        }
        else
        {
            return [self start:index];
        }
    }
}

/*!
  @brief  任务可能处于两种状态：
 1、无任何任务在执行：TaskManager按index来选择任务
 2、有任务在执行：
 1.1、正在执行的任务就是index，那么直接返回；
 2.1、正在执行的任务不是index，那么让正在执行的任务变为等待，转而执行index指定的任务
  @param  index 要下载的索引值
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)start:(int)index
{
    int indexRunning = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (indexRunning == index || index > (int)(dialectTaskList.count -1)) {
        return NO;
    }
    else
    {
        // 先停止正在执行的任务
        if (indexRunning >= 0)
        {
            
            MWDialectDownloadTask* t = [dialectTaskList objectAtIndex:index];
            t.status = TASK_STATUS_READY;
            return YES;
            
        }
        
        
        MWDialectDownloadTask* t = [dialectTaskList objectAtIndex:index];
        t.status = TASK_STATUS_RUNNING;
        [t run];
        
        return YES;
    }
}

/*!
  @brief 下载指定id的任务
  @return
  */
- (void)startWithTaskID:(int)taskID
{
    
    for (int i = 0; i < dialectTaskList.count; i++) {
        MWDialectDownloadTask *tmp = [dialectTaskList objectAtIndex:i];
        if (tmp.taskId == taskID) {
            [self start:i];
            return;
        }
    }
}

/*!
  @brief 停止TaskManager中正在执行的任务，整个TaskManager处于停止状态
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)stop
{
    
    int index = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (index>=0) {
        return [self stop:index];
    }
    return NO;
}

/*!
  @brief 停止TaskManager中index对应的任务：注意：只有状态为TASK_STATUS_RUNNING的任务才能被stop
  @param index对应的任务处于等待状态，那么直接返回，对应的任务处于执行状态，那么让正在执行的任务变为等待
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)stop:(int)index
{
    int count = [dialectTaskList count];
    if(index>=0 && index<count)
    {
        // 只有状态为TASK_STATUS_RUNNING的任务才能被stop
        MWDialectDownloadTask* t = [dialectTaskList objectAtIndex:index];
        if(t.status==TASK_STATUS_RUNNING || t.status==TASK_STATUS_READY)
        {
            t.status = TASK_STATUS_BLOCK;
            [t stop];
            
            [self start];
            return YES;
        }
    }
    return NO;
}

/*!
  @brief 停止TaskManager中taskID对应的任务：注意：只有状态为TASK_STATUS_RUNNING的任务才能被stop
  @param taskID对应的任务处于等待状态，那么直接返回，对应的任务处于执行状态，那么让正在执行的任务变为等待
  @return 成功返回 YES 失败返回 NO
  */
- (BOOL)stopWithTaskID:(int)taskID
{
    BOOL res = NO;
    
    for (int i = 0; i < dialectTaskList.count; i++) {
        MWDialectDownloadTask *tmp = [dialectTaskList objectAtIndex:i];
        if (tmp.taskId == taskID) {
            res = [self stop:i];
        }
    }
    
    return res;
}

/*!
  @brief 只暂停指定索引的任务，不自动下载等待的任务
  @param index 任务索引
  @return 成功返回 YES 失败返回 NO
  */
- (BOOL)stopCurrent:(int)index
{
    int count = [dialectTaskList count];
    if(index>=0 && index<count)
    {
        
        Task* t = [dialectTaskList objectAtIndex:index];
        if(t.status==TASK_STATUS_RUNNING)
        {
            
            t.status = TASK_STATUS_BLOCK;
            [t stop];
            
            return YES;
        }
    }
    return NO;
}

/*!
  @brief 只暂停指定索引的任务，不自动下载等待的任务
  @param taskID 任务id
  @return 成功返回 YES 失败返回 NO
  */
- (BOOL)stopWithOutOtherStartWithTaskID:(int)taskID
{
    int count = [dialectTaskList count];
    
    for (int i = 0; i < count ; i++ ) {
        
        MWDialectDownloadTask* t = [dialectTaskList objectAtIndex:i];
        if(t.taskId == taskID)
        {
            
            t.status = TASK_STATUS_BLOCK;
            [t stop];
            
            return YES;
        }
    }
    
    return NO;
}

/*!
  @brief 暂停所有的任务
  */
- (void)stopAllTask
{
    for (MWDialectDownloadTask *task in dialectTaskList) {
        if (task.status == TASK_STATUS_RUNNING || task.status == TASK_STATUS_READY) {
            task.status = TASK_STATUS_BLOCK;
        }
    }
}

/*!
  @brief  返回YES表示TaskManager中有任务正在运行
  @return 有任务在运行返回 YES 没有返回 NO
  */
-(BOOL)isRunning
{
    return [self _firstIndexWithStatus:TASK_STATUS_RUNNING]<0?NO:YES;
}

/*!
  @brief  返回YES表示TaskManager中对应的taskID任务正在运行
  @return 有任务在运行返回 YES 没有返回 NO
  */
- (BOOL)isRunningWithTaskID:(int)taskID
{
    BOOL res = NO;
    
    MWDialectDownloadTask *task = [self getTaskWithTaskID:taskID];
    
    if (task && task.status == TASK_STATUS_RUNNING) {
        
        res = YES;
    }
    
    return res;
}

/*!
  @brief 通过taskid获取任务
  @param taskID 任务ID
  @return 返回对应的任务
  */
- (MWDialectDownloadTask *)getTaskWithTaskID:(int)taskID
{
    for (MWDialectDownloadTask *temp in dialectTaskList) {
        if (temp.taskId == taskID) {
            
            return temp;
        }
        
    }
    return nil;
}

/*!
  @brief 移除索引为index处的任务，该操作会删除该任务。如果恰好该任务处于运行状态，removeTask后，整个TaskManager中将无任务在执行
  @param index 任务索引
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)removeTask:(int) index
{
    int count = [dialectTaskList count];
    if(index>=0 && index < count)
    {
        MWDialectDownloadTask* t = [dialectTaskList objectAtIndex:index];
        [t erase];
        [dialectTaskList removeObjectAtIndex:index];
        return  YES;
    }
    return NO;
}

/*!
  @brief 移除索引为index处的任务，该操作会删除该任务。如果恰好该任务处于运行状态，removeTaskId后，整个TaskManager中将无任务在执行
  @param taskId 任务ID
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)removeTaskId:(long) taskId
{
    int count = [dialectTaskList count];
	for (int i = 0; i < count; i++)
	{
        MWDialectDownloadTask* t = [dialectTaskList objectAtIndex:i];
		if (taskId == t.taskId) {
			if (taskId == 0) {
				[t erase];
				[dialectTaskList removeAllObjects];
			}
			else {
				[t erase];
				[dialectTaskList removeObjectAtIndex:i];
			}
			return YES;
		}
	}
    return NO;
}

/*!
  @brief  删除某一状态的任务
  @return 返回删除个数
  */
-(int)removeTasksForStatus:(int) status
{
    
    int count = 0;
    while (1) {
        int index = [self _firstIndexWithStatus:status];
        if(index>=0)
        {
            [self removeTask:index];
            ++count;
        }
        else
        {
            break;
        }
    }
    return count;
}

/*!
  @brief  从头开始向尾扫描mTaskList列表，直到遇到一个状态为TASK_STATUS_READY的任务对象
  @return 返回指<0则表示没找到可被执行的任务，否则表示所选任务的索引
  */
-(int)_selectOneTaskToRun
{
    return [self _firstIndexWithStatus:TASK_STATUS_READY];
}

/*!
  @brief 返回队列中，状态为status的第一个任务的索引
  @param status 任务状态
  @return 返回指<0则表示没找到可被执行的任务，否则表示任务的索引
  */
-(int)_firstIndexWithStatus:(int)status
{
    int count = [dialectTaskList count];
    for (int i=0;i<count;i++) {
        if(((MWDialectDownloadTask*)[dialectTaskList objectAtIndex:i]).status == status)
        {
            return i;
        }
    }
    return -1;
}

/*!
  @brief 根据taskId来判断task是否已经存在队列中
  @param task 任务对象
  @return 成功返回 YES 失败返回 NO
  */
-(BOOL)_taskExisted:(MWDialectDownloadTask*)task
{
    for (MWDialectDownloadTask* t in dialectTaskList) {
        // 用任务id来比较
        if(t.taskId == task.taskId)
        {
            return YES;
        }
    }
    return NO;
}


/*!
  @brief 获取任务列表中所有任务需要的空间大小
  @return 所需空间大小
  */
-(long long)getNeedSize
{
	long long size;
	size = 0;
    
	int count = [dialectTaskList count];
    for (int i=0;i<count;i++) {
        MWDialectDownloadTask* t = [dialectTaskList objectAtIndex:i];
        if(t.status == TASK_STATUS_READY || t.status == TASK_STATUS_RUNNING)
        {
            size += (t.total - t.current);
        }
    }
    return size;
}

/**
 *解压目录下所有文件
 *rootPath:要解压的路径名称(尾部无需/),matchName:要匹配的结尾名称,nil或""则不验证匹配
 */
-(BOOL) unZipFileInPath:(NSString *)rootPath MatchContent:(NSString*)matchName
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (fileManager==nil)
	{
        return nil;
    }
	//	NSLog(@"search files in path:%@,match text:%@",rootPath,matchName);
	NSError *error = nil;
	
	//fileList便是包含有该文件夹下所有文件的文件名及文件夹名的数组
	NSArray* fileList = [[NSArray alloc]initWithArray:[fileManager contentsOfDirectoryAtPath:rootPath error:&error]] ;
    
    //以下这段代码则可以列出给定一个文件夹里的所有子文件夹名
	NSMutableArray *fileArray = [[[NSMutableArray alloc] init] autorelease];
	signed char isDir = NO;
	//在上面那段程序中获得的fileList中列出文件名
	for (NSString *file in fileList)
	{
		NSString *path = [rootPath stringByAppendingPathComponent:file];
		[fileManager fileExistsAtPath:path isDirectory:(&isDir)];
		if (isDir)
		{
			//[dirArray addObject:file];文件夹
		}
		else
		{
			//			[dirArray addObject:[file stringByDeletingPathExtension]];//去除扩展名，文件
            if (matchName!=nil&&[matchName length]>0)
            {
                //匹配文件名结尾的字符
                if ([file hasSuffix:matchName]==YES)
                {
                    [fileArray addObject:path];
                }
            }
		}
        
		isDir = NO;
	}
	[fileList release];
    
    if (fileArray.count > 0) {
        for ( NSString *fileName in fileArray) {
            for (MWDialectDownloadTask *task in dialectTaskList) {
                if ([fileName hasSuffix:[task getFilename]]) {
                    [task checkZipFileAndUnZipFile];
                    return YES;
                }
            }
        }
        
    }
    return NO;
}


#pragma mark - 下载委托回调

-(void)progress:(MWDialectDownloadTask*)sender current:(long long)current total:(long long)total
{
    NSLog(@"%lld,%lld",current,total);
    
    if (delegate && [delegate respondsToSelector:@selector(progress:current:total:)]) {
        [delegate progress:sender current:current total:total];
    }
    
	
}

-(void)finished:(MWDialectDownloadTask*)sender
{
	sender.status = TASK_STATUS_FINISH;
    
    [self start];
    
    if (delegate && [delegate respondsToSelector:@selector(finished:)]) {
        [delegate finished:sender];
    }
}

-(void)exception:(MWDialectDownloadTask*)sender exception:(id)exception
{
    
    int exceptionCode = ((NSError *)exception).code;
    
    if (exceptionCode == DOWNLOADHANDLETYPE_UPZIPFAIL) {//解压失败，删除数据，重新下载
        
        //[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_SkinCheckResult object:[NSNumber numberWithInt:5]];
        
        [self removeTaskId:sender.taskId];
        
    }
    else if( exceptionCode == DOWNLOADHANDLETYPE_CURRENTLAGERTOTAL || exceptionCode == DOWNLOADHANDLETYPE_UPZIPFAIL || exceptionCode == DOWNLOADHANDLETYPE_CURRENTSMALLTOTAL  ){//下载失败
       // [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_SkinCheckResult object:[NSNumber numberWithInt:4]];
        isRequest = NO;
        [self removeTaskId:sender.taskId];
        
        if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
            [delegate exception:sender exception:[NSNumber numberWithInt:exceptionCode]];
        }
    }
    
    else {
        [self newFuntionDialectNetWorkHandle:sender Type:RT_DialectRequest];
        
    }
    
    [self store];
    
}

- (void)unZipFinish:(MWDialectDownloadTask*)sender
{
    [self autoSwitchTTSPath];
    
    if (delegate && [delegate respondsToSelector:@selector(unZipFinish:)]) {
        [delegate unZipFinish:sender];
    }
    else if ([ANParamValue sharedInstance].isInit){
        
    }
    
    
    [self store];
    
}

#pragma mark - url请求回调
//服务器成功应答
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data
{
    
    if (data && [data length])
    {
        char *szResult = (char *)[data bytes];
        
        NSString *tmp = [NSString stringWithFormat:@"%s",szResult];
        
        NSLog(@"方言请求结果：%@",tmp);
        
        NSDictionary *dialectDic = [NSDictionary dictionaryWithXMLData:data];
        
        NSString *result = [dialectDic objectForKey:@"Result"];
        
        if ([result isEqualToString:@"SUCCESS"]) {//皮肤与当前软件版本匹配
            
            
            [self addDialectListFromNetToLocal:data];
            
            if (request.requestCondition.requestType == RT_DialectUpdate) {
                //更新
                
            }
            else {
                double delayInSeconds = 0.2;
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    
                    if (![self addTaskToListWithIndex:self.dialectID requestType:request.requestCondition.requestType]) {
                        if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
                            [delegate exception:nil exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_URLREQUESTFAIL]];//url请求失败
                        }
                    }
                    
                });
            }
            
            
            
        }
        else if ([result isEqualToString:@"FAIL"])
        {
            if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
                [delegate exception:nil exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_URLREQUESTFAIL]];//url请求失败
            }
        }
        
    }
    else{
        
        
        if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
            [delegate exception:nil exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_URLREQUESTFAIL]];//url请求失败
        }
    }
}

- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error
{
    
	if (delegate && [delegate respondsToSelector:@selector(exception:exception:)]) {
        [delegate exception:nil exception:[NSNumber numberWithInt:DOWNLOADHANDLETYPE_URLREQUESTFAIL]];//url请求失败
    }
    else if (request.requestCondition.requestType == RT_DialectNewFuntionRequest){
        
        GDAlertView *alertView = [[[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Universal_DialectWithoutNetwork",@"Localizable")] autorelease];
        
        [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView){
            
        }];
        [alertView show];
    }
    
}
@end
