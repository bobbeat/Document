//
//  MWSkinDownloadTask.h
//  AutoNavi
//
//  Created by huang longfeng on 13-11-19.
//
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-DownloadTask.h"

@interface MWSkinDownloadTask : DownloadTask

- (void)checkZipFileAndUnZipFile;

@end
