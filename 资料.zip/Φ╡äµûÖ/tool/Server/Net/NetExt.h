//
//  NetExt.h
//  AutoNavi
//
//  Created by yu.liao on 13-5-14.
//
//

#import <Foundation/Foundation.h>
#import "NetRequestExt.h"
#import "NetConstant.h"
#import "NetOperation.h"
#import "NetBaseRequestCondition.h"

@protocol NetRequestExtDelegate;
@protocol NetSynRequestExtDelegate;

@interface NetExt : NSObject
{
    NSMutableSet *requests;
    NSOperationQueue *m_operationQueue;
}

+ (NetExt *)sharedInstance;

- (NetRequestExt *)requestWithCondition:(NetBaseRequestCondition *)condition delegate:(id<NetRequestExtDelegate>)delegate;

//取消对应类型的请求
- (BOOL)Net_CancelRequestWithType:(RequestType)requestType;
//取消所有的请求
- (BOOL)cancelAllRequests;
//字典转化为json数据,ImageEncode为图片编码方式
- (NSData *)DictionaryToJSON:(NSMutableDictionary *)dictionary ImageEncode:(ImageEncode)imageEncode;
//
//图片或者数据的组装
- (NSMutableData *)postBodyData:(NSMutableDictionary *)dictionary;

/*
    同步网络请求
 
    url:请求的url地址
    tag:标识
    params:参数
    httpMethod:请求方式
    bodyData:http的body
    delegate ： 同步请求回调  具体请查看 NetSynRequestExtDelegate
 */
- (NetOperation *)synRequestWithCondition:(NetBaseRequestCondition *)condition delegate:(id<NetSynRequestExtDelegate>)delegate;

//取消对应类型的同步请求
- (BOOL)cancelOperationWithType:(RequestType)requestType;
//取消所有的同步请求
- (BOOL)cancelAllOperation;

@end
