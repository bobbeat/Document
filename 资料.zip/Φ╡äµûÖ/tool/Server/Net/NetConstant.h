//
//  NetConstant.h
//  AutoNavi
//
//  Created by yu.liao on 13-5-14.
//
//

#ifndef AutoNavi_NetConstant_h
#define AutoNavi_NetConstant_h

//#define kNetDomain                       @"http://iphone.autonavi.com/"
#define kNetDomain                       @"http://210.13.211.107:8081/"
//#define kNetDomain1                      @"http://website.autonavi.com/"
#define kNetDomain1                      @"http://210.13.211.107:8081/"
#define kNetRequestStringBoundary        @"---------------------------1709113562ap036"      //分隔符
#define KNetResponseErrorDomain          @"NetResponseErrorDomain"                          //服务器返回内容异常

#define KNetChannelID @"41001"   //业务系统账号
#define kNetSignKey @"370060C88A374151A175AB60C5FCA7C5"  //md5值计算 String sign = MD5.md5s(syscode+parameter+"@"+key).toUpperCase（）

#define kNetHelpUrl        @"annex/iphonepage/help/menu.html"                               //8.0版本的使用帮助链接 简体
#define kNetHelpUrl_TW     @"annex/iphonepage/help_tw/menu.html"                            //8.0版本的使用帮助链接 繁体
#define kNetHelpUrl_EN     @"annex/iphonepage/help_en/menu.html"                            //8.0版本的使用帮助链接 英文


#endif
