//
//  NetRequestExtDelegate.h
//  AutoNavi
//
//  Created by yu.liao on 13-5-14.
//
//

#import <Foundation/Foundation.h>
#import "NetRequestExt.h"
#import "NetOperation.h"
@protocol NetRequestExtDelegate <NSObject>

//当error的成员变量domain值为KNetResponseErrorDomain时，如果终端需要提示，需提示"服务器返回内容异常，HTTP error" 其中HTTP error后面要跟error的成员变量code
- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error;
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data;

@end


@protocol NetSynRequestExtDelegate <NSObject>

//同步请求回调，
- (void)synRequest:(NetOperation *)operation didFailWithError:(NSError *)error;
- (void)synRequest:(NetOperation *)operation didFinishLoadingWithData:(NSData *)data;

@end