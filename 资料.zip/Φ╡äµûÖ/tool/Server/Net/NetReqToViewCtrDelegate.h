//
//  NetReqToViewCtrDelegate.h
//  AutoNavi
//
//  Created by yu.liao on 13-5-14.
//
//

#import <Foundation/Foundation.h>

@protocol NetReqToViewCtrDelegate <NSObject>

- (void)requestToViewCtrWithRequestType:(RequestType)requestType didFinishLoadingWithResult:(id)result;//id类型可以是NSDictionary NSArray
- (void)requestToViewCtrWithRequestType:(RequestType)requestType didFailWithError:(NSError *)error;//上层需根据error的值来判断网络连接超时还是网络连接错误

@end
