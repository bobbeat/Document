//
//  GDBL_UserBehaviorCountNew.h
//  AutoNavi
//
//  Created by jiangshu.fu on 13-5-27.
//
//

#import <Foundation/Foundation.h>


@interface GDBL_UserBehaviorCountNew : NSObject
{
}

+(GDBL_UserBehaviorCountNew *) shareInstance;

#pragma mark ---  各种变量  ---
//有InPath——在导航中  没有添加后最说明不再导航中
//门址搜索
@property(nonatomic) int addressSearch_InPath;
@property(nonatomic) int addressSearch;
//交叉路口搜索
@property(nonatomic) int crossSearch_InPath;
@property(nonatomic) int crossSearch;
//默认排序
@property(nonatomic) int defaultSort_InPath;
@property(nonatomic) int defaultSort;
//距离排序
@property(nonatomic) int distanceSort_InPath;
@property(nonatomic) int distanceSort;
//区域选择
@property(nonatomic) int regionSelect_InPath;
@property(nonatomic) int regionSelect;
//语音搜索
@property(nonatomic) int voiceSearchGoWhere_InPath;
@property(nonatomic) int voiceSearchGoWhere;
//沿光标搜索
@property(nonatomic) int alongCursorSearch_InPath;
@property(nonatomic) int alongCursorSearch;
//沿路径搜索
@property(nonatomic) int alongPathSearch_InPath;
@property(nonatomic) int alongPathSearch;
//沿目的地搜索
@property(nonatomic) int alongDestinationsearch_InPath;
@property(nonatomic) int alongDestinationsearch;
//类型（加油站）
@property(nonatomic,retain) NSMutableArray *stationType_InPath;
@property(nonatomic,retain) NSMutableArray *stationType;
//类型（停车场）
@property(nonatomic) int parkingType_InPath;
@property(nonatomic) int parkingType;
//类型（商务休闲）
@property(nonatomic,retain) NSMutableArray *businessCasualType_InPath;
@property(nonatomic,retain) NSMutableArray *businessCasualType;
//类型（餐饮美食）
@property(nonatomic,retain) NSMutableArray *foodDrinkType_InPath;
@property(nonatomic,retain) NSMutableArray *foodDrinkType;
//类型（酒店住宿）
@property(nonatomic,retain) NSMutableArray *hotelType_InPath;
@property(nonatomic,retain) NSMutableArray *hotelType;
//类型（商场购物）
@property(nonatomic,retain) NSMutableArray *shoppingType_InPath;
@property(nonatomic,retain) NSMutableArray *shoppingType;
//类型（风景名胜）
@property(nonatomic,retain) NSMutableArray *sightsType_InPath;
@property(nonatomic,retain) NSMutableArray *sightsType;
//类型（交通服务）
@property(nonatomic,retain) NSMutableArray *transportServicesType_InPath;
@property(nonatomic,retain) NSMutableArray *transportServicesType;
//类型（金融保险）
@property(nonatomic,retain) NSMutableArray *financeType_InPath;
@property(nonatomic,retain) NSMutableArray *financeType;
//类型（大厦楼宇）（次数）
@property(nonatomic) int buildingType_InPath;
@property(nonatomic) int buildingType;
//类型（休闲娱乐）
@property(nonatomic,retain) NSMutableArray *recreationType_InPath;
@property(nonatomic,retain) NSMutableArray *recreationType;
//类型（公司企业）
@property(nonatomic) int CorporateType_InPath;
@property(nonatomic) int CorporateType;
//类型（汽车服务）
@property(nonatomic,retain) NSMutableArray *carServiceType_InPath;
@property(nonatomic,retain) NSMutableArray *carServiceType;
//类型（体育运动）
@property(nonatomic,retain) NSMutableArray *sportsType_InPath;
@property(nonatomic,retain) NSMutableArray *sportsType;
//类型（生活服务）
@property(nonatomic,retain) NSMutableArray *livingServiceType_InPath;
@property(nonatomic,retain) NSMutableArray *livingServiceType;
//类型（科教文化）
@property(nonatomic,retain) NSMutableArray *educationType_InPath;
@property(nonatomic,retain) NSMutableArray *educationType;
//类型（医院药房）
@property(nonatomic,retain) NSMutableArray *hospitalType_InPath;
@property(nonatomic,retain) NSMutableArray *hospitalType;
//类型（住宅小区）
@property(nonatomic) int residentialAreaType_InPath;
@property(nonatomic) int residentialAreaType;
//类型（政府机关）
@property(nonatomic,retain) NSMutableArray *governmentType_InPath;
@property(nonatomic,retain) NSMutableArray *governmentType;
//类型（城市地名）
@property(nonatomic) int cityType_InPath;
@property(nonatomic) int cityType;
//详情设终点
@property(nonatomic) int detailSetEnd_InPath;
@property(nonatomic) int detailSetEnd;
//地图查看POI位置设终点
@property(nonatomic) int viewPOISetEnd_InPath;
@property(nonatomic) int viewPOISetEnd;
//详情设起点
@property(nonatomic) int detailSetStart_InPath;
@property(nonatomic) int detailSetStart;
//地图查看POI位置设起点
@property(nonatomic) int viewPOISetStart_InPath;
@property(nonatomic) int viewPOISetStart;
//移图设起点
@property(nonatomic) int figureMapSetSatar_InPath;
@property(nonatomic) int figureMapSetSatar;
//地图查看POI位置设途经点
@property(nonatomic) int viewPOISetWaypoint_InPath;
@property(nonatomic) int viewPOISetWaypoint;
//移图设途经点
@property(nonatomic) int figureSetWaypoint_InPath;
@property(nonatomic) int figureSetWaypoint;
//路线详情（路线管理）
@property(nonatomic) int managePathDetail_InPath;
@property(nonatomic) int managePathDetail;
//停止导航（转向箭头）
@property(nonatomic) int stopNaviByTurnArrow_InPath;
@property(nonatomic) int stopNaviByTurnArrow;
//停止导航（路线管理）
@property(nonatomic) int stopNaviByManage_InPath;
@property(nonatomic) int stopNaviByManage;
//模拟导航（概览图）
@property(nonatomic) int simulatedNaviByOverview_InPath;
@property(nonatomic) int simulatedNaviByOverview;
//模拟导航（路线管理）
@property(nonatomic) int simulatedNaviByManage_InPath;
@property(nonatomic) int simulatedNaviByManage;
//规划原则（路线管理）
@property(nonatomic) int planningByManage_InPath;
@property(nonatomic) int planningByManage;
//概览图（路线管理）
@property(nonatomic) int overviewByManage_InPath;
@property(nonatomic) int overviewByManage;
//推荐路线
@property(nonatomic) int suggestedLtineraries_InPath;
@property(nonatomic) int suggestedLtineraries;
//高速优先
@property(nonatomic) int highPriority_InPath;
@property(nonatomic) int highPriority;
//经济路线
@property(nonatomic) int economicRoute_InPath;
@property(nonatomic) int economicRoute;
//最短路线
@property(nonatomic) int shortestRoute_InPath;
@property(nonatomic) int shortestRoute;
//路线对比
@property(nonatomic) int directionsContrast_InPath;
@property(nonatomic) int directionsContrast;
//概览图查看全图按钮
@property(nonatomic) int overviewViewFull_InPath;
@property(nonatomic) int overviewViewFull;
//查看行车电脑
@property(nonatomic) int viewTripComputer_InPath;
@property(nonatomic) int viewTripComputer;
//放大（按钮操作）
@property(nonatomic) int enlargeByButton_InPath;
@property(nonatomic) int enlargeByButton;
//缩小（按钮操作）
@property(nonatomic) int narrowByButton_InPath;
@property(nonatomic) int narrowByButton;
//放大（单指双击）
@property(nonatomic) int enlargeByDoubleClick_InPath;
@property(nonatomic) int enlargeByDoubleClick;
//缩小（双指单击）
@property(nonatomic) int narrowByTwoFingerClick_InPath;
@property(nonatomic) int narrowByTwoFingerClick;
//放大（双指放开）
@property(nonatomic) int enlargeByPinOpen_InPath;
@property(nonatomic) int enlargeByPinOpen;
//缩小（双指捏合）
@property(nonatomic) int narrowByPinKneading_InPath;
@property(nonatomic) int narrowByPinKneading;
//收藏当前点
@property(nonatomic) int favoriteCurrentPoint_InPath;
@property(nonatomic) int favoriteCurrentPoint;
//消息盒子
@property(nonatomic) int messageBox_InPath;
@property(nonatomic) int messageBox;
//路线管理
@property(nonatomic) int pathManage_InPath;
@property(nonatomic) int pathManage;
//主辅路切换
@property(nonatomic) int switchMainAndSideRoads_InPath;
@property(nonatomic) int switchMainAndSideRoads;
//交通事件
@property(nonatomic) int trafficIncident_InPath;
@property(nonatomic) int trafficIncident;
//问题反馈
@property(nonatomic) int feedback_InPath;
@property(nonatomic) int feedback;
//交通事件显示
@property(nonatomic) int trafficEventDisplay_InPath;
@property(nonatomic) int trafficEventDisplay;

//字体大小 //在需要上传的时候，直接上传字体大小就OK了 。

//网络导航
//---  次数  ---
@property(nonatomic) int networkNavi_InPath;
@property(nonatomic) int networkNavi;
//---  时长  ---
@property(nonatomic) int networkNaviSeconds_InPath;
@property(nonatomic) int networkNaviSeconds;

//CPC导航
//---  次数  ---
@property(nonatomic) int CPCNavi_InPath;
@property(nonatomic) int CPCNavi;
//---  时长  ---
@property(nonatomic) int CPCNaviSeconds_InPath;
@property(nonatomic) int CPCNaviSeconds;
//---  统计时长  ---
//横屏
@property(nonatomic) int horizontalScreenSeconds_InPath;
@property(nonatomic) int horizontalScreenSeconds;
//竖屏
@property(nonatomic) int verticalScreenSeconds_InPath;
@property(nonatomic) int verticalScreenSeconds;
//地图显示的比例(25m)
@property(nonatomic) int mapProportion_25_InPath;
@property(nonatomic) int mapProportion_25;
//地图显示的比例(50m)
@property(nonatomic) int mapProportion_50_InPath;
@property(nonatomic) int mapProportion_50;
//地图显示的比例(100m)
@property(nonatomic) int mapProportion_100_InPath;
@property(nonatomic) int mapProportion_100;
//地图显示的比例(200m)
@property(nonatomic) int mapProportion_200_InPath;
@property(nonatomic) int mapProportion_200;
//地图显示的比例(500m)
@property(nonatomic) int mapProportion_500_InPath;
@property(nonatomic) int mapProportion_500;
//地图显示的比例(1km)
@property(nonatomic) int mapProportion_1k_InPath;
@property(nonatomic) int mapProportion_1k;
//地图显示的比例(2km)
@property(nonatomic) int mapProportion_2k_InPath;
@property(nonatomic) int mapProportion_2k;
//地图显示的比例(5km)
@property(nonatomic) int mapProportion_5k_InPath;
@property(nonatomic) int mapProportion_5k;
//地图显示的比例(10km)
@property(nonatomic) int mapProportion_10k_InPath;
@property(nonatomic) int mapProportion_10k;
//地图显示的比例(50km)
@property(nonatomic) int mapProportion_50k_InPath;
@property(nonatomic) int mapProportion_50k;
//地图显示的比例(200km)
@property(nonatomic) int mapProportion_200k_InPath;
@property(nonatomic) int mapProportion_200k;
//地图显示的比例(500km)
@property(nonatomic) int mapProportion_500k_InPath;
@property(nonatomic) int mapProportion_500k;
//英文版（开启）
@property(nonatomic) int openEnglishVersionSeconds_InPath;
@property(nonatomic) int openEnglishVersionSeconds;
#pragma  mark---  新添加  ---
//手动搜索
@property(nonatomic) int manualSearch_InPath;
@property(nonatomic) int manualSearch;
//智能搜索
@property(nonatomic) int smartSearch_InPath;
@property(nonatomic) int smartSearch;
//网络搜索
@property(nonatomic) int networkSearch_InPath;
@property(nonatomic) int networkSearch;
//语音搜索
@property(nonatomic) int voiceSearchSide_InPath;
@property(nonatomic) int voiceSearchSide;
//周边搜索
@property(nonatomic) int peripherySearch_InPath;
@property(nonatomic) int peripherySearch;
//移图设终点
@property(nonatomic) int figureMapSetEnd_InPath;
@property(nonatomic) int figureMapSetEnd;
//历史目的地
@property(nonatomic) int historyDestinnation_InPath;
@property(nonatomic) int historyDestinnation;
//地址簿
@property(nonatomic) int addressBook_InPath;
@property(nonatomic) int addressBook;
//通讯录导航
@property(nonatomic) int contactsNavigation_InPath;
@property(nonatomic) int contactsNavigation;
//路线详情（概览图）
@property(nonatomic) int routeDetailsOverview_InPath;
@property(nonatomic) int routeDetailsOverview;
//概览图(下一路名)
@property(nonatomic) int overviewNextWay_InPath;
@property(nonatomic) int overviewNextWay;
//位置分享（短信）
@property(nonatomic) int shareLocationBySMS_InPath;
@property(nonatomic) int shareLocationBySMS;
//位置分享（邮件）
@property(nonatomic) int shareLocationByEmail_InPath;
@property(nonatomic) int shareLocationByEmail;
//位置分享（新浪）
@property(nonatomic) int shareLocationBySina_InPath;
@property(nonatomic) int shareLocationBySina;
//位置分享（腾讯）
@property(nonatomic) int shareLocationByTX_InPath;
@property(nonatomic) int shareLocationByTX;
//微享定位
@property(nonatomic) int microShareLocation_InPath;
@property(nonatomic) int microShareLocation;
//北向上视角(t)
//---  次数  ---
@property(nonatomic) int northUpView_InPath;
@property(nonatomic) int northUpView;
//---  时长  ---
@property(nonatomic) int northUpViewSeconds_InPath;
@property(nonatomic) int northUpViewSeconds;
//车头向上视角(t)
//---  次数  ---
@property(nonatomic) int upView_InPath;
@property(nonatomic) int upView;
//---  时长  ---
@property(nonatomic) int upViewSeconds_InPath;
@property(nonatomic) int upViewSeconds;
//3D视角(t)
//---  次数  ---
@property(nonatomic) int car3DView_InPath;
@property(nonatomic) int car3DView;
//---  时长  ---
@property(nonatomic) int car3DViewSeconds_InPath;
@property(nonatomic) int car3DViewSeconds;
//实时交通
@property(nonatomic) int realTimeTraffic_InPath;
@property(nonatomic) int realTimeTraffic;
//交通信息
@property(nonatomic) int trafficInformation_InPath;
@property(nonatomic) int trafficInformation;
//智驾服务
@property(nonatomic) int smartDrivingServices_InPath;
@property(nonatomic) int smartDrivingServices;
//智驾设置目的地（下发成功）
@property(nonatomic) int smartDriveSetDestination_InPath;
@property(nonatomic) int smartDriveSetDestination;
//图层（携程在线）(t)
//---  次数  ---
@property(nonatomic) int layerByCtripOnline_InPath;
@property(nonatomic) int layerByCtripOnline;
//---  时长  ---
@property(nonatomic) int layerByCtripOnlineSeconds_InPath;
@property(nonatomic) int layerByCtripOnlineSeconds;
//图层（携程在线电话定购）
@property(nonatomic) int layerByCtripPhone_InPath;
@property(nonatomic) int layerByCtripPhone;
//图层（旅游）(t)
//---  次数  ---
@property(nonatomic) int layerByTravel_InPath;
@property(nonatomic) int layerByTravel;
//---  时长  ---
@property(nonatomic) int layerByTravelSeconds_InPath;
@property(nonatomic) int layerByTravelSeconds;
//图层（餐饮）(t)
//---  次数  ---
@property(nonatomic) int layerByFood_InPath;
@property(nonatomic) int layerByFood;
//---  时长  ---
@property(nonatomic) int layerByFoodSeconds_InPath;
@property(nonatomic) int layerByFoodSeconds;
//图层（高尔夫）(t)
//---  次数  ---
@property(nonatomic) int layerByGolf_InPath;
@property(nonatomic) int layerByGolf;
//---  时长  ---
@property(nonatomic) int layerByGolfSeconds_InPath;
@property(nonatomic) int layerByGolfSeconds;
//图层（我的图层）(t)
//---  次数  ---
@property(nonatomic) int layerByMyself_InPath;
@property(nonatomic) int layerByMyself;
//---  时长  ---
@property(nonatomic) int layerByMyselfSeconds_InPath;
@property(nonatomic) int layerByMyselfSeconds;
//图层（我的好友分享）(t)
//---  次数  ---
@property(nonatomic) int layerByFriendsShare_InPath;
@property(nonatomic) int layerByFriendsShare;
//---  时长  ---
@property(nonatomic) int layerByFriendsShareSeconds_InPath;
@property(nonatomic) int layerByFriendsShareSeconds;
//图层（高德用户分享）(t)
@property(nonatomic) int layerByGDShare_InPath;
@property(nonatomic) int layerByGDShare;
//---  时长  ---
@property(nonatomic) int layerByGDShareSeconds_InPath;
@property(nonatomic) int layerByGDShareSeconds;
//回家
@property(nonatomic) int goHome_InPath;
@property(nonatomic) int goHome;
//回公司
@property(nonatomic) int backCompany_InPath;
@property(nonatomic) int backCompany;
//交通信息条避让
@property(nonatomic) int avoidTraffice_InPath;
@property(nonatomic) int avoidTraffice;
//路线详情避让
@property(nonatomic) int avoidRouteDetail_InPath;
@property(nonatomic) int avoidRouteDetail;
//避让前
@property(nonatomic) int beforeAvoid_InPath;
@property(nonatomic) int beforeAvoid;
//避让后
@property(nonatomic) int afterAvoid_InPath;
@property(nonatomic) int afterAvoid;
//全程概览“取消避让”
@property(nonatomic) int cancelAvoid_InPath;
@property(nonatomic) int cancelAvoid;
//Routing功能
@property(nonatomic) int routingFunction_InPath;
@property(nonatomic) int routingFunction;
//云端备份信息
@property(nonatomic) int cloudBackupInformation_InPath;
@property(nonatomic) int cloudBackupInformation;
//设为家
@property(nonatomic) int setHome_InPath;
@property(nonatomic) int setHome;
//设为公司
@property(nonatomic) int setCompany_InPath;
@property(nonatomic) int setCompany;
//地图下载管理
@property(nonatomic) int downloadManage_InPath;
@property(nonatomic) int downloadManage;
//地图升级管理
@property(nonatomic) int mapUpdateManage_InPath;
@property(nonatomic) int mapUpdateManage;
//轨迹管理
@property(nonatomic) int locusManage_InPath;
@property(nonatomic) int locusManage;
//流量统计
@property(nonatomic) int flowStatistics_InPath;
@property(nonatomic) int flowStatistics;
//我喜欢高德导航
@property(nonatomic) int iLoveGD_InPath;
@property(nonatomic) int iLoveGD;
//新版本功能
@property(nonatomic) int newVersionFunction_InPath;
@property(nonatomic) int newVersionFunction;
//版本信息
@property(nonatomic) int versionInfo_InPath;
@property(nonatomic) int versionInfo;
//手机终端下载地图--- 这个变量不用了
@property(nonatomic) int downloadMapByPhone;
//旅游图层数据
@property(nonatomic) int travelLayerData;
//开启导航！
@property(nonatomic) int openNavigation;
//最后一次启动时间
@property(nonatomic,retain) NSString *lastStartUp;
//程序使用时长（即——打开——进入后台（关闭））
@property(nonatomic) int durationOfUse_InPath;
@property(nonatomic) int durationOfUse;
//手机终端下载地图//key --  城市编码   value  ---  下载次数
@property(nonatomic,retain) NSMutableDictionary *downloadMapByPhoneDict;

#pragma mark ---  5.29 新添加项目  ---
//去哪儿
@property(nonatomic) int goWhere_InPath;
@property(nonatomic) int goWhere;
//常用
@property(nonatomic) int commonUse_InPath;
@property(nonatomic) int commonUse;
//收藏当前点(弹出框的收藏当前点)
@property(nonatomic) int alertFavCurrentPoint_InPath;
@property(nonatomic) int alertFavCurrentPoint;
//我的收藏夹
@property(nonatomic) int myFavorites_InPath;
@property(nonatomic) int myFavorites;
//历史目的地
@property(nonatomic) int historyDestination_InPath;
@property(nonatomic) int historyDestination;
//路线管理
/*@property(nonatomic) int routeManage_InPath;
@property(nonatomic) int routeManage;*/
//多个途经点
@property(nonatomic) int multipleWaypoints_InPath;
@property(nonatomic) int multipleWaypoints;
//字体大小（大）
@property(nonatomic) int fontSizeLarge_InPath;
@property(nonatomic) int fontSizeLarge;
//字体大小（中）
@property(nonatomic) int fontSizeMedium_InPath;
@property(nonatomic) int fontSizeMedium;
//字体大小（小）
@property(nonatomic) int fontSizeSmall_InPath;
@property(nonatomic) int fontSizeSmall;
//昼夜模式（白天）
@property(nonatomic) int dayAndNightModeDay_InPath;
@property(nonatomic) int dayAndNightModeDay;
//昼夜模式（黑夜）
@property(nonatomic) int dayAndNightModeNight_InPath;
@property(nonatomic) int dayAndNightModeNight;
//昼夜模式（自动）
@property(nonatomic) int dayAndNightModeAuto_InPath;
@property(nonatomic) int dayAndNightModeAuto;
//语音选择（国语女声）
@property(nonatomic) int voiceSelectNationalFemale_InPath;
@property(nonatomic) int voiceSelectNationalFemale;
//语音选择（国语男声）
@property(nonatomic) int voiceSelectNationalMale_InPath;
@property(nonatomic) int voiceSelectNationalMale;
//语音选择（台湾普通话女声）
@property(nonatomic) int voiceSelectTaiwanFemale_InPath;
@property(nonatomic) int voiceSelectTaiwanFemale;
//语音选择（粤语女声）
@property(nonatomic) int voiceSelectCantoneseFemale_InPath;
@property(nonatomic) int voiceSelectCantoneseFemale;
//语音选择（东北普通话女声）
@property(nonatomic) int voiceSelectNortheasternFemale_InPath;
@property(nonatomic) int voiceSelectNortheasternFemale;
//语音选择（四川普通话女声）
@property(nonatomic) int voiceSelectSichuanFemale_InPath;
@property(nonatomic) int voiceSelectSichuanFemale;
//语音选择（湖南话男声）
@property(nonatomic) int voiceSelectHunanMale_InPath;
@property(nonatomic) int voiceSelectHunanMale;
//语音选择 (河南话男声)
@property(nonatomic) int voiceSelectHenanMale_InPath;
@property(nonatomic) int voiceSelectHenanMale;
//语音频率（一般）
@property(nonatomic) int voiceFrequencyGeneral_InPath;
@property(nonatomic) int voiceFrequencyGeneral;
//语音频率（频繁）
@property(nonatomic) int voiceFrequencyFrequent_InPath;
@property(nonatomic) int voiceFrequencyFrequent;
//信息优先显示（自动）
@property(nonatomic) int informationFirstAuto_InPath;
@property(nonatomic) int informationFirstAuto;
//信息优先显示（加油站）
@property(nonatomic) int informationFirstGasStation_InPath;
@property(nonatomic) int informationFirstGasStation;
//信息优先显示（停车场）
@property(nonatomic) int informationFirstParking_InPath;
@property(nonatomic) int informationFirstParking;
//信息优先显示（餐饮）
@property(nonatomic) int informationFirstFood_InPath;
@property(nonatomic) int informationFirstFood;
//信息优先显示（住宿）
@property(nonatomic) int informationFirstLodging_InPath;
@property(nonatomic) int informationFirstLodging;
//信息优先显示（娱乐）
@property(nonatomic) int informationFirstFun_InPath;
@property(nonatomic) int informationFirstFun;
//信息优先显示（景点）
@property(nonatomic) int informationFirstAttractions_InPath;
@property(nonatomic) int informationFirstAttractions;
//信息优先显示（医疗）
@property(nonatomic) int informationFirstMedical_InPath;
@property(nonatomic) int informationFirstMedical;
//store
@property(nonatomic) int store_InPath;
@property(nonatomic) int store;
//账号登录
@property(nonatomic) int accountLogin_InPath;
@property(nonatomic) int accountLogin;
//使用时长 （后台）
@property(nonatomic) int durationOfUseBackgroundSeconds_InPath;
@property(nonatomic) int durationOfUseBackgroundSeconds;
@property(nonatomic,retain) NSMutableArray *PathYawCount; //路径偏航统计－以字典形式统计key：1.time记录时间（年／月／日／时／分）2.dataVersion数据版本（如V21.2.2010.0007,统计时候只要记录21）3.appVersion程序版本（版本号：如7.3）4.startLon,startLat起点经纬度 5.midArray(midlon,midlat)中途点经纬度,数组－存储多个中途点 6.desLon,desLat目的地经纬度 7.pathPlan规划原则（纪录id：0：推荐路线1：高速优先2：经济路线3：最短路径）8.yawLon,yawLat偏航点经纬度

//中间变量 —— 导航开启时间，导航开启次数
@property (nonatomic,retain) NSString *tempFirstStartUp;
@property (nonatomic) int tempOpenNavigation;

//偏航次数统计
@property (nonatomic) int recalculationCount;

//实时交通开启时长
@property (nonatomic) int TMCTime;

#pragma mark ---  函数  ---

//读取数据
-(void)readData;
//保存数据
-(void)saveData;
//复位 
-(void)resetData;
//计时器（确定各种视图或者东西的持续时间）
-(void)timeCount;

/*
 统计周边各个项
 @param section  传入相对应的section
 @param subIndex 若有子列表传入对应子列表的索引
 **/
- (void)searchArroundCount:(int)section SubIndex:(int)subIndex;
//添加路径偏移统计信息
- (BOOL)addInfoToRouteYawCount;
//重置路径统计信息
- (void)resetPathYawData;
//组装路径偏航统计信息
- (NSString *)compostPathYaw;
@end
