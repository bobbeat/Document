//
//  GDBL_UserBehaviorCountNew.m
//  AutoNavi
//
//  Created by jiangshu.fu on 13-5-27.
//
//

#import "GDBL_UserBehaviorCountNew.h"
#import "ANParamValue.h"
#import "ANDataSource.h"
#import "UMengEventDefine.h"

static GDBL_UserBehaviorCountNew *instance;
#define filePath [NSHomeDirectory() stringByAppendingString:@"/Documents/UBCNew.plist"]

@implementation GDBL_UserBehaviorCountNew

@synthesize addressSearch_InPath,addressSearch,crossSearch_InPath,crossSearch,defaultSort_InPath,defaultSort,distanceSort_InPath,distanceSort,regionSelect_InPath,regionSelect,voiceSearchGoWhere_InPath,voiceSearchGoWhere,alongCursorSearch_InPath,alongCursorSearch,alongPathSearch_InPath,alongPathSearch,alongDestinationsearch_InPath,alongDestinationsearch,stationType_InPath,stationType,parkingType_InPath,parkingType,businessCasualType_InPath,businessCasualType,foodDrinkType_InPath,foodDrinkType,hotelType_InPath,hotelType,shoppingType_InPath,shoppingType,sightsType_InPath,sightsType,transportServicesType_InPath,transportServicesType,financeType_InPath,financeType,buildingType_InPath,buildingType,recreationType_InPath,recreationType,CorporateType_InPath,CorporateType,carServiceType_InPath,carServiceType,sportsType_InPath,sportsType,livingServiceType_InPath,livingServiceType,educationType_InPath,educationType,hospitalType_InPath,hospitalType,residentialAreaType_InPath,residentialAreaType,governmentType_InPath,governmentType,cityType_InPath,cityType,detailSetEnd_InPath,detailSetEnd,viewPOISetEnd_InPath,viewPOISetEnd,detailSetStart_InPath,detailSetStart,viewPOISetStart_InPath,viewPOISetStart,figureMapSetSatar_InPath,figureMapSetSatar,viewPOISetWaypoint_InPath,viewPOISetWaypoint,figureSetWaypoint_InPath,figureSetWaypoint,managePathDetail_InPath,managePathDetail,stopNaviByTurnArrow_InPath,stopNaviByTurnArrow,stopNaviByManage_InPath,stopNaviByManage,simulatedNaviByOverview_InPath,simulatedNaviByOverview,simulatedNaviByManage_InPath,simulatedNaviByManage,planningByManage_InPath,planningByManage,overviewByManage_InPath,overviewByManage,suggestedLtineraries_InPath,suggestedLtineraries,highPriority_InPath,highPriority,economicRoute_InPath,economicRoute,shortestRoute_InPath,shortestRoute,directionsContrast_InPath,directionsContrast,overviewViewFull_InPath,overviewViewFull,viewTripComputer_InPath,viewTripComputer,enlargeByButton_InPath,enlargeByButton,narrowByButton_InPath,narrowByButton,enlargeByDoubleClick_InPath,enlargeByDoubleClick,narrowByTwoFingerClick_InPath,narrowByTwoFingerClick,enlargeByPinOpen_InPath,enlargeByPinOpen,narrowByPinKneading_InPath,narrowByPinKneading,favoriteCurrentPoint_InPath,favoriteCurrentPoint,messageBox_InPath,messageBox,pathManage_InPath,pathManage,switchMainAndSideRoads_InPath,switchMainAndSideRoads,trafficIncident_InPath,trafficIncident,feedback_InPath,feedback,trafficEventDisplay_InPath,trafficEventDisplay,networkNavi_InPath,networkNavi,networkNaviSeconds_InPath,networkNaviSeconds,CPCNavi_InPath,CPCNavi,CPCNaviSeconds_InPath,CPCNaviSeconds,horizontalScreenSeconds_InPath,horizontalScreenSeconds,verticalScreenSeconds_InPath,verticalScreenSeconds,mapProportion_25_InPath,mapProportion_25,mapProportion_50_InPath,mapProportion_50,mapProportion_100_InPath,mapProportion_100,mapProportion_200_InPath,mapProportion_200,mapProportion_500_InPath,mapProportion_500,mapProportion_1k_InPath,mapProportion_1k,mapProportion_2k_InPath,mapProportion_2k,mapProportion_5k_InPath,mapProportion_5k,mapProportion_10k_InPath,mapProportion_10k,mapProportion_50k_InPath,mapProportion_50k,mapProportion_200k_InPath,mapProportion_200k,mapProportion_500k_InPath,mapProportion_500k,openEnglishVersionSeconds_InPath,openEnglishVersionSeconds,manualSearch_InPath,manualSearch,smartSearch_InPath,smartSearch,networkSearch_InPath,networkSearch,voiceSearchSide_InPath,voiceSearchSide,peripherySearch_InPath,peripherySearch,figureMapSetEnd_InPath,figureMapSetEnd,historyDestinnation_InPath,historyDestinnation,addressBook_InPath,addressBook,contactsNavigation_InPath,contactsNavigation,routeDetailsOverview_InPath,routeDetailsOverview,overviewNextWay_InPath,overviewNextWay,shareLocationBySMS_InPath,shareLocationBySMS,shareLocationByEmail_InPath,shareLocationByEmail,shareLocationBySina_InPath,shareLocationBySina,shareLocationByTX_InPath,shareLocationByTX,microShareLocation_InPath,microShareLocation,northUpView_InPath,northUpView,northUpViewSeconds_InPath,northUpViewSeconds,upView_InPath,upView,upViewSeconds_InPath,upViewSeconds,car3DView_InPath,car3DView,car3DViewSeconds_InPath,car3DViewSeconds,realTimeTraffic_InPath,realTimeTraffic,trafficInformation_InPath,trafficInformation,smartDrivingServices_InPath,smartDrivingServices,smartDriveSetDestination_InPath,smartDriveSetDestination,layerByCtripOnline_InPath,layerByCtripOnline,layerByCtripPhone_InPath,layerByCtripPhone,layerByCtripOnlineSeconds_InPath,layerByCtripOnlineSeconds,layerByTravel_InPath,layerByTravel,layerByTravelSeconds_InPath,layerByTravelSeconds,layerByFood_InPath,layerByFood,layerByFoodSeconds_InPath,layerByFoodSeconds,layerByGolf_InPath,layerByGolf,layerByGolfSeconds_InPath,layerByGolfSeconds,layerByMyself_InPath,layerByMyself,layerByMyselfSeconds_InPath,layerByMyselfSeconds,layerByFriendsShare_InPath,layerByFriendsShare,layerByFriendsShareSeconds_InPath,layerByFriendsShareSeconds,layerByGDShare_InPath,layerByGDShare,layerByGDShareSeconds_InPath,layerByGDShareSeconds,goHome_InPath,goHome,backCompany_InPath,backCompany,avoidTraffice_InPath,avoidTraffice,avoidRouteDetail_InPath,avoidRouteDetail,beforeAvoid_InPath,beforeAvoid,afterAvoid_InPath,afterAvoid,cancelAvoid_InPath,cancelAvoid,routingFunction_InPath,routingFunction,cloudBackupInformation_InPath,cloudBackupInformation,setHome_InPath,setHome,setCompany_InPath,setCompany,downloadManage_InPath,downloadManage,mapUpdateManage_InPath,mapUpdateManage,locusManage_InPath,locusManage,flowStatistics_InPath,flowStatistics,iLoveGD_InPath,iLoveGD,newVersionFunction_InPath,newVersionFunction,versionInfo_InPath,versionInfo,downloadMapByPhone,travelLayerData,openNavigation,lastStartUp,durationOfUse_InPath,durationOfUse,downloadMapByPhoneDict;
@synthesize goWhere_InPath,goWhere,commonUse_InPath,commonUse,alertFavCurrentPoint_InPath,alertFavCurrentPoint,myFavorites_InPath,myFavorites,historyDestination_InPath,historyDestination,voiceSelectHenanMale_InPath,voiceSelectHenanMale,multipleWaypoints_InPath,multipleWaypoints,fontSizeLarge_InPath,fontSizeLarge,fontSizeMedium_InPath,fontSizeMedium,fontSizeSmall_InPath,fontSizeSmall,dayAndNightModeDay_InPath,dayAndNightModeDay,dayAndNightModeNight_InPath,dayAndNightModeNight,dayAndNightModeAuto_InPath,dayAndNightModeAuto,voiceSelectNationalFemale_InPath,voiceSelectNationalFemale,voiceSelectNationalMale_InPath,voiceSelectNationalMale,voiceSelectTaiwanFemale_InPath,voiceSelectTaiwanFemale,voiceSelectCantoneseFemale_InPath,voiceSelectCantoneseFemale,voiceSelectNortheasternFemale_InPath,voiceSelectNortheasternFemale,voiceSelectSichuanFemale_InPath,voiceSelectSichuanFemale,voiceSelectHunanMale_InPath,voiceSelectHunanMale,voiceFrequencyGeneral_InPath,voiceFrequencyGeneral,voiceFrequencyFrequent_InPath,voiceFrequencyFrequent,informationFirstAuto_InPath,informationFirstAuto,informationFirstGasStation_InPath,informationFirstGasStation,informationFirstParking_InPath,informationFirstParking,informationFirstFood_InPath,informationFirstFood,informationFirstLodging_InPath,informationFirstLodging,informationFirstFun_InPath,informationFirstFun,informationFirstAttractions_InPath,informationFirstAttractions,informationFirstMedical_InPath,informationFirstMedical,store_InPath,store,accountLogin_InPath,accountLogin,durationOfUseBackgroundSeconds_InPath,durationOfUseBackgroundSeconds,PathYawCount,recalculationCount;
@synthesize tempFirstStartUp,tempOpenNavigation,TMCTime;
#pragma mark ---  辅助函数  ---

-(BOOL) isPath
{
    BOOL isPath = NO;
    GDBL_GetParam(G_GUIDE_STATUS, &isPath); //无路径下，才播报PCD
    return isPath;
}


+(GDBL_UserBehaviorCountNew *)shareInstance
{
    if (instance == nil) {
        instance  = [[GDBL_UserBehaviorCountNew alloc] init];
        [instance readData];
    }
    return instance;
}

#pragma mark ---  类函数  ---
-(id) init
{
    if(self = [super init]){
        downloadMapByPhoneDict = [[NSMutableDictionary alloc] init];
        lastStartUp = [[NSString alloc] init];
        
        stationType_InPath = [self newArroundArray:5];
        stationType = [self newArroundArray:5];
        
        businessCasualType_InPath = [self newArroundArray:5];
        businessCasualType = [self newArroundArray:5];
        
        foodDrinkType_InPath = [self newArroundArray:8];
        foodDrinkType = [self newArroundArray:8];
        
        hotelType_InPath = [self newArroundArray:8];
        hotelType = [self newArroundArray:8];
        
        shoppingType_InPath = [self newArroundArray:11];
        shoppingType = [self newArroundArray:11];
        
        sightsType_InPath = [self newArroundArray:6];
        sightsType = [self newArroundArray:6];
        
        transportServicesType_InPath = [self newArroundArray:10];
        transportServicesType = [self newArroundArray:10];
        
        financeType_InPath = [self newArroundArray:7];
        financeType = [self newArroundArray:7];
        
        recreationType_InPath = [self newArroundArray:6];
        recreationType = [self newArroundArray:6];
        
        carServiceType_InPath = [self newArroundArray:9];
        carServiceType = [self newArroundArray:9];
        
        sportsType_InPath = [self newArroundArray:3];
        sportsType = [self newArroundArray:3];
        
        livingServiceType_InPath = [self newArroundArray:6];
        livingServiceType = [self newArroundArray:6];
        
        educationType_InPath = [self newArroundArray:6];
        educationType = [self newArroundArray:6];
        
        hospitalType_InPath = [self newArroundArray:8];
        hospitalType = [self newArroundArray:8];
        
        governmentType_InPath = [self newArroundArray:6];
        governmentType = [self newArroundArray:6];
        
        PathYawCount = [[NSMutableArray alloc] init];
        
        tempFirstStartUp = [[NSString alloc] init];
        tempOpenNavigation = 0;
        recalculationCount = 0;
    }
    return self;
}

-(NSMutableArray *) newArroundArray :(int) count
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (int i = 0; i < count; i++) {
        NSNumber *number = [NSNumber numberWithInt:0];
        [array addObject:number];
    }
    return array;
}

-(void)dealloc
{
    [self saveData];
    
    if ( tempFirstStartUp != nil )
    {
        [tempFirstStartUp release];
        tempFirstStartUp = nil;
    }
    if(lastStartUp != nil)
    {
        [lastStartUp release];
        lastStartUp = nil;
    }
    if(stationType_InPath != nil)
    {
        [stationType_InPath release];
        stationType_InPath = nil;
    }
    if(stationType != nil)
    {
        [stationType release];
        stationType = nil;
    }
    if(businessCasualType_InPath != nil)
    {
        [businessCasualType_InPath release];
        businessCasualType_InPath = nil;
    }
    if(businessCasualType != nil)
    {
        [businessCasualType release];
        businessCasualType = nil;
    }
    if(foodDrinkType_InPath != nil)
    {
        [foodDrinkType_InPath release];
        foodDrinkType_InPath = nil;
    }
    if(foodDrinkType != nil)
    {
        [foodDrinkType release];
        foodDrinkType = nil;
    }
    if(hotelType_InPath != nil)
    {
        [hotelType_InPath release];
        hotelType_InPath = nil;
    }
    if(hotelType != nil)
    {
        [hotelType release];
        hotelType = nil;
    }
    if(shoppingType_InPath != nil)
    {
        [shoppingType_InPath release];
        shoppingType_InPath = nil;
    }
    if(shoppingType != nil)
    {
        [shoppingType release];
        shoppingType = nil;
    }
    if(sightsType_InPath != nil)
    {
        [sightsType_InPath release];
        sightsType_InPath = nil;
    }
    if(sightsType != nil)
    {
        [sightsType release];
        sightsType = nil;
    }
    if(transportServicesType_InPath != nil)
    {
        [transportServicesType_InPath release];
        transportServicesType_InPath = nil;
    }
    if(transportServicesType != nil)
    {
        [transportServicesType release];
        transportServicesType = nil;
    }
    if(financeType_InPath != nil)
    {
        [financeType_InPath release];
        financeType_InPath = nil;
    }
    if(financeType != nil)
    {
        [financeType release];
        financeType = nil;
    }
    if(recreationType_InPath != nil)
    {
        [recreationType_InPath release];
        recreationType_InPath = nil;
    }
    if(recreationType != nil)
    {
        [recreationType release];
        recreationType = nil;
    }
    if(carServiceType_InPath != nil)
    {
        [carServiceType_InPath release];
        carServiceType_InPath = nil;
    }
    if(carServiceType != nil)
    {
        [carServiceType release];
        carServiceType = nil;
    }
    if(sportsType_InPath != nil)
    {
        [sportsType_InPath release];
        sportsType_InPath = nil;
    }
    if(sportsType != nil)
    {
        [sportsType release];
        sportsType = nil;
    }
    if(livingServiceType_InPath != nil)
    {
        [livingServiceType_InPath release];
        livingServiceType_InPath = nil;
    }
    if(livingServiceType != nil)
    {
        [livingServiceType release];
        livingServiceType = nil;
    }
    if(educationType_InPath != nil)
    {
        [educationType_InPath release];
        educationType_InPath = nil;
    }
    if(educationType != nil)
    {
        [educationType release];
        educationType = nil;
    }
    if(hospitalType_InPath != nil)
    {
        [hospitalType_InPath release];
        hospitalType_InPath = nil;
    }
    if(hospitalType != nil)
    {
        [hospitalType release];
        hospitalType = nil;
    }
    if(governmentType_InPath != nil)
    {
        [governmentType_InPath release];
        governmentType_InPath = nil;
    }
    if(governmentType != nil)
    {
        [governmentType release];
        governmentType = nil;
    }
    [super dealloc];
}

//读取数据
-(void)readData
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    if(dic != nil)
    {
        NSNumber *openNavigationN = [dic objectForKey:@"openNavigation"];
        if(openNavigationN != nil)
        {
            self.openNavigation = [openNavigationN intValue];
        }
        if([dic objectForKey:@"lastStartUp"] != nil)
        {
            self.lastStartUp = [dic objectForKey:@"lastStartUp"];
        }
        if([dic objectForKey:@"downloadMapByPhoneDict"] && [[dic objectForKey:@"downloadMapByPhoneDict"] count] > 0)
        {
            self.downloadMapByPhoneDict = [dic objectForKey:@"downloadMapByPhoneDict"];
        }
        
        NSNumber *addressSearch_InPathN = [dic objectForKey:@"addressSearch_InPath"];
        if(addressSearch_InPathN != nil)
        {
            self.addressSearch_InPath = [addressSearch_InPathN intValue];
        }
        NSNumber *addressSearchN = [dic objectForKey:@"addressSearch"];
        if(addressSearchN != nil)
        {
            self.addressSearch = [addressSearchN intValue];
        }
        NSNumber *crossSearch_InPathN = [dic objectForKey:@"crossSearch_InPath"];
        if(crossSearch_InPathN != nil)
        {
            self.crossSearch_InPath = [crossSearch_InPathN intValue];
        }
        NSNumber *crossSearchN = [dic objectForKey:@"crossSearch"];
        if(crossSearchN != nil)
        {
            self.crossSearch = [crossSearchN intValue];
        }
        NSNumber *defaultSort_InPathN = [dic objectForKey:@"defaultSort_InPath"];
        if(defaultSort_InPathN != nil)
        {
            self.defaultSort_InPath = [defaultSort_InPathN intValue];
        }
        NSNumber *defaultSortN = [dic objectForKey:@"defaultSort"];
        if(defaultSortN != nil)
        {
            self.defaultSort = [defaultSortN intValue];
        }
        NSNumber *distanceSort_InPathN = [dic objectForKey:@"distanceSort_InPath"];
        if(distanceSort_InPathN != nil)
        {
            self.distanceSort_InPath = [distanceSort_InPathN intValue];
        }
        NSNumber *distanceSortN = [dic objectForKey:@"distanceSort"];
        if(distanceSortN != nil)
        {
            self.distanceSort = [distanceSortN intValue];
        }
        NSNumber *regionSelect_InPathN = [dic objectForKey:@"regionSelect_InPath"];
        if(regionSelect_InPathN != nil)
        {
            self.regionSelect_InPath = [regionSelect_InPathN intValue];
        }
        NSNumber *regionSelectN = [dic objectForKey:@"regionSelect"];
        if(regionSelectN != nil)
        {
            self.regionSelect = [regionSelectN intValue];
        }
        NSNumber *voiceSearchGoWhere_InPathN = [dic objectForKey:@"voiceSearchGoWhere_InPath"];
        if(voiceSearchGoWhere_InPathN != nil)
        {
            self.voiceSearchGoWhere_InPath = [voiceSearchGoWhere_InPathN intValue];
        }
        NSNumber *voiceSearchGoWhereN= [dic objectForKey:@"voiceSearchGoWhere"];
        if(voiceSearchGoWhereN != nil)
        {
            self.voiceSearchGoWhere = [voiceSearchGoWhereN intValue];
        }
        NSNumber *alongCursorSearch_InPathN = [dic objectForKey:@"alongCursorSearch_InPath"];
        if(alongCursorSearch_InPathN != nil)
        {
            self.alongCursorSearch_InPath = [alongCursorSearch_InPathN intValue];
        }
        NSNumber *alongCursorSearchN = [dic objectForKey:@"alongCursorSearch"];
        if(alongCursorSearchN != nil)
        {
            self.alongCursorSearch = [alongCursorSearchN intValue];
        }
        NSNumber *alongPathSearch_InPathN = [dic objectForKey:@"alongPathSearch_InPath"];
        if(alongPathSearch_InPathN != nil)
        {
            self.alongPathSearch_InPath = [alongPathSearch_InPathN intValue];
        }
        NSNumber *alongPathSearchN = [dic objectForKey:@"alongPathSearch"];
        if(alongPathSearchN != nil)
        {
            self.alongPathSearch = [alongPathSearchN intValue];
        }
        NSNumber *alongDestinationsearch_InPathN = [dic objectForKey:@"alongDestinationsearch_InPath"];
        if(alongDestinationsearch_InPathN != nil)
        {
            self.alongDestinationsearch_InPath = [alongDestinationsearch_InPathN intValue];
        }
        NSNumber *alongDestinationsearchN = [dic objectForKey:@"alongDestinationsearch"];
        if(alongDestinationsearchN != nil)
        {
            self.alongDestinationsearch = [alongDestinationsearchN intValue];
        }
        NSMutableArray *stationType_InPathN = [dic objectForKey:@"stationType_InPath"];
        if(stationType_InPathN != nil)
        {
            self.stationType_InPath = stationType_InPathN;
        }
        NSMutableArray *stationTypeN = [dic objectForKey:@"stationType"];
        if(stationTypeN != nil)
        {
            self.stationType = stationTypeN;
        }
        NSNumber *parkingType_InPathN = [dic objectForKey:@"parkingType_InPath"];
        if(parkingType_InPathN != nil)
        {
            self.parkingType_InPath = [parkingType_InPathN intValue];
        }
        NSNumber *parkingTypeN = [dic objectForKey:@"parkingType"];
        if(parkingTypeN != nil)
        {
            self.parkingType = [parkingTypeN intValue];
        }
        NSMutableArray *businessCasualType_InPathN = [dic objectForKey:@"businessCasualType_InPath"];
        if(businessCasualType_InPathN != nil)
        {
            self.businessCasualType_InPath = businessCasualType_InPathN;
        }
        NSMutableArray *businessCasualTypeN = [dic objectForKey:@"businessCasualType"];
        if(businessCasualTypeN != nil)
        {
            self.businessCasualType = businessCasualTypeN ;
        }
        NSMutableArray *foodDrinkType_InPathN = [dic objectForKey:@"foodDrinkType_InPath"];
        if(foodDrinkType_InPathN != nil)
        {
            self.foodDrinkType_InPath = foodDrinkType_InPathN ;
        }
        NSMutableArray *foodDrinkTypeN = [dic objectForKey:@"foodDrinkType"];
        if(foodDrinkTypeN != nil)
        {
            self.foodDrinkType = foodDrinkTypeN ;
        }
        NSMutableArray *hotelType_InPathN = [dic objectForKey:@"hotelType_InPath"];
        if(hotelType_InPathN != nil)
        {
            self.hotelType_InPath = hotelType_InPathN;
        }
        NSMutableArray *hotelTypeN = [dic objectForKey:@"hotelType"];
        if(hotelTypeN != nil)
        {
            self.hotelType = hotelTypeN;
        }
        NSMutableArray *shoppingTypeN = [dic objectForKey:@"shoppingType"];
        if(shoppingTypeN != nil)
        {
            self.shoppingType = shoppingTypeN ;
        }
        NSMutableArray *shoppingType_InPathN = [dic objectForKey:@"shoppingType_InPath"];
        if(shoppingType_InPathN != nil)
        {
            self.shoppingType_InPath = shoppingType_InPathN ;
        }
        NSMutableArray *sightsType_InPathN = [dic objectForKey:@"sightsType_InPath"];
        if(sightsType_InPathN != nil)
        {
            self.sightsType_InPath = sightsType_InPathN ;
        }
        NSMutableArray *sightsTypeN = [dic objectForKey:@"sightsType"];
        if(sightsTypeN != nil)
        {
            self.sightsType = sightsTypeN ;
        }
        NSMutableArray *transportServicesType_InPathN = [dic objectForKey:@"transportServicesType_InPath"];
        if(transportServicesType_InPathN != nil)
        {
            self.transportServicesType_InPath = transportServicesType_InPathN ;
        }
        NSMutableArray *transportServicesTypeN = [dic objectForKey:@"transportServicesType"];
        if(transportServicesTypeN != nil)
        {
            self.transportServicesType = transportServicesTypeN ;
        }
        NSMutableArray *financeType_InPathN = [dic objectForKey:@"financeType_InPath"];
        if(financeType_InPathN != nil)
        {
            self.financeType_InPath = financeType_InPathN ;
        }
        NSMutableArray *financeTypeN = [dic objectForKey:@"financeType"];
        if(financeTypeN != nil)
        {
            self.financeType = financeTypeN ;
        }
        NSNumber *buildingType_InPathN = [dic objectForKey:@"buildingType_InPath"];
        if(buildingType_InPathN != nil)
        {
            self.buildingType_InPath = [buildingType_InPathN intValue];
        }
        NSNumber *buildingTypeN = [dic objectForKey:@"buildingType"];
        if(buildingTypeN != nil)
        {
            self.buildingType = [buildingTypeN intValue];
        }
        NSMutableArray *recreationType_InPathN = [dic objectForKey:@"recreationType_InPath"];
        if(recreationType_InPathN != nil)
        {
            self.recreationType_InPath = recreationType_InPathN ;
        }
        NSMutableArray *recreationTypeN = [dic objectForKey:@"recreationType"];
        if(recreationTypeN != nil)
        {
            self.recreationType = recreationTypeN ;
        }
        NSNumber *CorporateType_InPathN = [dic objectForKey:@"CorporateType_InPath"];
        if(CorporateType_InPathN != nil)
        {
            self.CorporateType_InPath = [CorporateType_InPathN intValue];
        }
        NSNumber *CorporateTypeN = [dic objectForKey:@"CorporateType"];
        if(CorporateTypeN != nil)
        {
            self.CorporateType = [CorporateTypeN intValue];
        }
        NSMutableArray *carServiceType_InPathN = [dic objectForKey:@"carServiceType_InPath"];
        if(carServiceType_InPathN != nil)
        {
            self.carServiceType_InPath = carServiceType_InPathN ;
        }
        NSMutableArray *carServiceTypeN = [dic objectForKey:@"carServiceType"];
        if(carServiceTypeN != nil)
        {
            self.carServiceType = carServiceTypeN ;
        }
        NSMutableArray *sportsType_InPathN = [dic objectForKey:@"sportsType_InPath"];
        if(sportsType_InPathN != nil)
        {
            self.sportsType_InPath = sportsType_InPathN ;
        }
        NSMutableArray *sportsTypeN = [dic objectForKey:@"sportsType"];
        if(sportsTypeN != nil)
        {
            self.sportsType = sportsTypeN ;
        }
        NSMutableArray *livingServiceType_InPathN = [dic objectForKey:@"livingServiceType_InPath"];
        if(livingServiceType_InPathN != nil)
        {
            self.livingServiceType_InPath = livingServiceType_InPathN ;
        }
        NSMutableArray *livingServiceTypeN = [dic objectForKey:@"livingServiceType"];
        if(livingServiceTypeN != nil)
        {
            self.livingServiceType = livingServiceTypeN ;
        }
        NSMutableArray *educationType_InPathN = [dic objectForKey:@"educationType_InPath"];
        if(educationType_InPathN != nil)
        {
            self.educationType_InPath = educationType_InPathN ;
        }
        NSMutableArray *educationTypeN = [dic objectForKey:@"educationType"];
        if(educationTypeN != nil)
        {
            self.educationType = educationTypeN ;
        }
        NSMutableArray *hospitalType_InPathN = [dic objectForKey:@"hospitalType_InPath"];
        if(hospitalType_InPathN != nil)
        {
            self.hospitalType_InPath = hospitalType_InPathN ;
        }
        NSMutableArray *hospitalTypeN = [dic objectForKey:@"hospitalType"];
        if(hospitalTypeN != nil)
        {
            self.hospitalType = hospitalTypeN;
        }
        NSNumber *residentialAreaType_InPathN = [dic objectForKey:@"residentialAreaType_InPath"];
        if(residentialAreaType_InPathN != nil)
        {
            self.residentialAreaType_InPath = [residentialAreaType_InPathN intValue];
        }
        NSNumber *residentialAreaTypeN = [dic objectForKey:@"residentialAreaType_InPath"];
        if(residentialAreaTypeN != nil)
        {
            self.residentialAreaType = [residentialAreaTypeN intValue];
        }
        NSMutableArray *governmentType_InPathN = [dic objectForKey:@"governmentType_InPath"];
        if(governmentType_InPathN != nil)
        {
            self.governmentType_InPath = governmentType_InPathN ;
        }
        NSMutableArray *governmentTypeN = [dic objectForKey:@"governmentType"];
        if(governmentTypeN != nil)
        {
            self.governmentType = governmentTypeN ;
        }
        NSNumber *cityType_InPathN = [dic objectForKey:@"cityType_InPath"];
        if(cityType_InPathN != nil)
        {
            self.cityType_InPath = [cityType_InPathN intValue];
        }
        NSNumber *cityTypeN = [dic objectForKey:@"cityType"];
        if(cityTypeN != nil)
        {
            self.cityType = [cityTypeN intValue];
        }
        NSNumber *detailSetEnd_InPathN = [dic objectForKey:@"detailSetEnd_InPath"];
        if(detailSetEnd_InPathN != nil)
        {
            self.detailSetEnd_InPath = [detailSetEnd_InPathN intValue];
        }
        NSNumber *detailSetEndN = [dic objectForKey:@"detailSetEnd"];
        if(detailSetEndN != nil)
        {
            self.detailSetEnd = [detailSetEndN intValue];
        }
        NSNumber *viewPOISetEnd_InPathN = [dic objectForKey:@"viewPOISetEnd_InPath"];
        if(viewPOISetEnd_InPathN != nil)
        {
            self.viewPOISetEnd_InPath = [viewPOISetEnd_InPathN intValue];
        }
        NSNumber *viewPOISetEndN = [dic objectForKey:@"viewPOISetEnd"];
        if(viewPOISetEndN != nil)
        {
            self.viewPOISetEnd = [viewPOISetEndN intValue];
        }
        NSNumber *detailSetStart_InPathN = [dic objectForKey:@"detailSetStart_InPath"];
        if(detailSetStart_InPathN != nil)
        {
            self.detailSetStart_InPath = [detailSetStart_InPathN intValue];
        }
        NSNumber *detailSetStartN = [dic objectForKey:@"detailSetStart"];
        if(detailSetStartN != nil)
        {
            self.detailSetStart = [detailSetStartN intValue];
        }
        NSNumber *viewPOISetStart_InPathN = [dic objectForKey:@"viewPOISetStart_InPath"];
        if(viewPOISetStart_InPathN != nil)
        {
            self.viewPOISetStart_InPath = [viewPOISetStart_InPathN intValue];
        }
        NSNumber *viewPOISetStartN = [dic objectForKey:@"viewPOISetStart"];
        if(viewPOISetStartN != nil)
        {
            self.viewPOISetStart = [viewPOISetStartN intValue];
        }
        NSNumber *figureMapSetSatar_InPathN = [dic objectForKey:@"figureMapSetSatar_InPath"];
        if(figureMapSetSatar_InPathN != nil)
        {
            self.figureMapSetSatar_InPath = [figureMapSetSatar_InPathN intValue];
        }
        NSNumber *figureMapSetSatarN = [dic objectForKey:@"figureMapSetSatar"];
        if(figureMapSetSatarN != nil)
        {
            self.figureMapSetSatar = [figureMapSetSatarN intValue];
        }
        NSNumber *viewPOISetWaypoint_InPathN = [dic objectForKey:@"viewPOISetWaypoint_InPath"];
        if(viewPOISetWaypoint_InPathN != nil)
        {
            self.viewPOISetWaypoint_InPath = [viewPOISetWaypoint_InPathN intValue];
        }
        NSNumber *viewPOISetWaypointN = [dic objectForKey:@"viewPOISetWaypoint"];
        if(viewPOISetWaypointN != nil)
        {
            self.viewPOISetWaypoint = [viewPOISetWaypointN intValue];
        }
        NSNumber *figureSetWaypoint_InPathN = [dic objectForKey:@"figureSetWaypoint_InPath"];
        if(figureSetWaypoint_InPathN != nil)
        {
            self.figureSetWaypoint_InPath = [figureSetWaypoint_InPathN intValue];
        }
        NSNumber *figureSetWaypointN = [dic objectForKey:@"figureSetWaypoint"];
        if(figureSetWaypointN != nil)
        {
            self.figureSetWaypoint = [figureSetWaypointN intValue];
        }
        NSNumber *managePathDetail_InPathN = [dic objectForKey:@"managePathDetail_InPath"];
        if(managePathDetail_InPathN != nil)
        {
            self.managePathDetail_InPath = [managePathDetail_InPathN intValue];
        }
        NSNumber *managePathDetailN = [dic objectForKey:@"managePathDetail"];
        if(managePathDetailN != nil)
        {
            self.managePathDetail = [managePathDetailN intValue];
        }
        NSNumber *stopNaviByTurnArrow_InPathN = [dic objectForKey:@"stopNaviByTurnArrow_InPath"];
        if(stopNaviByTurnArrow_InPathN != nil)
        {
            self.stopNaviByTurnArrow_InPath = [stopNaviByTurnArrow_InPathN intValue];
        }
        NSNumber *stopNaviByTurnArrowN = [dic objectForKey:@"stopNaviByTurnArrow"];
        if(stopNaviByTurnArrowN != nil)
        {
            self.stopNaviByTurnArrow = [stopNaviByTurnArrowN intValue];
        }
        NSNumber *stopNaviByManage_InPathN = [dic objectForKey:@"stopNaviByManage_InPath"];
        if(stopNaviByManage_InPathN != nil)
        {
            self.stopNaviByManage_InPath = [stopNaviByManage_InPathN intValue];
        }
        NSNumber *stopNaviByManageN = [dic objectForKey:@"stopNaviByManage"];
        if(stopNaviByManageN != nil)
        {
            self.stopNaviByManage = [stopNaviByManageN intValue];
        }
        NSNumber *simulatedNaviByOverview_InPathN = [dic objectForKey:@"simulatedNaviByOverview_InPath"];
        if(simulatedNaviByOverview_InPathN != nil)
        {
            self.simulatedNaviByOverview_InPath = [simulatedNaviByOverview_InPathN intValue];
        }
        NSNumber *simulatedNaviByOverviewN = [dic objectForKey:@"simulatedNaviByOverview"];
        if(simulatedNaviByOverviewN != nil)
        {
            self.simulatedNaviByOverview = [simulatedNaviByOverviewN intValue];
        }
        NSNumber *simulatedNaviByManage_InPathN = [dic objectForKey:@"simulatedNaviByManage_InPath"];
        if(simulatedNaviByManage_InPathN != nil)
        {
            self.simulatedNaviByManage_InPath = [simulatedNaviByManage_InPathN intValue];
        }
        NSNumber *simulatedNaviByManageN = [dic objectForKey:@"simulatedNaviByManage"];
        if(simulatedNaviByManageN != nil)
        {
            self.simulatedNaviByManage = [simulatedNaviByManageN intValue];
        }
        NSNumber *planningByManage_InPathN = [dic objectForKey:@"planningByManage_InPath"];
        if(planningByManage_InPathN != nil)
        {
            self.planningByManage_InPath = [planningByManage_InPathN intValue];
        }
        NSNumber *planningByManageN = [dic objectForKey:@"planningByManage"];
        if(planningByManageN != nil)
        {
            self.planningByManage = [planningByManageN intValue];
        }
        NSNumber *overviewByManage_InPathN = [dic objectForKey:@"overviewByManage_InPath"];
        if(overviewByManage_InPathN != nil)
        {
            self.overviewByManage_InPath = [overviewByManage_InPathN intValue];
        }
        NSNumber *overviewByManageN = [dic objectForKey:@"overviewByManage"];
        if(overviewByManageN != nil)
        {
            self.overviewByManage = [overviewByManageN intValue];
        }
        NSNumber *suggestedLtineraries_InPathN = [dic objectForKey:@"suggestedLtineraries_InPath"];
        if(suggestedLtineraries_InPathN != nil)
        {
            self.suggestedLtineraries_InPath = [suggestedLtineraries_InPathN intValue];
        }
        NSNumber *suggestedLtinerariesN = [dic objectForKey:@"suggestedLtineraries"];
        if(suggestedLtinerariesN != nil)
        {
            self.suggestedLtineraries = [suggestedLtinerariesN intValue];
        }
        NSNumber *highPriority_InPathN = [dic objectForKey:@"highPriority_InPath"];
        if(highPriority_InPathN != nil)
        {
            self.highPriority_InPath = [highPriority_InPathN intValue];
        }
        NSNumber *highPriorityN = [dic objectForKey:@"highPriority"];
        if(highPriorityN != nil)
        {
            self.highPriority = [highPriorityN intValue];
        }
        NSNumber *economicRoute_InPathN = [dic objectForKey:@"economicRoute_InPath"];
        if(economicRoute_InPathN != nil)
        {
            self.economicRoute_InPath = [economicRoute_InPathN intValue];
        }
        NSNumber *economicRouteN = [dic objectForKey:@"economicRoute"];
        if(economicRouteN != nil)
        {
            self.economicRoute = [economicRouteN intValue];
        }
        NSNumber *shortestRoute_InPathN = [dic objectForKey:@"shortestRoute_InPath"];
        if(shortestRoute_InPathN != nil)
        {
            self.shortestRoute_InPath = [shortestRoute_InPathN intValue];
        }
        NSNumber *shortestRouteN = [dic objectForKey:@"shortestRoute"];
        if(shortestRouteN != nil)
        {
            self.shortestRoute = [shortestRouteN intValue];
        }
        NSNumber *directionsContrast_InPathN = [dic objectForKey:@"directionsContrast_InPath"];
        if(directionsContrast_InPathN != nil)
        {
            self.directionsContrast_InPath = [directionsContrast_InPathN intValue];
        }
        NSNumber *directionsContrastN = [dic objectForKey:@"directionsContrast"];
        if(directionsContrastN != nil)
        {
            self.directionsContrast = [directionsContrastN intValue];
        }
        NSNumber *overviewViewFull_InPathN = [dic objectForKey:@"overviewViewFull_InPath"];
        if(overviewViewFull_InPathN != nil)
        {
            self.overviewViewFull_InPath = [overviewViewFull_InPathN intValue];
        }
        NSNumber *overviewViewFullN = [dic objectForKey:@"overviewViewFull"];
        if(overviewViewFullN != nil)
        {
            self.overviewViewFull = [overviewViewFullN intValue];
        }
        NSNumber *viewTripComputer_InPathN = [dic objectForKey:@"viewTripComputer_InPath"];
        if(viewTripComputer_InPathN != nil)
        {
            self.viewTripComputer_InPath = [viewTripComputer_InPathN intValue];
        }
        NSNumber *viewTripComputerN = [dic objectForKey:@"viewTripComputer"];
        if(viewTripComputerN != nil)
        {
            self.viewTripComputer = [viewTripComputerN intValue];
        }
        NSNumber *enlargeByButton_InPathN = [dic objectForKey:@"enlargeByButton_InPath"];
        if(enlargeByButton_InPathN != nil)
        {
            self.enlargeByButton_InPath = [enlargeByButton_InPathN intValue];
        }
        NSNumber *enlargeByButtonN = [dic objectForKey:@"enlargeByButton"];
        if(enlargeByButtonN != nil)
        {
            self.enlargeByButton = [enlargeByButtonN intValue];
        }
        NSNumber *narrowByButton_InPathN = [dic objectForKey:@"narrowByButton_InPath"];
        if(narrowByButton_InPathN != nil)
        {
            self.narrowByButton_InPath = [narrowByButton_InPathN intValue];
        }
        NSNumber *narrowByButtonN = [dic objectForKey:@"narrowByButton"];
        if(narrowByButtonN != nil)
        {
            self.narrowByButton = [narrowByButtonN intValue];
        }
        NSNumber *enlargeByDoubleClick_InPathN = [dic objectForKey:@"enlargeByDoubleClick_InPath"];
        if(enlargeByDoubleClick_InPathN != nil)
        {
            self.enlargeByDoubleClick_InPath = [enlargeByDoubleClick_InPathN intValue];
        }
        NSNumber *enlargeByDoubleClickN = [dic objectForKey:@"enlargeByDoubleClick"];
        if(enlargeByDoubleClickN != nil)
        {
            self.enlargeByDoubleClick = [enlargeByDoubleClickN intValue];
        }
        NSNumber *narrowByTwoFingerClick_InPathN = [dic objectForKey:@"narrowByTwoFingerClick_InPath"];
        if(narrowByTwoFingerClick_InPathN != nil)
        {
            self.narrowByTwoFingerClick_InPath = [narrowByTwoFingerClick_InPathN intValue];
        }
        NSNumber *narrowByTwoFingerClickN = [dic objectForKey:@"narrowByTwoFingerClick"];
        if(narrowByTwoFingerClickN != nil)
        {
            self.narrowByTwoFingerClick = [narrowByTwoFingerClickN intValue];
        }
        NSNumber *enlargeByPinOpen_InPathN = [dic objectForKey:@"enlargeByPinOpen_InPath"];
        if(enlargeByPinOpen_InPathN != nil)
        {
            self.enlargeByPinOpen_InPath = [enlargeByPinOpen_InPathN intValue];
        }
        NSNumber *enlargeByPinOpenN = [dic objectForKey:@"enlargeByPinOpen"];
        if(enlargeByPinOpenN != nil)
        {
            self.enlargeByPinOpen = [enlargeByPinOpenN intValue];
        }
        NSNumber *narrowByPinKneading_InPathN = [dic objectForKey:@"narrowByPinKneading_InPath"];
        if(narrowByPinKneading_InPathN != nil)
        {
            self.narrowByPinKneading_InPath = [narrowByPinKneading_InPathN intValue];
        }
        NSNumber *narrowByPinKneadingN = [dic objectForKey:@"narrowByPinKneading"];
        if(narrowByPinKneadingN != nil)
        {
            self.narrowByPinKneading = [narrowByPinKneadingN intValue];
        }
        NSNumber *favoriteCurrentPoint_InPathN = [dic objectForKey:@"favoriteCurrentPoint_InPath"];
        if(favoriteCurrentPoint_InPathN != nil)
        {
            self.favoriteCurrentPoint_InPath = [favoriteCurrentPoint_InPathN intValue];
        }
        NSNumber *favoriteCurrentPointN = [dic objectForKey:@"favoriteCurrentPoint"];
        if(favoriteCurrentPointN != nil)
        {
            self.favoriteCurrentPoint = [favoriteCurrentPointN intValue];
        }
        NSNumber *messageBox_InPathN = [dic objectForKey:@"messageBox_InPath"];
        if(messageBox_InPathN != nil)
        {
            self.messageBox_InPath = [messageBox_InPathN intValue];
        }
        NSNumber *messageBoxN = [dic objectForKey:@"messageBox"];
        if(messageBoxN != nil)
        {
            self.messageBox = [messageBoxN intValue];
        }
        NSNumber *pathManage_InPathN = [dic objectForKey:@"pathManage_InPath"];
        if(pathManage_InPathN != nil)
        {
            self.pathManage_InPath = [pathManage_InPathN intValue];
        }
        NSNumber *pathManageN = [dic objectForKey:@"pathManage"];
        if(pathManageN != nil)
        {
            self.pathManage = [pathManageN intValue];
        }
        NSNumber *switchMainAndSideRoads_InPathN = [dic objectForKey:@"switchMainAndSideRoads_InPath"];
        if(switchMainAndSideRoads_InPathN != nil)
        {
            self.switchMainAndSideRoads_InPath = [switchMainAndSideRoads_InPathN intValue];
        }
        NSNumber *switchMainAndSideRoadsN = [dic objectForKey:@"switchMainAndSideRoads"];
        if(switchMainAndSideRoadsN != nil)
        {
            self.switchMainAndSideRoads = [switchMainAndSideRoadsN intValue];
        }
        NSNumber *trafficIncident_InPathN = [dic objectForKey:@"trafficIncident_InPath"];
        if(trafficIncident_InPathN != nil)
        {
            self.trafficIncident_InPath = [trafficIncident_InPathN intValue];
        }
        NSNumber *trafficIncidentN = [dic objectForKey:@"trafficIncident"];
        if(trafficIncidentN != nil)
        {
            self.trafficIncident = [trafficIncidentN intValue];
        }
        NSNumber *feedback_InPathN = [dic objectForKey:@"feedback_InPath"];
        if(feedback_InPathN != nil)
        {
            self.feedback_InPath = [feedback_InPathN intValue];
        }
        NSNumber *feedbackN = [dic objectForKey:@"feedback"];
        if(feedbackN != nil)
        {
            self.feedback = [feedbackN intValue];
        }
        NSNumber *trafficEventDisplay_InPathN = [dic objectForKey:@"trafficEventDisplay_InPath"];
        if(trafficEventDisplay_InPathN != nil)
        {
            self.trafficEventDisplay_InPath = [trafficEventDisplay_InPathN intValue];
        }
        NSNumber *trafficEventDisplayN = [dic objectForKey:@"trafficEventDisplay"];
        if(trafficEventDisplayN != nil)
        {
            self.trafficEventDisplay = [trafficEventDisplayN intValue];
        }
        NSNumber *networkNavi_InPathN = [dic objectForKey:@"networkNavi_InPath"];
        if(networkNavi_InPathN != nil)
        {
            self.networkNavi_InPath = [networkNavi_InPathN intValue];
        }
        NSNumber *networkNaviN = [dic objectForKey:@"networkNavi"];
        if(networkNaviN != nil)
        {
            self.networkNavi = [networkNaviN intValue];
        }
        NSNumber *networkNaviSeconds_InPathN = [dic objectForKey:@"networkNaviSeconds_InPath"];
        if(networkNaviSeconds_InPathN != nil)
        {
            self.networkNaviSeconds_InPath = [networkNaviSeconds_InPathN intValue];
        }
        NSNumber *networkNaviSecondsN = [dic objectForKey:@"networkNaviSeconds"];
        if(networkNaviSecondsN != nil)
        {
            self.networkNaviSeconds = [networkNaviSecondsN intValue];
        }
        NSNumber *CPCNavi_InPathN = [dic objectForKey:@"CPCNavi_InPath"];
        if(CPCNavi_InPathN != nil)
        {
            self.CPCNavi_InPath = [CPCNavi_InPathN intValue];
        }
        NSNumber *CPCNaviN = [dic objectForKey:@"CPCNavi"];
        if(CPCNaviN != nil)
        {
            self.CPCNavi = [CPCNaviN intValue];
        }
        NSNumber *CPCNaviSeconds_InPathN = [dic objectForKey:@"CPCNaviSeconds_InPath"];
        if(CPCNaviSeconds_InPathN != nil)
        {
            self.CPCNaviSeconds_InPath = [CPCNaviSeconds_InPathN intValue];
        }
        NSNumber *CPCNaviSecondsN = [dic objectForKey:@"CPCNaviSeconds"];
        if(CPCNaviSecondsN != nil)
        {
            self.CPCNaviSeconds = [CPCNaviSecondsN intValue];
        }
        NSNumber *horizontalScreenSeconds_InPathN = [dic objectForKey:@"horizontalScreenSeconds_InPath"];
        if(horizontalScreenSeconds_InPathN != nil)
        {
            self.horizontalScreenSeconds_InPath = [horizontalScreenSeconds_InPathN intValue];
        }
        NSNumber *horizontalScreenSecondsN = [dic objectForKey:@"horizontalScreenSeconds"];
        if(horizontalScreenSecondsN != nil)
        {
            self.horizontalScreenSeconds = [horizontalScreenSecondsN intValue];
        }
        NSNumber *verticalScreenSeconds_InPathN = [dic objectForKey:@"verticalScreenSeconds_InPath"];
        if(verticalScreenSeconds_InPathN != nil)
        {
            self.verticalScreenSeconds_InPath = [verticalScreenSeconds_InPathN intValue];
        }
        NSNumber *verticalScreenSecondsN = [dic objectForKey:@"verticalScreenSeconds"];
        if(verticalScreenSecondsN != nil)
        {
            self.verticalScreenSeconds = [verticalScreenSecondsN intValue];
        }
        NSNumber *mapProportion_25_InPathN = [dic objectForKey:@"mapProportion_25_InPath"];
        if(mapProportion_25_InPathN != nil)
        {
            self.mapProportion_25_InPath = [mapProportion_25_InPathN intValue];
        }
        NSNumber *mapProportion_25N = [dic objectForKey:@"mapProportion_25"];
        if(mapProportion_25N != nil)
        {
            self.mapProportion_25 = [mapProportion_25N intValue];
        }
        NSNumber *mapProportion_50_InPathN = [dic objectForKey:@"mapProportion_50_InPath"];
        if(mapProportion_50_InPathN != nil)
        {
            self.mapProportion_50_InPath = [mapProportion_50_InPathN intValue];
        }
        NSNumber *mapProportion_50N = [dic objectForKey:@"mapProportion_50"];
        if(mapProportion_50N != nil)
        {
            self.mapProportion_50 = [mapProportion_50N intValue];
        }
        NSNumber *mapProportion_100_InPathN = [dic objectForKey:@"mapProportion_100_InPath"];
        if(mapProportion_100_InPathN != nil)
        {
            self.mapProportion_100_InPath = [mapProportion_100_InPathN intValue];
        }
        NSNumber *mapProportion_100N = [dic objectForKey:@"mapProportion_100"];
        if(mapProportion_100N != nil)
        {
            self.mapProportion_100 = [mapProportion_100N intValue];
        }
        NSNumber *mapProportion_200_InPathN = [dic objectForKey:@"mapProportion_200_InPath"];
        if(mapProportion_200_InPathN != nil)
        {
            self.mapProportion_200_InPath = [mapProportion_200_InPathN intValue];
        }
        NSNumber *mapProportion_200N = [dic objectForKey:@"mapProportion_200"];
        if(mapProportion_200N != nil)
        {
            self.mapProportion_200 = [mapProportion_200N intValue];
        }
        NSNumber *mapProportion_500_InPathN = [dic objectForKey:@"mapProportion_500_InPath"];
        if(mapProportion_500_InPathN != nil)
        {
            self.mapProportion_500_InPath = [mapProportion_500_InPathN intValue];
        }
        NSNumber *mapProportion_500N = [dic objectForKey:@"mapProportion_500"];
        if(mapProportion_500N != nil)
        {
            self.mapProportion_500 = [mapProportion_500N intValue];
        }
        NSNumber *mapProportion_1k_InPathN = [dic objectForKey:@"mapProportion_1k_InPath"];
        if(mapProportion_1k_InPathN != nil)
        {
            self.mapProportion_1k_InPath = [mapProportion_1k_InPathN intValue];
        }
        NSNumber *mapProportion_1kN = [dic objectForKey:@"mapProportion_1k"];
        if(mapProportion_1kN != nil)
        {
            self.mapProportion_1k = [mapProportion_1kN intValue];
        }
        NSNumber *mapProportion_2k_InPathN = [dic objectForKey:@"mapProportion_2k_InPath"];
        if(mapProportion_2k_InPathN != nil)
        {
            self.mapProportion_2k_InPath = [mapProportion_2k_InPathN intValue];
        }
        NSNumber *mapProportion_2kN = [dic objectForKey:@"mapProportion_2k"];
        if(mapProportion_2kN != nil)
        {
            self.mapProportion_2k = [mapProportion_2kN intValue];
        }
        NSNumber *mapProportion_5k_InPathN = [dic objectForKey:@"mapProportion_5k_InPath"];
        if(mapProportion_5k_InPathN != nil)
        {
            self.mapProportion_5k_InPath = [mapProportion_5k_InPathN intValue];
        }
        NSNumber *mapProportion_5kN = [dic objectForKey:@"mapProportion_5k"];
        if(mapProportion_5kN != nil)
        {
            self.mapProportion_5k = [mapProportion_5kN intValue];
        }
        NSNumber *mapProportion_10k_InPathN = [dic objectForKey:@"mapProportion_10k_InPath"];
        if(mapProportion_10k_InPathN != nil)
        {
            self.mapProportion_10k_InPath = [mapProportion_10k_InPathN intValue];
        }
        NSNumber *mapProportion_10kN = [dic objectForKey:@"mapProportion_10k"];
        if(mapProportion_10kN != nil)
        {
            self.mapProportion_10k = [mapProportion_10kN intValue];
        }
        NSNumber *mapProportion_50k_InPathN = [dic objectForKey:@"mapProportion_50k_InPath"];
        if(mapProportion_50k_InPathN != nil)
        {
            self.mapProportion_50k_InPath = [mapProportion_50k_InPathN intValue];
        }
        NSNumber *mapProportion_50kN = [dic objectForKey:@"mapProportion_50k"];
        if(mapProportion_50kN != nil)
        {
            self.mapProportion_50k = [mapProportion_50kN intValue];
        }
        NSNumber *mapProportion_200k_InPathN = [dic objectForKey:@"mapProportion_200k_InPath"];
        if(mapProportion_200k_InPathN != nil)
        {
            self.mapProportion_200k_InPath = [mapProportion_200k_InPathN intValue];
        }
        NSNumber *mapProportion_200kN = [dic objectForKey:@"mapProportion_200k"];
        if(mapProportion_200kN != nil)
        {
            self.mapProportion_200k = [mapProportion_200kN intValue];
        }
        NSNumber *mapProportion_500k_InPathN = [dic objectForKey:@"mapProportion_500k_InPath"];
        if(mapProportion_500k_InPathN != nil)
        {
            self.mapProportion_500k_InPath = [mapProportion_500k_InPathN intValue];
        }
        NSNumber *mapProportion_500kN = [dic objectForKey:@"mapProportion_500k"];
        if(mapProportion_500kN != nil)
        {
            self.mapProportion_500k = [mapProportion_500kN intValue];
        }
        NSNumber *openEnglishVersionSeconds_InPathN = [dic objectForKey:@"openEnglishVersionSeconds_InPath"];
        if(openEnglishVersionSeconds_InPathN != nil)
        {
            self.openEnglishVersionSeconds_InPath = [openEnglishVersionSeconds_InPathN intValue];
        }
        NSNumber *openEnglishVersionSecondsN = [dic objectForKey:@"openEnglishVersionSeconds"];
        if(openEnglishVersionSecondsN != nil)
        {
            self.openEnglishVersionSeconds = [openEnglishVersionSecondsN intValue];
        }
        
        //------------自动生成
        
        
        NSNumber *manualSearch_InPathN = [dic objectForKey:@"manualSearch_InPath"];
        if(manualSearch_InPathN != nil)
        {
            self.manualSearch_InPath = [manualSearch_InPathN intValue];
        }
        NSNumber *manualSearchN = [dic objectForKey:@"manualSearch"];
        if(manualSearchN != nil)
        {
            self.manualSearch = [manualSearchN intValue];
        }
        NSNumber *smartSearch_InPathN = [dic objectForKey:@"smartSearch_InPath"];
        if(smartSearch_InPathN != nil)
        {
            self.smartSearch_InPath = [smartSearch_InPathN intValue];
        }
        NSNumber *smartSearchN = [dic objectForKey:@"smartSearch"];
        if(smartSearchN != nil)
        {
            self.smartSearch = [smartSearchN intValue];
        }
        NSNumber *networkSearch_InPathN = [dic objectForKey:@"networkSearch_InPath"];
        if(networkSearch_InPathN != nil)
        {
            self.networkSearch_InPath = [networkSearch_InPathN intValue];
        }
        NSNumber *networkSearchN = [dic objectForKey:@"networkSearch"];
        if(networkSearchN != nil)
        {
            self.networkSearch = [networkSearchN intValue];
        }
        NSNumber *voiceSearchSide_InPathN = [dic objectForKey:@"voiceSearchSide_InPath"];
        if(voiceSearchSide_InPathN != nil)
        {
            self.voiceSearchSide_InPath = [voiceSearchSide_InPathN intValue];
        }
        NSNumber *voiceSearchSideN = [dic objectForKey:@"voiceSearchSide"];
        if(voiceSearchSideN != nil)
        {
            self.voiceSearchSide = [voiceSearchSideN intValue];
        }
        NSNumber *peripherySearch_InPathN = [dic objectForKey:@"peripherySearch_InPath"];
        if(peripherySearch_InPathN != nil)
        {
            self.peripherySearch_InPath = [peripherySearch_InPathN intValue];
        }
        NSNumber *peripherySearchN = [dic objectForKey:@"peripherySearch"];
        if(peripherySearchN != nil)
        {
            self.peripherySearch = [peripherySearchN intValue];
        }
        NSNumber *figureMapSetEnd_InPathN = [dic objectForKey:@"figureMapSetEnd_InPath"];
        if(figureMapSetEnd_InPathN != nil)
        {
            self.figureMapSetEnd_InPath = [figureMapSetEnd_InPathN intValue];
        }
        NSNumber *figureMapSetEndN = [dic objectForKey:@"figureMapSetEnd"];
        if(figureMapSetEndN != nil)
        {
            self.figureMapSetEnd = [figureMapSetEndN intValue];
        }
        NSNumber *historyDestinnation_InPathN = [dic objectForKey:@"historyDestinnation_InPath"];
        if(historyDestinnation_InPathN != nil)
        {
            self.historyDestinnation_InPath = [historyDestinnation_InPathN intValue];
        }
        NSNumber *historyDestinnationN = [dic objectForKey:@"historyDestinnation"];
        if(historyDestinnationN != nil)
        {
            self.historyDestinnation = [historyDestinnationN intValue];
        }
        NSNumber *addressBook_InPathN = [dic objectForKey:@"addressBook_InPath"];
        if(addressBook_InPathN != nil)
        {
            self.addressBook_InPath = [addressBook_InPathN intValue];
        }
        NSNumber *addressBookN = [dic objectForKey:@"addressBook"];
        if(addressBookN != nil)
        {
            self.addressBook = [addressBookN intValue];
        }
        NSNumber *contactsNavigation_InPathN = [dic objectForKey:@"contactsNavigation_InPath"];
        if(contactsNavigation_InPathN != nil)
        {
            self.contactsNavigation_InPath = [contactsNavigation_InPathN intValue];
        }
        NSNumber *contactsNavigationN = [dic objectForKey:@"contactsNavigation"];
        if(contactsNavigationN != nil)
        {
            self.contactsNavigation = [contactsNavigationN intValue];
        }
        NSNumber *routeDetailsOverview_InPathN = [dic objectForKey:@"routeDetailsOverview_InPath"];
        if(routeDetailsOverview_InPathN != nil)
        {
            self.routeDetailsOverview_InPath = [routeDetailsOverview_InPathN intValue];
        }
        NSNumber *routeDetailsOverviewN = [dic objectForKey:@"routeDetailsOverview"];
        if(routeDetailsOverviewN != nil)
        {
            self.routeDetailsOverview = [routeDetailsOverviewN intValue];
        }
        NSNumber *overviewNextWay_InPathN = [dic objectForKey:@"overviewNextWay_InPath"];
        if(overviewNextWay_InPathN != nil)
        {
            self.overviewNextWay_InPath = [overviewNextWay_InPathN intValue];
        }
        NSNumber *overviewNextWayN = [dic objectForKey:@"overviewNextWay"];
        if(overviewNextWayN != nil)
        {
            self.overviewNextWay = [overviewNextWayN intValue];
        }
        NSNumber *shareLocationBySMS_InPathN = [dic objectForKey:@"shareLocationBySMS_InPath"];
        if(shareLocationBySMS_InPathN != nil)
        {
            self.shareLocationBySMS_InPath = [shareLocationBySMS_InPathN intValue];
        }
        NSNumber *shareLocationBySMSN = [dic objectForKey:@"shareLocationBySMS"];
        if(shareLocationBySMSN != nil)
        {
            self.shareLocationBySMS = [shareLocationBySMSN intValue];
        }
        NSNumber *shareLocationByEmail_InPathN = [dic objectForKey:@"shareLocationByEmail_InPath"];
        if(shareLocationByEmail_InPathN != nil)
        {
            self.shareLocationByEmail_InPath = [shareLocationByEmail_InPathN intValue];
        }
        NSNumber *shareLocationByEmailN = [dic objectForKey:@"shareLocationByEmail"];
        if(shareLocationByEmailN != nil)
        {
            self.shareLocationByEmail = [shareLocationByEmailN intValue];
        }
        NSNumber *shareLocationBySina_InPathN = [dic objectForKey:@"shareLocationBySina_InPath"];
        if(shareLocationBySina_InPathN != nil)
        {
            self.shareLocationBySina_InPath = [shareLocationBySina_InPathN intValue];
        }
        NSNumber *shareLocationBySinaN = [dic objectForKey:@"shareLocationBySina"];
        if(shareLocationBySinaN != nil)
        {
            self.shareLocationBySina = [shareLocationBySinaN intValue];
        }
        NSNumber *shareLocationByTX_InPathN = [dic objectForKey:@"shareLocationByTX_InPath"];
        if(shareLocationByTX_InPathN != nil)
        {
            self.shareLocationByTX_InPath = [shareLocationByTX_InPathN intValue];
        }
        NSNumber *shareLocationByTXN = [dic objectForKey:@"shareLocationByTX"];
        if(shareLocationByTXN != nil)
        {
            self.shareLocationByTX = [shareLocationByTXN intValue];
        }
        NSNumber *microShareLocation_InPathN = [dic objectForKey:@"microShareLocation_InPath"];
        if(microShareLocation_InPathN != nil)
        {
            self.microShareLocation_InPath = [microShareLocation_InPathN intValue];
        }
        NSNumber *microShareLocationN = [dic objectForKey:@"microShareLocation"];
        if(microShareLocationN != nil)
        {
            self.microShareLocation = [microShareLocationN intValue];
        }
        NSNumber *northUpView_InPathN = [dic objectForKey:@"northUpView_InPath"];
        if(northUpView_InPathN != nil)
        {
            self.northUpView_InPath = [northUpView_InPathN intValue];
        }
        NSNumber *northUpViewN = [dic objectForKey:@"northUpView"];
        if(northUpViewN != nil)
        {
            self.northUpView = [northUpViewN intValue];
        }
        NSNumber *northUpViewSeconds_InPathN = [dic objectForKey:@"northUpViewSeconds_InPath"];
        if(northUpViewSeconds_InPathN != nil)
        {
            self.northUpViewSeconds_InPath = [northUpViewSeconds_InPathN intValue];
        }
        NSNumber *northUpViewSecondsN = [dic objectForKey:@"northUpViewSeconds"];
        if(northUpViewSecondsN != nil)
        {
            self.northUpViewSeconds = [northUpViewSecondsN intValue];
        }
        NSNumber *upView_InPathN = [dic objectForKey:@"upView_InPath"];
        if(upView_InPathN != nil)
        {
            self.upView_InPath = [upView_InPathN intValue];
        }
        NSNumber *upViewN = [dic objectForKey:@"upView"];
        if(upViewN != nil)
        {
            self.upView = [upViewN intValue];
        }
        NSNumber *upViewSeconds_InPathN = [dic objectForKey:@"upViewSeconds_InPath"];
        if(upViewSeconds_InPathN != nil)
        {
            self.upViewSeconds_InPath = [upViewSeconds_InPathN intValue];
        }
        NSNumber *upViewSecondsN = [dic objectForKey:@"upViewSeconds"];
        if(upViewSecondsN != nil)
        {
            self.upViewSeconds = [upViewSecondsN intValue];
        }
        NSNumber *car3DView_InPathN = [dic objectForKey:@"car3DView_InPath"];
        if(car3DView_InPathN != nil)
        {
            self.car3DView_InPath = [car3DView_InPathN intValue];
        }
        NSNumber *car3DViewN = [dic objectForKey:@"car3DView"];
        if(car3DViewN != nil)
        {
            self.car3DView = [car3DViewN intValue];
        }
        NSNumber *car3DViewSeconds_InPathN = [dic objectForKey:@"car3DViewSeconds_InPath"];
        if(car3DViewSeconds_InPathN != nil)
        {
            self.car3DViewSeconds_InPath = [car3DViewSeconds_InPathN intValue];
        }
        NSNumber *car3DViewSecondsN = [dic objectForKey:@"car3DViewSeconds"];
        if(car3DViewSecondsN != nil)
        {
            self.car3DViewSeconds = [car3DViewSecondsN intValue];
        }
        NSNumber *realTimeTraffic_InPathN = [dic objectForKey:@"realTimeTraffic_InPath"];
        if(realTimeTraffic_InPathN != nil)
        {
            self.realTimeTraffic_InPath = [realTimeTraffic_InPathN intValue];
        }
        NSNumber *realTimeTrafficN = [dic objectForKey:@"realTimeTraffic"];
        if(realTimeTrafficN != nil)
        {
            self.realTimeTraffic = [realTimeTrafficN intValue];
        }
        NSNumber *trafficInformation_InPathN = [dic objectForKey:@"trafficInformation_InPath"];
        if(trafficInformation_InPathN != nil)
        {
            self.trafficInformation_InPath = [trafficInformation_InPathN intValue];
        }
        NSNumber *trafficInformationN = [dic objectForKey:@"trafficInformation"];
        if(trafficInformationN != nil)
        {
            self.trafficInformation = [trafficInformationN intValue];
        }
        NSNumber *smartDrivingServices_InPathN = [dic objectForKey:@"smartDrivingServices_InPath"];
        if(smartDrivingServices_InPathN != nil)
        {
            self.smartDrivingServices_InPath = [smartDrivingServices_InPathN intValue];
        }
        NSNumber *smartDrivingServicesN = [dic objectForKey:@"smartDrivingServices"];
        if(smartDrivingServicesN != nil)
        {
            self.smartDrivingServices = [smartDrivingServicesN intValue];
        }
        NSNumber *smartDriveSetDestination_InPathN = [dic objectForKey:@"smartDriveSetDestination_InPath"];
        if(smartDriveSetDestination_InPathN != nil)
        {
            self.smartDriveSetDestination_InPath = [smartDriveSetDestination_InPathN intValue];
        }
        NSNumber *smartDriveSetDestinationN = [dic objectForKey:@"smartDriveSetDestination"];
        if(smartDriveSetDestinationN != nil)
        {
            self.smartDriveSetDestination = [smartDriveSetDestinationN intValue];
        }
        NSNumber *layerByCtripOnline_InPathN = [dic objectForKey:@"layerByCtripOnline_InPath"];
        if(layerByCtripOnline_InPathN != nil)
        {
            self.layerByCtripOnline_InPath = [layerByCtripOnline_InPathN intValue];
        }
        NSNumber *layerByCtripOnlineN = [dic objectForKey:@"layerByCtripOnline"];
        if(layerByCtripOnlineN != nil)
        {
            self.layerByCtripOnline = [layerByCtripOnlineN intValue];
        }
        NSNumber *layerByCtripPhone_InPathN = [dic objectForKey:@"layerByCtripPhone_InPath"];
        if(layerByCtripPhone_InPathN != nil)
        {
            self.layerByCtripPhone_InPath = [layerByCtripPhone_InPathN intValue];
        }
        NSNumber *layerByCtripPhoneN = [dic objectForKey:@"layerByCtripPhone"];
        if(layerByCtripPhoneN != nil)
        {
            self.layerByCtripPhone = [layerByCtripPhoneN intValue];
        }
        NSNumber *layerByCtripOnlineSeconds_InPathN = [dic objectForKey:@"layerByCtripOnlineSeconds_InPath"];
        if(layerByCtripOnlineSeconds_InPathN != nil)
        {
            self.layerByCtripOnlineSeconds_InPath = [layerByCtripOnlineSeconds_InPathN intValue];
        }
        NSNumber *layerByCtripOnlineSecondsN = [dic objectForKey:@"layerByCtripOnlineSeconds"];
        if(layerByCtripOnlineSecondsN != nil)
        {
            self.layerByCtripOnlineSeconds = [layerByCtripOnlineSecondsN intValue];
        }
        NSNumber *layerByTravel_InPathN = [dic objectForKey:@"layerByTravel_InPath"];
        if(layerByTravel_InPathN != nil)
        {
            self.layerByTravel_InPath = [layerByTravel_InPathN intValue];
        }
        NSNumber *layerByTravelN = [dic objectForKey:@"layerByTravel"];
        if(layerByTravelN != nil)
        {
            self.layerByTravel = [layerByTravelN intValue];
        }
        NSNumber *layerByTravelSeconds_InPathN = [dic objectForKey:@"layerByTravelSeconds_InPath"];
        if(layerByTravelSeconds_InPathN != nil)
        {
            self.layerByTravelSeconds_InPath = [layerByTravelSeconds_InPathN intValue];
        }
        NSNumber *layerByTravelSecondsN = [dic objectForKey:@"layerByTravelSeconds"];
        if(layerByTravelSecondsN != nil)
        {
            self.layerByTravelSeconds = [layerByTravelSecondsN intValue];
        }
        NSNumber *layerByFood_InPathN = [dic objectForKey:@"layerByFood_InPath"];
        if(layerByFood_InPathN != nil)
        {
            self.layerByFood_InPath = [layerByFood_InPathN intValue];
        }
        NSNumber *layerByFoodN = [dic objectForKey:@"layerByFood"];
        if(layerByFoodN != nil)
        {
            self.layerByFood = [layerByFoodN intValue];
        }
        NSNumber *layerByFoodSeconds_InPathN = [dic objectForKey:@"layerByFoodSeconds_InPath"];
        if(layerByFoodSeconds_InPathN != nil)
        {
            self.layerByFoodSeconds_InPath = [layerByFoodSeconds_InPathN intValue];
        }
        NSNumber *layerByFoodSecondsN = [dic objectForKey:@"layerByFoodSeconds"];
        if(layerByFoodSecondsN != nil)
        {
            self.layerByFoodSeconds = [layerByFoodSecondsN intValue];
        }
        NSNumber *layerByGolf_InPathN = [dic objectForKey:@"layerByGolf_InPath"];
        if(layerByGolf_InPathN != nil)
        {
            self.layerByGolf_InPath = [layerByGolf_InPathN intValue];
        }
        NSNumber *layerByGolfN = [dic objectForKey:@"layerByGolf"];
        if(layerByGolfN != nil)
        {
            self.layerByGolf = [layerByGolfN intValue];
        }
        NSNumber *layerByGolfSeconds_InPathN = [dic objectForKey:@"layerByGolfSeconds_InPath"];
        if(layerByGolfSeconds_InPathN != nil)
        {
            self.layerByGolfSeconds_InPath = [layerByGolfSeconds_InPathN intValue];
        }
        NSNumber *layerByGolfSecondsN = [dic objectForKey:@"layerByGolfSeconds"];
        if(layerByGolfSecondsN != nil)
        {
            self.layerByGolfSeconds = [layerByGolfSecondsN intValue];
        }
        NSNumber *layerByMyself_InPathN = [dic objectForKey:@"layerByMyself_InPath"];
        if(layerByMyself_InPathN != nil)
        {
            self.layerByMyself_InPath = [layerByMyself_InPathN intValue];
        }
        NSNumber *layerByMyselfN = [dic objectForKey:@"layerByMyself"];
        if(layerByMyselfN != nil)
        {
            self.layerByMyself = [layerByMyselfN intValue];
        }
        NSNumber *layerByMyselfSeconds_InPathN = [dic objectForKey:@"layerByMyselfSeconds_InPath"];
        if(layerByMyselfSeconds_InPathN != nil)
        {
            self.layerByMyselfSeconds_InPath = [layerByMyselfSeconds_InPathN intValue];
        }
        NSNumber *layerByMyselfSecondsN = [dic objectForKey:@"layerByMyselfSeconds"];
        if(layerByMyselfSecondsN != nil)
        {
            self.layerByMyselfSeconds = [layerByMyselfSecondsN intValue];
        }
        NSNumber *layerByFriendsShare_InPathN = [dic objectForKey:@"layerByFriendsShare_InPath"];
        if(layerByFriendsShare_InPathN != nil)
        {
            self.layerByFriendsShare_InPath = [layerByFriendsShare_InPathN intValue];
        }
        NSNumber *layerByFriendsShareN = [dic objectForKey:@"layerByFriendsShare"];
        if(layerByFriendsShareN != nil)
        {
            self.layerByFriendsShare = [layerByFriendsShareN intValue];
        }
        NSNumber *layerByFriendsShareSeconds_InPathN = [dic objectForKey:@"layerByFriendsShareSeconds_InPath"];
        if(layerByFriendsShareSeconds_InPathN != nil)
        {
            self.layerByFriendsShareSeconds_InPath = [layerByFriendsShareSeconds_InPathN intValue];
        }
        NSNumber *layerByFriendsShareSecondsN = [dic objectForKey:@"layerByFriendsShareSeconds"];
        if(layerByFriendsShareSecondsN != nil)
        {
            self.layerByFriendsShareSeconds = [layerByFriendsShareSecondsN intValue];
        }
        NSNumber *layerByGDShare_InPathN = [dic objectForKey:@"layerByGDShare_InPath"];
        if(layerByGDShare_InPathN != nil)
        {
            self.layerByGDShare_InPath = [layerByGDShare_InPathN intValue];
        }
        NSNumber *layerByGDShareN = [dic objectForKey:@"layerByGDShare"];
        if(layerByGDShareN != nil)
        {
            self.layerByGDShare = [layerByGDShareN intValue];
        }
        NSNumber *layerByGDShareSeconds_InPathN = [dic objectForKey:@"layerByGDShareSeconds_InPath"];
        if(layerByGDShareSeconds_InPathN != nil)
        {
            self.layerByGDShareSeconds_InPath = [layerByGDShareSeconds_InPathN intValue];
        }
        NSNumber *layerByGDShareSecondsN = [dic objectForKey:@"layerByGDShareSeconds"];
        if(layerByGDShareSecondsN != nil)
        {
            self.layerByGDShareSeconds = [layerByGDShareSecondsN intValue];
        }
        NSNumber *goHome_InPathN = [dic objectForKey:@"goHome_InPath"];
        if(goHome_InPathN != nil)
        {
            self.goHome_InPath = [goHome_InPathN intValue];
        }
        NSNumber *goHomeN = [dic objectForKey:@"goHome"];
        if(goHomeN != nil)
        {
            self.goHome = [goHomeN intValue];
        }
        NSNumber *backCompany_InPathN = [dic objectForKey:@"backCompany_InPath"];
        if(backCompany_InPathN != nil)
        {
            self.backCompany_InPath = [backCompany_InPathN intValue];
        }
        NSNumber *backCompanyN = [dic objectForKey:@"backCompany"];
        if(backCompanyN != nil)
        {
            self.backCompany = [backCompanyN intValue];
        }
        NSNumber *avoidTraffice_InPathN = [dic objectForKey:@"avoidTraffice_InPath"];
        if(avoidTraffice_InPathN != nil)
        {
            self.avoidTraffice_InPath = [avoidTraffice_InPathN intValue];
        }
        NSNumber *avoidTrafficeN = [dic objectForKey:@"avoidTraffice"];
        if(avoidTrafficeN != nil)
        {
            self.avoidTraffice = [avoidTrafficeN intValue];
        }
        NSNumber *avoidRouteDetail_InPathN = [dic objectForKey:@"avoidRouteDetail_InPath"];
        if(avoidRouteDetail_InPathN != nil)
        {
            self.avoidRouteDetail_InPath = [avoidRouteDetail_InPathN intValue];
        }
        NSNumber *avoidRouteDetailN = [dic objectForKey:@"avoidRouteDetail"];
        if(avoidRouteDetailN != nil)
        {
            self.avoidRouteDetail = [avoidRouteDetailN intValue];
        }
        NSNumber *beforeAvoid_InPathN = [dic objectForKey:@"beforeAvoid_InPath"];
        if(beforeAvoid_InPathN != nil)
        {
            self.beforeAvoid_InPath = [beforeAvoid_InPathN intValue];
        }
        NSNumber *beforeAvoidN = [dic objectForKey:@"beforeAvoid"];
        if(beforeAvoidN != nil)
        {
            self.beforeAvoid = [beforeAvoidN intValue];
        }
        NSNumber *afterAvoid_InPathN = [dic objectForKey:@"afterAvoid_InPath"];
        if(afterAvoid_InPathN != nil)
        {
            self.afterAvoid_InPath = [afterAvoid_InPathN intValue];
        }
        NSNumber *afterAvoidN = [dic objectForKey:@"afterAvoid"];
        if(afterAvoidN != nil)
        {
            self.afterAvoid = [afterAvoidN intValue];
        }
        NSNumber *cancelAvoid_InPathN = [dic objectForKey:@"cancelAvoid_InPath"];
        if(cancelAvoid_InPathN != nil)
        {
            self.cancelAvoid_InPath = [cancelAvoid_InPathN intValue];
        }
        NSNumber *cancelAvoidN = [dic objectForKey:@"cancelAvoid"];
        if(cancelAvoidN != nil)
        {
            self.cancelAvoid = [cancelAvoidN intValue];
        }
        NSNumber *routingFunction_InPathN = [dic objectForKey:@"routingFunction_InPath"];
        if(routingFunction_InPathN != nil)
        {
            self.routingFunction_InPath = [routingFunction_InPathN intValue];
        }
        NSNumber *routingFunctionN = [dic objectForKey:@"routingFunction"];
        if(routingFunctionN != nil)
        {
            self.routingFunction = [routingFunctionN intValue];
        }
        NSNumber *cloudBackupInformation_InPathN = [dic objectForKey:@"cloudBackupInformation_InPath"];
        if(cloudBackupInformation_InPathN != nil)
        {
            self.cloudBackupInformation_InPath = [cloudBackupInformation_InPathN intValue];
        }
        NSNumber *cloudBackupInformationN = [dic objectForKey:@"cloudBackupInformation"];
        if(cloudBackupInformationN != nil)
        {
            self.cloudBackupInformation = [cloudBackupInformationN intValue];
        }
        NSNumber *setHome_InPathN = [dic objectForKey:@"setHome_InPath"];
        if(setHome_InPathN != nil)
        {
            self.setHome_InPath = [setHome_InPathN intValue];
        }
        NSNumber *setHomeN = [dic objectForKey:@"setHome"];
        if(setHomeN != nil)
        {
            self.setHome = [setHomeN intValue];
        }
        NSNumber *setCompany_InPathN = [dic objectForKey:@"setCompany_InPath"];
        if(setCompany_InPathN != nil)
        {
            self.setCompany_InPath = [setCompany_InPathN intValue];
        }
        NSNumber *setCompanyN = [dic objectForKey:@"setCompany"];
        if(setCompanyN != nil)
        {
            self.setCompany = [setCompanyN intValue];
        }
        NSNumber *downloadManage_InPathN = [dic objectForKey:@"downloadManage_InPath"];
        if(downloadManage_InPathN != nil)
        {
            self.downloadManage_InPath = [downloadManage_InPathN intValue];
        }
        NSNumber *downloadManageN = [dic objectForKey:@"downloadManage"];
        if(downloadManageN != nil)
        {
            self.downloadManage = [downloadManageN intValue];
        }
        NSNumber *mapUpdateManage_InPathN = [dic objectForKey:@"mapUpdateManage_InPath"];
        if(mapUpdateManage_InPathN != nil)
        {
            self.mapUpdateManage_InPath = [mapUpdateManage_InPathN intValue];
        }
        NSNumber *mapUpdateManageN = [dic objectForKey:@"mapUpdateManage"];
        if(mapUpdateManageN != nil)
        {
            self.mapUpdateManage = [mapUpdateManageN intValue];
        }
        NSNumber *locusManage_InPathN = [dic objectForKey:@"locusManage_InPath"];
        if(locusManage_InPathN != nil)
        {
            self.locusManage_InPath = [locusManage_InPathN intValue];
        }
        NSNumber *locusManageN = [dic objectForKey:@"locusManage"];
        if(locusManageN != nil)
        {
            self.locusManage = [locusManageN intValue];
        }
        NSNumber *flowStatistics_InPathN = [dic objectForKey:@"flowStatistics_InPath"];
        if(flowStatistics_InPathN != nil)
        {
            self.flowStatistics_InPath = [flowStatistics_InPathN intValue];
        }
        NSNumber *flowStatisticsN = [dic objectForKey:@"flowStatistics"];
        if(flowStatisticsN != nil)
        {
            self.flowStatistics = [flowStatisticsN intValue];
        }
        NSNumber *iLoveGD_InPathN = [dic objectForKey:@"iLoveGD_InPath"];
        if(iLoveGD_InPathN != nil)
        {
            self.iLoveGD_InPath = [iLoveGD_InPathN intValue];
        }
        NSNumber *iLoveGDN = [dic objectForKey:@"iLoveGD"];
        if(iLoveGDN != nil)
        {
            self.iLoveGD = [iLoveGDN intValue];
        }
        NSNumber *newVersionFunction_InPathN = [dic objectForKey:@"newVersionFunction_InPath"];
        if(newVersionFunction_InPathN != nil)
        {
            self.newVersionFunction_InPath = [newVersionFunction_InPathN intValue];
        }
        NSNumber *newVersionFunctionN = [dic objectForKey:@"newVersionFunction"];
        if(newVersionFunctionN != nil)
        {
            self.newVersionFunction = [newVersionFunctionN intValue];
        }
        NSNumber *versionInfo_InPathN = [dic objectForKey:@"versionInfo_InPath"];
        if(versionInfo_InPathN != nil)
        {
            self.versionInfo_InPath = [versionInfo_InPathN intValue];
        }
        NSNumber *versionInfoN = [dic objectForKey:@"versionInfo"];
        if(versionInfoN != nil)
        {
            self.versionInfo = [versionInfoN intValue];
        }
        NSNumber *downloadMapByPhoneN = [dic objectForKey:@"downloadMapByPhone"];
        if(downloadMapByPhoneN != nil)
        {
            self.downloadMapByPhone = [downloadMapByPhoneN intValue];
        }
        NSNumber *travelLayerDataN = [dic objectForKey:@"travelLayerData"];
        if(travelLayerDataN != nil)
        {
            self.travelLayerData = [travelLayerDataN intValue];
        }
        
        NSNumber *durationOfUse_InPathN = [dic objectForKey:@"durationOfUse_InPath"];
        if(durationOfUse_InPathN != nil)
        {
            self.durationOfUse_InPath = [durationOfUse_InPathN intValue];
        }
        
        NSNumber *durationOfUseN = [dic objectForKey:@"durationOfUse"];
        if(durationOfUseN != nil)
        {
            self.durationOfUse = [durationOfUseN intValue];
        }
        
#pragma mark ---  5.29  ---
        
        NSNumber *goWhere_InPathN = [dic objectForKey:@"goWhere_InPath"];
        if(goWhere_InPathN != nil)
        {
            self.goWhere_InPath = [goWhere_InPathN intValue];
        }
        NSNumber *goWhereN = [dic objectForKey:@"goWhere"];
        if(goWhereN != nil)
        {
            self.goWhere = [goWhereN intValue];
        }
        NSNumber *commonUse_InPathN = [dic objectForKey:@"commonUse_InPath"];
        if(commonUse_InPathN != nil)
        {
            self.commonUse_InPath = [commonUse_InPathN intValue];
        }
        NSNumber *commonUseN = [dic objectForKey:@"commonUse"];
        if(commonUseN != nil)
        {
            self.commonUse = [commonUseN intValue];
        }
        NSNumber *alertFavCurrentPoint_InPathN = [dic objectForKey:@"alertFavCurrentPoint_InPath"];
        if(alertFavCurrentPoint_InPathN != nil)
        {
            self.alertFavCurrentPoint_InPath = [alertFavCurrentPoint_InPathN intValue];
        }
        NSNumber *alertFavCurrentPointN = [dic objectForKey:@"alertFavCurrentPoint"];
        if(alertFavCurrentPointN != nil)
        {
            self.alertFavCurrentPoint = [alertFavCurrentPointN intValue];
        }
        NSNumber *myFavorites_InPathN = [dic objectForKey:@"myFavorites_InPath"];
        if(myFavorites_InPathN != nil)
        {
            self.myFavorites_InPath = [myFavorites_InPathN intValue];
        }
        NSNumber *myFavoritesN = [dic objectForKey:@"myFavorites"];
        if(myFavoritesN != nil)
        {
            self.myFavorites = [myFavoritesN intValue];
        }
        NSNumber *historyDestination_InPathN = [dic objectForKey:@"historyDestination_InPath"];
        if(historyDestination_InPathN != nil)
        {
            self.historyDestination_InPath = [historyDestination_InPathN intValue];
        }
        NSNumber *historyDestinationN = [dic objectForKey:@"historyDestination"];
        if(historyDestinationN != nil)
        {
            self.historyDestination = [historyDestinationN intValue];
        }
        NSNumber *voiceSelectHenanMale_InPathN = [dic objectForKey:@"voiceSelectHenanMale_InPath"];
        if(voiceSelectHenanMale_InPathN != nil)
        {
            self.voiceSelectHenanMale_InPath = [voiceSelectHenanMale_InPathN intValue];
        }
        NSNumber *voiceSelectHenanMaleN = [dic objectForKey:@"voiceSelectHenanMale"];
        if(voiceSelectHenanMaleN != nil)
        {
            self.voiceSelectHenanMale = [voiceSelectHenanMaleN intValue];
        }
        NSNumber *multipleWaypoints_InPathN = [dic objectForKey:@"multipleWaypoints_InPath"];
        if(multipleWaypoints_InPathN != nil)
        {
            self.multipleWaypoints_InPath = [multipleWaypoints_InPathN intValue];
        }
        NSNumber *multipleWaypointsN = [dic objectForKey:@"multipleWaypoints"];
        if(multipleWaypointsN != nil)
        {
            self.multipleWaypoints = [multipleWaypointsN intValue];
        }
        NSNumber *fontSizeLarge_InPathN = [dic objectForKey:@"fontSizeLarge_InPath"];
        if(fontSizeLarge_InPathN != nil)
        {
            self.fontSizeLarge_InPath = [fontSizeLarge_InPathN intValue];
        }
        NSNumber *fontSizeLargeN = [dic objectForKey:@"fontSizeLarge"];
        if(fontSizeLargeN != nil)
        {
            self.fontSizeLarge = [fontSizeLargeN intValue];
        }
        NSNumber *fontSizeMedium_InPathN = [dic objectForKey:@"fontSizeMedium_InPath"];
        if(fontSizeMedium_InPathN != nil)
        {
            self.fontSizeMedium_InPath = [fontSizeMedium_InPathN intValue];
        }
        NSNumber *fontSizeMediumN = [dic objectForKey:@"fontSizeMedium"];
        if(fontSizeMediumN != nil)
        {
            self.fontSizeMedium = [fontSizeMediumN intValue];
        }
        NSNumber *fontSizeSmall_InPathN = [dic objectForKey:@"fontSizeSmall_InPath"];
        if(fontSizeSmall_InPathN != nil)
        {
            self.fontSizeSmall_InPath = [fontSizeSmall_InPathN intValue];
        }
        NSNumber *fontSizeSmallN = [dic objectForKey:@"fontSizeSmall"];
        if(fontSizeSmallN != nil)
        {
            self.fontSizeSmall = [fontSizeSmallN intValue];
        }
        NSNumber *dayAndNightModeDay_InPathN = [dic objectForKey:@"dayAndNightModeDay_InPath"];
        if(dayAndNightModeDay_InPathN != nil)
        {
            self.dayAndNightModeDay_InPath = [dayAndNightModeDay_InPathN intValue];
        }
        NSNumber *dayAndNightModeDayN = [dic objectForKey:@"dayAndNightModeDay"];
        if(dayAndNightModeDayN != nil)
        {
            self.dayAndNightModeDay = [dayAndNightModeDayN intValue];
        }
        NSNumber *dayAndNightModeNight_InPathN = [dic objectForKey:@"dayAndNightModeNight_InPath"];
        if(dayAndNightModeNight_InPathN != nil)
        {
            self.dayAndNightModeNight_InPath = [dayAndNightModeNight_InPathN intValue];
        }
        NSNumber *dayAndNightModeNightN = [dic objectForKey:@"dayAndNightModeNight"];
        if(dayAndNightModeNightN != nil)
        {
            self.dayAndNightModeNight = [dayAndNightModeNightN intValue];
        }
        NSNumber *dayAndNightModeAuto_InPathN = [dic objectForKey:@"dayAndNightModeAuto_InPath"];
        if(dayAndNightModeAuto_InPathN != nil)
        {
            self.dayAndNightModeAuto_InPath = [dayAndNightModeAuto_InPathN intValue];
        }
        NSNumber *dayAndNightModeAutoN = [dic objectForKey:@"dayAndNightModeAuto"];
        if(dayAndNightModeAutoN != nil)
        {
            self.dayAndNightModeAuto = [dayAndNightModeAutoN intValue];
        }
        NSNumber *voiceSelectNationalFemale_InPathN = [dic objectForKey:@"voiceSelectNationalFemale_InPath"];
        if(voiceSelectNationalFemale_InPathN != nil)
        {
            self.voiceSelectNationalFemale_InPath = [voiceSelectNationalFemale_InPathN intValue];
        }
        NSNumber *voiceSelectNationalFemaleN = [dic objectForKey:@"voiceSelectNationalFemale"];
        if(voiceSelectNationalFemaleN != nil)
        {
            self.voiceSelectNationalFemale = [voiceSelectNationalFemaleN intValue];
        }
        NSNumber *voiceSelectNationalMale_InPathN = [dic objectForKey:@"voiceSelectNationalMale_InPath"];
        if(voiceSelectNationalMale_InPathN != nil)
        {
            self.voiceSelectNationalMale_InPath = [voiceSelectNationalMale_InPathN intValue];
        }
        NSNumber *voiceSelectNationalMaleN = [dic objectForKey:@"voiceSelectNationalMale"];
        if(voiceSelectNationalMaleN != nil)
        {
            self.voiceSelectNationalMale = [voiceSelectNationalMaleN intValue];
        }
        NSNumber *voiceSelectTaiwanFemale_InPathN = [dic objectForKey:@"voiceSelectTaiwanFemale_InPath"];
        if(voiceSelectTaiwanFemale_InPathN != nil)
        {
            self.voiceSelectTaiwanFemale_InPath = [voiceSelectTaiwanFemale_InPathN intValue];
        }
        NSNumber *voiceSelectTaiwanFemaleN = [dic objectForKey:@"voiceSelectTaiwanFemale"];
        if(voiceSelectTaiwanFemaleN != nil)
        {
            self.voiceSelectTaiwanFemale = [voiceSelectTaiwanFemaleN intValue];
        }
        NSNumber *voiceSelectCantoneseFemale_InPathN = [dic objectForKey:@"voiceSelectCantoneseFemale_InPath"];
        if(voiceSelectCantoneseFemale_InPathN != nil)
        {
            self.voiceSelectCantoneseFemale_InPath = [voiceSelectCantoneseFemale_InPathN intValue];
        }
        NSNumber *voiceSelectCantoneseFemaleN = [dic objectForKey:@"voiceSelectCantoneseFemale"];
        if(voiceSelectCantoneseFemaleN != nil)
        {
            self.voiceSelectCantoneseFemale = [voiceSelectCantoneseFemaleN intValue];
        }
        NSNumber *voiceSelectNortheasternFemale_InPathN = [dic objectForKey:@"voiceSelectNortheasternFemale_InPath"];
        if(voiceSelectNortheasternFemale_InPathN != nil)
        {
            self.voiceSelectNortheasternFemale_InPath = [voiceSelectNortheasternFemale_InPathN intValue];
        }
        NSNumber *voiceSelectNortheasternFemaleN = [dic objectForKey:@"voiceSelectNortheasternFemale"];
        if(voiceSelectNortheasternFemaleN != nil)
        {
            self.voiceSelectNortheasternFemale = [voiceSelectNortheasternFemaleN intValue];
        }
        NSNumber *voiceSelectSichuanFemale_InPathN = [dic objectForKey:@"voiceSelectSichuanFemale_InPath"];
        if(voiceSelectSichuanFemale_InPathN != nil)
        {
            self.voiceSelectSichuanFemale_InPath = [voiceSelectSichuanFemale_InPathN intValue];
        }
        NSNumber *voiceSelectSichuanFemaleN = [dic objectForKey:@"voiceSelectSichuanFemale"];
        if(voiceSelectSichuanFemaleN != nil)
        {
            self.voiceSelectSichuanFemale = [voiceSelectSichuanFemaleN intValue];
        }
        NSNumber *voiceSelectHunanMale_InPathN = [dic objectForKey:@"voiceSelectHunanMale_InPath"];
        if(voiceSelectHunanMale_InPathN != nil)
        {
            self.voiceSelectHunanMale_InPath = [voiceSelectHunanMale_InPathN intValue];
        }
        NSNumber *voiceSelectHunanMaleN = [dic objectForKey:@"voiceSelectHunanMale"];
        if(voiceSelectHunanMaleN != nil)
        {
            self.voiceSelectHunanMale = [voiceSelectHunanMaleN intValue];
        }
        NSNumber *voiceFrequencyGeneral_InPathN = [dic objectForKey:@"voiceFrequencyGeneral_InPath"];
        if(voiceFrequencyGeneral_InPathN != nil)
        {
            self.voiceFrequencyGeneral_InPath = [voiceFrequencyGeneral_InPathN intValue];
        }
        NSNumber *voiceFrequencyGeneralN = [dic objectForKey:@"voiceFrequencyGeneral"];
        if(voiceFrequencyGeneralN != nil)
        {
            self.voiceFrequencyGeneral = [voiceFrequencyGeneralN intValue];
        }
        NSNumber *voiceFrequencyFrequent_InPathN = [dic objectForKey:@"voiceFrequencyFrequent_InPath"];
        if(voiceFrequencyFrequent_InPathN != nil)
        {
            self.voiceFrequencyFrequent_InPath = [voiceFrequencyFrequent_InPathN intValue];
        }
        NSNumber *voiceFrequencyFrequentN = [dic objectForKey:@"voiceFrequencyFrequent"];
        if(voiceFrequencyFrequentN != nil)
        {
            self.voiceFrequencyFrequent = [voiceFrequencyFrequentN intValue];
        }
        NSNumber *informationFirstAuto_InPathN = [dic objectForKey:@"informationFirstAuto_InPath"];
        if(informationFirstAuto_InPathN != nil)
        {
            self.informationFirstAuto_InPath = [informationFirstAuto_InPathN intValue];
        }
        NSNumber *informationFirstAutoN = [dic objectForKey:@"informationFirstAuto"];
        if(informationFirstAutoN != nil)
        {
            self.informationFirstAuto = [informationFirstAutoN intValue];
        }
        NSNumber *informationFirstGasStation_InPathN = [dic objectForKey:@"informationFirstGasStation_InPath"];
        if(informationFirstGasStation_InPathN != nil)
        {
            self.informationFirstGasStation_InPath = [informationFirstGasStation_InPathN intValue];
        }
        NSNumber *informationFirstGasStationN = [dic objectForKey:@"informationFirstGasStation"];
        if(informationFirstGasStationN != nil)
        {
            self.informationFirstGasStation = [informationFirstGasStationN intValue];
        }
        NSNumber *informationFirstParking_InPathN = [dic objectForKey:@"informationFirstParking_InPath"];
        if(informationFirstParking_InPathN != nil)
        {
            self.informationFirstParking_InPath = [informationFirstParking_InPathN intValue];
        }
        NSNumber *informationFirstParkingN = [dic objectForKey:@"informationFirstParking"];
        if(informationFirstParkingN != nil)
        {
            self.informationFirstParking = [informationFirstParkingN intValue];
        }
        NSNumber *informationFirstFood_InPathN = [dic objectForKey:@"informationFirstFood_InPath"];
        if(informationFirstFood_InPathN != nil)
        {
            self.informationFirstFood_InPath = [informationFirstFood_InPathN intValue];
        }
        NSNumber *informationFirstFoodN = [dic objectForKey:@"informationFirstFood"];
        if(informationFirstFoodN != nil)
        {
            self.informationFirstFood = [informationFirstFoodN intValue];
        }
        NSNumber *informationFirstLodging_InPathN = [dic objectForKey:@"informationFirstLodging_InPath"];
        if(informationFirstLodging_InPathN != nil)
        {
            self.informationFirstLodging_InPath = [informationFirstLodging_InPathN intValue];
        }
        NSNumber *informationFirstLodgingN = [dic objectForKey:@"informationFirstLodging"];
        if(informationFirstLodgingN != nil)
        {
            self.informationFirstLodging = [informationFirstLodgingN intValue];
        }
        NSNumber *informationFirstFun_InPathN = [dic objectForKey:@"informationFirstFun_InPath"];
        if(informationFirstFun_InPathN != nil)
        {
            self.informationFirstFun_InPath = [informationFirstFun_InPathN intValue];
        }
        NSNumber *informationFirstFunN = [dic objectForKey:@"informationFirstFun"];
        if(informationFirstFunN != nil)
        {
            self.informationFirstFun = [informationFirstFunN intValue];
        }
        NSNumber *informationFirstAttractions_InPathN = [dic objectForKey:@"informationFirstAttractions_InPath"];
        if(informationFirstAttractions_InPathN != nil)
        {
            self.informationFirstAttractions_InPath = [informationFirstAttractions_InPathN intValue];
        }
        NSNumber *informationFirstAttractionsN = [dic objectForKey:@"informationFirstAttractions"];
        if(informationFirstAttractionsN != nil)
        {
            self.informationFirstAttractions = [informationFirstAttractionsN intValue];
        }
        NSNumber *informationFirstMedical_InPathN = [dic objectForKey:@"informationFirstMedical_InPath"];
        if(informationFirstMedical_InPathN != nil)
        {
            self.informationFirstMedical_InPath = [informationFirstMedical_InPathN intValue];
        }
        NSNumber *informationFirstMedicalN = [dic objectForKey:@"informationFirstMedical"];
        if(informationFirstMedicalN != nil)
        {
            self.informationFirstMedical = [informationFirstMedicalN intValue];
        }
        NSNumber *store_InPathN = [dic objectForKey:@"store_InPath"];
        if(store_InPathN != nil)
        {
            self.store_InPath = [store_InPathN intValue];
        }
        NSNumber *storeN = [dic objectForKey:@"store"];
        if(storeN != nil)
        {
            self.store = [storeN intValue];
        }
        NSNumber *accountLogin_InPathN = [dic objectForKey:@"accountLogin_InPath"];
        if(accountLogin_InPathN != nil)
        {
            self.accountLogin_InPath = [accountLogin_InPathN intValue];
        }
        NSNumber *accountLoginN = [dic objectForKey:@"accountLogin"];
        if(accountLoginN != nil)
        {
            self.accountLogin = [accountLoginN intValue];
        }
        NSNumber *durationOfUseBackgroundSeconds_InPathN = [dic objectForKey:@"durationOfUseBackgroundSeconds_InPath"];
        if(durationOfUseBackgroundSeconds_InPathN != nil)
        {
            self.durationOfUseBackgroundSeconds_InPath = [durationOfUseBackgroundSeconds_InPathN intValue];
        }
        NSNumber *durationOfUseBackgroundSecondsN = [dic objectForKey:@"durationOfUseBackgroundSeconds"];
        if(durationOfUseBackgroundSecondsN != nil)
        {
            self.durationOfUseBackgroundSeconds = [durationOfUseBackgroundSecondsN intValue];
        }
        NSMutableArray *pathYawCountN = [dic objectForKey:@"PathYawCount"];
        if (pathYawCountN && [pathYawCountN count] > 0) {
            self.PathYawCount = pathYawCountN;
        }
        NSNumber *recalculationCountN = [dic objectForKey:@"recalculationCount"];
        if(recalculationCountN != nil)
        {
            self.recalculationCount = [recalculationCountN intValue];
        }
        NSNumber *TMCTimeN = [dic objectForKey:@"TMCTime"];
        if(TMCTimeN != nil)
        {
            self.TMCTime = [TMCTimeN intValue];
        }
    }
}

//保存数据
-(void)saveData
{
    if(self.tempOpenNavigation != 0)
    {
        if([self.lastStartUp length ] == 0)
        {
            self.lastStartUp = self.tempFirstStartUp ;
        }
        else
        {
            self.lastStartUp = [NSString stringWithFormat:@"%@,%@",
                                                                     self.lastStartUp,
                                                                     self.tempFirstStartUp ];
        }
        self.openNavigation += self.tempOpenNavigation;
        self.tempOpenNavigation = 0;
    }
    NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:
                          self.lastStartUp,@"lastStartUp",
                          [NSNumber numberWithInt:self.openNavigation],@"openNavigation",
                          [NSNumber numberWithInt:self.addressSearch_InPath],@"addressSearch_InPath",
                          [NSNumber numberWithInt:self.addressSearch],@"addressSearch",
                          [NSNumber numberWithInt:self.crossSearch_InPath],@"crossSearch_InPath",
                          [NSNumber numberWithInt:self.crossSearch],@"crossSearch",
                          [NSNumber numberWithInt:self.defaultSort_InPath],@"defaultSort_InPath",
                          [NSNumber numberWithInt:self.defaultSort],@"defaultSort",
                          [NSNumber numberWithInt:self.distanceSort_InPath],@"distanceSort_InPath",
                          [NSNumber numberWithInt:self.distanceSort],@"distanceSort",
                          [NSNumber numberWithInt:self.regionSelect_InPath],@"regionSelect_InPath",
                          [NSNumber numberWithInt:self.regionSelect],@"regionSelect",
                          [NSNumber numberWithInt:self.voiceSearchGoWhere_InPath],@"voiceSearchGoWhere_InPath",
                          [NSNumber numberWithInt:self.voiceSearchGoWhere],@"voiceSearchGoWhere",
                          [NSNumber numberWithInt:self.alongCursorSearch_InPath],@"alongCursorSearch_InPath",
                          [NSNumber numberWithInt:self.alongCursorSearch],@"alongCursorSearch",
                          [NSNumber numberWithInt:self.alongPathSearch_InPath],@"alongPathSearch_InPath",
                          [NSNumber numberWithInt:self.alongPathSearch],@"alongPathSearch",
                          [NSNumber numberWithInt:self.alongDestinationsearch_InPath],@"alongDestinationsearch_InPath",
                          [NSNumber numberWithInt:self.alongDestinationsearch],@"alongDestinationsearch",
                          self.stationType_InPath,@"stationType_InPath",
                          self.stationType,@"stationType",
                          [NSNumber numberWithInt:self.parkingType_InPath],@"parkingType_InPath",
                          [NSNumber numberWithInt:self.parkingType],@"parkingType",
                          self.businessCasualType_InPath,@"businessCasualType_InPath",
                          self.businessCasualType,@"businessCasualType",
                          self.foodDrinkType_InPath,@"foodDrinkType_InPath",
                          self.foodDrinkType,@"foodDrinkType",
                          self.hotelType_InPath,@"hotelType_InPath",
                          self.hotelType,@"hotelType",
                          self.shoppingType_InPath,@"shoppingType_InPath",
                          self.shoppingType,@"shoppingType",
                          self.sightsType_InPath,@"sightsType_InPath",
                          self.sightsType,@"sightsType",
                          self.transportServicesType_InPath,@"transportServicesType_InPath",
                          self.transportServicesType,@"transportServicesType",
                          self.financeType_InPath,@"financeType_InPath",
                          self.financeType,@"financeType",
                          [NSNumber numberWithInt:self.buildingType_InPath],@"buildingType_InPath",
                          [NSNumber numberWithInt:self.buildingType],@"buildingType",
                          self.recreationType_InPath,@"recreationType_InPath",
                          self.recreationType,@"recreationType",
                          [NSNumber numberWithInt:self.CorporateType_InPath],@"CorporateType_InPath",
                          [NSNumber numberWithInt:self.CorporateType],@"CorporateType",
                          self.carServiceType_InPath,@"carServiceType_InPath",
                          self.carServiceType,@"carServiceType",
                          self.sportsType_InPath,@"sportsType_InPath",
                          self.sportsType,@"sportsType",
                          self.livingServiceType_InPath,@"livingServiceType_InPath",
                          self.livingServiceType,@"livingServiceType",
                          self.educationType_InPath,@"educationType_InPath",
                          self.educationType,@"educationType",
                          self.hospitalType_InPath,@"hospitalType_InPath",
                          self.hospitalType,@"hospitalType",
                          [NSNumber numberWithInt:self.residentialAreaType_InPath],@"residentialAreaType_InPath",
                          [NSNumber numberWithInt:self.residentialAreaType],@"residentialAreaType",
                          self.governmentType_InPath,@"governmentType_InPath",
                          self.governmentType,@"governmentType",
                          [NSNumber numberWithInt:self.cityType_InPath],@"cityType_InPath",
                          [NSNumber numberWithInt:self.cityType],@"cityType",
                          [NSNumber numberWithInt:self.detailSetEnd_InPath],@"detailSetEnd_InPath",
                          [NSNumber numberWithInt:self.detailSetEnd],@"detailSetEnd",
                          [NSNumber numberWithInt:self.viewPOISetEnd_InPath],@"viewPOISetEnd_InPath",
                          [NSNumber numberWithInt:self.viewPOISetEnd],@"viewPOISetEnd",
                          [NSNumber numberWithInt:self.detailSetStart_InPath],@"detailSetStart_InPath",
                          [NSNumber numberWithInt:self.detailSetStart],@"detailSetStart",
                          [NSNumber numberWithInt:self.viewPOISetStart_InPath],@"viewPOISetStart_InPath",
                          [NSNumber numberWithInt:self.viewPOISetStart],@"viewPOISetStart",
                          [NSNumber numberWithInt:self.figureMapSetSatar_InPath],@"figureMapSetSatar_InPath",
                          [NSNumber numberWithInt:self.figureMapSetSatar],@"figureMapSetSatar",
                          [NSNumber numberWithInt:self.viewPOISetWaypoint_InPath],@"viewPOISetWaypoint_InPath",
                          [NSNumber numberWithInt:self.viewPOISetWaypoint],@"viewPOISetWaypoint",
                          [NSNumber numberWithInt:self.figureSetWaypoint_InPath],@"figureSetWaypoint_InPath",
                          [NSNumber numberWithInt:self.figureSetWaypoint],@"figureSetWaypoint",
                          [NSNumber numberWithInt:self.managePathDetail_InPath],@"managePathDetail_InPath",
                          [NSNumber numberWithInt:self.managePathDetail],@"managePathDetail",
                          [NSNumber numberWithInt:self.stopNaviByTurnArrow_InPath],@"stopNaviByTurnArrow_InPath",
                          [NSNumber numberWithInt:self.stopNaviByTurnArrow],@"stopNaviByTurnArrow",
                          [NSNumber numberWithInt:self.stopNaviByManage_InPath],@"stopNaviByManage_InPath",
                          [NSNumber numberWithInt:self.stopNaviByManage],@"stopNaviByManage",
                          [NSNumber numberWithInt:self.simulatedNaviByOverview_InPath],@"simulatedNaviByOverview_InPath",
                          [NSNumber numberWithInt:self.simulatedNaviByOverview],@"simulatedNaviByOverview",
                          [NSNumber numberWithInt:self.simulatedNaviByManage_InPath],@"simulatedNaviByManage_InPath",
                          [NSNumber numberWithInt:self.simulatedNaviByManage],@"simulatedNaviByManage",
                          [NSNumber numberWithInt:self.planningByManage_InPath],@"planningByManage_InPath",
                          [NSNumber numberWithInt:self.planningByManage],@"planningByManage",
                          [NSNumber numberWithInt:self.overviewByManage_InPath],@"overviewByManage_InPath",
                          [NSNumber numberWithInt:self.overviewByManage],@"overviewByManage",
                          [NSNumber numberWithInt:self.suggestedLtineraries_InPath],@"suggestedLtineraries_InPath",
                          [NSNumber numberWithInt:self.suggestedLtineraries],@"suggestedLtineraries",
                          [NSNumber numberWithInt:self.highPriority_InPath],@"highPriority_InPath",
                          [NSNumber numberWithInt:self.highPriority],@"highPriority",
                          [NSNumber numberWithInt:self.economicRoute_InPath],@"economicRoute_InPath",
                          [NSNumber numberWithInt:self.economicRoute],@"economicRoute",
                          [NSNumber numberWithInt:self.shortestRoute_InPath],@"shortestRoute_InPath",
                          [NSNumber numberWithInt:self.shortestRoute],@"shortestRoute",
                          [NSNumber numberWithInt:self.directionsContrast_InPath],@"directionsContrast_InPath",
                          [NSNumber numberWithInt:self.directionsContrast],@"directionsContrast",
                          [NSNumber numberWithInt:self.overviewViewFull_InPath],@"overviewViewFull_InPath",
                          [NSNumber numberWithInt:self.overviewViewFull],@"overviewViewFull",
                          [NSNumber numberWithInt:self.viewTripComputer_InPath],@"viewTripComputer_InPath",
                          [NSNumber numberWithInt:self.viewTripComputer],@"viewTripComputer",
                          [NSNumber numberWithInt:self.enlargeByButton_InPath],@"enlargeByButton_InPath",
                          [NSNumber numberWithInt:self.enlargeByButton],@"enlargeByButton",
                          [NSNumber numberWithInt:self.narrowByButton_InPath],@"narrowByButton_InPath",
                          [NSNumber numberWithInt:self.narrowByButton],@"narrowByButton",
                          [NSNumber numberWithInt:self.enlargeByDoubleClick_InPath],@"enlargeByDoubleClick_InPath",
                          [NSNumber numberWithInt:self.enlargeByDoubleClick],@"enlargeByDoubleClick",
                          [NSNumber numberWithInt:self.narrowByTwoFingerClick_InPath],@"narrowByTwoFingerClick_InPath",
                          [NSNumber numberWithInt:self.narrowByTwoFingerClick],@"narrowByTwoFingerClick",
                          [NSNumber numberWithInt:self.enlargeByPinOpen_InPath],@"enlargeByPinOpen_InPath",
                          [NSNumber numberWithInt:self.enlargeByPinOpen],@"enlargeByPinOpen",
                          [NSNumber numberWithInt:self.narrowByPinKneading_InPath],@"narrowByPinKneading_InPath",
                          [NSNumber numberWithInt:self.narrowByPinKneading],@"narrowByPinKneading",
                          [NSNumber numberWithInt:self.favoriteCurrentPoint_InPath],@"favoriteCurrentPoint_InPath",
                          [NSNumber numberWithInt:self.favoriteCurrentPoint],@"favoriteCurrentPoint",
                          [NSNumber numberWithInt:self.messageBox_InPath],@"messageBox_InPath",
                          [NSNumber numberWithInt:self.messageBox],@"messageBox",
                          [NSNumber numberWithInt:self.pathManage_InPath],@"pathManage_InPath",
                          [NSNumber numberWithInt:self.pathManage],@"pathManage",
                          [NSNumber numberWithInt:self.switchMainAndSideRoads_InPath],@"switchMainAndSideRoads_InPath",
                          [NSNumber numberWithInt:self.switchMainAndSideRoads],@"switchMainAndSideRoads",
                          [NSNumber numberWithInt:self.trafficIncident_InPath],@"trafficIncident_InPath",
                          [NSNumber numberWithInt:self.trafficIncident],@"trafficIncident",
                          [NSNumber numberWithInt:self.feedback_InPath],@"feedback_InPath",
                          [NSNumber numberWithInt:self.feedback],@"feedback",
                          [NSNumber numberWithInt:self.trafficEventDisplay_InPath],@"trafficEventDisplay_InPath",
                          [NSNumber numberWithInt:self.trafficEventDisplay],@"trafficEventDisplay",
                          [NSNumber numberWithInt:self.networkNavi_InPath],@"networkNavi_InPath",
                          [NSNumber numberWithInt:self.networkNavi],@"networkNavi",
                          [NSNumber numberWithInt:self.networkNaviSeconds_InPath],@"networkNaviSeconds_InPath",
                          [NSNumber numberWithInt:self.networkNaviSeconds],@"networkNaviSeconds",
                          [NSNumber numberWithInt:self.CPCNavi_InPath],@"CPCNavi_InPath",
                          [NSNumber numberWithInt:self.CPCNavi],@"CPCNavi",
                          [NSNumber numberWithInt:self.CPCNaviSeconds_InPath],@"CPCNaviSeconds_InPath",
                          [NSNumber numberWithInt:self.CPCNaviSeconds],@"CPCNaviSeconds",
                          [NSNumber numberWithInt:self.horizontalScreenSeconds_InPath],@"horizontalScreenSeconds_InPath",
                          [NSNumber numberWithInt:self.horizontalScreenSeconds],@"horizontalScreenSeconds",
                          [NSNumber numberWithInt:self.verticalScreenSeconds_InPath],@"verticalScreenSeconds_InPath",
                          [NSNumber numberWithInt:self.verticalScreenSeconds],@"verticalScreenSeconds",
                          [NSNumber numberWithInt:self.mapProportion_25_InPath],@"mapProportion_25_InPath",
                          [NSNumber numberWithInt:self.mapProportion_25],@"mapProportion_25",
                          [NSNumber numberWithInt:self.mapProportion_50_InPath],@"mapProportion_50_InPath",
                          [NSNumber numberWithInt:self.mapProportion_50],@"mapProportion_50",
                          [NSNumber numberWithInt:self.mapProportion_100_InPath],@"mapProportion_100_InPath",
                          [NSNumber numberWithInt:self.mapProportion_100],@"mapProportion_100",
                          [NSNumber numberWithInt:self.mapProportion_200_InPath],@"mapProportion_200_InPath",
                          [NSNumber numberWithInt:self.mapProportion_200],@"mapProportion_200",
                          [NSNumber numberWithInt:self.mapProportion_500_InPath],@"mapProportion_500_InPath",
                          [NSNumber numberWithInt:self.mapProportion_500],@"mapProportion_500",
                          [NSNumber numberWithInt:self.mapProportion_1k_InPath],@"mapProportion_1k_InPath",
                          [NSNumber numberWithInt:self.mapProportion_1k],@"mapProportion_1k",
                          [NSNumber numberWithInt:self.mapProportion_2k_InPath],@"mapProportion_2k_InPath",
                          [NSNumber numberWithInt:self.mapProportion_2k],@"mapProportion_2k",
                          [NSNumber numberWithInt:self.mapProportion_5k_InPath],@"mapProportion_5k_InPath",
                          [NSNumber numberWithInt:self.mapProportion_5k],@"mapProportion_5k",
                          [NSNumber numberWithInt:self.mapProportion_10k_InPath],@"mapProportion_10k_InPath",
                          [NSNumber numberWithInt:self.mapProportion_10k],@"mapProportion_10k",
                          [NSNumber numberWithInt:self.mapProportion_50k_InPath],@"mapProportion_50k_InPath",
                          [NSNumber numberWithInt:self.mapProportion_50k],@"mapProportion_50k",
                          [NSNumber numberWithInt:self.mapProportion_200k_InPath],@"mapProportion_200k_InPath",
                          [NSNumber numberWithInt:self.mapProportion_200k],@"mapProportion_200k",
                          [NSNumber numberWithInt:self.mapProportion_500k_InPath],@"mapProportion_500k_InPath",
                          [NSNumber numberWithInt:self.mapProportion_500k],@"mapProportion_500k",
                          [NSNumber numberWithInt:self.openEnglishVersionSeconds_InPath],@"openEnglishVersionSeconds_InPath",
                          [NSNumber numberWithInt:self.openEnglishVersionSeconds],@"openEnglishVersionSeconds",
                          //自动生成的新变量
                          [NSNumber numberWithInt:self.manualSearch_InPath],@"manualSearch_InPath",
                          [NSNumber numberWithInt:self.manualSearch],@"manualSearch",
                          [NSNumber numberWithInt:self.smartSearch_InPath],@"smartSearch_InPath",
                          [NSNumber numberWithInt:self.smartSearch],@"smartSearch",
                          [NSNumber numberWithInt:self.networkSearch_InPath],@"networkSearch_InPath",
                          [NSNumber numberWithInt:self.networkSearch],@"networkSearch",
                          [NSNumber numberWithInt:self.voiceSearchSide_InPath],@"voiceSearchSide_InPath",
                          [NSNumber numberWithInt:self.voiceSearchSide],@"voiceSearchSide",
                          [NSNumber numberWithInt:self.peripherySearch_InPath],@"peripherySearch_InPath",
                          [NSNumber numberWithInt:self.peripherySearch],@"peripherySearch",
                          [NSNumber numberWithInt:self.figureMapSetEnd_InPath],@"figureMapSetEnd_InPath",
                          [NSNumber numberWithInt:self.figureMapSetEnd],@"figureMapSetEnd",
                          [NSNumber numberWithInt:self.historyDestinnation_InPath],@"historyDestinnation_InPath",
                          [NSNumber numberWithInt:self.historyDestinnation],@"historyDestinnation",
                          [NSNumber numberWithInt:self.addressBook_InPath],@"addressBook_InPath",
                          [NSNumber numberWithInt:self.addressBook],@"addressBook",
                          [NSNumber numberWithInt:self.contactsNavigation_InPath],@"contactsNavigation_InPath",
                          [NSNumber numberWithInt:self.contactsNavigation],@"contactsNavigation",
                          [NSNumber numberWithInt:self.routeDetailsOverview_InPath],@"routeDetailsOverview_InPath",
                          [NSNumber numberWithInt:self.routeDetailsOverview],@"routeDetailsOverview",
                          [NSNumber numberWithInt:self.overviewNextWay_InPath],@"overviewNextWay_InPath",
                          [NSNumber numberWithInt:self.overviewNextWay],@"overviewNextWay",
                          [NSNumber numberWithInt:self.shareLocationBySMS_InPath],@"shareLocationBySMS_InPath",
                          [NSNumber numberWithInt:self.shareLocationBySMS],@"shareLocationBySMS",
                          [NSNumber numberWithInt:self.shareLocationByEmail_InPath],@"shareLocationByEmail_InPath",
                          [NSNumber numberWithInt:self.shareLocationByEmail],@"shareLocationByEmail",
                          [NSNumber numberWithInt:self.shareLocationBySina_InPath],@"shareLocationBySina_InPath",
                          [NSNumber numberWithInt:self.shareLocationBySina],@"shareLocationBySina",
                          [NSNumber numberWithInt:self.shareLocationByTX_InPath],@"shareLocationByTX_InPath",
                          [NSNumber numberWithInt:self.shareLocationByTX],@"shareLocationByTX",
                          [NSNumber numberWithInt:self.microShareLocation_InPath],@"microShareLocation_InPath",
                          [NSNumber numberWithInt:self.microShareLocation],@"microShareLocation",
                          [NSNumber numberWithInt:self.northUpView_InPath],@"northUpView_InPath",
                          [NSNumber numberWithInt:self.northUpView],@"northUpView",
                          [NSNumber numberWithInt:self.northUpViewSeconds_InPath],@"northUpViewSeconds_InPath",
                          [NSNumber numberWithInt:self.northUpViewSeconds],@"northUpViewSeconds",
                          [NSNumber numberWithInt:self.upView_InPath],@"upView_InPath",
                          [NSNumber numberWithInt:self.upView],@"upView",
                          [NSNumber numberWithInt:self.upViewSeconds_InPath],@"upViewSeconds_InPath",
                          [NSNumber numberWithInt:self.upViewSeconds],@"upViewSeconds",
                          [NSNumber numberWithInt:self.car3DView_InPath],@"car3DView_InPath",
                          [NSNumber numberWithInt:self.car3DView],@"car3DView",
                          [NSNumber numberWithInt:self.car3DViewSeconds_InPath],@"car3DViewSeconds_InPath",
                          [NSNumber numberWithInt:self.car3DViewSeconds],@"car3DViewSeconds",
                          [NSNumber numberWithInt:self.realTimeTraffic_InPath],@"realTimeTraffic_InPath",
                          [NSNumber numberWithInt:self.realTimeTraffic],@"realTimeTraffic",
                          [NSNumber numberWithInt:self.trafficInformation_InPath],@"trafficInformation_InPath",
                          [NSNumber numberWithInt:self.trafficInformation],@"trafficInformation",
                          [NSNumber numberWithInt:self.smartDrivingServices_InPath],@"smartDrivingServices_InPath",
                          [NSNumber numberWithInt:self.smartDrivingServices],@"smartDrivingServices",
                          [NSNumber numberWithInt:self.smartDriveSetDestination_InPath],@"smartDriveSetDestination_InPath",
                          [NSNumber numberWithInt:self.smartDriveSetDestination],@"smartDriveSetDestination",
                          [NSNumber numberWithInt:self.layerByCtripOnline_InPath],@"layerByCtripOnline_InPath",
                          [NSNumber numberWithInt:self.layerByCtripOnline],@"layerByCtripOnline",
                          [NSNumber numberWithInt:self.layerByCtripPhone_InPath],@"layerByCtripPhone_InPath",
                          [NSNumber numberWithInt:self.layerByCtripPhone],@"layerByCtripPhone",
                          [NSNumber numberWithInt:self.layerByCtripOnlineSeconds_InPath],@"layerByCtripOnlineSeconds_InPath",
                          [NSNumber numberWithInt:self.layerByCtripOnlineSeconds],@"layerByCtripOnlineSeconds",
                          [NSNumber numberWithInt:self.layerByTravel_InPath],@"layerByTravel_InPath",
                          [NSNumber numberWithInt:self.layerByTravel],@"layerByTravel",
                          [NSNumber numberWithInt:self.layerByTravelSeconds_InPath],@"layerByTravelSeconds_InPath",
                          [NSNumber numberWithInt:self.layerByTravelSeconds],@"layerByTravelSeconds",
                          [NSNumber numberWithInt:self.layerByFood_InPath],@"layerByFood_InPath",
                          [NSNumber numberWithInt:self.layerByFood],@"layerByFood",
                          [NSNumber numberWithInt:self.layerByFoodSeconds_InPath],@"layerByFoodSeconds_InPath",
                          [NSNumber numberWithInt:self.layerByFoodSeconds],@"layerByFoodSeconds",
                          [NSNumber numberWithInt:self.layerByGolf_InPath],@"layerByGolf_InPath",
                          [NSNumber numberWithInt:self.layerByGolf],@"layerByGolf",
                          [NSNumber numberWithInt:self.layerByGolfSeconds_InPath],@"layerByGolfSeconds_InPath",
                          [NSNumber numberWithInt:self.layerByGolfSeconds],@"layerByGolfSeconds",
                          [NSNumber numberWithInt:self.layerByMyself_InPath],@"layerByMyself_InPath",
                          [NSNumber numberWithInt:self.layerByMyself],@"layerByMyself",
                          [NSNumber numberWithInt:self.layerByMyselfSeconds_InPath],@"layerByMyselfSeconds_InPath",
                          [NSNumber numberWithInt:self.layerByMyselfSeconds],@"layerByMyselfSeconds",
                          [NSNumber numberWithInt:self.layerByFriendsShare_InPath],@"layerByFriendsShare_InPath",
                          [NSNumber numberWithInt:self.layerByFriendsShare],@"layerByFriendsShare",
                          [NSNumber numberWithInt:self.layerByFriendsShareSeconds_InPath],@"layerByFriendsShareSeconds_InPath",
                          [NSNumber numberWithInt:self.layerByFriendsShareSeconds],@"layerByFriendsShareSeconds",
                          [NSNumber numberWithInt:self.layerByGDShare_InPath],@"layerByGDShare_InPath",
                          [NSNumber numberWithInt:self.layerByGDShare],@"layerByGDShare",
                          [NSNumber numberWithInt:self.layerByGDShareSeconds_InPath],@"layerByGDShareSeconds_InPath",
                          [NSNumber numberWithInt:self.layerByGDShareSeconds],@"layerByGDShareSeconds",
                          [NSNumber numberWithInt:self.goHome_InPath],@"goHome_InPath",
                          [NSNumber numberWithInt:self.goHome],@"goHome",
                          [NSNumber numberWithInt:self.backCompany_InPath],@"backCompany_InPath",
                          [NSNumber numberWithInt:self.backCompany],@"backCompany",
                          [NSNumber numberWithInt:self.avoidTraffice_InPath],@"avoidTraffice_InPath",
                          [NSNumber numberWithInt:self.avoidTraffice],@"avoidTraffice",
                          [NSNumber numberWithInt:self.avoidRouteDetail_InPath],@"avoidRouteDetail_InPath",
                          [NSNumber numberWithInt:self.avoidRouteDetail],@"avoidRouteDetail",
                          [NSNumber numberWithInt:self.beforeAvoid_InPath],@"beforeAvoid_InPath",
                          [NSNumber numberWithInt:self.beforeAvoid],@"beforeAvoid",
                          [NSNumber numberWithInt:self.afterAvoid_InPath],@"afterAvoid_InPath",
                          [NSNumber numberWithInt:self.afterAvoid],@"afterAvoid",
                          [NSNumber numberWithInt:self.cancelAvoid_InPath],@"cancelAvoid_InPath",
                          [NSNumber numberWithInt:self.cancelAvoid],@"cancelAvoid",
                          [NSNumber numberWithInt:self.routingFunction_InPath],@"routingFunction_InPath",
                          [NSNumber numberWithInt:self.routingFunction],@"routingFunction",
                          [NSNumber numberWithInt:self.cloudBackupInformation_InPath],@"cloudBackupInformation_InPath",
                          [NSNumber numberWithInt:self.cloudBackupInformation],@"cloudBackupInformation",
                          [NSNumber numberWithInt:self.setHome_InPath],@"setHome_InPath",
                          [NSNumber numberWithInt:self.setHome],@"setHome",
                          [NSNumber numberWithInt:self.setCompany_InPath],@"setCompany_InPath",
                          [NSNumber numberWithInt:self.setCompany],@"setCompany",
                          [NSNumber numberWithInt:self.downloadManage_InPath],@"downloadManage_InPath",
                          [NSNumber numberWithInt:self.downloadManage],@"downloadManage",
                          [NSNumber numberWithInt:self.mapUpdateManage_InPath],@"mapUpdateManage_InPath",
                          [NSNumber numberWithInt:self.mapUpdateManage],@"mapUpdateManage",
                          [NSNumber numberWithInt:self.locusManage_InPath],@"locusManage_InPath",
                          [NSNumber numberWithInt:self.locusManage],@"locusManage",
                          [NSNumber numberWithInt:self.flowStatistics_InPath],@"flowStatistics_InPath",
                          [NSNumber numberWithInt:self.flowStatistics],@"flowStatistics",
                          [NSNumber numberWithInt:self.iLoveGD_InPath],@"iLoveGD_InPath",
                          [NSNumber numberWithInt:self.iLoveGD],@"iLoveGD",
                          [NSNumber numberWithInt:self.newVersionFunction_InPath],@"newVersionFunction_InPath",
                          [NSNumber numberWithInt:self.newVersionFunction],@"newVersionFunction",
                          [NSNumber numberWithInt:self.versionInfo_InPath],@"versionInfo_InPath",
                          [NSNumber numberWithInt:self.versionInfo],@"versionInfo",
                          [NSNumber numberWithInt:self.downloadMapByPhone],@"downloadMapByPhone",
                          [NSNumber numberWithInt:self.travelLayerData],@"travelLayerData",
                          [NSNumber numberWithInt:self.durationOfUse_InPath],@"durationOfUse_InPath",
                          [NSNumber numberWithInt:self.durationOfUse],@"durationOfUse",
                          
                          //**5.29
                          [NSNumber numberWithInt:self.goWhere_InPath],@"goWhere_InPath",
                          [NSNumber numberWithInt:self.goWhere],@"goWhere",
                          [NSNumber numberWithInt:self.commonUse_InPath],@"commonUse_InPath",
                          [NSNumber numberWithInt:self.commonUse],@"commonUse",
                          [NSNumber numberWithInt:self.alertFavCurrentPoint_InPath],@"alertFavCurrentPoint_InPath",
                          [NSNumber numberWithInt:self.alertFavCurrentPoint],@"alertFavCurrentPoint",
                          [NSNumber numberWithInt:self.myFavorites_InPath],@"myFavorites_InPath",
                          [NSNumber numberWithInt:self.myFavorites],@"myFavorites",
                          [NSNumber numberWithInt:self.historyDestination_InPath],@"historyDestination_InPath",
                          [NSNumber numberWithInt:self.historyDestination],@"historyDestination",
                          [NSNumber numberWithInt:self.voiceSelectHenanMale_InPath],@"voiceSelectHenanMale_InPath",
                          [NSNumber numberWithInt:self.voiceSelectHenanMale],@"voiceSelectHenanMale",
                          [NSNumber numberWithInt:self.multipleWaypoints_InPath],@"multipleWaypoints_InPath",
                          [NSNumber numberWithInt:self.multipleWaypoints],@"multipleWaypoints",
                          [NSNumber numberWithInt:self.fontSizeLarge_InPath],@"fontSizeLarge_InPath",
                          [NSNumber numberWithInt:self.fontSizeLarge],@"fontSizeLarge",
                          [NSNumber numberWithInt:self.fontSizeMedium_InPath],@"fontSizeMedium_InPath",
                          [NSNumber numberWithInt:self.fontSizeMedium],@"fontSizeMedium",
                          [NSNumber numberWithInt:self.fontSizeSmall_InPath],@"fontSizeSmall_InPath",
                          [NSNumber numberWithInt:self.fontSizeSmall],@"fontSizeSmall",
                          [NSNumber numberWithInt:self.dayAndNightModeDay_InPath],@"dayAndNightModeDay_InPath",
                          [NSNumber numberWithInt:self.dayAndNightModeDay],@"dayAndNightModeDay",
                          [NSNumber numberWithInt:self.dayAndNightModeNight_InPath],@"dayAndNightModeNight_InPath",
                          [NSNumber numberWithInt:self.dayAndNightModeNight],@"dayAndNightModeNight",
                          [NSNumber numberWithInt:self.dayAndNightModeAuto_InPath],@"dayAndNightModeAuto_InPath",
                          [NSNumber numberWithInt:self.dayAndNightModeAuto],@"dayAndNightModeAuto",
                          [NSNumber numberWithInt:self.voiceSelectNationalFemale_InPath],@"voiceSelectNationalFemale_InPath",
                          [NSNumber numberWithInt:self.voiceSelectNationalFemale],@"voiceSelectNationalFemale",
                          [NSNumber numberWithInt:self.voiceSelectNationalMale_InPath],@"voiceSelectNationalMale_InPath",
                          [NSNumber numberWithInt:self.voiceSelectNationalMale],@"voiceSelectNationalMale",
                          [NSNumber numberWithInt:self.voiceSelectTaiwanFemale_InPath],@"voiceSelectTaiwanFemale_InPath",
                          [NSNumber numberWithInt:self.voiceSelectTaiwanFemale],@"voiceSelectTaiwanFemale",
                          [NSNumber numberWithInt:self.voiceSelectCantoneseFemale_InPath],@"voiceSelectCantoneseFemale_InPath",
                          [NSNumber numberWithInt:self.voiceSelectCantoneseFemale],@"voiceSelectCantoneseFemale",
                          [NSNumber numberWithInt:self.voiceSelectNortheasternFemale_InPath],@"voiceSelectNortheasternFemale_InPath",
                          [NSNumber numberWithInt:self.voiceSelectNortheasternFemale],@"voiceSelectNortheasternFemale",
                          [NSNumber numberWithInt:self.voiceSelectSichuanFemale_InPath],@"voiceSelectSichuanFemale_InPath",
                          [NSNumber numberWithInt:self.voiceSelectSichuanFemale],@"voiceSelectSichuanFemale",
                          [NSNumber numberWithInt:self.voiceSelectHunanMale_InPath],@"voiceSelectHunanMale_InPath",
                          [NSNumber numberWithInt:self.voiceSelectHunanMale],@"voiceSelectHunanMale",
                          [NSNumber numberWithInt:self.voiceFrequencyGeneral_InPath],@"voiceFrequencyGeneral_InPath",
                          [NSNumber numberWithInt:self.voiceFrequencyGeneral],@"voiceFrequencyGeneral",
                          [NSNumber numberWithInt:self.voiceFrequencyFrequent_InPath],@"voiceFrequencyFrequent_InPath",
                          [NSNumber numberWithInt:self.voiceFrequencyFrequent],@"voiceFrequencyFrequent",
                          [NSNumber numberWithInt:self.informationFirstAuto_InPath],@"informationFirstAuto_InPath",
                          [NSNumber numberWithInt:self.informationFirstAuto],@"informationFirstAuto",
                          [NSNumber numberWithInt:self.informationFirstGasStation_InPath],@"informationFirstGasStation_InPath",
                          [NSNumber numberWithInt:self.informationFirstGasStation],@"informationFirstGasStation",
                          [NSNumber numberWithInt:self.informationFirstParking_InPath],@"informationFirstParking_InPath",
                          [NSNumber numberWithInt:self.informationFirstParking],@"informationFirstParking",
                          [NSNumber numberWithInt:self.informationFirstFood_InPath],@"informationFirstFood_InPath",
                          [NSNumber numberWithInt:self.informationFirstFood],@"informationFirstFood",
                          [NSNumber numberWithInt:self.informationFirstLodging_InPath],@"informationFirstLodging_InPath",
                          [NSNumber numberWithInt:self.informationFirstLodging],@"informationFirstLodging",
                          [NSNumber numberWithInt:self.informationFirstFun_InPath],@"informationFirstFun_InPath",
                          [NSNumber numberWithInt:self.informationFirstFun],@"informationFirstFun",
                          [NSNumber numberWithInt:self.informationFirstAttractions_InPath],@"informationFirstAttractions_InPath",
                          [NSNumber numberWithInt:self.informationFirstAttractions],@"informationFirstAttractions",
                          [NSNumber numberWithInt:self.informationFirstMedical_InPath],@"informationFirstMedical_InPath",
                          [NSNumber numberWithInt:self.informationFirstMedical],@"informationFirstMedical",
                          [NSNumber numberWithInt:self.store_InPath],@"store_InPath",
                          [NSNumber numberWithInt:self.store],@"store",
                          [NSNumber numberWithInt:self.accountLogin_InPath],@"accountLogin_InPath",
                          [NSNumber numberWithInt:self.accountLogin],@"accountLogin",
                          [NSNumber numberWithInt:self.durationOfUseBackgroundSeconds_InPath],@"durationOfUseBackgroundSeconds_InPath",
                          [NSNumber numberWithInt:self.durationOfUseBackgroundSeconds],@"durationOfUseBackgroundSeconds",
                          self.PathYawCount,@"PathYawCount",
                          self.downloadMapByPhoneDict,@"downloadMapByPhoneDict",
                           [NSNumber numberWithInt:self.recalculationCount],@"recalculationCount",
                          [NSNumber numberWithInt:self.TMCTime],@"TMCTime",
                          nil];
    
    
    [dic writeToFile:filePath atomically:YES];
}

//将数组所有位数都置为0
-(void) resetArrayZero :(NSMutableArray *)sender
{
    NSNumber * number = [NSNumber numberWithInt:0];
    for(int i = 0; i < sender.count; i++)
    {
        [sender replaceObjectAtIndex:i withObject:number];
    }
}

//复位
-(void)resetData
{
    self.openNavigation = 0;
    self.addressSearch_InPath = 0;
    self.addressSearch = 0;
    self.crossSearch_InPath = 0;
    self.crossSearch = 0;
    self.defaultSort_InPath = 0;
    self.defaultSort = 0;
    self.distanceSort_InPath = 0;
    self.distanceSort = 0;
    self.regionSelect_InPath = 0;
    self.regionSelect = 0;
    self.voiceSearchGoWhere_InPath = 0;
    self.voiceSearchGoWhere = 0;
    self.alongCursorSearch_InPath = 0;
    self.alongCursorSearch = 0;
    self.alongPathSearch_InPath = 0;
    self.alongPathSearch = 0;
    self.alongDestinationsearch_InPath = 0;
    self.alongDestinationsearch = 0;
    [self resetArrayZero:self.stationType_InPath];
    [self resetArrayZero:self.stationType];
    self.parkingType_InPath = 0;
    self.parkingType = 0;
    [self resetArrayZero:self.businessCasualType_InPath];
    [self resetArrayZero:self.businessCasualType];
    [self resetArrayZero:self.foodDrinkType_InPath];
    [self resetArrayZero:self.foodDrinkType];
    [self resetArrayZero:self.hotelType_InPath];
    [self resetArrayZero:self.hotelType];
    [self resetArrayZero:self.shoppingType_InPath];
    [self resetArrayZero:self.shoppingType];
    [self resetArrayZero:self.sightsType_InPath];
    [self resetArrayZero:self.sightsType];
    [self resetArrayZero:self.transportServicesType_InPath];
    [self resetArrayZero:self.transportServicesType];
    [self resetArrayZero:self.financeType_InPath];
    [self resetArrayZero:self.financeType];
    [self resetArrayZero:self.recreationType_InPath];
    [self resetArrayZero:self.recreationType];
    [self resetArrayZero:self.carServiceType_InPath];
    [self resetArrayZero:self.carServiceType];
    [self resetArrayZero:self.sportsType_InPath];
    [self resetArrayZero:self.sportsType];
    [self resetArrayZero:self.livingServiceType_InPath];
    [self resetArrayZero:self.livingServiceType];
    [self resetArrayZero:self.educationType_InPath];
    [self resetArrayZero:self.educationType];
    [self resetArrayZero:self.hospitalType_InPath];
    [self resetArrayZero:self.hospitalType];
    [self resetArrayZero:self.governmentType_InPath];
    [self resetArrayZero:self.governmentType];
    self.buildingType_InPath  = 0;
    self.buildingType = 0;
    self.CorporateType_InPath = 0;
    self.CorporateType = 0;
    self.residentialAreaType_InPath = 0;
    self.residentialAreaType = 0;
    self.cityType_InPath = 0;
    self.cityType = 0;
    self.detailSetEnd_InPath = 0;
    self.detailSetEnd = 0;
    self.viewPOISetEnd_InPath = 0;
    self.viewPOISetEnd = 0;
    self.detailSetStart_InPath = 0;
    self.detailSetStart = 0;
    self.viewPOISetStart_InPath = 0;
    self.viewPOISetStart = 0;
    self.figureMapSetSatar_InPath = 0;
    self.figureMapSetSatar = 0;
    self.viewPOISetWaypoint_InPath = 0;
    self.viewPOISetWaypoint = 0;
    self.figureSetWaypoint_InPath = 0;
    self.figureSetWaypoint = 0;
    self.managePathDetail_InPath = 0;
    self.managePathDetail = 0;
    self.stopNaviByTurnArrow_InPath = 0;
    self.stopNaviByTurnArrow = 0;
    self.stopNaviByManage_InPath = 0;
    self.stopNaviByManage = 0;
    self.simulatedNaviByOverview_InPath = 0;
    self.simulatedNaviByOverview = 0;
    self.simulatedNaviByManage_InPath = 0;
    self.simulatedNaviByManage = 0;
    self.planningByManage_InPath = 0;
    self.planningByManage = 0;
    self.overviewByManage_InPath = 0;
    self.overviewByManage = 0;
    self.suggestedLtineraries_InPath = 0;
    self.suggestedLtineraries = 0;
    self.highPriority_InPath = 0;
    self.highPriority = 0;
    self.economicRoute_InPath = 0;
    self.economicRoute = 0;
    self.shortestRoute_InPath = 0;
    self.shortestRoute = 0;
    self.directionsContrast_InPath = 0;
    self.directionsContrast = 0;
    self.overviewViewFull_InPath = 0;
    self.overviewViewFull = 0;
    self.viewTripComputer_InPath = 0;
    self.viewTripComputer = 0;
    self.enlargeByButton_InPath = 0;
    self.enlargeByButton = 0;
    self.narrowByButton_InPath = 0;
    self.narrowByButton = 0;
    self.enlargeByDoubleClick_InPath = 0;
    self.enlargeByDoubleClick = 0;
    self.narrowByTwoFingerClick_InPath = 0;
    self.narrowByTwoFingerClick = 0;
    self.enlargeByPinOpen_InPath = 0;
    self.enlargeByPinOpen = 0;
    self.narrowByPinKneading_InPath = 0;
    self.narrowByPinKneading = 0;
    self.favoriteCurrentPoint_InPath = 0;
    self.favoriteCurrentPoint = 0;
    self.messageBox_InPath = 0;
    self.messageBox = 0;
    self.pathManage_InPath = 0;
    self.pathManage = 0;
    self.switchMainAndSideRoads_InPath = 0;
    self.switchMainAndSideRoads = 0;
    self.trafficIncident_InPath = 0;
    self.trafficIncident = 0;
    self.feedback_InPath = 0;
    self.feedback = 0;
    self.trafficEventDisplay_InPath = 0;
    self.trafficEventDisplay = 0;
    self.networkNavi_InPath = 0;
    self.networkNavi = 0;
    self.networkNaviSeconds_InPath = 0;
    self.networkNaviSeconds = 0;
    self.CPCNavi_InPath = 0;
    self.CPCNavi = 0;
    self.CPCNaviSeconds_InPath = 0;
    self.CPCNaviSeconds = 0;
    self.horizontalScreenSeconds_InPath = 0;
    self.horizontalScreenSeconds = 0;
    self.verticalScreenSeconds_InPath = 0;
    self.verticalScreenSeconds = 0;
    self.mapProportion_25_InPath = 0;
    self.mapProportion_25 = 0;
    self.mapProportion_50_InPath = 0;
    self.mapProportion_50 = 0;
    self.mapProportion_100_InPath = 0;
    self.mapProportion_100 = 0;
    self.mapProportion_200_InPath = 0;
    self.mapProportion_200 = 0;
    self.mapProportion_500_InPath = 0;
    self.mapProportion_500 = 0;
    self.mapProportion_1k_InPath = 0;
    self.mapProportion_1k = 0;
    self.mapProportion_2k_InPath = 0;
    self.mapProportion_2k = 0;
    self.mapProportion_5k_InPath = 0;
    self.mapProportion_5k = 0;
    self.mapProportion_10k_InPath = 0;
    self.mapProportion_10k = 0;
    self.mapProportion_50k_InPath = 0;
    self.mapProportion_50k = 0;
    self.mapProportion_200k_InPath = 0;
    self.mapProportion_200k = 0;
    self.mapProportion_500k_InPath = 0;
    self.mapProportion_500k = 0;
    self.openEnglishVersionSeconds_InPath = 0;
    self.openEnglishVersionSeconds = 0;
    
    //自动生成的复位
    self.manualSearch_InPath = 0;
    self.manualSearch = 0;
    self.smartSearch_InPath = 0;
    self.smartSearch = 0;
    self.networkSearch_InPath = 0;
    self.networkSearch = 0;
    self.voiceSearchSide_InPath = 0;
    self.voiceSearchSide = 0;
    self.peripherySearch_InPath = 0;
    self.peripherySearch = 0;
    self.figureMapSetEnd_InPath = 0;
    self.figureMapSetEnd = 0;
    self.historyDestinnation_InPath = 0;
    self.historyDestinnation = 0;
    self.addressBook_InPath = 0;
    self.addressBook = 0;
    self.contactsNavigation_InPath = 0;
    self.contactsNavigation = 0;
    self.routeDetailsOverview_InPath = 0;
    self.routeDetailsOverview = 0;
    self.overviewNextWay_InPath = 0;
    self.overviewNextWay = 0;
    self.shareLocationBySMS_InPath = 0;
    self.shareLocationBySMS = 0;
    self.shareLocationByEmail_InPath = 0;
    self.shareLocationByEmail = 0;
    self.shareLocationBySina_InPath = 0;
    self.shareLocationBySina = 0;
    self.shareLocationByTX_InPath = 0;
    self.shareLocationByTX = 0;
    self.microShareLocation_InPath = 0;
    self.microShareLocation = 0;
    self.northUpView_InPath = 0;
    self.northUpView = 0;
    self.northUpViewSeconds_InPath = 0;
    self.northUpViewSeconds = 0;
    self.upView_InPath = 0;
    self.upView = 0;
    self.upViewSeconds_InPath = 0;
    self.upViewSeconds = 0;
    self.car3DView_InPath = 0;
    self.car3DView = 0;
    self.car3DViewSeconds_InPath = 0;
    self.car3DViewSeconds = 0;
    self.realTimeTraffic_InPath = 0;
    self.realTimeTraffic = 0;
    self.trafficInformation_InPath = 0;
    self.trafficInformation = 0;
    self.smartDrivingServices_InPath = 0;
    self.smartDrivingServices = 0;
    self.smartDriveSetDestination_InPath = 0;
    self.smartDriveSetDestination = 0;
    self.layerByCtripOnline_InPath = 0;
    self.layerByCtripOnline = 0;
    self.layerByCtripPhone_InPath = 0;
    self.layerByCtripPhone = 0;
    self.layerByCtripOnlineSeconds_InPath = 0;
    self.layerByCtripOnlineSeconds = 0;
    self.layerByTravel_InPath = 0;
    self.layerByTravel = 0;
    self.layerByTravelSeconds_InPath = 0;
    self.layerByTravelSeconds = 0;
    self.layerByFood_InPath = 0;
    self.layerByFood = 0;
    self.layerByFoodSeconds_InPath = 0;
    self.layerByFoodSeconds = 0;
    self.layerByGolf_InPath = 0;
    self.layerByGolf = 0;
    self.layerByGolfSeconds_InPath = 0;
    self.layerByGolfSeconds = 0;
    self.layerByMyself_InPath = 0;
    self.layerByMyself = 0;
    self.layerByMyselfSeconds_InPath = 0;
    self.layerByMyselfSeconds = 0;
    self.layerByFriendsShare_InPath = 0;
    self.layerByFriendsShare = 0;
    self.layerByFriendsShareSeconds_InPath = 0;
    self.layerByFriendsShareSeconds = 0;
    self.layerByGDShare_InPath = 0;
    self.layerByGDShare = 0;
    self.layerByGDShareSeconds_InPath = 0;
    self.layerByGDShareSeconds = 0;
    self.goHome_InPath = 0;
    self.goHome = 0;
    self.backCompany_InPath = 0;
    self.backCompany = 0;
    self.avoidTraffice_InPath = 0;
    self.avoidTraffice = 0;
    self.avoidRouteDetail_InPath = 0;
    self.avoidRouteDetail = 0;
    self.beforeAvoid_InPath = 0;
    self.beforeAvoid = 0;
    self.afterAvoid_InPath = 0;
    self.afterAvoid = 0;
    self.cancelAvoid_InPath = 0;
    self.cancelAvoid = 0;
    self.routingFunction_InPath = 0;
    self.routingFunction = 0;
    self.cloudBackupInformation_InPath = 0;
    self.cloudBackupInformation = 0;
    self.setHome_InPath = 0;
    self.setHome = 0;
    self.setCompany_InPath = 0;
    self.setCompany = 0;
    self.downloadManage_InPath = 0;
    self.downloadManage = 0;
    self.mapUpdateManage_InPath = 0;
    self.mapUpdateManage = 0;
    self.locusManage_InPath = 0;
    self.locusManage = 0;
    self.flowStatistics_InPath = 0;
    self.flowStatistics = 0;
    self.iLoveGD_InPath = 0;
    self.iLoveGD = 0;
    self.newVersionFunction_InPath = 0;
    self.newVersionFunction = 0;
    self.versionInfo_InPath = 0;
    self.versionInfo = 0;
    self.downloadMapByPhone = 0;
    self.travelLayerData = 0;
    
    self.durationOfUse_InPath = 0;
    self.durationOfUse = 0;
    if (downloadMapByPhoneDict) {
        [downloadMapByPhoneDict release];
        downloadMapByPhoneDict = nil;
    }
    
    downloadMapByPhoneDict = [[NSMutableDictionary alloc]init];
    //  self.downloadMapByPhoneDict = [NSMutableDictionary dictionary];
    self.lastStartUp = @"";
    //**5.29
    
    self.goWhere_InPath = 0;
    self.goWhere = 0;
    self.commonUse_InPath = 0;
    self.commonUse = 0;
    self.alertFavCurrentPoint_InPath = 0;
    self.alertFavCurrentPoint = 0;
    self.myFavorites_InPath = 0;
    self.myFavorites = 0;
    self.historyDestination_InPath = 0;
    self.historyDestination = 0;
    self.voiceSelectHenanMale_InPath = 0;
    self.voiceSelectHenanMale = 0;
    self.multipleWaypoints_InPath = 0;
    self.multipleWaypoints = 0;
    self.fontSizeLarge_InPath = 0;
    self.fontSizeLarge = 0;
    self.fontSizeMedium_InPath = 0;
    self.fontSizeMedium = 0;
    self.fontSizeSmall_InPath = 0;
    self.fontSizeSmall = 0;
    self.dayAndNightModeDay_InPath = 0;
    self.dayAndNightModeDay = 0;
    self.dayAndNightModeNight_InPath = 0;
    self.dayAndNightModeNight = 0;
    self.dayAndNightModeAuto_InPath = 0;
    self.dayAndNightModeAuto = 0;
    self.voiceSelectNationalFemale_InPath = 0;
    self.voiceSelectNationalFemale = 0;
    self.voiceSelectNationalMale_InPath = 0;
    self.voiceSelectNationalMale = 0;
    self.voiceSelectTaiwanFemale_InPath = 0;
    self.voiceSelectTaiwanFemale = 0;
    self.voiceSelectCantoneseFemale_InPath = 0;
    self.voiceSelectCantoneseFemale = 0;
    self.voiceSelectNortheasternFemale_InPath = 0;
    self.voiceSelectNortheasternFemale = 0;
    self.voiceSelectSichuanFemale_InPath = 0;
    self.voiceSelectSichuanFemale = 0;
    self.voiceSelectHunanMale_InPath = 0;
    self.voiceSelectHunanMale = 0;
    self.voiceFrequencyGeneral_InPath = 0;
    self.voiceFrequencyGeneral = 0;
    self.voiceFrequencyFrequent_InPath = 0;
    self.voiceFrequencyFrequent = 0;
    self.informationFirstAuto_InPath = 0;
    self.informationFirstAuto = 0;
    self.informationFirstGasStation_InPath = 0;
    self.informationFirstGasStation = 0;
    self.informationFirstParking_InPath = 0;
    self.informationFirstParking = 0;
    self.informationFirstFood_InPath = 0;
    self.informationFirstFood = 0;
    self.informationFirstLodging_InPath = 0;
    self.informationFirstLodging = 0;
    self.informationFirstFun_InPath = 0;
    self.informationFirstFun = 0;
    self.informationFirstAttractions_InPath = 0;
    self.informationFirstAttractions = 0;
    self.informationFirstMedical_InPath = 0;
    self.informationFirstMedical = 0;
    self.store_InPath = 0;
    self.store = 0;
    self.accountLogin_InPath = 0;
    self.accountLogin = 0;
    self.durationOfUseBackgroundSeconds_InPath = 0;
    self.durationOfUseBackgroundSeconds = 0;
    self.recalculationCount = 0;
    self.TMCTime = 0;
    // [self saveData];
}

#pragma mark ---  索引的数组下表变量添加  ----
/*
 对于周边的查询，当有下级的子菜单统计时，使用数组保存数据，加一的操作调用该函数
 @param sender 传入的要加一的对象数组(NSMutableArray)
 @param index  传入的sender在指定索引处的变量+1
 @return BOOL  传入的索引是否越界
 **/
-(BOOL) searchArroundAdd:(NSMutableArray *)sender withIndex:(int) index
{
    if(index >= sender.count )
    {
        return NO;
    }
    int i = [[sender objectAtIndex:index] intValue];
    i++;
    [sender replaceObjectAtIndex:index withObject:[NSNumber numberWithInt:i]];
    return  YES;
}

/*
 统计周边各个项
 @param section  传入相对应的section
 @param subIndex 若有子列表传入对应子列表的索引
 **/
- (void)searchArroundCount:(int)section SubIndex:(int)subIndex
{
    switch (section) {
        case 0:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.stationType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.stationType withIndex:subIndex];
            }
        }
            break;
        case 1:
        {
            if ([self isPath]) {
                self.parkingType_InPath ++;
            }
            else{
                self.parkingType ++;
            }
        }
            break;
        case 2:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.businessCasualType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.businessCasualType withIndex:subIndex];
            }
        }
            break;
        case 3:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.foodDrinkType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.foodDrinkType withIndex:subIndex];
            }
        }
            break;
        case 4:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.hotelType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.hotelType withIndex:subIndex];
            }
        }
            break;
        case 5:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.shoppingType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.shoppingType withIndex:subIndex];
            }
        }
            break;
        case 6:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.sightsType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.sightsType withIndex:subIndex];
            }
        }
            break;
        case 7:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.transportServicesType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.transportServicesType withIndex:subIndex];
            }
        }
            break;
        case 8:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.financeType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.financeType withIndex:subIndex];
            }
        }
            break;
        case 9:
        {
            if ([self isPath]) {
                self.buildingType_InPath ++;
            }
            else{
                self.buildingType ++;
            }
        }
            break;
        case 10:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.recreationType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.recreationType withIndex:subIndex];
            }
        }
            break;
        case 11:
        {
            if ([self isPath]) {
                self.CorporateType_InPath ++;
            }
            else{
                self.CorporateType ++;
            }
        }
            break;
        case 12:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.carServiceType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.carServiceType withIndex:subIndex];
            }
        }
            break;
        case 13:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.sportsType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.sportsType withIndex:subIndex];
            }
        }
            break;
        case 14:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.livingServiceType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.livingServiceType withIndex:subIndex];
            }
        }
            break;
        case 15:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.educationType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.educationType withIndex:subIndex];
            }
        }
            break;
        case 16:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.hospitalType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.hospitalType withIndex:subIndex];
            }
        }
            break;
        case 17:
        {
            if ([self isPath]) {
                self.residentialAreaType_InPath ++;
            }
            else{
                self.residentialAreaType ++;
            }
        }
            break;
        case 18:
        {
            if ([self isPath]) {
                [self searchArroundAdd:self.governmentType_InPath withIndex:subIndex];
            }
            else{
                [self searchArroundAdd:self.governmentType withIndex:subIndex];
            }
        }
            break;
        case 19:
        {
            if ([self isPath]) {
                self.cityType_InPath ++;
            }
            else{
                self.cityType ++;
            }
        }
            break;
        default:
            break;
    }
}

//---  计时使用的中间变量  ---
static int UBNetNaviSeconds           = 0;
//static int UBNetCPCNaviSeconds        = 0;
static int UBHorizontalScreenSeconds  = 0;
static int UBVerticalScreenSeconds    = 0;
static int UB_25_MapSeconds   = 0;
static int UB_50_MapSeconds   = 0;
static int UB_100_MapSeconds  = 0;
static int UB_200_MapSeconds  = 0;
static int UB_500_MapSeconds  = 0;
static int UB_1k_MapSeconds   = 0;
static int UB_2k_MapSeconds   = 0;
static int UB_5k_MapSeconds   = 0;
static int UB_10k_MapSeconds  = 0;
static int UB_50k_MapSeconds  = 0;
static int UB_200k_MapSeconds = 0;
static int UB_500k_MapSeconds = 0;
//车的视角模式
static int UBnorthUpViewSeconds =0;
static int UBupViewSeconds = 0;
static int UBcar3DViewSeconds = 0;
//使用时长
static int UBDurationOfUseSeconds = 0;
static int UBDurationOfUseBackgroundSeconds = 0;

static int UBNetNaviSeconds_Path           = 0;
//static int UBNetCPCNaviSeconds_Path        = 0;
static int UBHorizontalScreenSeconds_Path  = 0;
static int UBVerticalScreenSeconds_Path    = 0;
static int UB_25_MapSeconds_Path   = 0;
static int UB_50_MapSeconds_Path   = 0;
static int UB_100_MapSeconds_Path  = 0;
static int UB_200_MapSeconds_Path  = 0;
static int UB_500_MapSeconds_Path  = 0;
static int UB_1k_MapSeconds_Path   = 0;
static int UB_2k_MapSeconds_Path   = 0;
static int UB_5k_MapSeconds_Path   = 0;
static int UB_10k_MapSeconds_Path  = 0;
static int UB_50k_MapSeconds_Path  = 0;
static int UB_200k_MapSeconds_Path = 0;
static int UB_500k_MapSeconds_Path = 0;
static int UBnorthUpViewSeconds_Path = 0;
static int UBupViewSeconds_Path = 0;
static int UBcar3DViewSeconds_Path = 0;
static int UBDurationOfUseSeconds_Path = 0;
static int UBDurationOfUseBackgroundSeconds_Path = 0;

//---  定时器定时调用的函数  ---
-(void) timeCountAction
{
    
    if([self isPath])
    {
        //屏幕方向
        [self screenStatusBarOrientationPathAdd];
        //地图比例
        [self  mapProportionPath];
        //使用网络地图
        [self networkNaviCountPathAdd];
        //车辆视图分别使用时长
        [self mapViewModePathAdd];
        //程序使用时长——前台
        [self durationOfUsePathAdd];
    }
    else
    {
        [self screenStatusBarOrientationAdd];
        [self  mapProportion];
        [self networkNaviCountAdd];
        [self mapViewModeAdd];
        [self durationOfUseAdd];
    }
    [self TMCTimeTotal];
}

//---  定时器定时调用  ---
-(void)timeCount
{
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timeCountAction) userInfo:nil repeats:YES];
}

#pragma mark ---  辅助函数  ---
//---  屏幕方向统计  ---
-(void) screenStatusBarOrientationPathAdd
{
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication]statusBarOrientation];
    if(orientation == UIDeviceOrientationLandscapeRight || orientation == UIDeviceOrientationLandscapeLeft)
    {
        UBHorizontalScreenSeconds_Path++;
        if(UBHorizontalScreenSeconds_Path >= 60)
        {
            self.horizontalScreenSeconds_InPath++;
            UBHorizontalScreenSeconds_Path = 0;
        }
    }
    else
    {
        UBVerticalScreenSeconds_Path++;
        if(UBVerticalScreenSeconds_Path >= 60)
        {
            self.verticalScreenSeconds_InPath++;
            UBVerticalScreenSeconds_Path = 0;
        }
    }
}

-(void) screenStatusBarOrientationAdd
{
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication]statusBarOrientation];
    if(orientation == UIDeviceOrientationLandscapeRight || orientation == UIDeviceOrientationLandscapeLeft)
    {
        UBHorizontalScreenSeconds++;
        if(UBHorizontalScreenSeconds >= 60)
        {
            UBHorizontalScreenSeconds = 0;
            self.horizontalScreenSeconds++;
        }
    }
    else
    {
        UBVerticalScreenSeconds++;
        if(UBVerticalScreenSeconds >= 60)
        {
            UBVerticalScreenSeconds = 0;
            self.verticalScreenSeconds++;
        }
    }
}

//---  地图缩放级别判断统计  ---
-(void) mapProportionPath
{
    GZOOMLEVEL pValue;
	GDBL_GetParam(G_MAP_SCALE_LEVEL_2D, &pValue);
    switch (pValue) {
        case ZOOM_25_M:
            UB_25_MapSeconds_Path++;
            if(UB_25_MapSeconds_Path >= 60){
                self.mapProportion_25_InPath++;
                UB_25_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_50_M:
            UB_50_MapSeconds_Path++;
            if(UB_50_MapSeconds_Path >= 60){
                self.mapProportion_50_InPath++;
                UB_50_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_100_M:
            UB_100_MapSeconds_Path++;
            if(UB_100_MapSeconds_Path >= 60){
                self.mapProportion_100_InPath++;
                UB_100_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_200_M:
            UB_200_MapSeconds_Path++;
            if(UB_200_MapSeconds_Path >= 60){
                self.mapProportion_200_InPath++;
                UB_200_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_500_M:
            UB_500_MapSeconds_Path++;
            if(UB_500_MapSeconds_Path >= 60){
                self.mapProportion_100_InPath++;
                UB_500_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_1_KM:
            UB_1k_MapSeconds_Path++;
            if(UB_1k_MapSeconds_Path >= 60){
                self.mapProportion_1k_InPath++;
                UB_1k_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_2_KM:
            UB_2k_MapSeconds_Path++;
            if(UB_2k_MapSeconds_Path >= 60){
                self.mapProportion_2k_InPath++;
                UB_2k_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_5_KM:
            UB_5k_MapSeconds_Path++;
            if(UB_5k_MapSeconds_Path >= 60){
                self.mapProportion_5k_InPath++;
                UB_5k_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_10_KM:
            UB_10k_MapSeconds_Path++;
            if(UB_10k_MapSeconds_Path >= 60){
                self.mapProportion_10k_InPath++;
                UB_10k_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_50_KM:
            UB_50k_MapSeconds_Path++;
            if(UB_50k_MapSeconds_Path >= 60){
                self.mapProportion_50k_InPath++;
                UB_50k_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_200_KM:
            UB_200k_MapSeconds_Path++;
            if(UB_200k_MapSeconds_Path >= 60){
                self.mapProportion_200k_InPath++;
                UB_200k_MapSeconds_Path = 0;
            }
            break;
        case ZOOM_500_KM:
            UB_500k_MapSeconds_Path++;
            if(UB_500k_MapSeconds_Path >= 60){
                self.mapProportion_500k_InPath++;
                UB_500k_MapSeconds_Path = 0;
            }
            break;
        default:
            break;
    }
}

-(void) mapProportion
{
    GZOOMLEVEL pValue;
	GDBL_GetParam(G_MAP_SCALE_LEVEL_2D, &pValue);
    switch (pValue) {
        case ZOOM_25_M:
            UB_25_MapSeconds++;
            if(UB_25_MapSeconds >= 60){
                self.mapProportion_25++;
                UB_25_MapSeconds = 0;
            }
            break;
        case ZOOM_50_M:
            UB_50_MapSeconds++;
            if(UB_50_MapSeconds >= 60){
                self.mapProportion_50++;
                UB_50_MapSeconds = 0;
            }
            break;
        case ZOOM_100_M:
            UB_100_MapSeconds++;
            if(UB_100_MapSeconds >= 60){
                self.mapProportion_100++;
                UB_100_MapSeconds = 0;
            }
            break;
        case ZOOM_200_M:
            UB_200_MapSeconds++;
            if(UB_200_MapSeconds >= 60){
                self.mapProportion_200++;
                UB_200_MapSeconds = 0;
            }
            break;
        case ZOOM_500_M:
            UB_500_MapSeconds++;
            if(UB_500_MapSeconds >= 60){
                self.mapProportion_100++;
                UB_500_MapSeconds = 0;
            }
            break;
        case ZOOM_1_KM:
            UB_1k_MapSeconds++;
            if(UB_1k_MapSeconds >= 60){
                self.mapProportion_1k++;
                UB_1k_MapSeconds = 0;
            }
            break;
        case ZOOM_2_KM:
            UB_2k_MapSeconds++;
            if(UB_2k_MapSeconds >= 60){
                self.mapProportion_2k++;
                UB_2k_MapSeconds = 0;
            }
            break;
        case ZOOM_5_KM:
            UB_5k_MapSeconds++;
            if(UB_5k_MapSeconds >= 60){
                self.mapProportion_5k++;
                UB_5k_MapSeconds = 0;
            }
            break;
        case ZOOM_10_KM:
            UB_10k_MapSeconds++;
            if(UB_10k_MapSeconds >= 60){
                self.mapProportion_10k++;
                UB_10k_MapSeconds = 0;
            }
            break;
        case ZOOM_50_KM:
            UB_50k_MapSeconds++;
            if(UB_50k_MapSeconds >= 60){
                self.mapProportion_50k++;
                UB_50k_MapSeconds = 0;
            }
            break;
        case ZOOM_200_KM:
            UB_200k_MapSeconds++;
            if(UB_200k_MapSeconds >= 60){
                self.mapProportion_200k++;
                UB_200k_MapSeconds = 0;
            }
            break;
        case ZOOM_500_KM:
            UB_500k_MapSeconds++;
            if(UB_500k_MapSeconds >= 60){
                self.mapProportion_500k++;
                UB_500k_MapSeconds = 0;
            }
            break;
        default:
            break;
    }
}

//---  网络导航时间统计  ---
-(void) networkNaviCountPathAdd
{
    if([ANParamValue sharedInstance].isUseNETMap == YES)
    {
        UBNetNaviSeconds_Path++;
        if(UBNetNaviSeconds_Path >= 60)
        {
            self.networkNaviSeconds_InPath++;
            UBNetNaviSeconds_Path = 0;
        }
    }
}

-(void) networkNaviCountAdd
{
    if([ANParamValue sharedInstance].isUseNETMap == YES)
    {
        UBNetNaviSeconds++;
        if(UBNetNaviSeconds >= 60)
        {
            self.networkNaviSeconds++;
            UBNetNaviSeconds = 0;
        }
    }
}

//---  地图的三种视图模式的时间统计  ---
-(void) mapViewModePathAdd
{
    GMAPVIEWMODE eMapViewMode;
    GDBL_GetParam(G_MAP_VIEW_MODE, &eMapViewMode);
    switch (eMapViewMode) {
        case GMAPVIEW_MODE_NORTH:
        {
            UBnorthUpViewSeconds_Path++;
            if (UBnorthUpViewSeconds_Path >= 60) {
                self.northUpViewSeconds_InPath++;
                UBnorthUpViewSeconds_Path = 0;
            }
        }
            break;
        case GMAPVIEW_MODE_CAR:
        {
            UBupViewSeconds_Path++;
            if(UBupViewSeconds_Path >= 60){
                self.upViewSeconds_InPath++;
                UBupViewSeconds_Path = 0;
            }
        }
            break;
        case GMAPVIEW_MODE_3D:
        {
            UBcar3DViewSeconds_Path++;
            if(UBcar3DViewSeconds_Path >= 60)
            {
                self.car3DViewSeconds_InPath++;
                UBcar3DViewSeconds_Path = 0;
            }
        }
            break;
        default:
            break;
    }
}

-(void) mapViewModeAdd
{
    GMAPVIEWMODE eMapViewMode;
    GDBL_GetParam(G_MAP_VIEW_MODE, &eMapViewMode);
    switch (eMapViewMode) {
        case GMAPVIEW_MODE_NORTH:
        {
            UBnorthUpViewSeconds++;
            if (UBnorthUpViewSeconds >= 60) {
                self.northUpViewSeconds++;
                UBnorthUpViewSeconds = 0;
            }
        }
            break;
        case GMAPVIEW_MODE_CAR:
        {
            UBupViewSeconds++;
            if(UBupViewSeconds >= 60){
                self.upViewSeconds++;
                UBupViewSeconds = 0;
            }
        }
            break;
        case GMAPVIEW_MODE_3D:
        {
            UBcar3DViewSeconds++;
            if(UBcar3DViewSeconds >= 60)
            {
                self.car3DViewSeconds++;
                UBcar3DViewSeconds = 0;
            }
        }
            break;
        default:
            break;
    }
}

//---  使用时长前台——后台  ---
- (void) durationOfUsePathAdd
{
    if(UIApplicationStateBackground == [[UIApplication sharedApplication] applicationState] || UIApplicationStateInactive == [[UIApplication sharedApplication] applicationState])
    {
        UBDurationOfUseBackgroundSeconds_Path++;
        if(UBDurationOfUseBackgroundSeconds_Path >= 60)
        {
            self.durationOfUseBackgroundSeconds_InPath++;
            UBDurationOfUseBackgroundSeconds_Path = 0;
        }
    }
    else
    {
        UBDurationOfUseSeconds_Path++;
        if(UBDurationOfUseSeconds_Path >= 60){
            self.durationOfUse_InPath++;
            UBDurationOfUseSeconds_Path = 0;
        }
    }
}

- (void) durationOfUseAdd
{
    if(UIApplicationStateBackground == [[UIApplication sharedApplication] applicationState] || UIApplicationStateInactive == [[UIApplication sharedApplication] applicationState])
    {
        UBDurationOfUseBackgroundSeconds++;
        if(UBDurationOfUseBackgroundSeconds >= 60)
        {
            self.durationOfUseBackgroundSeconds++;
            UBDurationOfUseBackgroundSeconds = 0;
        }
    }
    else
    {
        UBDurationOfUseSeconds++;
        if(UBDurationOfUseSeconds >= 60){
            self.durationOfUse++;
            UBDurationOfUseSeconds = 0;
        }
    }
}


- (void) TMCTimeTotal
{
    if([[ANParamValue sharedInstance] GMD_isTMCOn])
    {
        TMCTime++;
    }
}

//---  CPC导航  ---
#pragma mark ---  用户偏航统计  ---
//重置路径统计信息
- (void)resetPathYawData
{
    [PathYawCount removeAllObjects];
    [self saveData];
}
//添加路径偏移统计信息
- (BOOL)addInfoToRouteYawCount
{
    self.recalculationCount ++ ;
    NSMutableDictionary *routeYawInfo;
    NSMutableArray *midArray = [[NSMutableArray alloc] initWithCapacity:2];
    NSString *yawTime,*dataVersion,*appVersion,*startCoord_x,*startCoord_y,*desCoord_x,*desCoord_y,*carCoord_x,*carCoord_y;
    
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss"];
    yawTime = [formatter stringFromDate: [NSDate date]];
    
    GVERSION pVersion = {0};
    GDBL_GetMapVersion(NULL,&pVersion);
    dataVersion = [NSString stringWithFormat:@"%s",pVersion.szVersion];
    
    appVersion = [NSString stringWithFormat:@"%.1f",SOFTVERSIONNUM];
    
    GROUTEOPTION routeRule;
    GDBL_GetParam(G_ROUTE_OPTION, &routeRule);
    
    GPOI *ppJourneyPoint = NULL;
	GDBL_GetJourneyPoint(&ppJourneyPoint);
    
    for (int i = 1; i < 4; i++) {
        if (ppJourneyPoint[i].Coord.x != 0 || ppJourneyPoint[i].Coord.y != 0) {
            NSMutableDictionary *midCoord = [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:ppJourneyPoint[i].Coord.x],@"midLon",[NSNumber numberWithInt:ppJourneyPoint[i].Coord.y],@"midLat", nil];
            [midArray addObject:midCoord];
        }
    }
    GCARINFO carInfo = {0};
    GDBL_GetCarInfo(&carInfo);
    
    startCoord_x = [NSString stringWithFormat:@"%d",ppJourneyPoint[0].Coord.x];
    startCoord_y = [NSString stringWithFormat:@"%d",ppJourneyPoint[0].Coord.y];
    desCoord_x = [NSString stringWithFormat:@"%d",ppJourneyPoint[6].Coord.x];
    desCoord_y = [NSString stringWithFormat:@"%d",ppJourneyPoint[6].Coord.y];
    carCoord_x = [NSString stringWithFormat:@"%d",carInfo.Coord.x];
    carCoord_y = [NSString stringWithFormat:@"%d",carInfo.Coord.y];
    routeYawInfo = [[NSMutableDictionary alloc] init];
    if (yawTime) {
        [routeYawInfo setObject:yawTime forKey:@"time"];
    }
    if (dataVersion) {
        [routeYawInfo setObject:dataVersion forKey:@"dataVersion"];
    }
    if (appVersion) {
        [routeYawInfo setObject:appVersion forKey:@"appVersion"];
    }
    if (midArray && [midArray count] > 0) {
        [routeYawInfo setObject:midArray forKey:@"midArray"];
    }
    if(startCoord_x)
    {
        [routeYawInfo setObject:startCoord_x forKey:@"startLon"];
    }
    if(startCoord_y)
    {
        [routeYawInfo setObject:startCoord_y forKey:@"startLat"];
    }
    if(desCoord_x)
    {
        [routeYawInfo setObject:desCoord_x forKey:@"desLon"];
    }
    if(desCoord_y)
    {
        [routeYawInfo setObject:desCoord_y forKey:@"desLat"];
    }
    [routeYawInfo setObject:[NSNumber numberWithInt:routeRule] forKey:@"pathPlan"];
    if(carCoord_x)
    {
        [routeYawInfo setObject:carCoord_x forKey:@"yawLon"];
    }
    if(carCoord_y)
    {
        [routeYawInfo setObject:carCoord_y forKey:@"yawLat"];
    }
    if (self.PathYawCount && self.PathYawCount.count > 300) {
        [self.PathYawCount removeObjectAtIndex:0];
    }
    [self.PathYawCount addObject:routeYawInfo];
    [midArray release];
    [routeYawInfo release];
    return YES;
}
//组装路径偏航信息
- (NSString *)compostPathYaw
{
    
    NSMutableString *pathYawString = [[[NSMutableString alloc] init] autorelease];
	[pathYawString appendFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>"
	"<useraction>""<routeyaw>"];
    
    if (self.PathYawCount && [self.PathYawCount count] >0 ) {
        for (NSDictionary *pathYaw in self.PathYawCount)
        {
            
            [pathYawString appendFormat:@""];
            [pathYawString appendFormat:@"<item>""<recordtime>%@</recordtime>",[pathYaw objectForKey:@"time"]];
            [pathYawString appendFormat:@""];
            [pathYawString appendFormat:@"<dataversion>%@</dataversion>",[pathYaw objectForKey:@"dataVersion"]];
            [pathYawString appendFormat:@""];
            [pathYawString appendFormat:@"<appversion>%@</appversion>",[pathYaw objectForKey:@"appVersion"]];
            [pathYawString appendFormat:@""];
            [pathYawString appendFormat:@"<start_lat>%@</start_lat>""<start_lon>%@</start_lon>",[pathYaw objectForKey:@"startLat"],[pathYaw objectForKey:@"startLon"]];
            [pathYawString appendFormat:@""];
            [pathYawString appendFormat:@"<end_lat>%@</end_lat>""<end_lon>%@</end_lon>",[pathYaw objectForKey:@"desLat"],[pathYaw objectForKey:@"desLon"]];
            [pathYawString appendFormat:@""];
            
            [pathYawString appendFormat:@"<rule>%@</rule>",[pathYaw objectForKey:@"pathPlan"]];
            
            [pathYawString appendFormat:@""];
            
            [pathYawString appendFormat:@"<yawpoint_lat>%@</yawpoint_lat>""<yawpoint_lon>%@</yawpoint_lon>",[pathYaw objectForKey:@"yawLat"],[pathYaw objectForKey:@"yawLon"]];
            
            if ([(NSMutableArray *)[pathYaw objectForKey:@"midArray"] count] > 0) {
                
                [pathYawString appendFormat:@""];
                [pathYawString appendFormat:@"<midway>"];
                for (NSDictionary *midDic in (NSArray *)[pathYaw objectForKey:@"midArray"]) {
                     [pathYawString appendFormat:@""];
                     [pathYawString appendFormat:@"<point>""<lat>%@</lat>""<lon>%@</lon>""</point>",[midDic objectForKey:@"midLat"],[midDic objectForKey:@"midLon"]];
                    
                }
                 [pathYawString appendFormat:@""];
                 [pathYawString appendFormat:@"</midway>"];
            }
             [pathYawString appendFormat:@""];
             [pathYawString appendFormat:@"</item>"];
            
        }
         [pathYawString appendFormat:@""];
         [pathYawString appendFormat:@"</routeyaw>""</useraction>"];
    }
    return pathYawString;
}
@end
