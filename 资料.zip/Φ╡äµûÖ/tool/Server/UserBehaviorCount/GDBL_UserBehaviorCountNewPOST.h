//
//  GDBL_UserBehaviorCountNewPOST.h
//  AutoNavi
//
//  Created by jiangshu.fu on 13-5-27.
//
//

#import <Foundation/Foundation.h>
#import "NetRequestExtDelegate.h"

@interface GDBL_UserBehaviorCountNewPOST : NSObject

+ (GDBL_UserBehaviorCountNewPOST *) sharedInstance ;

- (NSData *) DataRequest;

@end
