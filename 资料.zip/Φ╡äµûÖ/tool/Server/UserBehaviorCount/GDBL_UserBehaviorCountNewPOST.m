//
//  GDBL_UserBehaviorCountNewPOST.m
//  AutoNavi
//
//  Created by jiangshu.fu on 13-5-27.
//
//

#import "GDBL_UserBehaviorCountNewPOST.h"
#import "ANParamValue.h"
#import "GDBL_UserBehaviorCountNew.h"
#import "NetConstant.h"
#import "NetExt.h"
#import "ANDataSource.h"
#import "sys/utsname.h"
#import "NSString+Category.h"


@implementation GDBL_UserBehaviorCountNewPOST

static GDBL_UserBehaviorCountNewPOST *instance = nil;

+ (GDBL_UserBehaviorCountNewPOST *) sharedInstance
{
    if (instance == nil) {
        instance = [[GDBL_UserBehaviorCountNewPOST alloc] init];
    }
    return instance;
}

//组装XML数据
-(NSString *) composeXML
{
    
    int lAdminCode;
    GCOORDTEL coordTel;
	coordTel.eFlag = COORDTEL_TYPE_COORD;
	coordTel.u.Coord.x = -1;
	coordTel.u.Coord.y = -1;
	GDBL_GetAdminCode(&coordTel,&lAdminCode);
    
    struct utsname systemInfo;
    uname(&systemInfo);
    
    NSString *strData = @"";
    strData = @"<?xml version=\'1.0\' encoding=\'utf-8\'?>"
    "<useraction>"
    "<baseinfo>"
    "<mac>";
    strData = [strData stringByAppendingFormat:@"%@",[[ANDataSource sharedInstance] GMD_GetDeviceID]];//mac信息
    strData = [strData stringByAppendingFormat:@"</mac>"
               "<token>"];
    strData = [strData stringByAppendingFormat:@"%@",deviceTokenEx];//token
    strData = [strData stringByAppendingFormat:@"</token>"
               "<imei>"];
    strData = [strData stringByAppendingFormat:@"%@",VendorID];//imei
    strData = [strData stringByAppendingFormat:@"</imei>"
               "<adcode>"];
    strData = [strData stringByAppendingFormat:@"%d",lAdminCode];//用户所在地行政区编号
    strData = [strData stringByAppendingFormat:@"</adcode>"
               "<iosversion>"];
    strData = [strData stringByAppendingFormat:@"%@",CurrentSystemVersion];//系统版本
    strData = [strData stringByAppendingFormat:@"</iosversion>"
               "<appversion>"];
    strData = [strData stringByAppendingFormat:@"%.1f",SOFTVERSIONNUM];//导航版本
    strData = [strData stringByAppendingFormat:@"</appversion>"
               "<dataversion>"];
    strData = [strData stringByAppendingFormat:@"%@",[[ANDataSource sharedInstance] GMD_GetVersionInfoWithMainID:1]];//数据版本
    strData = [strData stringByAppendingFormat:@"</dataversion>"
               "<device>"];
    strData = [strData stringByAppendingFormat:@"%@",[NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding]];//设备型号
    strData = [strData stringByAppendingFormat:@"</device>"
               "<startup_time>"];
    strData = [strData stringByAppendingFormat:@"%@",[GDBL_UserBehaviorCountNew shareInstance].lastStartUp];//最后一次启动导航时间
    strData = [strData stringByAppendingFormat:@"</startup_time>"
               "</baseinfo>"];
    strData = [strData stringByAppendingFormat:@"<actions>"];
    
    //开启导航
    if([GDBL_UserBehaviorCountNew shareInstance].openNavigation != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"PU001"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"2"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
               [GDBL_UserBehaviorCountNew shareInstance].openNavigation];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
//    strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].durationOfUse_InPath];//持续时长
//    strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    
    
//    strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
//    strData = [strData stringByAppendingFormat:@"PU001"];//操作ID
//    strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
//    strData = [strData stringByAppendingFormat:@"1"];//使用模式
//    strData = [strData stringByAppendingFormat:@"</usemode>"];
//    strData = [strData stringByAppendingFormat:@"<duration>"];
//    strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].durationOfUse];//持续时长
//    strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    
    //单个item项目
    if([GDBL_UserBehaviorCountNew shareInstance].addressSearch_InPath != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU004"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].addressSearch_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].addressSearch != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU004"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].addressSearch];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].crossSearch_InPath != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU005"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].crossSearch_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].crossSearch != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU005"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].crossSearch];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].defaultSort_InPath != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU006"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].defaultSort_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].defaultSort != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU006"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].defaultSort];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].distanceSort_InPath != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU007"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].distanceSort_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].distanceSort != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU007"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].distanceSort];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].regionSelect_InPath != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU009"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].regionSelect_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if([GDBL_UserBehaviorCountNew shareInstance].regionSelect != 0)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU009"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].regionSelect];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSearchGoWhere_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU008"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].voiceSearchGoWhere_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSearchGoWhere)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU008"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].voiceSearchGoWhere];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].alongCursorSearch_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU012"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].alongCursorSearch_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].alongCursorSearch)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU012"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].alongCursorSearch];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].alongPathSearch_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU013"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
               [GDBL_UserBehaviorCountNew shareInstance].alongPathSearch_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].alongPathSearch)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU013"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].alongPathSearch];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].alongDestinationsearch_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU014"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].alongDestinationsearch_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].alongDestinationsearch)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU014"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].alongDestinationsearch];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].stationType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].stationType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",15 + i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].stationType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].stationType.count; i++ ) {
        if(0 !=  [[[GDBL_UserBehaviorCountNew shareInstance].stationType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",15 + i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].stationType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].parkingType_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU020"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].parkingType_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].parkingType)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU020"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].parkingType];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].businessCasualType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].businessCasualType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",21+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].businessCasualType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].businessCasualType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].businessCasualType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",21+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].businessCasualType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].foodDrinkType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].foodDrinkType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",26+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].foodDrinkType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].foodDrinkType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].foodDrinkType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",26+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].foodDrinkType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].hotelType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].hotelType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",34+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].hotelType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].hotelType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].hotelType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",34+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].hotelType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].shoppingType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].shoppingType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",42+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                    [[GDBL_UserBehaviorCountNew shareInstance].shoppingType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].shoppingType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].shoppingType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",42+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].shoppingType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].sightsType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].sightsType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",53+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].sightsType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].sightsType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].sightsType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",53+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].sightsType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].transportServicesType_InPath.count; i++ ) {
        if(0 !=  [[[GDBL_UserBehaviorCountNew shareInstance].transportServicesType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",59+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].transportServicesType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].transportServicesType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].transportServicesType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",59+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].transportServicesType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].financeType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].financeType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",69+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].financeType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
        
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].financeType.count; i++ ) {
        if(0 !=  [[[GDBL_UserBehaviorCountNew shareInstance].financeType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",69+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].financeType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].buildingType_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU076"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].buildingType_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].buildingType)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU076"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].buildingType];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].recreationType_InPath.count; i++ ) {
        if( 0 != [[[GDBL_UserBehaviorCountNew shareInstance].recreationType_InPath objectAtIndex:i]intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",77 + i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].recreationType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
        
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].recreationType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].recreationType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",77+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].recreationType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].CorporateType_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU083"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].CorporateType_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].CorporateType)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU083"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].CorporateType];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].carServiceType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].carServiceType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",84+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].carServiceType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].carServiceType.count; i++ ) {
        if( 0 != [[[GDBL_UserBehaviorCountNew shareInstance].carServiceType objectAtIndex:i] intValue] )
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",84+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].carServiceType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].sportsType_InPath.count; i++ ) {
        if(0 !=  [[[GDBL_UserBehaviorCountNew shareInstance].sportsType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",93+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].sportsType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].sportsType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].sportsType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU0%d",93+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].sportsType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].livingServiceType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].livingServiceType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            if(96 + i >= 100)
            {
                strData = [strData stringByAppendingFormat:@"CU%d",96+i];//操作ID
            }
            else
            {
                strData = [strData stringByAppendingFormat:@"CU0%d",96+i];//操作ID
            }
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].livingServiceType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
        
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].livingServiceType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].livingServiceType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            if(96 + i >= 100)
            {
                strData = [strData stringByAppendingFormat:@"CU%d",96+i];//操作ID
            }
            else
            {
                strData = [strData stringByAppendingFormat:@"CU0%d",96+i];//操作ID
            }
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].livingServiceType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].educationType_InPath.count; i++ ) {
        if( 0 != [[[GDBL_UserBehaviorCountNew shareInstance].educationType_InPath objectAtIndex:i]intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU10%d",2+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].educationType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].educationType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].educationType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU10%d",2+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].educationType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].hospitalType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].hospitalType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU%d",108+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].hospitalType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].hospitalType.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].hospitalType objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU%d",108+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].hospitalType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].residentialAreaType_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU116"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].residentialAreaType_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].residentialAreaType)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU116"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].residentialAreaType];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].governmentType_InPath.count; i++ ) {
        if(0 != [[[GDBL_UserBehaviorCountNew shareInstance].governmentType_InPath objectAtIndex:i] intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU1%d",17+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"0"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].governmentType_InPath objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    for (int i = 0 ; i < [GDBL_UserBehaviorCountNew shareInstance].governmentType.count; i++ ) {
        if( 0 != [[[GDBL_UserBehaviorCountNew shareInstance].governmentType objectAtIndex:i]intValue])
        {
            strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
            strData = [strData stringByAppendingFormat:@"CU1%d",17+i];//操作ID
            strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
            strData = [strData stringByAppendingFormat:@"1"];//使用模式
            strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
            strData = [strData stringByAppendingFormat:@"%@",
                       [[GDBL_UserBehaviorCountNew shareInstance].governmentType objectAtIndex:i]];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
            strData = [strData stringByAppendingFormat:@"</item>"];
        }
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].cityType_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU123"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].cityType_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].cityType)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU123"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].cityType];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].detailSetEnd_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU124"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].detailSetEnd_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].detailSetEnd)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU124"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].detailSetEnd];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].viewPOISetEnd_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU125"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].viewPOISetEnd_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].viewPOISetEnd)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU125"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].viewPOISetEnd];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].detailSetStart_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU127"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].detailSetStart_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].detailSetStart)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU127"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].detailSetStart];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].viewPOISetStart_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU128"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].viewPOISetStart_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].viewPOISetStart)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU128"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
              [GDBL_UserBehaviorCountNew shareInstance].viewPOISetStart];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].figureMapSetSatar_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU129"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].figureMapSetSatar_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].figureMapSetSatar)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU129"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].figureMapSetSatar];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].viewPOISetWaypoint_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU130"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].viewPOISetWaypoint_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].viewPOISetWaypoint)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU130"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].viewPOISetWaypoint];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].figureSetWaypoint_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU131"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].figureSetWaypoint_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].figureSetWaypoint)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU131"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].figureSetWaypoint];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].managePathDetail_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU136"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].managePathDetail_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].managePathDetail)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU136"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].managePathDetail];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].stopNaviByTurnArrow_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU137"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].stopNaviByTurnArrow_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].stopNaviByTurnArrow)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU137"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].stopNaviByTurnArrow];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].stopNaviByManage_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU138"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].stopNaviByManage_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].stopNaviByManage)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU138"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].stopNaviByManage];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].simulatedNaviByOverview_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU139"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].simulatedNaviByOverview_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].simulatedNaviByOverview)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU139"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].simulatedNaviByOverview];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if( 0 != [GDBL_UserBehaviorCountNew shareInstance].simulatedNaviByManage_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU140"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].simulatedNaviByManage_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].simulatedNaviByManage)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU140"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].simulatedNaviByManage];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].planningByManage_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU141"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].planningByManage_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].planningByManage)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU141"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].planningByManage];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].overviewByManage_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU143"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].overviewByManage_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].overviewByManage)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU143"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].overviewByManage];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].suggestedLtineraries_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU144"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].suggestedLtineraries_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].suggestedLtineraries)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU144"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].suggestedLtineraries];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].highPriority_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU145"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].highPriority_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].highPriority)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU145"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].highPriority];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].economicRoute_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU146"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].economicRoute_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].economicRoute)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU146"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].economicRoute];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shortestRoute_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU147"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].shortestRoute_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shortestRoute)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU147"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].shortestRoute];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].directionsContrast_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU148"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].directionsContrast_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].directionsContrast)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU148"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].directionsContrast];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].overviewViewFull_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU154"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].overviewViewFull_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].overviewViewFull)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU154"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].overviewViewFull];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].viewTripComputer_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU155"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].viewTripComputer_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].viewTripComputer)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU155"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].viewTripComputer];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].enlargeByButton_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU156"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].enlargeByButton_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].enlargeByButton)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU156"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].enlargeByButton];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].narrowByButton_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU157"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].narrowByButton_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].narrowByButton)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU157"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                       [GDBL_UserBehaviorCountNew shareInstance].narrowByButton];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].enlargeByDoubleClick_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU158"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].enlargeByDoubleClick_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].enlargeByDoubleClick)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU158"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].enlargeByDoubleClick];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].narrowByTwoFingerClick_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU159"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].narrowByTwoFingerClick_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].narrowByTwoFingerClick)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU159"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].narrowByTwoFingerClick];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].enlargeByPinOpen_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU160"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].enlargeByPinOpen_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].enlargeByPinOpen)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU160"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].enlargeByPinOpen];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].narrowByPinKneading_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU161"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].narrowByPinKneading_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].narrowByPinKneading)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU161"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].narrowByPinKneading];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].favoriteCurrentPoint_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU162"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].favoriteCurrentPoint_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].favoriteCurrentPoint)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU162"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].favoriteCurrentPoint];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].messageBox_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU167"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].messageBox_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].messageBox)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU167"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].messageBox];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].pathManage_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU170"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].pathManage_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].pathManage)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU170"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].pathManage];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].switchMainAndSideRoads_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU171"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].switchMainAndSideRoads_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].switchMainAndSideRoads)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU171"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].switchMainAndSideRoads];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].trafficIncident_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU178"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].trafficIncident_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].trafficIncident)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU178"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].trafficIncident];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].feedback_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU190"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].feedback_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].feedback)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU190"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].feedback];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].trafficEventDisplay_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU191"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].trafficEventDisplay_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].trafficEventDisplay)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU191"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].trafficEventDisplay];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].networkNavi_InPath ||  0 != [GDBL_UserBehaviorCountNew shareInstance].networkNaviSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU012"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>" ];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].networkNavi_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].networkNavi_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if( 0 != [GDBL_UserBehaviorCountNew shareInstance].networkNaviSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].networkNaviSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].networkNavi || 0 !=  [GDBL_UserBehaviorCountNew shareInstance].networkNaviSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU012"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>" ];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].networkNavi)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].networkNavi];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>" ];
        }
        if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].networkNaviSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",
                       [GDBL_UserBehaviorCountNew shareInstance].networkNaviSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].CPCNavi_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].CPCNaviSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU013"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].CPCNavi_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].CPCNavi_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].CPCNaviSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",
                    [GDBL_UserBehaviorCountNew shareInstance].CPCNaviSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].CPCNavi || 0 != [GDBL_UserBehaviorCountNew shareInstance].CPCNaviSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU013"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].CPCNavi)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d",
                    [GDBL_UserBehaviorCountNew shareInstance].CPCNavi];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].CPCNaviSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",
                       [GDBL_UserBehaviorCountNew shareInstance].CPCNaviSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].horizontalScreenSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU014"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].horizontalScreenSeconds_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].horizontalScreenSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU014"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
               [GDBL_UserBehaviorCountNew shareInstance].horizontalScreenSeconds];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].verticalScreenSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU015"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].verticalScreenSeconds_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if( 0 != [GDBL_UserBehaviorCountNew shareInstance].verticalScreenSeconds )
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU015"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].verticalScreenSeconds];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_25_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU001"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_25_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_25)
    {
    strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
    strData = [strData stringByAppendingFormat:@"DU001"];//操作ID
    strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
    strData = [strData stringByAppendingFormat:@"1"];//使用模式
    strData = [strData stringByAppendingFormat:@"</usemode>"];
    strData = [strData stringByAppendingFormat:@"<duration>"];
    strData = [strData stringByAppendingFormat:@"%d",
               [GDBL_UserBehaviorCountNew shareInstance].mapProportion_25];//持续时长
    strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 !=[GDBL_UserBehaviorCountNew shareInstance].mapProportion_50_InPath )
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU002"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].mapProportion_50_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_50)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU002"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_50];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_100_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU003"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_100_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_100)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU003"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_100];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].mapProportion_200_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU004"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_200_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_200)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU004"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_200];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_500_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU005"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_500_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_500)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU005"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_500];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_1k_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU006"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].mapProportion_1k_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_1k)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU006"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_1k];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_2k_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU007"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_2k_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 !=[GDBL_UserBehaviorCountNew shareInstance].mapProportion_2k)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU007"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_2k];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_5k_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU008"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_5k_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_5k)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU008"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                [GDBL_UserBehaviorCountNew shareInstance].mapProportion_5k];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_10k_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU009"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_10k_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 !=[GDBL_UserBehaviorCountNew shareInstance].mapProportion_10k)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU009"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_10k];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_50k_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU010"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_50k_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_50k)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU010"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_50k];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_200k_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU011"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_200k_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].mapProportion_200k)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU011"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_200k];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_500k_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU012"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_500k_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapProportion_500k)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"DU012"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        strData = [strData stringByAppendingFormat:@"<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].mapProportion_500k];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].openEnglishVersionSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU182"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].openEnglishVersionSeconds_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].openEnglishVersionSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU182"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d",
                   [GDBL_UserBehaviorCountNew shareInstance].openEnglishVersionSeconds];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    //半自动生成
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].manualSearch_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU001"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].manualSearch_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].manualSearch)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU001"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].manualSearch];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].smartSearch_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU002"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].smartSearch_InPath];//  操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].smartSearch)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU002"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].smartSearch];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].networkSearch_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU003"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].networkSearch_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].networkSearch)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU003"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].networkSearch];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSearchSide_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU011"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSearchSide_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSearchSide_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU011"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSearchSide];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].peripherySearch_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU010"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].peripherySearch_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].peripherySearch)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU010"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].peripherySearch];//操    作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].figureMapSetEnd_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU126"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].figureMapSetEnd_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].figureMapSetEnd)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU126"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].figureMapSetEnd];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].historyDestinnation_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU132"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].historyDestinnation_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].historyDestinnation)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU132"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].historyDestinnation];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=[GDBL_UserBehaviorCountNew shareInstance].addressBook_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU133"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].addressBook_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].addressBook)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU133"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].addressBook];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].contactsNavigation_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU134"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].contactsNavigation_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].contactsNavigation)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU134"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].contactsNavigation];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].routeDetailsOverview_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU135"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].routeDetailsOverview_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].routeDetailsOverview)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU135"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].routeDetailsOverview];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].overviewNextWay_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU142"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].overviewNextWay_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].overviewNextWay)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU142"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].overviewNextWay];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shareLocationBySMS_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU149"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].shareLocationBySMS_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shareLocationBySMS)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU149"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].shareLocationBySMS];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shareLocationByEmail_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU150"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].shareLocationByEmail_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shareLocationByEmail)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU150"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].shareLocationByEmail];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shareLocationBySina_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU151"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].shareLocationBySina_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shareLocationBySina)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU151"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].shareLocationBySina];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shareLocationByTX_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU152"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].shareLocationByTX_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].shareLocationByTX)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU152"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].shareLocationByTX];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].microShareLocation_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU153"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].microShareLocation_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].microShareLocation)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU153"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].microShareLocation];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].northUpView_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU001"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].northUpView_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].northUpView_InPath  ];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].northUpView || 0 != [GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU001"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].northUpView)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].northUpView];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].northUpViewSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].upView_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].upViewSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU002"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].upView_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].upView_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].upViewSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].upViewSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].upView ||0 != [GDBL_UserBehaviorCountNew shareInstance].upViewSeconds )
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU002"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].upView)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].upView];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].upViewSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].upViewSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].car3DView_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU003"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].car3DView_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].car3DView_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].car3DView || 0 != [GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU003"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].car3DView)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].car3DView];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].car3DViewSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].realTimeTraffic_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU163"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].realTimeTraffic_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].realTimeTraffic)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU163"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].realTimeTraffic];//操    作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].trafficInformation_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU164"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].trafficInformation_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].trafficInformation)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU164"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].trafficInformation];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].smartDrivingServices_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU165"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].smartDrivingServices_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].smartDrivingServices)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU165"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].smartDrivingServices];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].smartDriveSetDestination_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU166"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].smartDriveSetDestination_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].smartDriveSetDestination)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU166"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].smartDriveSetDestination];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>"];
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnline_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnlineSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU004"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnline_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnline_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnlineSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnlineSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnline || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnlineSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU004"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnline)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnline];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnlineSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByCtripOnlineSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
        
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripPhone_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU005"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByCtripPhone_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByCtripPhone)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU005"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByCtripPhone];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByTravel_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByTravelSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU006"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByTravel_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByTravel_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByTravelSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByTravelSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByTravel || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByTravelSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU006"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByTravel)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByTravel];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByTravelSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByTravelSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFood_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFoodSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU007"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFood_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByFood_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFoodSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByFoodSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFood ||0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFoodSeconds )
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU007"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFood)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByFood];//操    作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if( 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFoodSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByFoodSeconds];//   持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGolf_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGolfSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU008"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGolf_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByGolf_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGolfSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByGolfSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGolf || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGolfSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU008"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGolf)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByGolf];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGolfSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByGolfSeconds];//   持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByMyself_InPath || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByMyselfSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU009"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByMyself_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByMyself_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByMyselfSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByMyselfSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByMyself || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByMyselfSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU009"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByMyself)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByMyself];//操作次    数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByMyselfSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByMyselfSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShare_InPath ||
       0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShareSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU010"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShare_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShare_InPath];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShareSeconds_InPath)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShareSeconds_InPath];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShare
       || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShareSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU010"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShare)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShare];//操作次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShareSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByFriendsShareSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
     if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGDShare_InPath
        || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGDShareSeconds_InPath)
     {
         strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
         strData = [strData stringByAppendingFormat:@"AU011"];//操作ID
         strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
         strData = [strData stringByAppendingFormat:@"0"];//使用模式
         strData = [strData stringByAppendingFormat:@"</usemode>"];
         if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGDShare_InPath)
         {
             strData = [strData stringByAppendingFormat:@"<times>"];
             strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByGDShare_InPath];//操作次数
             strData = [strData stringByAppendingFormat:@"</times>"];
         }
         if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGDShareSeconds_InPath)
         {
             strData = [strData stringByAppendingFormat:@"<duration>"];
             strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByGDShareSeconds_InPath];//持续时长
             strData = [strData stringByAppendingFormat:@"</duration>"];
         }
         strData = [strData stringByAppendingFormat:@"</item>"];
     }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGDShare || 0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGDShareSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"AU011"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>"];
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGDShare)
        {
            strData = [strData stringByAppendingFormat:@"<times>"];
            strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].layerByGDShare];//操作    次数
            strData = [strData stringByAppendingFormat:@"</times>"];
        }
        if(0 != [GDBL_UserBehaviorCountNew shareInstance].layerByGDShareSeconds)
        {
            strData = [strData stringByAppendingFormat:@"<duration>"];
            strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].layerByGDShareSeconds];//持续时长
            strData = [strData stringByAppendingFormat:@"</duration>"];
        }
        strData = [strData stringByAppendingFormat:@"</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].goHome_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU168"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].goHome_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].goHome)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU168"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].goHome];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].backCompany_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU169"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].backCompany_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].backCompany)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU169"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].backCompany];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].avoidTraffice_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU172"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].avoidTraffice_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].avoidTraffice)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU172"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].avoidTraffice];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].avoidRouteDetail_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU173"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].avoidRouteDetail_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].avoidRouteDetail)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU173"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].avoidRouteDetail];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].beforeAvoid_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU174"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].beforeAvoid_InPath];//  操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].beforeAvoid)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU174"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].beforeAvoid];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].afterAvoid_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU175"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].afterAvoid_InPath];//操作次    数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].afterAvoid)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU175"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].afterAvoid];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].cancelAvoid_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU176"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].cancelAvoid_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].cancelAvoid)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU176"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].cancelAvoid];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].routingFunction_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU177"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].routingFunction_InPath];//  操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].routingFunction)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU177"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].routingFunction];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].cloudBackupInformation_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU179"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].cloudBackupInformation_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].cloudBackupInformation)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU179"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].cloudBackupInformation];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].setHome_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU180"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].setHome_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].setHome)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU180"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].setHome];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].setCompany_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU181"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].setCompany_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].setCompany)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU181"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].setCompany];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].downloadManage_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU183"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].downloadManage_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].downloadManage)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU183"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].downloadManage];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }

    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapUpdateManage_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU184"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].mapUpdateManage_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].mapUpdateManage)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU184"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].mapUpdateManage];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].locusManage_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU185"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].locusManage_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].locusManage)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU185"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].locusManage];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].flowStatistics_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU186"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].flowStatistics_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].flowStatistics)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU186"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].flowStatistics];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].iLoveGD_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU187"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].iLoveGD_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].iLoveGD)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU187"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].iLoveGD];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=[GDBL_UserBehaviorCountNew shareInstance].newVersionFunction_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU188"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].newVersionFunction_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].newVersionFunction)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU188"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].newVersionFunction];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].versionInfo_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU189"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].versionInfo_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].versionInfo)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU189"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].versionInfo];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    //***5.29
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].goWhere_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU217"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].goWhere_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].goWhere)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU217"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].goWhere];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].commonUse_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU218"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].commonUse_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].commonUse)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU218"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].commonUse];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].alertFavCurrentPoint_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU219"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].alertFavCurrentPoint_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].alertFavCurrentPoint)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU219"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].alertFavCurrentPoint];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].myFavorites_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU220"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].myFavorites_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].myFavorites)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU220"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].myFavorites];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].historyDestination_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU221"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].historyDestination_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].historyDestination)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU221"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].historyDestination];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectHenanMale_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU222"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectHenanMale_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectHenanMale)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU222"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectHenanMale];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].multipleWaypoints_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU223"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].multipleWaypoints_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].multipleWaypoints)
    {
    strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
    strData = [strData stringByAppendingFormat:@"CU223"];//操作ID
    strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
    strData = [strData stringByAppendingFormat:@"1"];//使用模式
    strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
    strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].multipleWaypoints];//操作次数
    strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].fontSizeLarge_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU192"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].fontSizeLarge_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].fontSizeLarge)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU192"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].fontSizeLarge];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].fontSizeMedium_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU193"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].fontSizeMedium_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].fontSizeMedium)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU193"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].fontSizeMedium];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].fontSizeSmall_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU194"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].fontSizeSmall_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].fontSizeSmall)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU194"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].fontSizeSmall];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeDay_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU195"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeDay_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeDay)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU195"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeDay];//操作    次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if( 0 != [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeNight_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU196"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeNight_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeNight)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU196"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeNight];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeAuto_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU197"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeAuto_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeAuto)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU197"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].dayAndNightModeAuto];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=  [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNationalFemale_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU198"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNationalFemale_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNationalFemale)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU198"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNationalFemale];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNationalMale_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU199"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNationalMale_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNationalMale)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU199"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNationalMale];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectTaiwanFemale_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU200"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].   voiceSelectTaiwanFemale_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectTaiwanFemale)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU200"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectTaiwanFemale];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectCantoneseFemale_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU201"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectCantoneseFemale_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectCantoneseFemale)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU201"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectCantoneseFemale];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNortheasternFemale_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU202"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNortheasternFemale_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNortheasternFemale)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU202"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectNortheasternFemale];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectSichuanFemale_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU203"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectSichuanFemale_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectSichuanFemale)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU203"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectSichuanFemale];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectHunanMale_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU204"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectHunanMale_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceSelectHunanMale)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU204"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceSelectHunanMale];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 !=[GDBL_UserBehaviorCountNew shareInstance].voiceFrequencyGeneral_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU205"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceFrequencyGeneral_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceFrequencyGeneral)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU205"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceFrequencyGeneral];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceFrequencyFrequent_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU206"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceFrequencyFrequent_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].voiceFrequencyFrequent)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU206"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].voiceFrequencyFrequent];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstAuto_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU207"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstAuto_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstAuto)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU207"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstAuto];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstGasStation_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU208"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstGasStation_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstGasStation)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU208"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstGasStation];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstParking_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU209"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstParking_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstParking)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU209"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstParking];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstFood_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU210"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstFood_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstFood)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU210"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstFood];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstLodging_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU211"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstLodging_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstLodging)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU211"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstLodging];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstFun_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU212"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstFun_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstFun)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU212"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstFun];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstAttractions_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU213"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstAttractions_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstAttractions)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU213"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstAttractions];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstMedical_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU214"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstMedical_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].informationFirstMedical)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU214"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].informationFirstMedical];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].store_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU215"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].store_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].store)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU215"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].store];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].accountLogin_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU216"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].accountLogin_InPath];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].accountLogin)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"CU216"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
        strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].accountLogin];//操作次数
        strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    }
    
     //前台使用时长
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].durationOfUse_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"TU001"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].durationOfUse_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].durationOfUse)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"TU001"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].durationOfUse];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }

    
    //后台使用时长
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].durationOfUseBackgroundSeconds_InPath)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"TU002"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"0"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].durationOfUseBackgroundSeconds_InPath];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].durationOfUseBackgroundSeconds)
    {
        strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
        strData = [strData stringByAppendingFormat:@"TU002"];//操作ID
        strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
        strData = [strData stringByAppendingFormat:@"1"];//使用模式
        strData = [strData stringByAppendingFormat:@"</usemode>""<duration>"];
        strData = [strData stringByAppendingFormat:@"%d",[GDBL_UserBehaviorCountNew shareInstance].durationOfUseBackgroundSeconds];//持续时长
        strData = [strData stringByAppendingFormat:@"</duration>""</item>"];
    }
    

    
    
    
    
//    strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
//    strData = [strData stringByAppendingFormat:@"MU001"];//操作ID
//    strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
//    strData = [strData stringByAppendingFormat:@"2"];//使用模式
//    strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
//    strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].downloadMapByPhone];//操作次数
//    strData = [strData stringByAppendingFormat:@"</times>""</item>"];
    
//    strData = [strData stringByAppendingFormat:@"<item>""<opid>"];
//    strData = [strData stringByAppendingFormat:@"MU002"];//操作ID
//    strData = [strData stringByAppendingFormat:@"</opid>""<usemode>"];
//    strData = [strData stringByAppendingFormat:@"2"];//使用模式
//    strData = [strData stringByAppendingFormat:@"</usemode>""<times>"];
//    strData = [strData stringByAppendingFormat:@"%d", [GDBL_UserBehaviorCountNew shareInstance].travelLayerData];//操作次数
//    strData = [strData stringByAppendingFormat:@"</times>""</item>"];

    
    
    strData = [strData stringByAppendingFormat:@"</actions>"];
    strData = [strData stringByAppendingFormat:@"<datadownloads>"];
    if(0 != [GDBL_UserBehaviorCountNew shareInstance].travelLayerData)
    {
        strData = [strData stringByAppendingFormat:@"<map>"];
        strData = [strData stringByAppendingFormat:@"<citycode>MU002</citycode>"];
        strData = [strData stringByAppendingFormat:@"<d_times>%d</d_times>",[GDBL_UserBehaviorCountNew shareInstance].travelLayerData];
        strData = [strData stringByAppendingFormat:@"</map>"];
    }
    
    for(NSString *key in [[GDBL_UserBehaviorCountNew shareInstance].downloadMapByPhoneDict allKeys])
    {
        strData = [strData stringByAppendingFormat:@"<map>"];
        strData = [strData stringByAppendingFormat:@"<citycode>%@</citycode>",key];
        strData = [strData stringByAppendingFormat:@"<d_times>%@</d_times>",[[GDBL_UserBehaviorCountNew shareInstance].downloadMapByPhoneDict objectForKey:key]];
        strData = [strData stringByAppendingFormat:@"</map>"];
    }
    
    strData = [strData stringByAppendingFormat:@"</datadownloads>"];
    strData = [strData stringByAppendingFormat:@"</useraction>"];
    
    return strData;
}
-(NSData *) DataRequest
{
    //上传参数
//    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
//    [dict setObject:@"xml" forKey:@"out"];
    NSString *xmlData = [self composeXML];
    NSLog(@"UBC==%@",xmlData);
    NSData *postData = [xmlData dataUsingEncoding:NSUTF8StringEncoding];
    return postData;
   /* [[NetExt sharedInstance] requestWithURL:addressUrl
                            withRequestType:RT_UserBehavior_Count
                                  urlParams:dict
                                 httpMethod:@"POST"
                                   bodyData:postData
                                   delegate:self];
    */
    
//    [dict release];
}


@end
