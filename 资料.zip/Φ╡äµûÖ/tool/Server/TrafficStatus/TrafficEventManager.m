//
//  TrafficEventManager.m
//  AutoNavi
//
//  Created by liyuhang on 13-6-7.
//
//

#import "TrafficEventManager.h"
#import "TrafficEventReport.h"
#import "GDBL_typedef.h"
#import "GDMID_Interface.h"
#import "MWMapOperator.h"

/*
  定义一些内容
 */
#pragma mark static valuable
static  TrafficEventManager*    pTrafficEventManagerInstance = nil;

static  float                   fszScreenPixelScale;                // 比例

static  NSString*               szPicture[6] = {@"IC_ACCIDENT_AUTONAVI.png", @"IC_ACCIDENT_USER.png",
                                                @"IC_POLICE_AUTONAVI.png",@"IC_POLICE_USER.png",
                                                @"IC_TRAFFIC_AUTONAVI.png",@"IC_TRAFFIC_USER.png"};

static NSString *               szRetinaPicture[6] = {@"IC_ACCIDENT_AUTONAVI@2x.png", @"IC_ACCIDENT_USER@2x.png",
                                                        @"IC_POLICE_AUTONAVI@2x.png",@"IC_POLICE_USER@2x.png",
                                                        @"IC_TRAFFIC_AUTONAVI@2x.png",@"IC_TRAFFIC_USER@2x.png"};

static GBITMAP*                 currentBitmap[6] = {NULL};

static GCUSTOMELEMENT           pCustomElement[200]={0};
#pragma mark struct nemu 
//////////////////////////////////////////////////////////////////////////////////////////////////////
enum TYPE_TRAFFIC_STATUS
{
    IC_ACCIDENT_0=0,
    IC_POLICE_1,
    IC_TRAFFIC_2,
};

// window bitmap
typedef struct _bitmap_file_header bitmap_file_header;
struct _bitmap_file_header
{
    unsigned short Type;
    unsigned int Size;
    unsigned short Reserved1;
    unsigned short Reserved2;
    unsigned int OffSet;
};

typedef struct _bitmap_info_header bitmap_info_header;
struct _bitmap_info_header
{
    unsigned int Size;
    long Width;
    long Height;
    short int Planes;
    short int BitCount;
    unsigned int Compression;
    unsigned int SizeImage;
    long XPelsPerMeter;
    long YPelsPerMeter;
    unsigned int ClrUsed;
    unsigned int ClrImportant;
};
#pragma mark show map icon callback
void GetElement(GCUSTOMELEMENT **ppElements, Gint32 *pNumberOfElement)
{
    if (![[TrafficEventManager sharedInstance] GDBL_ShowTrafficEventInfo]) {
        GDMID_SetGetElementCB(NULL);
        return;
    }
    [[TrafficEventManager sharedInstance] GDBL_SetTrafficEventInfo];
    memset(pCustomElement, 0, sizeof(GCUSTOMELEMENT));
    *pNumberOfElement = 0;
    NSArray* pArray = [[TrafficEventManager sharedInstance] GDBL_GetTrafficEventArray];
    //
    if (nil!=pArray&&[pArray count]>0) {
        *pNumberOfElement = [pArray count];
        TrafficDownLoadEvent *trafficEventGE=nil;
        int nPicIndex = 0;
        for (int i=0; i<*pNumberOfElement; i++) {
            trafficEventGE = [pArray objectAtIndex:i];
    //      layerid=1055(0),     该值可为11020(0) 缓慢           11021(1) 拥堵         11022(2) 阻塞，
    //      layerid=1050(1),     该值可为11010(0) 故障车辆        11011(1) 车祸         11012(2) 路面障碍，
    //      layerid=1060(2),     该值可为11030(0) 检查           11031(1) 管制
            
            if(trafficEventGE.psnUserID == 105)
            {
                if (trafficEventGE.psnLayerId == 1055) {
                    nPicIndex = IC_TRAFFIC_2*2;
                }else if (trafficEventGE.psnLayerId == 1050) {
                    nPicIndex = IC_ACCIDENT_0;
                }else if (trafficEventGE.psnLayerId == 1060) {
                    nPicIndex = IC_POLICE_1*2;
                }

            }
            else
            {
                if (trafficEventGE.psnLayerId == 1055) {
                    nPicIndex = IC_TRAFFIC_2*2+1;
                }else if (trafficEventGE.psnLayerId == 1050) {
                    nPicIndex = IC_ACCIDENT_0+1;
                }else if (trafficEventGE.psnLayerId == 1060) {
                    nPicIndex = IC_POLICE_1*2+1;
                }

            }
            pCustomElement[i].pImage = currentBitmap[nPicIndex];
            if (pCustomElement[i].pImage ) {
//                pCustomElement[i].x = trafficEventGE.psScrPoint.x+currentBitmap[nPicIndex]->cxWidth/2;
//                pCustomElement[i].y = trafficEventGE.psScrPoint.y;
            }
        }
    }
    (*ppElements) = pCustomElement;
}

#pragma mark class declare
//////////////////////////////////////////////////////////////////////////////////////////////////////
@interface TrafficEventManager()
{
    BOOL                        m_bShowTrafficEvent;
    NSMutableArray*             m_mArrayTrafficEvent;       //保存搜索到事件
    NSMutableArray*             m_mScreenPoint;             //保存图面显示的坐标
    BOOL                        m_bNetWorking;
    id<TrafficEventDelegate>    m_idDelegate;
    BOOL                        m_bShowEvent;
    int                         m_flag;                     //将要扩大或者缩小的比例
}
/*
 内部方法
 */
-(BOOL)getDataInfoFromFile;
-(CGPoint)transPointGeoToScr:(CGPoint)layerCoord;
-(int)changeGDScaleToAmapScale:(int)nScale;

//////////////////////////////////////////////////////////////////////////////////////////////////////
@end
#pragma mark class define
/*
 类定义
 */
@implementation TrafficEventManager


#pragma mark init and dealloc
-(id)init
{
    self = [super init];
    if (self) {
        m_mScreenPoint = [[NSMutableArray alloc] init];
        m_bNetWorking = NO;
        fszScreenPixelScale = (([UIScreen instancesRespondToSelector:@selector(scale)]==YES)?(([[UIScreen mainScreen] scale] == 2.0)?2.0:1.0):1.0 );
        // 读取图片信息
        [self getDataInfoFromFile];
        memset(&pCustomElement, 0, sizeof(GCUSTOMELEMENT));
        m_flag = 0;
    }
    return self;
}

-(void)dealloc
{
    [m_mScreenPoint release];
    m_mScreenPoint = nil;
    [super dealloc];
}
#pragma mathods in header
/**
 实例化对象
 */
+ (TrafficEventManager *)sharedInstance
{
    if (nil==pTrafficEventManagerInstance) {
        pTrafficEventManagerInstance = [[TrafficEventManager alloc] init];
        //
    }
    return pTrafficEventManagerInstance;
}
/**
 析构对象
 */
+ (void)purgeInstance
{
    if (pTrafficEventManagerInstance) {
        [pTrafficEventManagerInstance release];
        pTrafficEventManagerInstance = nil;
    }
}

/**
 从网络段获取交通事件
 flag : 1 :放大比例尺级别  -1:缩小比例尺级别   0:不放大也不缩小
 */

- (void)GDBL_GetTrafficEventInfo :(int) flag
{
    GZOOMLEVEL pValue1;
    GDBL_GetParam(G_MAP_SCALE_LEVEL_2D, &pValue1);
    m_flag = flag;
    if(pValue1 == ZOOM_500_KM || pValue1 == ZOOM_200_KM
       || ( pValue1 == ZOOM_50_KM && flag != 1) || ( pValue1 == ZOOM_10_KM && flag == -1 ) )
    {
        [self GDBL_ReleaseTrafficEventInfo];
        //删除了事件之后，把界面上的button也一起删除
        if (m_idDelegate&&[m_idDelegate respondsToSelector:@selector(updateTrafficEventInfo:)] ) {
            [m_idDelegate updateTrafficEventInfo:m_flag];
        }
        return;
    }
    //
    NSLog(@"GDBL_GetTrafficEventInfo");
    GETELEMENT pFun = GNULL;
    pFun = GetElement;
    GSTATUS gRet = GDMID_SetGetElementCB(pFun);
    m_bShowEvent = YES;
    //
    if (m_bNetWorking) {
        return;
    }
    // 大小
    int scaleFactor = 1;
    if ([[UIScreen mainScreen] respondsToSelector:@selector(displayLinkWithTarget:selector:)])
    {
        scaleFactor = (int)[[UIScreen mainScreen] scale];
    }
    else
    {
        scaleFactor = 1;
    }
    int nSize ;
    int nHorSize ;
    UIInterfaceOrientation ori = [[UIApplication sharedApplication] statusBarOrientation];
    if (ori == UIInterfaceOrientationPortrait || ori == UIInterfaceOrientationPortraitUpsideDown)
    {
        nSize = SCREENWIDTH*scaleFactor;
        nHorSize = SCREENHEIGHT*scaleFactor;
    }
    else  if (ori == UIInterfaceOrientationLandscapeLeft || ori == UIInterfaceOrientationLandscapeRight)
    {
        nSize = SCREENHEIGHT*scaleFactor;
        nHorSize = SCREENWIDTH*scaleFactor;
    }
    
    
    
    
    
        
    
    //  经纬度转换
    GCOORD scrCoord_LU = {0, 0};
	GCOORD pgdCoord_LU;
    GCOORD scrCoord_RD = {nSize, nHorSize};
	GCOORD pgdCoord_RD;
    
    GHMAPVIEW mapHandle;
    GDBL_GetMapViewHandle(GMAP_VIEW_TYPE_MAIN,&mapHandle);
    
	gRet=GDBL_CoordConvert(GCC_SCR_TO_GEO, &scrCoord_LU, &pgdCoord_LU,mapHandle);
    gRet=GDBL_CoordConvert(GCC_SCR_TO_GEO, &scrCoord_RD, &pgdCoord_RD,mapHandle);
    // 获取比例尺
    GZOOMLEVEL pValue;
	GDBL_GetParam(G_MAP_SCALE_LEVEL_2D, &pValue);
    int nScale = [self changeGDScaleToAmapScale:pValue];
    //
    m_bNetWorking = YES;
    TrafficDownLoadRequest* pDownloadRequest = [[TrafficDownLoadRequest alloc] init];
    pDownloadRequest.psnWidth = nSize;
    pDownloadRequest.psnHeight = nHorSize;
    pDownloadRequest.psnLeftPoint_X = pgdCoord_LU.x;
    pDownloadRequest.psnLeftPoint_Y = pgdCoord_LU.y;
    pDownloadRequest.psnRighPoint_X = pgdCoord_RD.x;
    pDownloadRequest.psnRighPoint_Y = pgdCoord_RD.y;
    pDownloadRequest.psnLevelOfDetail = nScale;
    NSLog(@"pgdCoord_LU = %d,%d",pgdCoord_LU.x,pgdCoord_LU.y);
    NSLog(@"pgdCoord_RD = %d,%d",pgdCoord_RD.x,pgdCoord_RD.y);
    NSLog(@"nScale = %d",nScale);

    //
    [[TrafficEventReport sharedInstance] DownloadTrafficEvent:pDownloadRequest
                                                  requestType:RT_TRAFFIC_EVEN_DOWNLOAD
                                               viewContorller:self];
    [pDownloadRequest release];
    //
//    25m           19	 10m
//    50m           18	 25m
//    100m          17	 50m
//    200m          16	 100m
//    500m          15	 200m
//    1km           14	 500m
//    2km           13	 1km
//    5km           12	 2km
//    10km          11	 5km
//    50km          9	 20km
//    200km         6	 100km
//    500km         5
}

/**
 删除本地保存交通事件
 */
- (void)GDBL_ReleaseTrafficEventInfo
{
    NSMutableArray* pArray = (NSMutableArray*)[[TrafficEventReport sharedInstance] GD_BLGetTrafficEventArray];
    [pArray removeAllObjects];
    m_bShowEvent = NO;
}

/**
 移图时更新交通事件对应的屏幕坐标
 */
- (void)GDBL_UpdateTrafficEventInfoOnScreen
{
    
}

/**
 设置交通事件信息到地图
 */
- (void)GDBL_SetTrafficEventInfo
{


    
    NSArray* pArray = [[TrafficEventReport sharedInstance] GD_BLGetTrafficEventArray];
    //tempArray = [list copy];
    int nCountOfEvetn = [pArray count];

    [m_mScreenPoint removeAllObjects];
    //
    for(int i=0;i<nCountOfEvetn;i++)
    {
        TrafficDownLoadEvent* trafficEventST = [pArray objectAtIndex:i];
        
        trafficEventST.psScrPoint = [self transPointGeoToScr:trafficEventST.psGeoPoint];
        //
        // 大小
        int scaleFactor = 1;
        if ([[UIScreen mainScreen] respondsToSelector:@selector(displayLinkWithTarget:selector:)])
        {
            scaleFactor = (int)[[UIScreen mainScreen] scale];
        }
        else
        {
            scaleFactor = 1;
        }
        int nSize;
        int nHorSize;
        UIInterfaceOrientation ori = [[UIApplication sharedApplication] statusBarOrientation];
        if (ori == UIInterfaceOrientationPortrait || ori == UIInterfaceOrientationPortraitUpsideDown)
        {
            nSize = SCREENWIDTH*scaleFactor;
            nHorSize = SCREENHEIGHT*scaleFactor;
        }
        else  if (ori == UIInterfaceOrientationLandscapeLeft || ori == UIInterfaceOrientationLandscapeRight)
        {
            nSize = SCREENHEIGHT*scaleFactor;
            nHorSize = SCREENWIDTH*scaleFactor;
        }
        
        CGRect rcSize = CGRectMake(0, 0, nSize, nHorSize);
        if(YES==CGRectContainsPoint(rcSize, trafficEventST.psScrPoint))
        {
            //					updataInfo.scPoint= CGPointMake(updataInfo.scPoint.x, updataInfo.scPoint.y);
            [m_mScreenPoint addObject:trafficEventST];
            
        }
    }
    if (m_idDelegate&&[m_idDelegate respondsToSelector:@selector(updateTrafficEventInfo:)] ) {
        [m_idDelegate updateTrafficEventInfo:m_flag];
    }
}
/**
 是否显示交通事件
 @param 布尔值 是否显示
 */
- (BOOL)GDBL_ShowTrafficEventInfo
{
    return m_bShowEvent;
}
/**
 当前图面显示的点数组
 */
- (NSArray*)GDBL_GetTrafficEventArray
{
    return m_mScreenPoint;
}

/**
 设置代理
 */
- (void)GDBL_SetTrafficEventDelegate:(id<TrafficEventDelegate>)idDelegate;
{
    m_idDelegate = idDelegate;
}

- (BOOL)GDBL_GetTrafficEventConnect
{
    return m_bNetWorking;
}

- (void)GDBL_SetTrafficEventConnect:(BOOL)netWorking
{
    m_bNetWorking = netWorking;
}

#pragma mark network delegate
- (void)requestToViewCtrWithRequestType:(RequestType)requestType didFinishLoadingWithResult:(id)result//id类型可以是NSDictionary NSArray
{
    m_bNetWorking = NO;
    [self GDBL_SetTrafficEventInfo];
    [[MWMapOperator sharedInstance] MW_ShowMapView:GMAP_VIEW_TYPE_MAIN WithParma1:0 WithParma2:0 WithParma3:0];
}
- (void)requestToViewCtrWithRequestType:(RequestType)requestType didFailWithError:(NSError *)error//上层需根据error的值来判断网络连接超时还是网络连接错误
{
    m_bNetWorking = NO;
    NSLog(@"AutoNavi->Request error:%d, mRequsetSettingError==100,mParsingError=101,mErrorFromServer=102", [error code]);
}
#pragma internal mathod
- (BOOL)getDataInfoFromFile
{
    for (int i=0; i<6; i++) {
        currentBitmap[i] = (GBITMAP*)malloc(sizeof(GBITMAP));
        UIImage* image;
        if((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone))
        {
            image = IMAGE(szPicture[i], IMAGEPATH_TYPE_1) ;
        }
        else
        {
            image = IMAGE(szRetinaPicture[i], IMAGEPATH_TYPE_1);
        }
        CGImageRef inImage = image.CGImage;
        // Create off screen bitmap context to draw the image into. Format ARGB is 4 bytes for each pixel: Alpa, Red, Green, Blue
        CGContextRef cgctx = [self createARGBBitmapContextFromImage:inImage];
        if (cgctx == NULL) { return nil; /* error */ }
        
        size_t w = CGImageGetWidth(inImage);
        size_t h = CGImageGetHeight(inImage);
        CGRect rect = {{0,0},{(float)w,(float)h}};
        currentBitmap[i]->nID=100+i;                                   // ID标识 固定值
        currentBitmap[i]->cxWidth =(int)w;
        currentBitmap[i]->cyHeight =(int)h;
        currentBitmap[i]->cbxPitch =2;
        currentBitmap[i]->cbyPicth =2*((int)w);
        
        int nDataCount=w*h*2;
        Guint8 *tmpRGBData= (Guint8*)malloc(nDataCount*sizeof(Guint8));
        Guint8 *rgbData = tmpRGBData;
        
        int nAlphaLen= nDataCount/2;
        Guint8 *tmpAlpha = (Guint8*)malloc(nAlphaLen);
        Guint8 *alpha=tmpAlpha;
        
        // Draw the image to the bitmap context. Once we draw, the memory
        // allocated for the context for rendering will then contain the
        // raw image data in the specified color space.
        CGContextDrawImage(cgctx, rect, inImage);
        
        // Now we can get a pointer to the image data associated with the bitmap
        // context.
        unsigned char* data = (unsigned char*)CGBitmapContextGetData (cgctx);
        if (data != NULL) {
            //offset locates the pixel in the data from x,y.
            //4 for 4 bytes of data per pixel, w is width of one row of data.
            @try {
                unsigned short int write_data;
                
                for (int offset=0; offset<nDataCount*2;) {
                    *tmpAlpha = (data[offset]*32/256);
                    tmpAlpha++;
                    write_data = (data[offset+3] >> 3)  | (( data[offset+2] & 0xFC) << 3) |(( data[offset+1] & 0xF8) << 8);
                    //                write_data = (data[offset+1] >> 3)  | (((data[offset+2]<<8)& 0xFC) << 3) |((( data[offset+3]<<16) & 0xF8) << 8);
                    *tmpRGBData = (write_data&0xffffffff);
                    tmpRGBData++;
                    *tmpRGBData = (write_data>>8);
                    tmpRGBData++;
                    offset+=4;
                }
                
                currentBitmap[i]->pData = (Guint8*)malloc(nDataCount*sizeof(Guint8));
                memcpy(currentBitmap[i]->pData, rgbData, nDataCount);
                //            currentBitmap->pData =rgbData;
                
                currentBitmap[i]->pAlpha= (Guint8*)malloc(nAlphaLen*sizeof(Guint8));
                memcpy(currentBitmap[i]->pAlpha, alpha, nAlphaLen);
                //            currentBitmap->pAlpha =alpha;
                
                
                free(rgbData);
                tmpRGBData = NULL;
                free(alpha);
                tmpAlpha = NULL;
            }
            @catch (NSException * e) {
                printf("exception %s\n",[[e reason] UTF8String]);
            }
        }
        CGContextRelease(cgctx);
        // Free image data memory for the context
        if (data) {
            free(data);
        }
        //
    }
    return YES;
}
- (CGContextRef) createARGBBitmapContextFromImage:(CGImageRef) inImage {
    
    CGContextRef    context = NULL;
    CGColorSpaceRef colorSpace;
    void *          bitmapData;
    int             bitmapByteCount;
    int             bitmapBytesPerRow;
    
    // Get image width, height. We'll use the entire image.
    size_t pixelsWide = CGImageGetWidth(inImage);
    size_t pixelsHigh = CGImageGetHeight(inImage);
    
    // Declare the number of bytes per row. Each pixel in the bitmap in this
    // example is represented by 4 bytes; 8 bits each of red, green, blue, and
    // alpha.
    bitmapBytesPerRow   = (pixelsWide * 4);
    bitmapByteCount     = (bitmapBytesPerRow * pixelsHigh);
    
    // Use the generic RGB color space.
    colorSpace = CGColorSpaceCreateDeviceRGB();
    
    if (colorSpace == NULL)
    {
        fprintf(stderr, "Error allocating color space\n");
        return NULL;
    }
    
    // Allocate memory for image data. This is the destination in memory
    // where any drawing to the bitmap context will be rendered.
    bitmapData = malloc( bitmapByteCount );
    if (bitmapData == NULL)
    {
        fprintf (stderr, "Memory not allocated!");
        CGColorSpaceRelease( colorSpace );
        return NULL;
    }
    
    // Create the bitmap context. We want pre-multiplied ARGB, 8-bits
    // per component. Regardless of what the source image format is
    // (CMYK, Grayscale, and so on) it will be converted over to the format
    // specified here by CGBitmapContextCreate.
    context = CGBitmapContextCreate (bitmapData,
                                     pixelsWide,
                                     pixelsHigh,
                                     8,      // bits per component
                                     bitmapBytesPerRow,
                                     colorSpace,
                                     kCGImageAlphaPremultipliedFirst);
    if (context == NULL)
    {
        free (bitmapData);
        fprintf (stderr, "Context not created!");
    }
    
    // Make sure and release colorspace before returning
    CGColorSpaceRelease( colorSpace );
    
    return context;
}
//经纬坐标转换屏幕坐标
-(CGPoint)transPointGeoToScr:(CGPoint)layerCoord
{
	GCOORD scrCoord;
	GCOORD pgdCoord;
	CGPoint layerPoint;
	pgdCoord.x = layerCoord.x;
	pgdCoord.y = layerCoord.y;
	GSTATUS gRet;
    
    GHMAPVIEW mapHandle;
    GDBL_GetMapViewHandle(GMAP_VIEW_TYPE_MAIN,&mapHandle);
    
	gRet=GDBL_CoordConvert(GCC_GEO_TO_SCR, &scrCoord, &pgdCoord,mapHandle);
    
    if (GD_ERR_OK==gRet) {
        layerPoint = CGPointMake(scrCoord.x, scrCoord.y);
    }else
    {
        layerPoint = CGPointMake(-1, -1);//转换失败或3D模式下的天空区域内
    }
	return layerPoint;
}
//    25m           19	 10m
//    50m           18	 25m
//    100m          17	 50m
//    200m          16	 100m
//    500m          15	 200m
//    1km           14	 500m
//    2km           13	 1km
//    5km           12	 2km
//    10km          11	 5km
//    50km          9	 20km
//    200km         6	 100km
//    500km         5


-(int)changeGDScaleToAmapScale:(int)nScale
{
    int nGDScale =15;
    switch (nScale) {
        case 0:
            nScale = 4;
            break;
        case 1:
            nScale = 5;
            break;
        case 2:
            nScale = 8;
            break;
        case 3:
            nScale = 8;
            break;
        case 4:
            nScale = 9;
            break;
        case 5:
            nScale = 10;
            break;
        case 6:
            nScale = 11;
            break;
        case 7:
            nScale = 12;
            break;
        case 8:
            nScale = 12;
            break;
        case 9:
            nScale = 14;
            break;
        case 10:
            nScale = 15;
            break;
        case 11:
            nScale = 16;
            break;
        default:
            break;
    }
    return nScale;
}


@end
