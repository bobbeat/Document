//
//  UserFeedback.h
//  AutoNavi
//
//  Created by huang longfeng on 13-5-13.
//
//

#import <Foundation/Foundation.h>
#import "NetKit.h"
#import "TrafficEventObject.h"


#define kTrafficEventErrorDomain            @"TrafficEventErrorDomain"//交通时间模块的错误码
/*
 查看是否有上传
http://sns.dev.myamap.com/ws/archive/trafficevent_sync/?starttime=1370330131&endtime=&channel=autonavi&sign=1E361A3CACC34204A0E3497841DEF13C&pagesize=&pagenum=
 */
@protocol NetReqToViewCtrDelegate;

@interface TrafficEventReport : NSObject <NetRequestExtDelegate>
{

}
@property (nonatomic, retain)   id<NetReqToViewCtrDelegate>     psIdDelegate;
@property (nonatomic, retain)   NSMutableDictionary*            psdicViewController;
@property (nonatomic, retain)   NSMutableArray*                 psArrayTrafficEvent;
/**
 实例化对象
 */
+ (TrafficEventReport *)sharedInstance;

/**
 析构对象
 */
+ (void)purgeInstance;

/**
 上传请求 
 @param control             NetReqToViewCtrDelegate对象，用于接收请求完成发生的消息
 @param requestType         检索索引值
 @param pSubmitEvent        请求结构体填充
 
 @see NetReqToViewCtrDelegate
 */
- (void)SubmitTheTrafficEvent:(TrafficSubmitEvent*)pSubmitEvent
                  requestType:(RequestType)requestType
               viewContorller:(id<NetReqToViewCtrDelegate>)pViewContorller;
/**
 下载请求
 @param control             NetReqToViewCtrDelegate对象，用于接收请求完成发生的消息
 @param requestType         检索索引值
 @param pSubmitEvent        请求结构体填充
 
 @see NetReqToViewCtrDelegate
 */
- (void)DownloadTrafficEvent:(TrafficDownLoadRequest*)pDownLoadEventRequest
                 requestType:(RequestType)requestType
              viewContorller:(id<NetReqToViewCtrDelegate>)pViewContorller;
/**
 取消所有请求
 @see NetReqToViewCtrDelegate
 */
- (BOOL)Net_CancelAllRequest;

/**
 取消某个类型的请求 
 @param requestType         检索索引值
 @see NetReqToViewCtrDelegate
 */
- (BOOL)Net_CancelRequestWithType:(RequestType)requestType;

/**
 获取所获得地交通事件数组
 */
- (NSArray*)GD_BLGetTrafficEventArray;

@end
