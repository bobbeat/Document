//
//  TrafficEventManager.h
//  AutoNavi
//
//  Created by liyuhang on 13-6-7.
//
//

#import <Foundation/Foundation.h>
#import "NetKit.h"


@protocol  TrafficEventDelegate <NSObject>
@required
-(void)updateTrafficEventInfo:(int) flag;
@end

//////////////////////////////////////////////////////////////////

@interface TrafficEventManager : NSObject<NetReqToViewCtrDelegate>
{
    
}

/**
 实例化对象
 */
+ (TrafficEventManager *)sharedInstance;

/**
 析构对象
 */
+ (void)purgeInstance;

/**
 从网络段获取交通事件
 */
- (void)GDBL_GetTrafficEventInfo :(int) flag;

/**
 删除本地保存交通事件
 */
- (void)GDBL_ReleaseTrafficEventInfo;

/**
 移图时更新交通事件对应的屏幕坐标
 */
- (void)GDBL_UpdateTrafficEventInfoOnScreen;

/**
 设置交通事件信息到地图
 */
- (void)GDBL_SetTrafficEventInfo;

/**
 是否显示交通事件
 @param 布尔值 是否显示
 */
- (BOOL)GDBL_ShowTrafficEventInfo;

/**
 当前图面显示的点数组
 */
- (NSArray*)GDBL_GetTrafficEventArray;
/***
 *返回当前连接状态
 ***/
- (BOOL)GDBL_GetTrafficEventConnect;
- (void)GDBL_SetTrafficEventConnect:(BOOL)netWorking;
/**
 设置代理
 */
- (void)GDBL_SetTrafficEventDelegate:(id<TrafficEventDelegate>)idDelegate;
@end
