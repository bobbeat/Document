//
//  TrafficEventObject.h
//  AutoNavi
//
//  Created by liyuhang on 13-6-4.
//
//

#import <Foundation/Foundation.h>

/*
 1 Traffic status object for submitting event from user
 */
@interface TrafficSubmitEvent : NSObject
{
    
}
@property (nonatomic, assign) int psnLongitude;
@property (nonatomic, assign) int psnLatitude;
@property (nonatomic, assign) int psnLayerId;
@property (nonatomic, assign) int psnLayerDetailTag;
@property (nonatomic, assign) int psnSizeOfPic;
//
@property (nonatomic, copy)   NSString* psszAddress;
@property (nonatomic, copy)   NSString* psszContent;
@property (nonatomic, retain) UIImage*  psImage;
@end

/*
 2 Traffic status object for downloading event from sever
 */
@interface TrafficDownLoadRequest : NSObject
{
    
}
@property (nonatomic, assign) int   psnLeftPoint_X;
@property (nonatomic, assign) int   psnRighPoint_X;
@property (nonatomic, assign) int   psnLeftPoint_Y;
@property (nonatomic, assign) int   psnRighPoint_Y;
@property (nonatomic, assign) int   psnHeight;
@property (nonatomic, assign) int   psnWidth;
@property (nonatomic, assign) int   psnLevelOfDetail;
@end

/*
 3 The detals of downloaded traffic event
 */
@interface TrafficDownLoadEvent : NSObject
{
    
}
@property (nonatomic, assign)   int psnEventID;
@property (nonatomic, assign)   int psnUserID;
@property (nonatomic, assign)   int psnLayerId;
@property (nonatomic, assign)   int psnLayerDetailTag;
//@property (nonatomic, assign)   int psnDirection;
//@property (nonatomic, assign)   int psnPositionOnRoad;
@property (nonatomic, assign)   int psnCreateTime;
//@property (nonatomic, assign)   int psnPielPoint_X;
//@property (nonatomic, assign)   int psnPielPoint_Y;
@property (nonatomic, assign)   CGPoint   psGeoPoint;
@property (nonatomic, assign)   CGPoint   psScrPoint;
@property (nonatomic, copy)     NSString* psszTitleID;
@property (nonatomic, copy)     NSString* psszAddress;
@property (nonatomic, copy)     NSString* psszTitle;
@property (nonatomic, copy)     NSString* psszPickureUrl;
@property (nonatomic, copy)     NSString* psszNickName;
@end








