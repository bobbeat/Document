//
//  UserFeedback.m
//  AutoNavi
//
//  Created by huang longfeng on 13-5-13.
//
//

#import "TrafficEventReport.h"
#import "TrafficEventManager.h"
#import "GDNet_ProtocolParse.h"
#import "GDNet_ProtocolDefine.h"
#import <CommonCrypto/CommonDigest.h>


/*************************************************************************
 ******************    交通事件    *****************************************
 **************************************************************************/
// 1  服务器
#define kTrafficEventServerSubmit         @"http://sns.amap.com:80/ws/archive/trafficevent_update/?"    //正式服务器地址
//#define kTrafficEventServerSubmit           @"http://sns.test.myamap.com:80/ws/archive/trafficevent_update/?"
#define kTrafficEventServerDownload         @"http://layer.amap.com:80/clusterservice/messagehandle?"      //正式服务器地址
//#define kTrafficEventServerDownload         @"http://cs.test.myamap.com:80/clusterservice/messagehandle?"

#define kTrafficEventBoundary                @"---------------------------7ddcc1a3104a0"                         //content-type



//#define _M_DEST_NET_WORK_ 1
static TrafficEventReport*      pscInstance = nil;
typedef int (*pFunctionForMD5)(char *sign,int gSize,const char *pData);
int FunctionForMD5(char *sign, int gSzie, const char *pData)
{
	const char* inputStr = pData;
    unsigned char outPutStr[16] = {0} ;
    //
    CC_MD5(inputStr, strlen(inputStr), outPutStr);
	//
    for (int i=0; i<16; i++) {
        sprintf(&sign[i*2], "%x", (outPutStr[i]&0xF0)>>4);
        sprintf(&sign[i*2+1], "%x", outPutStr[i]&0x0F);
    }
    return 1;
}
/*
 */
@interface TrafficEventReport()
{

    NSMutableDictionary*            m_dicViewController;
    id<NetReqToViewCtrDelegate>     m_idDelegate;
    NSMutableArray*                 m_marrayTrafficEvent;
}

- (void)handleResponseData:(NSData *)data withRequestType:(RequestType) type;
- (id)errorWithCode:(NSInteger)code userInfo:(NSDictionary *)userInfo;
- (void)failedWithError:(NSError *)error withRequestType:(RequestType) type;
@end



/*
 */
@implementation TrafficEventReport

#pragma mark MD5

@synthesize psdicViewController = m_dicViewController;
@synthesize psIdDelegate = m_idDelegate;
@synthesize psArrayTrafficEvent = m_marrayTrafficEvent;

/*
 1 class mathods
 */
+(TrafficEventReport *)sharedInstance
{
    if (pscInstance == nil)
    {
        pscInstance = [[TrafficEventReport alloc] init];
        //
        BOOL bStatus = AOS_Init();
        pFunctionForMD5 pFunction;
        pFunction= FunctionForMD5;
        AOS_SetMD5Func(pFunction);
        NSLog(@"AutoNavi->The traffic event init:%d", bStatus);
    }
    return pscInstance;
}

+(void)purgeInstance
{
    if (pscInstance) {
        [pscInstance release];
        pscInstance = nil;
    }
}
/*
 2 override 
 */
- (id) init {
	self = [super init];
	if (self != nil)
    {
        m_dicViewController = [[NSMutableDictionary alloc] init];
        m_marrayTrafficEvent = [[NSMutableArray alloc] init];
	}
	return self;
}
- (void)dealloc
{
    self.psIdDelegate = nil;
    self.psdicViewController = nil;
    self.psArrayTrafficEvent = nil;
    [super dealloc];
}
-(void) setString:(char*)szTring
{
    strcpy(szTring, "1111");
}

-(void) setString11:(char**)szString
{
    strcpy(*szString, "2222");
}
// 上传请求
- (void)SubmitTheTrafficEvent:(TrafficSubmitEvent*)pSubmitEvent
                  requestType:(RequestType)requestType
               viewContorller:(id<NetReqToViewCtrDelegate>)pViewContorller;
{
    if(pViewContorller)
    {
        [m_dicViewController setObject:pViewContorller forKey:[NSNumber numberWithInt:requestType]];
    }
    //
/*
 First 
 */
    // 不同的参数
    AOS_UserTrafficUploadReq stSubmitRequest;
    memset(&stSubmitRequest, 0, sizeof(AOS_UserTrafficUploadReq));
    /*
     layerid=1055(0),     该值可为11020(0) 缓慢           11021(1) 拥堵         11022(2) 阻塞，
     layerid=1050(1),     该值可为11010(0) 故障车辆        11011(1) 车祸         11012(2) 路面障碍，
     layerid=1060(2),     该值可为11030(0) 检查           11031(1) 管制 
     */
    if (pSubmitEvent.psnLayerId==0) {
        stSubmitRequest.eLayerid = 1055;
        stSubmitRequest.eLayertag = 11020+pSubmitEvent.psnLayerDetailTag;
    }else if (pSubmitEvent.psnLayerId==1) {
        stSubmitRequest.eLayerid = 1050;
        stSubmitRequest.eLayertag = 11010+pSubmitEvent.psnLayerDetailTag;
    }else if (pSubmitEvent.psnLayerId==2) {
        stSubmitRequest.eLayerid = 1060;
        stSubmitRequest.eLayertag = 11030+pSubmitEvent.psnLayerDetailTag;
    }
    stSubmitRequest.iLatitude = pSubmitEvent.psnLatitude;
    stSubmitRequest.iLongitude = pSubmitEvent.psnLongitude;
    if (pSubmitEvent.psImage) {
        //
        NSData *pictureData = UIImageJPEGRepresentation(pSubmitEvent.psImage, 0.5);
        stSubmitRequest.pPicBuff = (char*)[pictureData bytes];
        stSubmitRequest.nSize = [pictureData length];//strlen(stSubmitRequest.pPicBuf
    }
    if (pSubmitEvent.psszAddress) {
        strcpy(stSubmitRequest.szAddress, [pSubmitEvent.psszAddress cStringUsingEncoding:NSUTF8StringEncoding]);
    }
    if (pSubmitEvent.psszContent) {
        strcpy(stSubmitRequest.szContent, [pSubmitEvent.psszContent cStringUsingEncoding:NSUTF8StringEncoding]);
    }
    // 相同的参数
    strcpy(stSubmitRequest.szAppid, "11100");
    strcpy(stSubmitRequest.szChannel, "navigation");
  
/*
 Second
 */
    char* szRequest = (char*)malloc(60*1024);
    int  nResult = 0;
    int nStatus = AOS_UserTrafficUpload_CombStr(&stSubmitRequest, szRequest,&nResult);
    NSLog(@"Autonavi->synthesize the submit request:%d", nStatus);
    NSLog(@"Autonavi->%s", szRequest);
/*
 Third
 */
    NSMutableDictionary *dic_head = nil;
    
    if(requestType>=RT_TRAFFIC_EVENT_VEHICLE_FAULT&&requestType<=RT_TRAFFIC_EVENT_CONTROL)
    {
        dic_head = [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"multipart/form-data; boundary=%@",kTrafficEventBoundary  ],@"Content-Type", nil];
    }
    else if(requestType==RT_TRAFFIC_EVEN_DOWNLOAD)
    {
        dic_head = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"gzip",@"Accept-Encoding", nil];
    }
    
    NSData *bodyData = [[NSData alloc] initWithBytes:szRequest length:60*1024];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = kTrafficEventServerSubmit;
    condition.requestType = requestType;
    condition.httpMethod = @"POST";
    condition.httpHeaderFieldParams = dic_head;
    condition.bodyData = bodyData;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [bodyData release];
    //
    free(szRequest);
}
// 下载请求
- (void)DownloadTrafficEvent:(TrafficDownLoadRequest*)pDownLoadEventRequest
                 requestType:(RequestType)requestType
              viewContorller:(id<NetReqToViewCtrDelegate>)pViewContorller;
{
    if(pViewContorller)
    {
        [m_dicViewController setObject:pViewContorller forKey:[NSNumber numberWithInt:requestType]];
    }
/*
First
*/
    // 不同的参数
    AOS_GetTraffic_EventReq stDownloadRequest = {0};
    stDownloadRequest.Height = pDownLoadEventRequest.psnHeight;
    stDownloadRequest.Weighth = pDownLoadEventRequest.psnWidth;
    stDownloadRequest.levelOfDetail = pDownLoadEventRequest.psnLevelOfDetail;
    stDownloadRequest.RightDown.x = pDownLoadEventRequest.psnRighPoint_X;
    stDownloadRequest.RightDown.y = pDownLoadEventRequest.psnRighPoint_Y;
    stDownloadRequest.LeftUpper.x = pDownLoadEventRequest.psnLeftPoint_X;
    stDownloadRequest.LeftUpper.y = pDownLoadEventRequest.psnLeftPoint_Y;
    
/*
 Second
 */
    char szRequest[1024*5] = {0};
    int  nResult = 0;
    int nStatus = AOS_GetTraffic_Event_CombStr(&stDownloadRequest, szRequest,&nResult);
    NSLog(@"Autonavi->synthesize the download request:%d", nStatus);
    NSLog(@"Autonavi->%s", szRequest);
/*
 Third
 */
    NSMutableDictionary *dic_head = nil;
    
    if(requestType>=RT_TRAFFIC_EVENT_VEHICLE_FAULT&&requestType<=RT_TRAFFIC_EVENT_CONTROL)
    {
        dic_head = [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"multipart/form-data; boundary=%@",kTrafficEventBoundary  ],@"Content-Type", nil];
    }
    else if(requestType==RT_TRAFFIC_EVEN_DOWNLOAD)
    {
        dic_head = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"gzip",@"Accept-Encoding", nil];
    }
    
    NSData *bodyData = [[NSData alloc] initWithBytes:szRequest length:1024];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = kTrafficEventServerDownload;
    condition.requestType = requestType;
    condition.httpMethod = @"POST";
    condition.httpHeaderFieldParams = dic_head;
    condition.bodyData = bodyData;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [bodyData release];

}

//取消所有请求
- (BOOL)Net_CancelAllRequest
{
    if ([[NetExt sharedInstance] cancelAllRequests]) {
        [[TrafficEventManager sharedInstance] GDBL_SetTrafficEventConnect:NO];
        return YES;
    }
    return NO;
}
//取消某个类型的请求
- (BOOL)Net_CancelRequestWithType:(RequestType)requestType
{
    if ([[NetExt sharedInstance] Net_CancelRequestWithType:requestType]) {
        [[TrafficEventManager sharedInstance] GDBL_SetTrafficEventConnect:NO];
        return YES;
    }
    return NO;
}
/**
 获取所获得地交通事件数组
 */
- (NSArray*)GD_BLGetTrafficEventArray
{
    return (NSArray*)m_marrayTrafficEvent;
}
#pragma mark request
- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error{
    
    m_idDelegate = [m_dicViewController objectForKey:[NSNumber numberWithInt:request.requestCondition.requestType]];
    
    if ([m_idDelegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFailWithError:)]) {
        [m_idDelegate requestToViewCtrWithRequestType:request.requestCondition.requestType didFailWithError:error];
    }
}
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data{
    
    m_idDelegate = [m_dicViewController objectForKey:[NSNumber numberWithInt:request.requestCondition.requestType]];
    [self handleResponseData:data withRequestType:request.requestCondition.requestType];
}
#pragma mark private methods
- (void)handleResponseData:(NSData *)data withRequestType:(RequestType) type
{
    NSError *error = nil;
    char* szResult = (char*)[data bytes];
    NSLog(@"Autonavi->The result:%s", szResult);
    int   nLengthOfResult = strlen(szResult);
    int   nStatus = 0;
    //
    switch (type) {
            // 上传
        case  RT_TRAFFIC_EVENT_VEHICLE_FAULT://    = 30,//11010 故障车辆
        case  RT_TRAFFIC_EVENT_COLLISION://        = 31,//11011 车祸
        case  RT_TRAFFIC_EVENT_ROAD_FAULT://       = 32,//11012 路面障碍
        case  RT_TRAFFIC_EVENT_SOLW://             = 33,//11020 缓慢
        case  RT_TRAFFIC_EVENT_CROWDING://         = 34,//11021 拥堵
        case  RT_TRAFFIC_EVENT_HEAVY://            = 35,//11022 阻塞
        case  RT_TRAFFIC_EVENT_CHECK://            = 36,//11030 检查
        case   RT_TRAFFIC_EVENT_CONTROL://         = 37,//11031 管制
        {
            AOS_UserTrafficUpload stSubmitResult = {0};
            nStatus = AOS_UserTrafficUpload_Parse(szResult, nLengthOfResult, &stSubmitResult);
            if (nStatus) {
                nStatus = stSubmitResult.stAOS_ServerResponse.bResult;
                NSLog(@"Autonavi->The result from submitting traffic event:%d %s", stSubmitResult.stAOS_ServerResponse.bResult,stSubmitResult.stAOS_ServerResponse.szMessage);
                if (!nStatus) {
                    error = [self errorWithCode:mErrorFromServer userInfo:nil];
                }
            }
            else{
                error = [self errorWithCode:mParsingError userInfo:nil];
            }
        }
            break;
            // 下载
        case RT_TRAFFIC_EVEN_DOWNLOAD://           = 40,// 下载数据
        {
            AOS_GetTraffic_Event stDownloadResult = {0};
            nStatus = AOS_GetTraffic_Event_Parse(szResult, nLengthOfResult, &stDownloadResult);
#ifdef _M_DEST_NET_WORK_
            [m_marrayTrafficEvent removeAllObjects];
            //
            for (int i=0; i<10; i++) {
                TrafficDownLoadEvent* pTrafficEvent = [[TrafficDownLoadEvent alloc] init];
                pTrafficEvent.psnCreateTime = 1370504;
                pTrafficEvent.psnLayerDetailTag = 11020;
                pTrafficEvent.psnLayerId = 1055;

                CGPoint point = {118147919+i*400, 24566251+i*400};
                pTrafficEvent.psGeoPoint = point;
                pTrafficEvent.psnEventID = 25750+i;
                if (stDownloadResult.pAOS_Traffic_Event[i].szAddress) {
                    pTrafficEvent.psszAddress = [NSString stringWithFormat:@"address:%d",i];
                }
                if (stDownloadResult.pAOS_Traffic_Event[i].szNick) {
                    pTrafficEvent.psszNickName = [NSString stringWithFormat:@"szNick:%d",i];
                }
                if (stDownloadResult.pAOS_Traffic_Event[i].szPicture) {
                    pTrafficEvent.psszPickureUrl = [NSString stringWithFormat:@"http://files.dev.myamap.com/files/download/public/8/5/2013/6/9/14/36/39d6a1fbe94b7b9a790a64d0e4a99edb.jpg?ver=9803"];
                }
                if (stDownloadResult.pAOS_Traffic_Event[i].szTileid) {
                    pTrafficEvent.psszTitleID = [NSString stringWithFormat:@"szTileid:%d",i];
                }
                if (stDownloadResult.pAOS_Traffic_Event[i].szTitle) {
                    pTrafficEvent.psszTitle = [NSString stringWithFormat:@"szTitle:%d",i];
                }
                [m_marrayTrafficEvent addObject:pTrafficEvent];
                [pTrafficEvent release];
                
            }
            
#else
            if (nStatus) {
                if (stDownloadResult.iErrcode==0) {
                    NSLog(@"stDownloadResult.iNumber = %d",stDownloadResult.iNumber);
                    //
                    [m_marrayTrafficEvent removeAllObjects];
                    //
                    for (int i=0; i<stDownloadResult.iNumber; i++) {
                        TrafficDownLoadEvent* pTrafficEvent = [[TrafficDownLoadEvent alloc] init];
                        pTrafficEvent.psnCreateTime = stDownloadResult.pAOS_Traffic_Event[i].iTime;
                        //                     
                        pTrafficEvent.psnLayerDetailTag = stDownloadResult.pAOS_Traffic_Event[i].eLayertag;
                        pTrafficEvent.psnLayerId = stDownloadResult.pAOS_Traffic_Event[i].eLayerid;
                        //
                        GCOORD pwgsCoord;
                        GCOORD pgdCoord;
                        pwgsCoord.x = stDownloadResult.pAOS_Traffic_Event[i].stGpoint.x;
                        pwgsCoord.y = stDownloadResult.pAOS_Traffic_Event[i].stGpoint.y;
                        //GDBL_WGSToGDCoord(&pwgsCoord,&pgdCoord);
                        //
                        CGPoint point = {pwgsCoord.x, pwgsCoord.y};
                        pTrafficEvent.psGeoPoint = point;
                        pTrafficEvent.psnEventID = stDownloadResult.pAOS_Traffic_Event[i].iId;
                        pTrafficEvent.psnUserID = stDownloadResult.pAOS_Traffic_Event[i].iUids;
                        //                   
                        if (stDownloadResult.pAOS_Traffic_Event[i].szAddress) {
                            pTrafficEvent.psszAddress = [NSString stringWithCString:stDownloadResult.pAOS_Traffic_Event[i].szAddress encoding:NSUTF8StringEncoding];
                        }
                        if (stDownloadResult.pAOS_Traffic_Event[i].szNick) {
                            pTrafficEvent.psszNickName = [NSString stringWithCString:stDownloadResult.pAOS_Traffic_Event[i].szNick encoding:NSUTF8StringEncoding];
                        }
                        if (stDownloadResult.pAOS_Traffic_Event[i].szPicture) {
                            pTrafficEvent.psszPickureUrl = [NSString stringWithCString:stDownloadResult.pAOS_Traffic_Event[i].szPicture encoding:NSUTF8StringEncoding];
                        }
                        if (stDownloadResult.pAOS_Traffic_Event[i].szTileid) {
                            pTrafficEvent.psszTitleID = [NSString stringWithCString:stDownloadResult.pAOS_Traffic_Event[i].szTileid encoding:NSUTF8StringEncoding];
                        }
                        if (stDownloadResult.pAOS_Traffic_Event[i].szTitle) {
                            pTrafficEvent.psszTitle = [NSString stringWithCString:stDownloadResult.pAOS_Traffic_Event[i].szTitle encoding:NSUTF8StringEncoding];
                        }
                        [m_marrayTrafficEvent addObject:pTrafficEvent];
                        [pTrafficEvent release];
                        
                    }
                }else{
                    error = [self errorWithCode:mErrorFromServer userInfo:nil];
                }
                
            }else{
                error = [self errorWithCode:mParsingError userInfo:nil];
            }
    
#endif
         }
            break;
        default:
            break;
    }
    if(error != nil)
    {
        [self failedWithError:error withRequestType:type];
    }
    else if ([m_idDelegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFinishLoadingWithResult:)])
    {
        [m_idDelegate requestToViewCtrWithRequestType:type didFinishLoadingWithResult:nil];
    }
    [m_dicViewController removeObjectForKey:[NSNumber numberWithInt:type]];
}
- (id)errorWithCode:(NSInteger)code userInfo:(NSDictionary *)userInfo
{
    return [NSError errorWithDomain:kTrafficEventErrorDomain code:code userInfo:userInfo];
}
- (void)failedWithError:(NSError *)error withRequestType:(RequestType) type
{
    if ([m_idDelegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFailWithError:)]) {
        [m_idDelegate requestToViewCtrWithRequestType:type didFailWithError:error];
    }
    [m_dicViewController removeObjectForKey:[NSNumber numberWithInt:type]];
}
@end
