//
//  TrafficEventObject.m
//  AutoNavi
//
//  Created by liyuhang on 13-6-4.
//
//

#import "TrafficEventObject.h"
/*
 1 Traffic status object of submitting event from user
 */
@implementation TrafficSubmitEvent
//
@synthesize psnLatitude;
@synthesize psnLongitude;
@synthesize psnLayerId;
@synthesize psnLayerDetailTag;
@synthesize psnSizeOfPic;
@synthesize psImage;
@synthesize psszAddress;
@synthesize psszContent;

-(void)dealloc{
    self.psszAddress = nil;
    self.psImage = nil;
    self.psszContent = nil;
    [super dealloc];
}
@end

/*
 2 Traffic status object for downloading event from sever
 */

@implementation TrafficDownLoadRequest

@synthesize psnLeftPoint_X;
@synthesize psnLeftPoint_Y;
@synthesize psnRighPoint_X;
@synthesize psnRighPoint_Y;
@synthesize psnHeight;
@synthesize psnWidth;
@synthesize psnLevelOfDetail;

@end

/*
 3 The detals of downloaded traffic event
 */
@implementation TrafficDownLoadEvent

@synthesize psnEventID;
@synthesize psnUserID;
//@synthesize psnDirection;
@synthesize psnCreateTime;
@synthesize psnLayerDetailTag;
@synthesize psnLayerId;
//@synthesize psnPositionOnRoad;
//
@synthesize psGeoPoint;
@synthesize psScrPoint;
//
@synthesize psszAddress;
@synthesize psszTitle;
@synthesize psszTitleID;
@synthesize psszPickureUrl;
@synthesize psszNickName;

-(void)dealloc{
    self.psszTitleID = nil;
    self.psszTitle = nil;
    self.psszAddress = nil;
    self.psszPickureUrl = nil;
    self.psszNickName = nil;
    [super dealloc];
}
@end











