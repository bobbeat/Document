//
//  LogCommit.h
//  AutoNavi
//
//  Created by jiangshu.fu on 13-5-21.
//
//

#import <Foundation/Foundation.h>
#import "NetKit.h"

@interface LogCommit : NSObject <NetRequestExtDelegate>
{
    //记录文件名数组
    NSMutableArray *filesArray;
    //文件夹的路径
    NSString *directoryPath;
    //文件名与文件id对应的字典续
    NSMutableDictionary *fileDictionary;
}

@property (nonatomic, retain) NSMutableArray *filesArray;
@property (nonatomic, retain) NSString *directoryPath;
@property (nonatomic, retain) NSMutableDictionary *fileDictionary;

-(void) logRequest;

@end
