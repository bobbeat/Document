//
//  LogCommit.m
//  AutoNavi
//
//  Created by jiangshu.fu on 13-5-21.
//
//

#import "LogCommit.h"
#import "NSString+Category.h"
#import "ANDataSource.h"

#define kCrashLogDomain                  @"uploadlog/upload_log" //日志上传

@implementation LogCommit
//上传的文件id
#define kFileID                 @"crashLog"
//日志存放文件夹
#define kFolder                 @"/crashLog"
//搜索的文件后缀
#define kStringSuffix           @".log"

@synthesize filesArray;
@synthesize directoryPath;
@synthesize fileDictionary;

-(id) init
{
    self = [super init];
    if(self != nil)
    {
        filesArray = [[NSMutableArray alloc] init];
        //获取log文件存储的文件夹
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                             NSUserDomainMask,
                                                             YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        directoryPath = [[documentsDirectory stringByAppendingPathComponent:kFolder] retain];
        fileDictionary = [[NSMutableDictionary alloc] init];
    }
    return  self;
}

-(void) dealloc
{
    if(filesArray)
    {
        [filesArray release];
        filesArray = nil;
    }
    if(directoryPath)
    {
        [directoryPath release];
        directoryPath = nil;
    }
    if(fileDictionary)
    {
        [fileDictionary release];
        fileDictionary = nil;
    }
        [super dealloc];
}

#pragma mark ---  上传字符串的拼接和文件的数据的设置  ---
/**
 * 搜索符合文件名后缀的文件
 **/
-(void) searchLogFiles
{
    [self.filesArray removeAllObjects];
    NSFileManager *fileManage = [NSFileManager defaultManager];
    NSArray *files = [fileManage subpathsOfDirectoryAtPath:directoryPath
                                                         error:nil];  
    for(NSString *tmpFileName in files)
    {
        NSRange searchRange = [tmpFileName rangeOfString:kStringSuffix
                                                 options:NSBackwardsSearch];
        if(searchRange.length == 0)
        {
            continue;
        }
        [self.filesArray addObject:tmpFileName];
        if(filesArray.count == 5)
        {
            return ;
        }
    }
}

/**
 * 获取键对值的文件id与文件名的对应字典序
 **/
-(void) setFileIDWithName
{
    //获取文件字典序 —— 文件id（file“%d”,i）对应文件名称
    if(self.filesArray.count > 0 && self.filesArray.count <= 5)
    {
        for (int i = 0; i < self.filesArray.count; i++) {
            [self.fileDictionary setObject:[filesArray objectAtIndex:i]
                                    forKey:[NSString stringWithFormat:@"%@%d",
                                            kFileID,i]];
        }
    }
    else if(self.filesArray.count > 5)
    {
        for (int i = 0; i < 5; i++) {
            [self.fileDictionary setObject:[filesArray objectAtIndex:i]
                                    forKey:[NSString stringWithFormat:@"%@%d",
                                            kFileID,i]];
        }
    }
}

/**
 * 设置上传的NSData数据
 **/
-(NSData *) uploadData
{
    //分界string  前与后
    NSString *bodyPreBoundary = [NSString stringWithFormat:@"--%@\r\n",
                                 kNetRequestStringBoundary];
    NSString *bodySufBoundary = [NSString stringWithFormat:@"\r\n--%@--\r\n",
                                 kNetRequestStringBoundary];
    NSMutableData *body = [NSMutableData data];
    
    //数据开头分隔符
    [body appendData:[bodyPreBoundary dataUsingEncoding:NSUTF8StringEncoding]];
    for(NSString *key in [self.fileDictionary allKeys])
    {
        
        //文件头
        [body appendData:[[NSString stringWithFormat:
                           @" Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n Content-Type: text/plain\r\n\r\n",
                           key,[self.fileDictionary objectForKey:key]] dataUsingEncoding:NSUTF8StringEncoding]];
        
        //文件内容
        [body appendData:[NSData dataWithContentsOfFile:
                          [NSString stringWithFormat:@"%@/%@",
                           directoryPath,[self.fileDictionary objectForKey:key]]
                          ]];
    //数据最后的一条信息的分隔符
    [body appendData:[bodySufBoundary dataUsingEncoding:NSUTF8StringEncoding]];
    }
    //data数据的头设置
    NSMutableData *bodyData = [NSMutableData data];
    /*[bodyData appendData:[[NSString stringWithFormat:
                           @"Content-Type: multipart/form-data; boundary=%@\r\n Content-Length: %d\r\n",
                           kNetRequestStringBoundary,
                           [body length]] dataUsingEncoding:NSUTF8StringEncoding]];*/
    [bodyData appendData:body];
    
    
    return bodyData;
}

/**
 * 上传数据
 **/
-(void) logRequest
{
    [self searchLogFiles];
    if(self.filesArray.count <= 0)
    {
        NSLog(@"如果没有日志文件，就不请求了");
        return ;
    }
    [self setFileIDWithName];
    //上传地址
    //NSString *addressUrl = [NSString stringWithFormat:@"%@%@",kNetDomain,kCrashLogDomain];
    //上传参数设置
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    //组装文件id的字符串
    NSString *stringFileID = @"";
    [dict setObject:@"xml" forKey:@"out"];
    [dict setObject:[[ANDataSource sharedInstance] GMD_GetDeviceID] forKey:@"mac"];
    //判断逗号添加的位置
    BOOL firstAdd = YES;
    for(NSString *key in [self.fileDictionary allKeys])
    {
        if(firstAdd == YES) {
            firstAdd  = NO;
        }
        else
        {
            stringFileID = [stringFileID stringByAppendingFormat:@","];
        }
        stringFileID = [stringFileID stringByAppendingString:key];
    }
    [dict setObject:stringFileID forKey:@"file_ident"];
    
    NSData *data = [self uploadData];
    
    //发送的nsdata数据
    NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"data ========= \n%@",string);
    [string release];
    
    NSMutableDictionary *dic_headFiled = [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"multipart/form-data; boundary=%@",kNetRequestStringBoundary  ],@"Content-Type", nil];
    
    NetBaseRequestCondition *condition = [[NetBaseRequestCondition alloc] init];
    condition.requestType = RT_Log_Commit;
    condition.urlParams = dict;
    condition.httpHeaderFieldParams = dic_headFiled;
    condition.httpMethod = @"POST";
    condition.bodyData = data;
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [condition release];
    [dict release];
}

#pragma mark ---  NetRequestExtDelegate委托实现函数  ---
- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error
{
    NSLog(@"FAILWITHERROR------------");
}
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data
{
    NSLog(@"-----FINISHLOADING-----");
    char *szResult = (char *)[data bytes];
    NSString *tempResult = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
	NSLog(@"didFinishLoadingWithData==%@",tempResult);
    NSString *tmp = [NSString stringWithFormat:@"%s",szResult];
    NSString *result = [tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"];
    if([result isEqualToString:@"SUCCESS"])
    {
        NSLog(@"SUCCESS");
        NSFileManager *fileManage = [NSFileManager defaultManager];
        //删除上传完成的文件
        for (NSString *key in [self.fileDictionary allKeys]) {
            NSString *filePath = [NSString stringWithFormat:@"%@/%@",self.directoryPath,[self.fileDictionary objectForKey:key]];
            NSError *error;
            if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
            {
                [fileManage removeItemAtPath:filePath error:&error];
            }
            [self.fileDictionary removeObjectForKey:key];
            NSLog(@"__________delete%@",filePath);
        }
        // s上传完成后，继续上传，知道没有文件为止，程序自动停止上传
        [self logRequest];
    }
    else if([result isEqualToString:@"FAIL"])
    {
        NSString *errorInfo = [tmp CutFromNSString:@"<Error>" Tostring:@"</Error>"];
        NSLog(@"%@",errorInfo);
    }
    else
    {
        NSLog(@"服务器回传数据result != SUCCESS || False");
    }
    [tempResult release];
}


@end
