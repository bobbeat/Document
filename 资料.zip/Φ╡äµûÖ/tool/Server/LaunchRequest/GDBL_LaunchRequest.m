//
//  GDBL_LaunchRequest.m
//  AutoNavi
//
//  Created by huang longfeng on 13-5-24.
//
//

#import "GDBL_LaunchRequest.h"
#import "NetKit.h"
#import "Utility.h"
#import "NSString+Category.h"
#import "NetTypedef.h"
#import "GDBL_UserBehaviorCountNewPOST.h"
#include <sys/types.h>
#include <sys/sysctl.h>
#import"sys/utsname.h"
#import "MWMapOperator.h"
#import "GDCacheManager.h"

//开机网络请求相关-----------------------------------------------------------------------------------
#define kMapUpgradeURL                    @"iphonedata/version/"
#define kSoftWareVersionUpdateURL         @"iphonedata/getsoftversion_v2/"
#define kUserYawCountPostURL              @"iphonedata/upload_routeyaw/?out=xml"
#define kBackgroundSwitchOnOffURL         @"iphonedata/get_serviceonoff/"   //后来服务功能开关
#define kUserActionUploadURL              @"iphonedata/upload_useraction/"
#define kUploadToken                      @"iphonedata/collect_token_v2/"
#define HEAD_COLLECLOCATION               @"iphonedata/collectlocation/?"  //收集数据采集反馈 2012.5.2
#define HEAD_UpdateApp                    @"soft_update/iphone_soft_update_test/?"  //软件升级接口
#define kNetLaunchImageUrl                @"download_source/powerboot/"         //开机图片加载
#define kPowerVoiceDownload               @"download_source/power_voice/"       //开机语音下载

#define LAUNCHIMAGE_TIMEOUT               2.0f
#define LAUNCHIMAGE_SHOWTIME              2.0f
#define DEFAULTLAUNCHIMAGE                @"Default-Landscape.png"

#pragma mark ---  backgroundXMLParse  ---
@interface BackgroundXMLParse :NSObject <NSXMLParserDelegate>
{
    NSMutableDictionary                *backgroundServiceSwitch;
    NSString                    *serviceName;
    NSString                    *serviceID;
    NSString                    *switchOnOff;
    NSString                    *nodeStirng;
}
@property (nonatomic,retain) NSMutableDictionary *backgroundServiceSwitch;
@property (nonatomic,copy) NSString *serviceName;
@property (nonatomic,copy) NSString *serviceID;
@property (nonatomic,copy) NSString *nodeString;
@property (nonatomic,copy) NSString *switchOnOff;

@end

@implementation BackgroundXMLParse

@synthesize backgroundServiceSwitch;
@synthesize serviceID;
@synthesize serviceName;
@synthesize nodeString;
@synthesize switchOnOff;

#pragma  mark ---  XML Parser Delegate  ---



//开始解析前，在这里可以做一些初始化工作
- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    [backgroundServiceSwitch removeAllObjects];
    self.serviceName = nil;
    self.serviceID = nil;
    self.nodeString = nil;
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    if(qName)
    {
        elementName = qName;
    }
    else if([elementName isEqualToString:@"archive"])
    {
        backgroundServiceSwitch = [[NSMutableDictionary alloc] init];
    }
    else if([elementName isEqualToString:@"serviceid"] ||
            [elementName isEqualToString:@"servicename"] ||
            [elementName isEqualToString:@"onoff"])
    {
        self.nodeString = elementName;
    }
    NSLog(@"didStartElement");
}
///接收数据
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if(string == nil) return ;
    if([self.nodeString isEqualToString:@"serviceid"])
    {
        self.serviceID = string;
    }
    else if([self.nodeString isEqualToString:@"servicename"])
    {
        self.serviceName = string;
    }
    else if([self.nodeString isEqualToString:@"onoff"])
    {
        self.switchOnOff = string;
    }
    NSLog(@"string");
}

//解析XML结点尾标志
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if([elementName isEqualToString:@"item"] && self.serviceID != nil &&  self.serviceName != nil && self.switchOnOff != nil)
    {
        //存储数据
        //数组中的存储的是获取的对象——index 0：开关的状态  index 1：功能名称
        NSArray *tmpArray  = [[NSArray alloc] initWithObjects:self.switchOnOff,self.serviceName, nil];
        [self.backgroundServiceSwitch setObject:tmpArray forKey:self.serviceID];
        self.serviceID = nil;
        self.serviceName = nil;
        self.switchOnOff = nil;
        [tmpArray release];
    }
}

-(void)dealloc
{
    if(serviceID != nil)
    {
        [serviceID release];
        serviceID = nil;
    }
    if(serviceName != nil)
    {
        [serviceName release];
        serviceName = nil;
    }
    
    if(switchOnOff != nil)
    {
        [switchOnOff release];
        switchOnOff = nil;
    }
    if(backgroundServiceSwitch != nil)
    {
        [backgroundServiceSwitch release];
        backgroundServiceSwitch = nil;
    }
    if (nodeString)
    {
        [nodeString release];
        nodeString = nil;
    }
    [super dealloc];
}

@end

#pragma mark ---  GDBL_LaunchRequest  ---
@interface GDBL_LaunchRequest()
{
    @private
    NSMutableDictionary *m_Control;
    id<NetReqToViewCtrDelegate> delegate;
    UIImageView                 *defaultImageView;

}

@property (nonatomic)  NSMutableDictionary *m_Control;
@property (nonatomic,assign) id<NetReqToViewCtrDelegate> delegate;

@end
@implementation GDBL_LaunchRequest

@synthesize m_Control,delegate;

static GDBL_LaunchRequest * instance = nil;

-(id) init
{
    self = [super init];
	if (self != nil) {
        m_Control = [[NSMutableDictionary alloc] init];
	}
	return self;
}

+ (GDBL_LaunchRequest *) sharedInstance
{
    if(instance == nil)
    {
        instance = [[GDBL_LaunchRequest alloc] init];
    }
    return instance;
}
#pragma mark private methods
- (void)handleResponseData:(NSData *)data withRequestType:(RequestType) type
{
    id result = nil;
    NSError *error = nil;
    switch (type) {
        case REQ_UPDATE_APP:
        {
            result = data;
            NSLog(@"%@",[[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease]);
            NSString *str = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
            NSString *temp = [str CutFromNSString:@"<describe>" Tostring:@"</describe>"];
            if (temp.length<1) {
                temp=@"";
            }
            if ([str rangeOfString:@"<Result>SUCCESS</Result>"].length > 0&& [str rangeOfString:@"<Update>NEED</Update>"].length > 0 )
            {
                NSRange range_begin = [str rangeOfString:@"<UpdateCommand>"];
                NSRange range_end = [str rangeOfString:@"</UpdateCommand>"];
                
                int begin_position = range_begin.length + range_begin.location;
                int length = range_end.location - begin_position;
                NSString *updateCommand = [str substringWithRange:NSMakeRange(begin_position,length)];
                result = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES],@"Result",updateCommand,@"UpdateCommand",temp,@"Describe",nil];
                
            }
            else 
            {
                result = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO],@"Result",nil];
            }
        }
            break;
        case REQ_UPLOAD_LOCATIONINFO:
        {
            result = data;
            NSLog(@"%@",[[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease]);
        }
            break;
        case RT_LaunchRequest_MapUpgrade:
        {
            result = data;
        }
            break;
        case RT_LaunchRequest_UserYawUpload:
        {
            result = data;
        }
            break;
        case RT_LaunchRequest_UBC:
        {
            result = data;
        }
            break;
        case RT_LaunchRequest_SoftWareUpdate:
        {
            result = data;
        }
            break;
        case RT_Upload_Token:
        {
            result = data;
        }
            break;
        case RT_Upload_Token_To_Autonavi:
        {
            result = data;
        }
            break;
        case RT_Background_SwitchOnOff:
        {
            NSString *tmp = [[NSString alloc] initWithData:((NSData *)data) encoding:NSUTF8StringEncoding];
            
            if([[tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"] isEqualToString:@"FAIL"])
            {
                NSLog(@"网络后台开关：%@",tmp);
                error = [self errorWithCode:kLaunchRequestErrorCode_Background_SwitchOnOff userInfo:nil];
            }
            else if([[tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"] isEqualToString:@"SUCCESS"])
            {
                
                NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
                BackgroundXMLParse *bgXMLParse = [[[BackgroundXMLParse alloc] init] autorelease];
                [parser setShouldProcessNamespaces:NO];
                [parser setShouldReportNamespacePrefixes:NO];
                [parser setShouldResolveExternalEntities:NO];
                [parser setDelegate:bgXMLParse];
                [parser parse]; //开始解析
                [parser release];
                
                result = bgXMLParse.backgroundServiceSwitch;
            }
            
            [tmp release];
        }
            break;
        case RT_PowerVoiceRequest:
        {
            result = data;
        }
            break;
        case RT_PowerVoiceDownload:
        {
            result = data;
        }
            break;
        case RT_Background_launchImageRequest:
        {
            result = data;
        }
            break;
        case RT_Background_launchImageDownload:
        {
            result = data;
        }
            break;
        default:
            break;
    }
    if(error != nil)
    {
        [self failedWithError:error withRequestType:type];
    }
    else if ([delegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFinishLoadingWithResult:)])
    {
        [delegate requestToViewCtrWithRequestType:type didFinishLoadingWithResult:result];
    }
}

- (void)failedWithError:(NSError *)error withRequestType:(RequestType) type
{    
    if ([delegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFailWithError:)]) {
        [delegate requestToViewCtrWithRequestType:type didFailWithError:error];
    }
    
}

- (id)errorWithCode:(NSInteger)code userInfo:(NSDictionary *)userInfo
{
    return [NSError errorWithDomain:kLaunchRequestErrorDomain code:code userInfo:userInfo];
}


#pragma mark public methods


//地图数据升级检测
- (BOOL) Net_MapUpdateRequest:(id<NetReqToViewCtrDelegate>) control withRequestType:(RequestType)type
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
    NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
    [urlParams setObject:[NSString stringWithFormat:@"%0.1f",SOFTVERSIONNUM] forKey:@"client"];
    [urlParams setObject:[Utility GetMapNOVVersion] forKey:@"data"];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain stringByAppendingString:kMapUpgradeURL];
    condition.requestType = RT_LaunchRequest_MapUpgrade;
    condition.urlParams = urlParams;
    condition.httpMethod = @"GET";
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [urlParams release];
    return YES;
}

//用户行为统计上传
- (BOOL) Net_UserBehaviorCountRequest:(id<NetReqToViewCtrDelegate>) control   withRequestType:(RequestType)type
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    GDBL_UserBehaviorCountNewPOST *ubcPost = [[GDBL_UserBehaviorCountNewPOST alloc] init];
    
    NSData *bodyData = [ubcPost DataRequest];

    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain1 stringByAppendingString:kUserActionUploadURL];
    condition.requestType = RT_LaunchRequest_UBC;
    condition.httpMethod = @"POST";
    condition.bodyData = bodyData;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [ubcPost release];
    
    return YES;
}

//用户偏航统计上传
- (BOOL) Net_UserYawCountRequest:(id<NetReqToViewCtrDelegate>) control  withRequestType:(RequestType)type
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
     NSData *bodyData = [[[GDBL_UserBehaviorCountNew shareInstance] compostPathYaw] dataUsingEncoding:NSUTF8StringEncoding];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain1 stringByAppendingString:kUserYawCountPostURL];
    condition.requestType = RT_LaunchRequest_UserYawUpload;
    condition.httpMethod = @"POST";
    condition.bodyData = bodyData;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    return YES;
}

//软件版本升级
- (BOOL) Net_SoftVersionUpdateRequest:(id<NetReqToViewCtrDelegate>) control  withRequestType:(RequestType)type
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
    NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
    [urlParams setObject:[NSString stringWithFormat:@"V%.1f",SOFTVERSIONNUM] forKey:@"client_ver"];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain stringByAppendingString:kSoftWareVersionUpdateURL];
    condition.requestType = RT_LaunchRequest_SoftWareUpdate;
    condition.httpMethod = @"GET";
    condition.urlParams = urlParams;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [urlParams release];
    return YES;
}

//网络地图的后台开关控制
- (BOOL) Net_NetWorkSwitchControlRequest:(id<NetReqToViewCtrDelegate>) control   withRequestType:(RequestType)type
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt: RT_Background_SwitchOnOff]];
    NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
    [urlParams setObject: [[NSString stringWithFormat:@"V %@",[Utility GetMapNOVVersion]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
                  forKey:@"dataversion"];
    [urlParams setObject:[NSString stringWithFormat:@"%.1f",SOFTVERSIONNUM] forKey:@"appversion"];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain stringByAppendingString:kBackgroundSwitchOnOffURL];
    condition.requestType = RT_Background_SwitchOnOff;
    condition.httpMethod = @"GET";
    condition.urlParams = urlParams;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [urlParams release];
    return YES;
}

//上传token请求
- (BOOL) Net_UploadTokenWithControl:(id<NetReqToViewCtrDelegate>) control uuid:(NSString *)uuid token:(NSString *)token softversion:(NSString *)softversion devicetype:(NSString *)devicetype  withRequestType:(RequestType)type
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
    NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
    [urlParams setObject:softversion forKey:@"softversion"];
    if (uuid)
    {
        [urlParams setObject:uuid forKey:@"uuid"];
    }
    if(token)
    {
        [urlParams setObject:token forKey:@"token"];
    }
    [urlParams setObject:devicetype forKey:@"devicetype"];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain stringByAppendingString:kUploadToken];
    condition.requestType = type;
    condition.httpMethod = @"GET";
    condition.urlParams = urlParams;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [urlParams release];
    return YES;
}

//上传token至http://iphone.autonavi.com:8080/userToken/token

- (BOOL) Net_UploadTokenWithControl:(id<NetReqToViewCtrDelegate>)control uuid:(NSString *)uuid token:(NSString *)token  withRequestType:(RequestType)type
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
    NSString *strData = @"";
    strData = [strData stringByAppendingFormat:@"<udid>%@</udid><token>%@</token>", uuid,token];
    
    NSString *temp;
    temp = [self composeXML_GBK_ext2:strData activitycode:5];
    NSData *http_body = [temp dataUsingEncoding:0x80000632];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = @"http://iphone.autonavi.com:8080/userToken/token";
    condition.requestType = type;
    condition.httpMethod = @"POST";
    condition.bodyData = http_body;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    return YES;
}

- (BOOL) Net_UploadLocationInfoWithControl:(id<NetReqToViewCtrDelegate>)control withRequestType:(RequestType)type;//上传位置信息至后台
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
    NSString *dataVersion = [NSString stringWithFormat:@"%@",[Utility GetMapVersion]];
    
    NSString *sysVersion = CurrentSystemVersion;
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithFormat:@"%s",machine];
    NSString *macStr = deviceID;
    //获取地图中心信息
    GMAPCENTERINFO mapinfo = {0};
    [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
    NSString *latStr = [NSString stringWithFormat:@"%d", mapinfo.CenterCoord.y];
    NSString *lonStr = [NSString stringWithFormat:@"%d", mapinfo.CenterCoord.x];
    NSString *admincodeStr = [NSString stringWithFormat:@"%d", [[ANDataSource sharedInstance] GMD_GetCurrentAdmincode]];
    NSString *softVersionNum = [NSString stringWithFormat:@"%0.1f",SOFTVERSIONNUM];
    
    NSMutableDictionary *collectLocationParams = [[[NSMutableDictionary alloc] init] autorelease];
	[collectLocationParams setObject:macStr forKey:@"mac"];
	[collectLocationParams setObject:latStr forKey:@"lat"];
	[collectLocationParams setObject:lonStr forKey:@"lon"];
	[collectLocationParams setObject:admincodeStr forKey:@"admincode"];
	[collectLocationParams setObject:dataVersion forKey:@"version"];
	[collectLocationParams setObject:sysVersion forKey:@"ios"];
	[collectLocationParams setObject:platform forKey:@"phonetype"];
	[collectLocationParams setObject:softVersionNum forKey:@"client"];
    if (VendorID)
    {
        [collectLocationParams setObject:VendorID forKey:@"imei"];
    }
    if (deviceTokenEx)
    {
        [collectLocationParams setObject:deviceTokenEx forKey:@"token"];
    }
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [NSString stringWithFormat:@"%@%@",kNetDomain1,HEAD_COLLECLOCATION];
    condition.requestType = type;
    condition.urlParams = collectLocationParams;
    condition.httpMethod = @"GET";
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    
    free(machine);
    return YES;
}


/**
 *	软件升级接口
 *
 *	@param	control	控制器
 *	@param	type	请求类型
 *
 *	@return	成功 返回yes
 */

- (BOOL) Net_UpdateAppWithControl:(id<NetReqToViewCtrDelegate>)control withRequestType:(RequestType)type
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
#if  PROJECTMODE
     NSString *md5 = [[NSString stringWithFormat:@"%@%@",SOFTVERSION,KEY_MD5] stringFromMD5];
#else
     NSString *md5 = [[NSString stringWithFormat:@"%0.1f%@",SOFTVERSIONNUM,KEY_MD5] stringFromMD5];
#endif
    NSMutableDictionary *urlParams = [[[NSMutableDictionary alloc] init] autorelease];
#if  PROJECTMODE
    [urlParams setObject:[NSString stringWithFormat:@"%@",SOFTVERSION] forKey:@"soft_version"];
#else
    [urlParams setObject:[NSString stringWithFormat:@"%0.1f",SOFTVERSIONNUM] forKey:@"soft_version"];

#endif
    [urlParams setObject:md5 forKey:@"sign"];

    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [NSString stringWithFormat:@"%@%@",kNetDomain,HEAD_UpdateApp];
    condition.urlParams = urlParams;
    condition.requestType = type;
    condition.httpMethod = @"GET";
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    return YES;
}

/**
 *	开机图片加载
 *  @param  window  父视图
 *
 */
- (void)NET_LaunchImage:(UIWindow *)window
{
    window.windowLevel = 2000;
    
    defaultImageView = [[UIImageView alloc] initWithImage:[[ANDataSource sharedInstance] GMD_GetDefaultImage]];
    [window addSubview:defaultImageView];
    [window bringSubviewToFront:defaultImageView];
    [defaultImageView release];
    
    //请求开机图片
    
    BOOL bExpired = [[GDCacheManager globalCache] hasCacheForKey:GDCacheType_LaunchImage];
    
    if (bExpired) {
        
        [self Local_LaunchImage:window];
        
        return;
    }
    else{
        
        NSError *error = nil;
        
        NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
        [urlParams setValue:[NSString stringWithFormat:@"%0.1f",SOFTVERSIONNUM] forKey:@"client"];
        [urlParams setValue:DeviceResolutionName forKey:@"device"];
        
        NSString *requestUrl = [NetRequestExt serializeURL:[kNetDomain stringByAppendingString:kNetLaunchImageUrl] params:urlParams httpMethod:@"GET"];
        [urlParams release];
        
        
        NSURL *imageUrl = [NSURL URLWithString:requestUrl];
        NSURLRequest *imageUrlRequest = [[NSURLRequest alloc]initWithURL:imageUrl cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:LAUNCHIMAGE_TIMEOUT];
        NSData *received = [NSURLConnection sendSynchronousRequest:imageUrlRequest returningResponse:nil error:&error];
        [imageUrlRequest release];
        
        
        NSString *requestString = [[NSString alloc] initWithData:((NSData *)received) encoding:NSUTF8StringEncoding];
        
        if (requestString && ([requestString length] > 0)) {
            
            NSString *result = [requestString CutFromNSString:@"<Result>" Tostring:@"</Result>"];
            
            if ([result isEqualToString:@"SUCCESS"])
            {
                
                NSString *launchImageUrl = [requestString CutFromNSString:@"<url>" Tostring:@"</url>"];
                
                if (launchImageUrl && [launchImageUrl length] > 0) {
                    NSURL *url = [NSURL URLWithString:launchImageUrl];
                    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:LAUNCHIMAGE_TIMEOUT];
                    NSData *received = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];
                    [request release];
                    
                    if (!error) {
                        UIImage *image = [UIImage imageWithData:received];
                        
                        UIImageView *launchImageView;
                        
                        if (image != nil) {
                            
                            
                            //保存到缓存中
                            NSString *expired = [requestString CutFromNSString:@"<expired>" Tostring:@"</expired>"];
                            [[GDCacheManager globalCache] setData:received forKey:GDCacheType_LaunchImage withTimeoutString:expired];
                            
                            BOOL bExpired = [[GDCacheManager globalCache] isExpiredWithString:expired];
                            if (!bExpired) {
                                launchImageView = [[UIImageView alloc] initWithImage:image];
                                [launchImageView setFrame:CGRectMake(0., 0., window.frame.size.width , window.frame.size.height)];
                                [window addSubview:launchImageView];
                                [window bringSubviewToFront:launchImageView];
                                [launchImageView release];
                                
                                [defaultImageView removeFromSuperview];
                                
                                //动画显示开机图片
                                double delayInSeconds = LAUNCHIMAGE_SHOWTIME;
                                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
                                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                                    
                                    window.windowLevel = 0;
                                    
                                    [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                        launchImageView.alpha = 0;
                                    } completion:^(BOOL finished) {
                                        
                                        
                                        
                                        [launchImageView removeFromSuperview];
                                        
                                    }];
                                    
                                });
                                
                                return;
                            }
                            
                        }
                    }
                    
                    
                }
                
                
            }
            else if ([result isEqualToString:@"FAIL"])
            {
                NSString *errorResult = [requestString CutFromNSString:@"<Error>" Tostring:@"</Error>"];
                if ([errorResult isEqualToString:@"CLIENT_INVALID"])//软件版本号不合法
                {
                    
                }
                else if ([errorResult isEqualToString:@"DEVICE_INVALID"]){//设备类型不合法
                    
                }
                else if ([errorResult isEqualToString:@"FUNCTION_CLOSED"]){//该功能已关闭
                    
                }
                else if ([errorResult isEqualToString:@"PARAMS_MISS"]){//缺少参数
                    
                }
            }
            
        }
        
        window.windowLevel = 0;
        
        [defaultImageView removeFromSuperview];
    }
    
    
}

- (void)Local_LaunchImage:(UIWindow *)window
{
    UIImage *localImage = [UIImage imageWithData:[[GDCacheManager globalCache] dataForKey:GDCacheType_LaunchImage]];
    if (localImage) {
        
        UIImageView *launchImageView = [[UIImageView alloc] initWithImage:localImage];
        [launchImageView setFrame:CGRectMake(0., 0., window.frame.size.width , window.frame.size.height)];
        [window addSubview:launchImageView];
        [launchImageView release];
        
        [defaultImageView removeFromSuperview];
        
        //动画显示开机图片
       
        double delayInSeconds = LAUNCHIMAGE_SHOWTIME;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            
            window.windowLevel = 0;
            
            [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                launchImageView.alpha = 0;
            } completion:^(BOOL finished) {
                
                [launchImageView removeFromSuperview];
                
            }];
            
        });
       
        return;
    }
    else{
        
        window.windowLevel = 0;
        
        [defaultImageView removeFromSuperview];
        
    }
}

/**
 *	开机图片后台请求判断是否过期
 *
 *	@param	control	控制器
 *	@param	type	请求类型
 *
 *	@return	成功 返回yes
 */
- (BOOL)NET_BackgroundLaunchImageRequest:(id<NetReqToViewCtrDelegate>)control withRequestType:(RequestType)type
{
    
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
    NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
    [urlParams setValue:[NSString stringWithFormat:@"%0.1f",SOFTVERSIONNUM] forKey:@"client"];
    [urlParams setValue:DeviceResolutionName forKey:@"device"];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain stringByAppendingString:kNetLaunchImageUrl];
    condition.requestType = type;
    condition.httpMethod = @"GET";
    condition.urlParams = urlParams;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [urlParams release];
    return YES;
}

/**
 *	开机图片后台下载
 *
 *	@param	imageUrl 下载链接
 *	@param	type	请求类型
 *
 *	@return	成功 返回yes
 */
- (BOOL)NET_BackgroundLaunchImageDownload:(id<NetReqToViewCtrDelegate>)control WithRequestType:(RequestType)type DownloadUrl:(NSString *)imageUrl{
    
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = imageUrl;
    condition.requestType = type;
    condition.httpMethod = @"GET";
    condition.urlParams = nil;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    return YES;
}

/**
 *	开机语音请求
 *
 *	@param	control	控制器
 *	@param	type	请求类型
 *
 *	@return	成功 返回yes
 */
- (BOOL)NET_PowerVoiceRequest:(id<NetReqToViewCtrDelegate>)control withRequestType:(RequestType)type
{
        
        [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
        
        NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
        [urlParams setValue:[NSString stringWithFormat:@"%0.1f",SOFTVERSIONNUM] forKey:@"client"];
        
        NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
        condition.baceURL = [kNetDomain stringByAppendingString:kPowerVoiceDownload];
        condition.requestType = type;
        condition.httpMethod = @"GET";
        condition.urlParams = urlParams;
        
        [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
        [urlParams release];
        
        return YES;
    

}

/**
 *	开机语音下载
 *
 *	@param	voiceUrl 下载链接
 *	@param	type	请求类型
 *
 *	@return	成功 返回yes
 */
- (BOOL)NET_PowerVoiceDownload:(id<NetReqToViewCtrDelegate>)control WithRequestType:(RequestType)type DownloadUrl:(NSString *)voiceUrl
{
    [m_Control setObject:control forKey:[NSNumber numberWithInt:type]];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = voiceUrl;
    condition.requestType = type;
    condition.httpMethod = @"GET";
    condition.urlParams = nil;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    return YES;
}

//@add start by ly for push 10.11.21
-(NSString *)composeXML_GBK_ext2:(NSString *)content activitycode:(int)code
{
	NSString *strData = @"";
	strData = @"<?xml version=\"1.0\" encoding=\"GBK\"?>"
	"<opg>"
    "<activitycode>000";
	strData = [strData stringByAppendingFormat:@"%d", code];
	strData = [strData stringByAppendingString:@"</activitycode>""<processtime>"];
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYYMMddhhmmss"];
    NSString *locationString=[formatter stringFromDate: [NSDate date]];
    [formatter release];
	strData = [strData stringByAppendingString:locationString];
	strData = [strData stringByAppendingString:@"</processtime>""<actioncode>0</actioncode>""<svccont>"];
	strData = [strData stringByAppendingString:content];
	strData	= [strData stringByAppendingString:@"</svccont>""</opg>"];
	//NSLog(strData);
	return strData;
}

//取消所有请求
- (BOOL)Net_CancelAllRequest
{
    if ([[NetExt sharedInstance] cancelAllRequests]) {
        return YES;
    }
    return NO;
}
//取消某个类型的请求
- (BOOL)Net_CancelRequestWithType:(RequestType)requestType
{
    if ([[NetExt sharedInstance] Net_CancelRequestWithType:requestType]) {
        return YES;
    }
    return NO;
}
#pragma mark NetRequestExtDelegate
- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error{
    delegate = [self.m_Control objectForKey:[NSNumber numberWithInt:request.requestCondition.requestType]];
    [self failedWithError:error withRequestType:request.requestCondition.requestType];
    [self.m_Control removeObjectForKey:[NSNumber numberWithInt:request.requestCondition.requestType]];
}
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data{
    delegate = [self.m_Control objectForKey:[NSNumber numberWithInt:request.requestCondition.requestType]];
    [self handleResponseData:data withRequestType:request.requestCondition.requestType];
    [self.m_Control removeObjectForKey:[NSNumber numberWithInt:request.requestCondition.requestType]];
}

@end


























