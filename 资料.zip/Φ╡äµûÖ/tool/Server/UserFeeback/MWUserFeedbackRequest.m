//
//  MWUserFeedbackRequest.m
//  AutoNavi
//
//  Created by gaozhimin on 13-7-25.
//
//

#import "MWUserFeedbackRequest.h"
#import "JSONKit.h"
#import "NSObject+SBJSON.h"
#import "Account.h"
#import "NSString+Category.h"

//UserFeedback-----------------------------------------------------------------------------------------
//#define kUserFeedBackDomain              @"http://home.autonavi.com/"
#define kUserFeedBackDomain               @"http://106.3.73.3:8085/"
#define kUserFeedBackDataURL             @"api/eapi_dataError.do"        //数据问题
#define kUserFeedBackFuntionURL          @"api/eapi_funcError.do"        //功能问题
#define kUserFeedBackSuggestionURL       @"api/eapi_adviceError.do"      //建议问题
#define kUserFeedBackQueryDetailURL      @"api/eapi_queryOneFeedback.do" //查询详细回复信息
#define kUserFeedBackQueryListURL        @"api/eapi_queryFeedbackList.do"//查询回复信息列表
#define kUserFeedBackDeleteURL           @"api/eapi_deleteOneFeedback.do"//删除一条回复信息
#define kUserFeedBackUserName            @"feedback"                          //用户名
#define kUserFeedBackPassword            @"fdb123bdf"                         //密码

static MWUserFeedbackRequest *instance = nil;

@implementation MWUserFeedbackRequest

+(MWUserFeedbackRequest *)sharedInstance
{
    if (instance == nil)
    {
        instance = [[MWUserFeedbackRequest alloc] init];
    }
    return instance;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        _viewControllerDic = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (void)dealloc
{
    [_viewControllerDic release];
    _viewControllerDic = nil;
    [super dealloc];
}

#pragma mark - public method

- (BOOL)Net_FeedbackDataProblem:(MWFeedbackDataCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate
{

    NSString *cityName;
    NSString *cityAdminCode;
    [[ANDataSource sharedInstance] GMD_GetCurrentCityName:&cityName adminCode:&cityAdminCode];
    condition.cityName = cityName;
    condition.cityCode = cityAdminCode;
    int mDeviceModel = 0;
    if (isiPhone)
        mDeviceModel = 2;
    else
        mDeviceModel = 1;
    NSMutableDictionary *postParam = [[NSMutableDictionary alloc] init];
    
    [postParam setObject:[kUserFeedBackUserName stringFromMD5] forKey:@"userName"];
    [postParam setObject:[kUserFeedBackPassword stringFromMD5] forKey:@"password"];
    [postParam setObject:[NSNumber numberWithInt:mDeviceModel] forKey:@"deviceModel"];
    [postParam setObject:[NSString stringWithFormat:@"%.2f",IOS_VERSION] forKey:@"systemVersion"];
    [postParam setObject:[NSString stringWithFormat:@"%.2f",SOFTVERSIONNUM] forKey:@"softVersion"];
    [postParam setObject:[NSNumber numberWithInt:[[ANDataSource sharedInstance] GMD_GetDataVersion]] forKey:@"dataVersion"];
    [postParam setObject:[NSNumber numberWithInt:IsSteal] forKey:@"isSteal"];
    if ([deviceID length] > 0) {
        [postParam setObject:deviceID forKey:@"mac"];
    }
    if ([deviceTokenEx length] > 0) {
        [postParam setObject:deviceTokenEx forKey:@"token"];
    }
    
    
    [postParam setObject:[NSNumber numberWithInt:condition.dataType] forKey:@"dataType"];
    if ([condition.cityCode length] > 0) {
        [postParam setObject:condition.cityCode forKey:@"cityCode"];
    }
    if ([condition.qq length] > 0) {
        [postParam setObject:condition.qq forKey:@"qq"];
    }
    if ([condition.tel length] > 0) {
        [postParam setObject:condition.tel forKey:@"tel"];
    }
    if ([condition.errorType length] > 0) {
        [postParam setObject:condition.errorType forKey:@"errorType"];
    }
    if ([condition.cityName length] > 0) {
        [postParam setObject:condition.cityName forKey:@"cityName"];
    }
    if ([condition.name length] > 0 ) {
        [postParam setObject:condition.name forKey:@"name"];
    }
    if ([condition.errorDesc length] > 0) {
        [postParam setObject:condition.errorDesc forKey:@"errorDesc"];
    }
    
    
    
    NSData *bodyData = [[NSData alloc] initWithData:[[NetExt sharedInstance] DictionaryToJSON:postParam ImageEncode:IE_Base64]];
    [postParam release];
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = [kUserFeedBackDomain stringByAppendingString:kUserFeedBackDataURL];
    net_condition.bodyData = bodyData;
    net_condition.httpMethod = @"POST";
    
    [_viewControllerDic setObject:delegate forKey:[NSNumber numberWithInt:type]]; 
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:self];
    [bodyData release];
    return YES;
}

- (BOOL)Net_FeedbackFunctionProblem:(MWFeedbackFunctionCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate
{
    
    NSString *cityName;
    NSString *cityAdminCode;
    [[ANDataSource sharedInstance] GMD_GetCurrentCityName:&cityName adminCode:&cityAdminCode];
    int mDeviceModel = 0;
    if (isiPhone)
        mDeviceModel = 2;
    else
        mDeviceModel = 1;
    NSMutableDictionary *postParam = [[NSMutableDictionary alloc] init];
    
    [postParam setObject:[kUserFeedBackUserName stringFromMD5] forKey:@"userName"];
    [postParam setObject:[kUserFeedBackPassword stringFromMD5] forKey:@"password"];
    [postParam setObject:[NSNumber numberWithInt:mDeviceModel] forKey:@"deviceModel"];
    [postParam setObject:[NSString stringWithFormat:@"%.2f",IOS_VERSION] forKey:@"systemVersion"];
    [postParam setObject:[NSString stringWithFormat:@"%.2f",SOFTVERSIONNUM] forKey:@"softVersion"];
    [postParam setObject:[NSNumber numberWithInt:[[ANDataSource sharedInstance] GMD_GetDataVersion]] forKey:@"dataVersion"];
    [postParam setObject:[NSNumber numberWithInt:IsSteal] forKey:@"isSteal"];
    if ([deviceID length] > 0) {
        [postParam setObject:deviceID forKey:@"mac"];
    }
    if ([deviceTokenEx length] > 0) {
        [postParam setObject:deviceTokenEx forKey:@"token"];
    }
    
    
    [postParam setObject:[NSNumber numberWithInt:condition.questionType] forKey:@"questionType"];
    if ([condition.qq length] > 0) {
        [postParam setObject:condition.qq forKey:@"qq"];
    }
    if ([condition.tel length] > 0) {
        [postParam setObject:condition.tel forKey:@"tel"];
    }
    if ([condition.errorDesc length] > 0) {
        [postParam setObject:condition.errorDesc forKey:@"errorDesc"];
    }
    if (condition.pic) {
        [postParam setObject:condition.pic forKey:@"pic"];
    }
    
    NSData *bodyData = [[NSData alloc] initWithData:[[NetExt sharedInstance] DictionaryToJSON:postParam ImageEncode:IE_Base64]];
    [postParam release];
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = [kUserFeedBackDomain stringByAppendingString:kUserFeedBackFuntionURL];
    net_condition.bodyData = bodyData;
    net_condition.httpMethod = @"POST";
    
    [_viewControllerDic setObject:delegate forKey:[NSNumber numberWithInt:type]];
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:self];
     [bodyData release];
    return YES;
}

- (BOOL)Net_FeedbackAdviceProblem:(MWFeedbackAdviceCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate
{
    NSString *cityName;
    NSString *cityAdminCode;
    [[ANDataSource sharedInstance] GMD_GetCurrentCityName:&cityName adminCode:&cityAdminCode];
    int mDeviceModel = 0;
    if (isiPhone) 
        mDeviceModel = 2;
    else
        mDeviceModel = 1;
    NSMutableDictionary *postParam = [[NSMutableDictionary alloc] init];
    
    [postParam setObject:[kUserFeedBackUserName stringFromMD5] forKey:@"userName"];
    [postParam setObject:[kUserFeedBackPassword stringFromMD5] forKey:@"password"];
    [postParam setObject:[NSNumber numberWithInt:mDeviceModel] forKey:@"deviceModel"];
    [postParam setObject:[NSString stringWithFormat:@"%.2f",IOS_VERSION] forKey:@"systemVersion"];
    [postParam setObject:[NSString stringWithFormat:@"%.2f",SOFTVERSIONNUM] forKey:@"softVersion"];
    [postParam setObject:[NSNumber numberWithInt:[[ANDataSource sharedInstance] GMD_GetDataVersion]] forKey:@"dataVersion"];
    [postParam setObject:[NSNumber numberWithInt:IsSteal] forKey:@"isSteal"];
    if ([deviceID length] > 0) {
        [postParam setObject:deviceID forKey:@"mac"];
    }
    if ([deviceTokenEx length] > 0) {
        [postParam setObject:deviceTokenEx forKey:@"token"];
    }
    
    
    if ([condition.qq length] > 0) {
        [postParam setObject:condition.qq forKey:@"qq"];
    }
    if ([condition.tel length] > 0) {
        [postParam setObject:condition.tel forKey:@"tel"];
    }
    if ([condition.errorDesc length] > 0) {
        [postParam setObject:condition.errorDesc forKey:@"errorDesc"];
    }
    if (condition.pic) {
        [postParam setObject:condition.pic forKey:@"pic"];
    }
    
    NSData *bodyData = [[NSData alloc] initWithData:[[NetExt sharedInstance] DictionaryToJSON:postParam ImageEncode:IE_Base64]];
    [postParam release];
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = [kUserFeedBackDomain stringByAppendingString:kUserFeedBackSuggestionURL];
    net_condition.bodyData = bodyData;
    net_condition.httpMethod = @"POST";
    
    [_viewControllerDic setObject:delegate forKey:[NSNumber numberWithInt:type]];
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:self];
     [bodyData release];
    return YES;
}


- (BOOL)Net_FeedbackQueryList:(MWFeedbackQueryListCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate
{
    NSMutableDictionary *postParam = [[NSMutableDictionary alloc] init];
    
    [postParam setObject:[kUserFeedBackUserName stringFromMD5] forKey:@"userName"];
    [postParam setObject:[kUserFeedBackPassword stringFromMD5] forKey:@"password"];
    

    if ([deviceID length] > 0) {
        [postParam setObject:deviceID forKey:@"mac"];
    }
    if ([deviceTokenEx length] > 0) {
        [postParam setObject:deviceTokenEx forKey:@"token"];
    }
    NSData *bodyData = [[NSData alloc] initWithData:[[NetExt sharedInstance] DictionaryToJSON:postParam ImageEncode:IE_Base64]];
    [postParam release];
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = [kUserFeedBackDomain stringByAppendingString:kUserFeedBackQueryListURL];
    net_condition.bodyData = bodyData;
    net_condition.httpMethod = @"POST";
    
    [_viewControllerDic setObject:delegate forKey:[NSNumber numberWithInt:type]];
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:self];
     [bodyData release];
    return YES;
}


- (BOOL)Net_FeedbackQueryDetail:(MWFeedbackQueryDetailCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate
{
    NSMutableDictionary *postParam = [[NSMutableDictionary alloc] init];
    
    [postParam setObject:[kUserFeedBackUserName stringFromMD5] forKey:@"userName"];
    [postParam setObject:[kUserFeedBackPassword stringFromMD5] forKey:@"password"];
    
    [postParam setObject:condition.answerId forKey:@"answerId"];
    [postParam setObject:[NSNumber numberWithInt:condition.funcType] forKey:@"funcType"];
    
    NSData *bodyData = [[NSData alloc] initWithData:[[NetExt sharedInstance] DictionaryToJSON:postParam ImageEncode:IE_Base64]];
    [postParam release];
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = [kUserFeedBackDomain stringByAppendingString:kUserFeedBackQueryDetailURL];
    net_condition.bodyData = bodyData;
    net_condition.httpMethod = @"POST";
    
    [_viewControllerDic setObject:delegate forKey:[NSNumber numberWithInt:type]];
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:self];
     [bodyData release];
    return YES;
}


- (BOOL)Net_FeedbackDeleteOne:(MWFeedbackDeleteOneCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate
{
    NSMutableDictionary *postParam = [[NSMutableDictionary alloc] init];
    
    [postParam setObject:[kUserFeedBackUserName stringFromMD5] forKey:@"userName"];
    [postParam setObject:[kUserFeedBackPassword stringFromMD5] forKey:@"password"];
    
    [postParam setObject:condition.answerId forKey:@"answerId"];
    
    NSData *bodyData = [[NSData alloc] initWithData:[[NetExt sharedInstance] DictionaryToJSON:postParam ImageEncode:IE_Base64]];
    [postParam release];
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = [kUserFeedBackDomain stringByAppendingString:kUserFeedBackDeleteURL];
    net_condition.bodyData = bodyData;
    net_condition.httpMethod = @"POST";
    
    [_viewControllerDic setObject:delegate forKey:[NSNumber numberWithInt:type]];
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:self];
    [bodyData release];
    return YES;
}
//取消所有请求
- (BOOL)Net_CancelAllRequest
{
    if ([[NetExt sharedInstance] cancelAllRequests])
    {
        [_viewControllerDic removeAllObjects];
        return YES;
    }
    return NO;
}
//取消某个类型的请求
- (BOOL)Net_CancelRequestWithType:(RequestType)requestType
{
    if ([[NetExt sharedInstance] Net_CancelRequestWithType:requestType])
    {
        [_viewControllerDic removeObjectForKey:[NSNumber numberWithInt:requestType]];
        return YES;
    }
    return NO;
}
#pragma mark - NetRequestExtDelegate callback


- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error
{
    [self failedWithError:error withRequestType:request.requestCondition.requestType];
}
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data{
    
    [self handleResponseData:data withRequestType:request.requestCondition.requestType];
}

#pragma mark private methods

- (void)handleResponseData:(NSData *)data withRequestType:(RequestType) type
{
    NSError *error = nil;
    
	id result = [self parseJSONData:data error:&error];
	NSString *jsonStr1 = [result JSONRepresentation]; //将字典转化为json
    NSLog(@"json1=%@",jsonStr1);
    
    id<NetReqToViewCtrDelegate> delegate = [_viewControllerDic objectForKey:[NSNumber numberWithInt:type]];
    if(error != nil)
    {
        [self failedWithError:error withRequestType:type];
    }
    else 
    {
        if ([delegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFinishLoadingWithResult:)])
        {
            [delegate requestToViewCtrWithRequestType:type didFinishLoadingWithResult:result];
        }
    }
    [_viewControllerDic removeObjectForKey:[NSNumber numberWithInt:type]];
}

- (id)errorWithCode:(NSInteger)code userInfo:(NSDictionary *)userInfo
{
    return [NSError errorWithDomain:kUserFeedbackErrorDomain code:code userInfo:userInfo];
}
- (void)failedWithError:(NSError *)error withRequestType:(RequestType) type
{
    id<NetReqToViewCtrDelegate> delegate = [_viewControllerDic objectForKey:[NSNumber numberWithInt:type]];
    
    if ([delegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFailWithError:)]) {
        [delegate requestToViewCtrWithRequestType:type didFailWithError:error];
    }
    [_viewControllerDic removeObjectForKey:[NSNumber numberWithInt:type]];
}


- (id)parseJSONData:(NSData *)data error:(NSError **)error
{
    NSError *parseError = nil;
	id result =[data objectFromJSONDataWithParseOptions:JKParseOptionStrict error:&parseError];
	
	if (parseError && (error != nil))
    {
        *error = parseError;
	}
	
	return result;
}

@end
