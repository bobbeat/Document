//
//  MWUserFeedbackRequest.h
//  AutoNavi
//
//  Created by gaozhimin on 13-7-25.
//
//

#import <Foundation/Foundation.h>
#import "NetKit.h"
#import "MWFeedbackRequestCondition.h"

/*!
  @brief 根据当前地图视图frame的大小调整region范围
  @param region 要调整的经纬度范围
  @param region 要调整的经纬度范围
  @return 调整后的经纬度范围
  */

#define kUserFeedbackErrorDomain            @"UserFeedbackErrorDomain" //用户反馈模块的错误码

@interface MWUserFeedbackRequest : NSObject<NetRequestExtDelegate>
{
@private
    NSMutableDictionary             *_viewControllerDic;
}


+ (MWUserFeedbackRequest *)sharedInstance;

/*!
  @brief 上传数据问题反馈请求
  @param condition 请求的条件
  @param delegate 回调委托
  @return 成功返回YES
  */

- (BOOL)Net_FeedbackDataProblem:(MWFeedbackDataCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate;

/*!
  @brief 上传功能问题反馈请求
  @param condition 请求的条件
  @param delegate 回调委托
  @return 成功返回YES
  */
- (BOOL)Net_FeedbackFunctionProblem:(MWFeedbackFunctionCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate;

/*!
  @brief 上传建议反馈请求
  @param condition 请求的条件
  @param delegate 回调委托
  @return 成功返回YES
  */
- (BOOL)Net_FeedbackAdviceProblem:(MWFeedbackAdviceCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate;

/*!
  @brief 查询回复列表信息请求
  @param condition 请求的条件
  @param delegate 回调委托
  @return 成功返回YES
  */
- (BOOL)Net_FeedbackQueryList:(MWFeedbackQueryListCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate;

/*!
  @brief 查询详细回复信息请求
  @param condition 请求的条件
  @param delegate 回调委托
  @return 成功返回YES
  */
- (BOOL)Net_FeedbackQueryDetail:(MWFeedbackQueryDetailCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate;

/*!
  @brief 删除回复信息请求
  @param condition 请求的条件
  @param delegate 回调委托
  @return 成功返回YES
  */
- (BOOL)Net_FeedbackDeleteOne:(MWFeedbackDeleteOneCondition *)condition requestType:(RequestType)type delegate:(id<NetReqToViewCtrDelegate>)delegate;
/*!
  @brief 取消所有请求
  @return 成功返回YES
  */
- (BOOL)Net_CancelAllRequest;

/*!
  @brief 取消某个类型的请求
  @return 成功返回YES
  */
- (BOOL)Net_CancelRequestWithType:(RequestType)requestType;
@end
