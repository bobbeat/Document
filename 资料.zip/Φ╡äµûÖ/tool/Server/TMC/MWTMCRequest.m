//
//  MWTMCRequest.m
//  AutoNavi
//
//  Created by yu.liao on 13-9-13.
//
//

#import "MWTMCRequest.h"
#import "GDMID_Interface.h"
#import "NetKit.h"

static MWTMCRequest *instance = nil;

#define kTMCDomain @"http://trafficinfo.tinfochina.com:80"
#define kRefreshRate  60.0

@interface MWTMCRequest()
{
    int reqFlag;//0:登录 1:全量更新 2:增量更新
    
    NSTimer *refreshTimer;
}

@end

@implementation MWTMCRequest

@synthesize delegate,adminCode;
@synthesize isTMCOn;

+ (MWTMCRequest *)sharedInstance
{
    if (instance == nil)
	{
		instance = [[MWTMCRequest alloc] init];
	}
	return instance;
}

-(void)releaseInstance
{
      [self paramRelease];
//    if (instance != nil)
//    {
//		[instance release];
//        instance = nil;
//    }
    
}

-(void)dealloc
{
   // [self paramRelease];
    
    [super dealloc];
}

/*!
  @brief 开启实时交通
  @return 成功返回YES
  */
- (BOOL)Net_OpenTMC
{
    int isShow = 1;
    GDMID_SetParam(G_MAP_SHOW_TMC, &isShow);
    self.isTMCOn = YES;
    GSTATUS ret =  GDMID_TMC_SelectCity(&adminCode);
    if (ret == GD_ERR_NO_DATA)
    {
         [self failedWithError:[self errorWithCode:NetErrorNOTMCData userInfo:nil] withRequestType:REQ_TMC];
        return NO;
    }
   
    
    [self logonRequest];
    return YES;
}

/*!
  @brief 关闭实时交通
  @return 成功返回YES
  */
- (BOOL)Net_CloseTMC
{
    [self releaseInstance];
    
     return YES;
}

/*!
  @brief 取消所有请求
  @return 成功返回YES
  */
- (BOOL)Net_CancelRequest
{
    if ([[NetExt sharedInstance] Net_CancelRequestWithType:REQ_TMC])
    {
        return YES;
    }
     return NO;
}


#pragma mark - NetRequestExtDelegate delegate

- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error
{
    [self failedWithError:error withRequestType:request.requestCondition.requestType];
}
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data{
    
    [self handleResponseData:data withRequestType:request.requestCondition.requestType];
}


#pragma mark private methods

- (void)handleResponseData:(NSData *)data withRequestType:(RequestType) type
{
    if (reqFlag == 0)
    {
        if(RT_HttpLogon_Parse((char *)[data bytes],[data length]) == 0)//登陆返回数据解析
        {
            [self failedWithError:[self errorWithCode:NetErrorServerAnalyseException userInfo:nil] withRequestType:type];
            return;
        }
        else
        {
            reqFlag= 1;
            [self downloadRequest:0];
        }
    }
    else if(reqFlag == 1)
    {
        if(RT_HttpRoadInfo_Parse((char *)[data bytes],[data length]) == 0)//解析已接收报文
        {
            NSLog(@"%d",RT_HttpGetErrorCode());
            [self failedWithError:[self errorWithCode:NetErrorServerAnalyseException userInfo:nil] withRequestType:type];
            return;
        }
        
        EventContentEx_RT *pEventContent;
        EventContentEx_RT *pTrafficContent;
        int eventCount = RT_HttpGetRoadInfo(&pEventContent);

        GDMID_TMC_Update(pEventContent, eventCount);
        
        int trafficCount  = RT_HttpGetEventInfo(&pTrafficContent);
        GDMID_TMC_Update(pTrafficContent, trafficCount);
        
        reqFlag= 2;
       
        refreshTimer = [NSTimer scheduledTimerWithTimeInterval:kRefreshRate target:self selector:@selector(repeatRequest)
                                                          userInfo: nil repeats: YES];
        self.isTMCOn = YES;
        if ([delegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFinishLoadingWithResult:)])
        {
            [delegate requestToViewCtrWithRequestType:type didFinishLoadingWithResult:nil];
        }

    }
     else if(reqFlag == 2)
     {
         if(RT_HttpRoadInfo_Parse((char *)[data bytes],[data length]) == 0)//解析已接收报文
         {
             NSLog(@"%d",RT_HttpGetErrorCode());
             if (RT_HttpGetErrorCode() != 1020)
             {
                 [self failedWithError:[self errorWithCode:NetErrorServerAnalyseException userInfo:nil] withRequestType:type];
             }
             return;
         }
         
         EventContentEx_RT *pEventContent;
         EventContentEx_RT *pTrafficContent;
         
         int eventCount = RT_HttpGetRoadInfo(&pEventContent);
         GDMID_TMC_Update(pEventContent, eventCount);
         
         int trafficCount  = RT_HttpGetEventInfo(&pTrafficContent);
         GDMID_TMC_Update(pTrafficContent, trafficCount);
         
         self.isTMCOn = YES;
         
         if ([delegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFinishLoadingWithResult:)])
         {
             [delegate requestToViewCtrWithRequestType:type didFinishLoadingWithResult:nil];
         }

     }
}

- (id)errorWithCode:(NSInteger)code userInfo:(NSDictionary *)userInfo
{
    return [NSError errorWithDomain:kTMCErrorDomain code:code userInfo:userInfo];
}
- (void)failedWithError:(NSError *)error withRequestType:(RequestType) type
{

    if ([error.domain isEqualToString: KNetResponseErrorDomain]) {
        error = [self errorWithCode:NetErrorServerCrash userInfo:nil];
    }
    self.isTMCOn = NO;

    if ([delegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFailWithError:)]) {
        [delegate requestToViewCtrWithRequestType:type didFailWithError:error];
    }
   [self releaseInstance];
}

-(void)logonRequest
{
    RT_HttpParse_Init();//初始化数据
    RT_Logon logon;
    
    memset(logon.szProvider, 0x0, 32);
    memset(logon.szUserID,0x0,32);
    memset(logon.szSID, 0x0, 32);
    memset(logon.szPwd, 0x0, 32);
    
    memcpy(logon.szProvider, "iphone", 6);// 厂商ID
    memcpy(logon.szUserID, "stgufy", 6);// 用户ID
    memcpy(logon.szSID,[VendorID UTF8String],31);// 机器唯一码
    memcpy(logon.szPwd, "thufiro", 7);// 厂商密码
    
    char szUrl[256] = {0};
    int tmpValue = RT_HttpLogon_CombURL(logon,szUrl);//实时交通登陆请求(只需登录一次)
    if (tmpValue == 0)
    {
        [self failedWithError:[self errorWithCode:NetErrorServerAnalyseException userInfo:nil] withRequestType:REQ_TMC];
         return;
    }
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = REQ_TMC;
    net_condition.baceURL = [kTMCDomain stringByAppendingString:[NSString stringWithFormat:@"%s",szUrl]];
    net_condition.httpMethod = @"GET";
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:self];
}

-(void)downloadRequest:(int)dataMode
{
    char szUrl[256] = {0};
    memset(szUrl,0x0,256);
    RT_DataReq dataReq;
    dataReq.nCityCode = adminCode;
    dataReq.nMode = dataMode;/* 获取方式：0:全量包(第一次下载数据) 1:增量包(刷新) */
    int tmpValue = RT_HttpGetRTData_CombURL(dataReq,szUrl);//实时交通数据请求(每次获取TMC数据，都要调用)
    if (tmpValue == 0)
    {
        [self failedWithError:[self errorWithCode:NetErrorServerAnalyseException userInfo:nil] withRequestType:REQ_TMC];
        return;
    }
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = REQ_TMC;
    net_condition.baceURL = [kTMCDomain stringByAppendingString:[NSString stringWithFormat:@"%s",szUrl]];
    net_condition.httpMethod = @"GET";
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:self];
}

-(void)repeatRequest
{
    [self downloadRequest:1];
}

-(void)paramRelease
{
    self.isTMCOn = NO;
    int isShow = 0;
    GDMID_SetParam(G_MAP_SHOW_TMC, &isShow);
    
    GDMID_TMC_Close();
    
    int iCity = -1;
    GDMID_TMC_SelectCity(&iCity);
    
   
    
    RT_HttpParse_Release();
    
    if ([refreshTimer isValid])
    {
        [refreshTimer invalidate];
        refreshTimer= nil;
    }
    reqFlag = 0;
    if ([delegate respondsToSelector:@selector(requestToViewCtrWithRequestType:didFinishLoadingWithResult:)])
    {
        [delegate requestToViewCtrWithRequestType:REQ_TMC didFinishLoadingWithResult:nil];
    }
     self.delegate = nil;
}

- (void)setTMCState:(BOOL)state
{
    isTMCOn = state;
    BOOL tmcState = state;
    GDBL_SetParamExt(TMC_STATE, &tmcState);
}
@end
