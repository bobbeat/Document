//
//  MWTMCRequest.h
//  AutoNavi
//
//  Created by yu.liao on 13-9-13.
//
//

#import <Foundation/Foundation.h>

#define kTMCErrorDomain            @"TMCErrorDomain" //实时交通错误码

@interface MWTMCRequest : NSObject<NetRequestExtDelegate>

+ (MWTMCRequest *)sharedInstance;

@property (nonatomic,assign) id<NetReqToViewCtrDelegate> delegate;

/*需开启实时交通城市的行政编码*/
@property(nonatomic,assign) Gint32 adminCode;

@property (nonatomic,assign,setter = setTMCState:) BOOL isTMCOn;


/*!
  @brief 开启实时交通
  @return 成功返回YES
  */
- (BOOL)Net_OpenTMC;

/*!
  @brief 关闭实时交通
  @return 成功返回YES
  */
- (BOOL)Net_CloseTMC;

/*!
  @brief 取消所有请求
  @return 成功返回YES
  */
- (BOOL)Net_CancelRequest;

@end
