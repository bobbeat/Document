//
//  RoadInfo.m
//  AutoNavi
//
//  Created by liyuhang on 13-1-16.
//
//

#import "CustomRoadInfo.h"

@implementation MainRoadInfo
@synthesize psszDistance = m_szDistance;
@synthesize psszRoadName = m_szRoadName;
@synthesize psszNextRoadName = m_szNextRoadName;
@synthesize psarraySubRoadInfo = m_arraySubRoadInfo;
@synthesize psnDirectID = m_nDirectID;
@synthesize psnCountOfSubRoadInfo = m_nCountOfSubRoadInfo;
@synthesize psnTrafficStatus = m_nTrafficStatus;
@synthesize psbCarOnTheRoad = m_bCarOnTheRoad;
@synthesize psbShowSubRoadInfo = m_bShowSubRoadInfo;
@synthesize psimgView = m_imgView;
@synthesize psnIndexInRoadList = m_nIndexInRoadList;
@synthesize psbSetDetour = m_bSetDetour;
@synthesize psbEvent = m_bEvent;
@synthesize psszEventDetail = m_szEventDetail;
@synthesize psnEventState = m_nEventState;
@synthesize psszEventName = m_szEventName;

-(void)dealloc
{
    if (m_szEventName) {
        [m_szEventName release];
        m_szEventName = nil;
    }
    if (m_szEventDetail) {
        [m_szEventDetail release];
        m_szEventDetail = nil;
    }

    if (m_szRoadName) {
        [m_szRoadName release];
        m_szRoadName = nil;
    }
    if (m_szNextRoadName) {
        [m_szNextRoadName release];
        m_szNextRoadName = nil;
    }
    if (m_arraySubRoadInfo) {
        [m_arraySubRoadInfo release];
        m_arraySubRoadInfo = nil;
    }
    if (m_imgView) {
        [m_imgView release];
        m_imgView = nil;
    }
    [super dealloc];
}
@end

@implementation SubRoadInfo
@synthesize psszDistance = m_szDistance;
@synthesize psszRoadName = m_szRoadName;
@synthesize psnDirectID = m_nDirectID;
@synthesize psnTrafficStatus = m_nTrafficStatus;
@synthesize psbCarOnTheRoad = m_bCarOnTheRoad;
@synthesize psnIndexInRoadList = m_nIndexInRoadList;
@synthesize psbSetDetour = m_bSetDetour;

-(void)dealloc
{
    if (m_szRoadName) {
        [m_szRoadName release];
        m_szRoadName = nil;
    }
    if (m_szDistance) {
        [m_szDistance release];
        m_szDistance = nil;
    }
    [super dealloc];
}
@end
