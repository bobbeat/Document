//
//  RoadInfo.h
//  AutoNavi
//
//  Created by liyuhang on 13-1-16.
//
//

#import <Foundation/Foundation.h>
#import "CustomClassForRoadList.h"
// 主要道路
@interface MainRoadInfo : NSObject
{
    NSString *m_szDistance;
    NSString *m_szRoadName;
    NSString *m_szNextRoadName;
    int       m_nDirectID;
    int       m_nCountOfSubRoadInfo;
    int       m_nTrafficStatus;
    int       m_nEventState;
    NSMutableArray*  m_arraySubRoadInfo;
    BOOL      m_bCarOnTheRoad;
    BOOL      m_bShowSubRoadInfo;
    //
    CustomHeaderForRoadList* m_imgView;
    //
    int       m_nIndexInRoadList;
    BOOL      m_bSetDetour;
    BOOL      m_bEvent;
    NSString *m_szEventDetail;
    NSString *m_szEventName;
    
}
@property (nonatomic, copy) NSString *psszDistance;
@property (nonatomic, copy) NSString *psszRoadName;
@property (nonatomic, copy) NSString *psszNextRoadName;
@property (nonatomic, assign) int psnDirectID;
@property (nonatomic, assign) int psnCountOfSubRoadInfo;
@property (nonatomic, assign) int psnTrafficStatus;
@property (nonatomic, assign) int psnEventState;
@property (nonatomic, retain) NSMutableArray* psarraySubRoadInfo;
@property (nonatomic, assign) BOOL psbCarOnTheRoad;
@property (nonatomic, assign) BOOL psbShowSubRoadInfo;
@property (nonatomic, retain) CustomHeaderForRoadList* psimgView;
@property (nonatomic, assign) int  psnIndexInRoadList;
@property (nonatomic, assign) BOOL psbSetDetour;
@property (nonatomic, assign) BOOL psbEvent;
@property (nonatomic, copy)   NSString *psszEventDetail;
@property (nonatomic, copy)   NSString *psszEventName;

@end


// 详细道路
@interface SubRoadInfo : NSObject
{
    NSString* m_szDistance;
    NSString* m_szRoadName;
    int       m_nDirectID;
    int       m_nTrafficStatus;
    BOOL      m_bCarOnTheRoad;
    int       m_nIndexInRoadList;
    BOOL      m_bSetDetour;
}
@property (nonatomic, copy) NSString* psszDistance;
@property (nonatomic, copy) NSString* psszRoadName;
@property (nonatomic, assign) int psnDirectID;
@property (nonatomic, assign) int psnTrafficStatus;
@property (nonatomic, assign) BOOL psbCarOnTheRoad;
@property (nonatomic, assign) int  psnIndexInRoadList;
@property (nonatomic, assign) BOOL psbSetDetour;
@end