//
//  GDBL_DataVerify.m
//  plugin_DataVerify
//
//  Created by Autonavi on 12-5-4.
//  Copyright 2012 autonavi.com. All rights reserved.
//

#import "GDBL_DataVerify.h"

static GDBL_DataVerify* instance = nil;

@implementation GDBL_DataVerify

+(GDBL_DataVerify *)sharedInstance
{
    @synchronized(self)
    {
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    }
    return instance;
}

GSTATUS GDBL_CheckData()
{
	DataVerify *dataVerify = [[[DataVerify alloc] init] autorelease];
	DATAVERIFYRESULT nResult = [dataVerify runCheckData];
	if (nResult == CHECK_SUCCESS)
	{
		return GD_ER_OK;
	}
	if (nResult == WILL_DELETE_MAPDATA)
	{
		return GD_ER_MAPVERLOWER;
	}
	else if (nResult == NEED_UPDATE_NAVIVER)
	{
		return GD_ER_NAVIVERLOWER;
	}
	else if (nResult == DATA_NOT_COMPLETE)
	{
		return GD_ER_DATAIMCOMPLETE;
	}
	else if (nResult == UNCOMPRESS_CITYS_ZLIB)
	{
		return GD_ER_DATAUNCOMPRESS;
	}
	else if (nResult == BASE_ROAD_DATA_NOT_COMPLETE)
	{
		return GD_ER_BASELOADIMCOMPLETE;
	}
	else if (nResult == BASE_ROAD_DATA_DOWNLAODING)
	{
		return GD_ER_BASELOADDOWNLOADING;
	}
	else if (nResult == BASE_ROAD_DATA_NOT_EXIST)
	{
		return GD_ER_BASELOADNOTEXIST;
	}
    else if (nResult == GRESOURSE_NOMATCH)
	{
		return GD_ER_GRESOURSENOMATCH;
	}
    else if (nResult == SKIN_NOMATCH)
    {
        return GD_ER_SKINNOMATH;
    }
    else if (nResult == GRESOURCEANDSKIN_NOMATCH)
    {
        return GD_ER_GRESOURCEANDSKINNOMATCH;
    }
	else
	{
		return GD_ER_FAILED;
	}

}

GSTATUS GDBL_GetDataZlibs(NSArray **dataZlibs)
{
	DataVerify *dataVerify = [[[DataVerify alloc] init] autorelease];
	if ([dataVerify checkZlibOfCitysExist])
	{
		*dataZlibs = [[dataVerify.zlibCitysList retain] autorelease];
		return GD_ERR_OK;
	}
	else
	{
		*dataZlibs = nil;
		return GD_ERR_FAILED;
	}
}

void GDBL_EntryNaviApp()
{
	DataVerify *dataVerify = [[[DataVerify alloc] init] autorelease];
	[dataVerify handlerEntryNaviApp];
}

-(void)dealloc
{
    
    [super dealloc];
}
@end
