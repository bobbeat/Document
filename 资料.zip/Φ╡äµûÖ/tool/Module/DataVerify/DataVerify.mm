//
//  DataVerify.mm
//  New_GNaviServer
//
//  Created by yang yi on 12-3-31.
//  Copyright 2012 autonavi.com. All rights reserved.
//
#import "GDBL_Interface.h"
#import "DataVerify.h"
#import "GDBL_DataVerify.h"
#import "GDSkinColor.h"
#import "MWSkinDownloadManager.h"

#define g_data_path1 (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)?([UIScreen instancesRespondToSelector:@selector(scale)] ? (([[UIScreen mainScreen] scale] == 2.0)?(([[UIScreen mainScreen] currentMode].size.height == 960)?[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPhone4/"]  UTF8String]:[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPhone5/"]  UTF8String]):[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPhone3/"]  UTF8String]) : [[NSHomeDirectory() stringByAppendingString:@"/Documents/iPhone3/"]  UTF8String]):([UIScreen instancesRespondToSelector:@selector(scale)] ? (([[UIScreen mainScreen] scale] == 2.0)?[[NSHomeDirectory() stringByAppendingString:@"/Documents/NewiPad/"]  UTF8String]:[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPad/"]  UTF8String]) : [[NSHomeDirectory() stringByAppendingString:@"/Documents/iPad/"]  UTF8String])

@implementation DataVerify
@synthesize zlibCitysList;

static int unZip = 0;

-(id)init
{
	if (self = [super init])
	{
        documentsDirectory =[[NSString alloc] initWithFormat:@"%@",[NSHomeDirectory() stringByAppendingFormat:@"/Documents/GPS/"]];
       
    }
	return self;
}

 /**检测数据版本主流程*/
-(int) runCheckData
{
	dataVerifyResult = CHECK_SUCCESS;
    while (!isCheckFinish)
	{
        //检测是否有压缩文件存在
		isZlibOfCitysExist = [self checkZlibOfCitysExist];
		if (isZlibOfCitysExist)
		{
            unZip = 1;
			dataVerifyResult = UNCOMPRESS_CITYS_ZLIB;
			break;
		}
        
        //检测是否有一体化数据
        isIntegrativeDataExist = [self checkIntegrativeDataExist];
        if (isIntegrativeDataExist) 
        {
            //检测一体化数据是否完整
            isDataIntegrated = [self checkDataIntegrated];
            if (isDataIntegrated) 
            {
				
				//验证引擎版本是否与地图版本匹配
				compareEngineWithMapVersion=[self checkEngineWithMapVersion:YES];
                if (compareEngineWithMapVersion == GVERSION_SAME)
                {
                    isGresourseValid = [self checkGresourseValid];
                    if (CHECK_SUCCESS == isGresourseValid) {
                        [mapDataManage setMapDataType:self dataType:1];
                        //匹配，进入导航程序
                        [self handlerEntryNaviApp];
                        //dataVerifyResult = CHECK_SUCCESS;
                        //break;
                    }
                    else{
                        dataVerifyResult = isGresourseValid;
                        break;
                    }
                    
                }
                else
                {
					[mapDataManage setMapDataType:self dataType:0];//版本不匹配 modify 12-27
					//引擎版本低于地图版本
                    if (compareEngineWithMapVersion == GVERSION_NEWER) 
                    {
						dataVerifyResult = NEED_UPDATE_NAVIVER;
						break;
                        
                    }
					else//引擎版本高于地图版本
                    {
						dataVerifyResult = WILL_DELETE_MAPDATA;
						break;
                       
                    }
                }
            }
			else//地图数据不完整,验证引擎版本是否与地图版本匹配，匹配返回地图数据不完整，不匹配提示版本不匹配
            {
                //go to download new map data
                compareEngineWithMapVersion = [self checkEngineWithMapVersion:YES];
                if (compareEngineWithMapVersion == GVERSION_SAME)
                {
                    dataVerifyResult = DATA_NOT_COMPLETE;
                    break;
                }
				else
                {
                    [mapDataManage setMapDataType:self dataType:0];//版本不匹配 modify 12-27
					//引擎版本低于地图版本
                    if (compareEngineWithMapVersion == GVERSION_NEWER)
                    {
						dataVerifyResult = NEED_UPDATE_NAVIVER;
						break;
                        
                    }
					else//引擎版本高于地图版本
                    {
						dataVerifyResult = WILL_DELETE_MAPDATA;
						break;
                        
                    }
                }
				break;

            }
        }
		else
        {
            //检测是否有压缩文件存在
            isZlibOfCitysExist = [self checkZlibOfCitysExist];
            if (isZlibOfCitysExist)
            {
                
				dataVerifyResult = UNCOMPRESS_CITYS_ZLIB;
                break;
            }
			else
			{
                //检测基础数据文件夹是否存在
				BOOL isGPSExist = [self checkFileExist:documentsDirectory];
				if (isGPSExist==NO) 
				{
					dataVerifyResult = BASE_ROAD_DATA_NOT_EXIST;
					break;
				}
                //检测基础路网数据是否完整
                isBaseRoadDataExist = [self checkBaseRoadDataExist];
                if (isBaseRoadDataExist) 
                {
					
					//验证引擎版本是否与地图版本匹配
					compareEngineWithMapVersion=[self checkEngineWithMapVersion:NO];
                    if (compareEngineWithMapVersion == GVERSION_SAME)
                    {
                        isGresourseValid = [self checkGresourseValid];
                        if (CHECK_SUCCESS == isGresourseValid) {
                            [mapDataManage setMapDataType:self dataType:2];
                            //匹配，进入导航程序
                            [self handlerEntryNaviApp];
                            //dataVerifyResult = CHECK_SUCCESS;
                            //break;
                        }
                        else{
                            
                            dataVerifyResult = isGresourseValid;
                            break;
                        }

                    }
                    else
                    {
						[mapDataManage setMapDataType:self dataType:0];//版本不匹配 modify 12-27
                        //引擎版本低于地图版本
                        if (compareEngineWithMapVersion == GVERSION_NEWER) 
						{
							dataVerifyResult = NEED_UPDATE_NAVIVER;
							break;
						}
						else//引擎版本高于地图版本
						{
							dataVerifyResult = WILL_DELETE_MAPDATA;
							break;

						}
                    }
                }
				else
                {
                    //检测基础路网数据正在下载或不完整
                    BOOL isDownloading = [self checkBaseRoadDataAndDownload];
					if (isDownloading)
					{
						dataVerifyResult = BASE_ROAD_DATA_DOWNLAODING;
                        break;
					}
                    else//地图数据不完整,验证引擎版本是否与地图版本匹配，匹配返回地图数据不完整，不匹配提示版本不匹配
                    {
                        GVERSION pVersion = {0};
                        GDBL_GetMapVersion((char*)[mapDataManage getDataPath],&pVersion);
                        
                        if (strlen(pVersion.szVersion) > 0) {//能读取到数据版本号
                            compareEngineWithMapVersion = [self checkEngineWithMapVersion:NO];
                            if (compareEngineWithMapVersion == GVERSION_SAME)
                            {
                                dataVerifyResult = BASE_ROAD_DATA_NOT_COMPLETE;
                                break;
                            }
                            else
                            {
                                [mapDataManage setMapDataType:self dataType:0];//版本不匹配 modify 12-27
                                //引擎版本低于地图版本
                                if (compareEngineWithMapVersion == GVERSION_NEWER)
                                {
                                    dataVerifyResult = NEED_UPDATE_NAVIVER;
                                    break;
                                    
                                }
                                else//引擎版本高于地图版本
                                {
                                    dataVerifyResult = WILL_DELETE_MAPDATA;
                                    break;
                                    
                                }
                            }
                        }
                        else{
                            if (unZip) {
                                dataVerifyResult = BASE_ROAD_DATA_NOT_COMPLETE;
                            }
                            else{
                                dataVerifyResult = BASE_ROAD_DATA_NOT_EXIST;
                            }
                            
                            break;
                        }
                        //go to download new map data
                        
                    }
					

                }
            }
            
        }
        break;
    }
    return dataVerifyResult;
}

-(void)dealloc
{
    if (zlibCitysList) {
        [zlibCitysList release];
        zlibCitysList = nil;
    }
    [documentsDirectory release];
    [super dealloc];
}
#pragma mark public out 

/**进入导航程序*/
-(void) handlerEntryNaviApp
{    
	[[Global shareInstance] backToNavi:self ];
}

/**继续下载数据 0:第一次进入下载 1:未下载完成在次进入下载*/
-(void) handerContinuedownLoadState:(int)mapDownState
{
	[[Global shareInstance] enterCityDownload:self downState:mapDownState];
}

/**退出导航程序*/
-(void) handerQuitApplication
{
    [[Global shareInstance] quitApplication:self];
}

#pragma mark Private 供内部调用方法

/**检测基础路网数据是否正在下载并进入分城市数据下载*/
-(BOOL) checkBaseRoadDataAndDownload
{
    BOOL isBaseRoadDataDownloading =[self checkFileExist:[NSString stringWithFormat:@"%@%@.tmp",documentsDirectory,BASE_ROAD_DATA]];//判断基础路网数据是否下载中
	return isBaseRoadDataDownloading;
}

/**检测一体化数据是否(下载中)完整,若下载中继续数据下载*/
-(void) checkIntegratedDataAndDownload
{
    NSString* file=[NSString stringWithFormat:@"%@%@.tmp",documentsDirectory,INTEGRATE_DATA];
    BOOL isIntegrativeDataIsDownloading= [self checkFileExist:file];////判断一体化数据是否下载中
    if (!isIntegrativeDataIsDownloading)    
    {
        NSError *error;
        if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%s" ,[mapDataManage getIntegrateDataPath]]]) {
            [[NSFileManager defaultManager] removeItemAtPath:
             [NSString stringWithFormat:@"%s" ,[mapDataManage getIntegrateDataPath]] error:&error];
        }
        
        if (error==nil)
		{
            //delete data
        }
    }
    //continue download    
    [self handerContinuedownLoadState:isIntegrativeDataIsDownloading];
}

/**删除与基础路网不匹配的城市数据*/
-(void) deleteCityDataNotFitBaseRoadData
{
	
}

#pragma mark Private 供内部调用方法
/**加载一体化数据,为使用引擎函数做准备*/
-(BOOL) initIntegratedData
{
	return [mapDataManage initIntegratedData];
}

/**检测本地是否有一体化数据*/
-(BOOL) checkIntegrativeDataExist
{
    return [self checkFileExist:
			[NSString stringWithFormat:@"%s",[mapDataManage getIntegrateDataPath]]];
	
}
/**检测本地数据是否完整*/
-(BOOL) checkDataIntegrated
{
	
    NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *filePath = [NSString stringWithFormat:@"%s",[mapDataManage getIntegrateDataPath]];
	if([fileManager fileExistsAtPath:filePath])
	{
		FILE *fp = fopen([mapDataManage getIntegrateDataPath], "r");
		if(fp != NULL)
		{
            if (-1!=fseeko(fp, -8L, SEEK_END)) {//__DARWIN_C_LEVEL >= 200112L
                char data[9];
                memset(data, 0x0, 9);
                fread(data, 1, 9, fp);                
                fclose(fp);
                if (strcmp(data, "AutoNavi")==0) 
                {
                    return YES;
                }
				else
                {
                    return NO;
                }
            }
			else
            {
                fclose(fp);
                return NO;
            }
			
		}
		else 
		{
			return NO;
		}		
	}	
	return NO;    
}
/**验证本地是否有分城市压缩包*/
-(BOOL) checkZlibOfCitysExist
{
    if (zlibCitysList)
    {
        [zlibCitysList release];
        zlibCitysList = nil;
    }
	zlibCitysList= [[self searchFilesInPath:[NSHomeDirectory() stringByAppendingFormat:@"/Documents/"] MatchContent:@".gdzip"]retain];
    return [zlibCitysList count]>0?YES:NO;
}
/**验证本地是否有基础路网*/
-(BOOL) checkBaseRoadDataExist
{
    [self initIntegratedData];
    Gbool bAvailable = Gtrue;
	GDBL_IsGlobalDataAvailable((Gchar *)NSSTRING_TO_CSTRING(documentsDirectory),&bAvailable);
    if (bAvailable) {
        return YES;
    }
    return NO;
//	if ([self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,DBDATA_CHINA_DAT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,DBDATA_MAP_DAT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,DBDATA_ROUMESH_DAT]autorelease]]==YES&&
//		
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_ADCODE_DAT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_ALLIDX1_PDT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_ALLIDX2_PDT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_ALLIDX_PDT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_EXTADAREA_PDT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_GUIDEIDX0_DAT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_MAPIDX0_DAT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_MAPIDX1_DAT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_MAPIDX2_DAT]autorelease]]==YES&&
//		[self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_ROUIDX_DAT]autorelease]]==YES)
//	{   
//		if ([self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,IDX_ADCODE_DAT]autorelease]]==NO)
//		{
//			//engine check fail,check file exist instead
//			return NO;
//		}
//		
//		if (([self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,RES_3D_MARK16]autorelease]]==YES)&&
//			([self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,RES_3D_MARK32]autorelease]]==YES)&&
//			([self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,RES_LOGO16BMP]autorelease]]==YES)&&
//			([self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,RES_LOGO32BMP]autorelease]]==YES)&&
//			([self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,RES_WARN32]autorelease]]==YES)&&
//			([self checkFileExist:[[[NSString alloc] initWithFormat:@"%@%@",documentsDirectory,RES_WARN64]autorelease]]==YES))
//		{//res datas -- local method
//			
//			return YES;
//		}
//		else
//		{
//			return NO;
//		}
//	}
//	else
//	{//return by engine method
//		return NO;
//	}
}

/**验证引擎版本是否与地图版本匹配*/
-(int) checkEngineWithMapVersion:(BOOL)isIntegrateData
{
	GVERSION mapVer = {0};
	GVERSION engVer = {0};
	GVERCHECKRESULT nResult = GVERSION_SAME;
	//获取引擎版本
	GDBL_GetEngineVersion(&engVer);
	
	//获取地图版本
	if (isIntegrateData)	//一体化地图数据
	{
		GDBL_GetMapVersion((char*)[mapDataManage getIntegrateDataPath], &mapVer);
	}
	else	//分城市数据
	{
	GDBL_GetMapVersion((char*)[mapDataManage getDataPath], &mapVer);
	}

	//对比地图和引擎版本
	GDBL_EngineMapVerCompare(&engVer, &mapVer, &nResult);
	return nResult;
}

/**
 *获取目录下所有文件
 *rootPath:要查找的路径名称(尾部无需/),matchName:要匹配的结尾名称,nil或""则不验证匹配
 */
-(NSMutableArray*) searchFilesInPath:(NSString *)rootPath MatchContent:(NSString*)matchName
{
    NSFileManager *fileManager = [NSFileManager defaultManager];	
    if (fileManager==nil)
	{
        return nil;
    }
	//	NSLog(@"search files in path:%@,match text:%@",rootPath,matchName);
	NSError *error = nil;
	
	//fileList便是包含有该文件夹下所有文件的文件名及文件夹名的数组
	NSArray* fileList = [[NSArray alloc]initWithArray:[fileManager contentsOfDirectoryAtPath:rootPath error:&error]] ;
    
    //以下这段代码则可以列出给定一个文件夹里的所有子文件夹名
	NSMutableArray *fileArray = [[[NSMutableArray alloc] init] autorelease];
	signed char isDir = NO;
	//在上面那段程序中获得的fileList中列出文件名
	for (NSString *file in fileList) 
	{
		NSString *path = [rootPath stringByAppendingPathComponent:file];
		[fileManager fileExistsAtPath:path isDirectory:(&isDir)];
		if (isDir) 
		{
			//[dirArray addObject:file];文件夹
		}
		else 
		{
			//			[dirArray addObject:[file stringByDeletingPathExtension]];//去除扩展名，文件
            if (matchName!=nil&&[matchName length]>0)
            {
                //匹配文件名结尾的字符
                if ([file hasSuffix:matchName]==YES) 
                {
                    [fileArray addObject:path];
                }
            }
		}
        
		isDir = NO;
	}
	[fileList release];
    return fileArray;    
}

/**
 *检测文件是否存在
 *fileName:检测的文件名(完整路径)
 */
-(BOOL)checkFileExist:(NSString *)fileName
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:fileName])
	{
        FILE *fp = fopen([fileName UTF8String], "r");
        if(fp == NULL)
        {
            fclose(fp);
            return NO;
        }
        fclose(fp);
        return YES;
    }
    return NO;
}
#pragma mark Gresourse处理

- (DATAVERIFYRESULT)checkGresourseValid
{
    
    NSString *GResourseVersion; //本地资源版本号
    GVERSION m_GresourseVersion = {0};
    GSTATUS res;
    NSString *resoursePath = [NSString stringWithFormat:@"%s%@",g_data_path1,GresourcePath];
    res = GDBL_GetResourceVersion((Gchar *) NSSTRING_TO_CSTRING(resoursePath),&m_GresourseVersion);
    if (GD_ERR_OK == res) {
        GResourseVersion = [NSString stringWithFormat:@"%s",m_GresourseVersion.szVersion];
    }
    else
    {
        GResourseVersion = @"";
    }
    
    int skinType = 0;
    int skinCheckResult = 0;
    int gresourceCheckResult = 0;
    
    GDBL_GetParamExt(SKINTYPE, &skinType);
    GDBL_GetParamExt(SKIN_CHECKRESULT, &skinCheckResult);
    GDBL_GetParamExt(GRESOURCE_CHECKRESULT, &gresourceCheckResult);
    
    NSString *localSkinVersion = [[GDSkinColor sharedInstance] getSkinVersion] ?  [[GDSkinColor sharedInstance] getSkinVersion] : @"";//本地皮肤版本号
    NSString *tmpString = [[NSUserDefaults standardUserDefaults] objectForKey:PARAMGRESOURCEVERSIONKEY];//更新后都资源版本号
   
    
    NSString *skinVersion = [[MWSkinDownloadManager sharedInstance].updateVersionDictionary objectForKey:[NSNumber numberWithInt:skinType]];
    
    BOOL bUpdateGresource = (tmpString &&  ([tmpString length] > 0) &&  [tmpString isEqualToString:GResourseVersion]) ? NO : YES;
    BOOL bUpdateSkin = (( skinVersion && ([skinVersion length] > 0) && [skinVersion isEqualToString:localSkinVersion]) || 0 == skinType) ? NO : YES;
    
    if ( !bUpdateGresource && !bUpdateSkin)
    {//资源对比过，对比过的版本号和当前版本号相同
        return CHECK_SUCCESS;
    }
    else if (bUpdateGresource && !bUpdateSkin)
    {
        if(1 == gresourceCheckResult || 2 == gresourceCheckResult )//下载成功或者取消下载都返回程序
            return CHECK_SUCCESS;
        else
            return GRESOURSE_NOMATCH;
    }
    else if (bUpdateSkin && !bUpdateGresource){
        
        if(1 == skinCheckResult || 2 == skinCheckResult )//下载成功或者取消下载都返回程序
            return CHECK_SUCCESS;
        else
            return SKIN_NOMATCH;
    }
    else if (bUpdateGresource && bUpdateSkin)
    {
        if ((1 == skinCheckResult && 1 == gresourceCheckResult) || (2 == skinCheckResult) || (2 == gresourceCheckResult))
            return CHECK_SUCCESS;
        else
            return GRESOURCEANDSKIN_NOMATCH;
        
    }
    return CHECK_SUCCESS;
}
@end
