//
//  DataVerify.h
//  New_GNaviServer
//
//  Created by yang yi on 12-3-31.
//  Copyright 2012 autonavi.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "mapDataManage.h"
#define VERSION_URL @"http://iphone.autonavi.com/version"
#define BASE_ROAD_DATA @"GPS.gdzip"

#define INTEGRATE_DATA @"AutoNavi_Mapdata.dat"

#define DBDATA_CHINA_DAT @"dbdata/china/china.dat"
#define DBDATA_MAP_DAT @"dbdata/china/map.dat"
#define DBDATA_ROUMESH_DAT @"dbdata/china/roumesh.dat"

#define IDX_ADCODE_DAT  @"dbdata/idx/adcode.dat"
#define IDX_ALLIDX_PDT  @"dbdata/idx/allidx.pdt"
#define IDX_ALLIDX1_PDT  @"dbdata/idx/allidx1.pdt"
#define IDX_ALLIDX2_PDT  @"dbdata/idx/allidx2.pdt"
#define IDX_EXTADAREA_PDT  @"dbdata/idx/areaidx.dat"
#define IDX_GUIDEIDX0_DAT  @"dbdata/idx/guideidx0.dat"
#define IDX_MAPIDX0_DAT  @"dbdata/idx/mapidx0.dat"
#define IDX_MAPIDX1_DAT  @"dbdata/idx/mapidx1.dat"
#define IDX_MAPIDX2_DAT  @"dbdata/idx/mapidx2.dat"
#define IDX_ROUIDX_DAT  @"dbdata/idx/rouidx.dat"

#define RES_3D_MARK16 @"res/resall/3dmark16.dat"
#define RES_3D_MARK32 @"res/resall/3dmark32.dat"
#define RES_LOGO16BMP @"res/resall/logo16bmp.dat"
#define RES_LOGO32BMP @"res/resall/logo32bmp.dat"
#define RES_WARN32  @"res/resall/warn32.dat"
#define RES_WARN64  @"res/resall/warn64.dat"

#define MAP_DATA_CONTENT {@"",@""}

typedef enum DATAVERIFYRESULT {
    CHECK_SUCCESS	=0,
	WILL_DELETE_MAPDATA	,
	NEED_UPDATE_NAVIVER,
	DATA_NOT_COMPLETE,
	UNCOMPRESS_CITYS_ZLIB,
	BASE_ROAD_DATA_NOT_COMPLETE,
	BASE_ROAD_DATA_DOWNLAODING,
	BASE_ROAD_DATA_NOT_EXIST,
	DATA_CHECK_ERR,
    GRESOURSE_NOMATCH,
    SKIN_NOMATCH,
    GRESOURCEANDSKIN_NOMATCH,
}DATAVERIFYRESULT;

@interface DataVerify : NSObject {
//	UINavigationController *naviController;
	
	UILabel  *lblHandleStatus;       //status
    
    NSString *documentsDirectory;   //document directory
    NSString *applicationVersion;   //latest version
    NSArray  *zlibCitysList;
    
    BOOL isIntegrativeDataExist;    //是否有一体化数据
    BOOL isDataIntegrated;          //(一体化)数据是否完整
    BOOL isZlibOfCitysExist;        //是否有分城市压缩包
    BOOL isBaseRoadDataExist;       //是否有基础路网数据
    int  compareEngineWithMapVersion;//比较引擎版本号与地图版本号
    
    BOOL isCheckFinish;             //数据检测结束
    int  GresourseCheckResult;      //Gresourse下载结果:1.成功 2.取消下载 3.网络连接异常 4.配置文件下载异常 5.解压异常
    DATAVERIFYRESULT isGresourseValid;          //Gresourse是否匹配程序
	DATAVERIFYRESULT dataVerifyResult;
}
@property (nonatomic, retain) NSArray* zlibCitysList;

-(id)init;
#pragma mark public out 
/**进入导航程序*/
-(void) handlerEntryNaviApp;
/**继续下载数据 0:第一次进入下载 1:未下载完成在次进入下载*/
-(void) handerContinuedownLoadState:(int)mapDownState;
/**退出导航程序*/
-(void) handerQuitApplication;

#pragma mark Private 供内部调用方法
/**检测数据版本主流程*/
-(int) runCheckData;
/**加载一体化数据,为使用引擎函数做准备*/
-(BOOL) initIntegratedData;

///**删除所有数据*/
//-(void) deleteAllData;
/**检测基础路网数据是否正在下载并进入分城市数据下载*/
-(BOOL) checkBaseRoadDataAndDownload;
/**检测一体化数据是否(下载中)完整,若下载中继续数据下载*/
-(void) checkIntegratedDataAndDownload;

/**删除与基础路网不匹配的城市数据*/
-(void) deleteCityDataNotFitBaseRoadData;
/**检测本地是否有一体化数据*/
-(BOOL) checkIntegrativeDataExist;
/**检测本地数据是否完整*/
-(BOOL) checkDataIntegrated;
/**验证本地是否有分城市压缩包*/
-(BOOL) checkZlibOfCitysExist;
/**验证本地是否有基础路网*/
-(BOOL) checkBaseRoadDataExist;
///**验证程序版本与地图版本是否匹配*/
//-(int) checkProgrameIsFitForMapVersion;
/**验证引擎版本是否与地图版本匹配*/
-(int) checkEngineWithMapVersion:(BOOL)isIntegrateData;
/**解压分城市数据*/
//-(BOOL) unCompressCitysZlib;
/**
 *检测文件是否存在
 *fileName:检测的文件名(完整路径)
 */
-(BOOL)checkFileExist:(NSString *)fileName;
/**
 *获取目录下所有文件
 *rootPath:要查找的路径名称(尾部无需/),matchName:要匹配的结尾名称,nil或""则不验证匹配
 */
-(NSMutableArray*) searchFilesInPath:(NSString *)rootPath MatchContent:(NSString*)matchName;
/**
 *检测文件是否存在
 *fileName:检测的文件名(完整路径)
 */
-(BOOL) checkFileExist:(NSString*)fileName;

@end
