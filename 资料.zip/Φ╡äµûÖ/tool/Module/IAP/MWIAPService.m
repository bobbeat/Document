//
//  MWIAPService.m
//  IAPTest
//
//  Created by jingjie lin on 12-5-16.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import "MWIAPService.h"
static MWIAPService * instance = nil;
@implementation MWIAPService
@synthesize delegate;
+(MWIAPService *)shareInstance
{
    @synchronized(self)
    {
        if(instance == nil)
        {
            instance = [[super alloc] init];
            [[SKPaymentQueue defaultQueue] addTransactionObserver:instance];
        }
    }
    return instance;
}
-(void)dealloc
{
    [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
    [super dealloc];
}
-(void)buy:(NSString *)productID
{   
    if ([SKPaymentQueue canMakePayments]) {  
        [self RequestProductData:productID];    
    }  
    else  
    {  
        UIAlertView *alerView =  [[UIAlertView alloc] initWithTitle:@"提示"   
                                                            message:@"请到系统设置中开启应用程序内购买"                                                          
                                                           delegate:nil cancelButtonTitle:NSLocalizedString(@"确定",nil) otherButtonTitles:nil];  
        
        [alerView show];  
        [alerView release];  
        
    }   
}

-(void)RequestProductData:(NSString *)productID
{  
    NSArray *product = nil;  
    product=[[NSArray alloc] initWithObjects:productID,nil];
    NSSet *nsset = [NSSet setWithArray:product];  
    [product release];
    SKProductsRequest *request=[[SKProductsRequest alloc] initWithProductIdentifiers: nsset];  
    request.delegate=self;  
    [request start];  
    
}
#pragma mark SKProductsRequestDelegate
- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response{  
    
    NSArray *myProduct = response.products;  
    if([myProduct count] == 0)
    {
        [request cancel];
        if([delegate respondsToSelector:@selector(didFail)])
        {
            [delegate didFail];
        }
    }
       
    for(SKProduct *product in myProduct){  
        SKMutablePayment *payment = [SKMutablePayment paymentWithProduct:product]; 
        payment.quantity = 1;
        [[SKPaymentQueue defaultQueue] addPayment:payment]; 
    }   
}


#pragma mark SKPaymentTransactionObserver

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions//交易结果  
{  
    for (SKPaymentTransaction *transaction in transactions)  
    {  
        switch (transaction.transactionState)  
        {   
            case SKPaymentTransactionStatePurchased://交易完成   
                [self completeTransaction:transaction];  
                break;   
            case SKPaymentTransactionStateFailed:  
                [self failedTransaction:transaction];  
                break;   
            case SKPaymentTransactionStateRestored:  
                [self restoreTransaction:transaction];  
                break;
            case SKPaymentTransactionStatePurchasing:   
                break;  
            default:  
                break;  
        }  
    }  
}

#pragma mark myFun

- (void) completeTransaction: (SKPaymentTransaction *)transaction  
{    
    if([delegate respondsToSelector:@selector(didSuccess:)])
    {
        [delegate didSuccess:[NSString stringWithFormat:@"%@", [self base64Encoding:transaction.transactionReceipt]]];
    }
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];  
    
}

- (void) failedTransaction: (SKPaymentTransaction *)transaction{  
    if (transaction.error.code != SKErrorPaymentCancelled)  
    {  
    }  
    if([delegate respondsToSelector:@selector(didFail)])
    {
        [delegate didFail];
    }
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];  
    
    
}

- (void) restoreTransaction: (SKPaymentTransaction *)transaction  
{  
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}

static const char encodingTable[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
- (NSString *)base64Encoding:(NSData *)temp
{
	if ([temp length] == 0)
		return @"";
    char *characters = malloc((([temp length] + 2) / 3) * 4);
	if (characters == NULL)
		return nil;
	NSUInteger length = 0;
	NSUInteger i = 0;
	while (i < [temp length])
	{
		char buffer[3] = {0,0,0};
		short bufferLength = 0;
		while (bufferLength < 3 && i < [temp length])
			buffer[bufferLength++] = ((char *)[temp bytes])[i++];
		characters[length++] = encodingTable[(buffer[0] & 0xFC) >> 2];
		characters[length++] = encodingTable[((buffer[0] & 0x03) << 4) | ((buffer[1] & 0xF0) >> 4)];
		if (bufferLength > 1)
			characters[length++] = encodingTable[((buffer[1] & 0x0F) << 2) | ((buffer[2] & 0xC0) >> 6)];
		else characters[length++] = '=';
		if (bufferLength > 2)
			characters[length++] = encodingTable[buffer[2] & 0x3F];
		else characters[length++] = '=';
	}
	return [[[NSString alloc] initWithBytesNoCopy:characters length:length encoding:NSASCIIStringEncoding freeWhenDone:YES] autorelease];
}

@end
