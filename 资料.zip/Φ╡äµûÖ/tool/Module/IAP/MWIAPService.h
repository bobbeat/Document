//
//  MWIAPService.h
//  IAPTest
//
//  Created by jingjie lin on 12-5-16.
//  Copyright (c) 2012年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>

@protocol MWIAPServiceDelegate <NSObject>

-(void)didSuccess:(NSString *)receipt;
-(void)didFail;

@end

@interface MWIAPService : NSObject<SKProductsRequestDelegate,SKPaymentTransactionObserver>

@property(nonatomic,assign)id <MWIAPServiceDelegate>delegate;
+(MWIAPService*)shareInstance;
-(void)buy:(NSString *)productID;
- (NSString *)base64Encoding:(NSData *)temp;
@end
