//
//  Plugin_GresourseManager.h
//  AutoNavi
//
//  Created by huang longfeng on 13-5-6.
//
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-TaskManager.h"
#import "NetKit.h"


@interface Plugin_GresourseManager : NSObject <TaskStatusDelegate,NetRequestExtDelegate>
{
    NSMutableArray *GresourseTaskList;
    id<TaskStatusDelegate> delegate;    // 客户类填充该属性，以便TaskManager把通知发送给客户类
    NSString       *GresourseURL;       //Gresourse下载地址
    NSString       *GresourseMatchVersion;//匹配的版本号
    long long      GresourceSize;
    BOOL           cancelGresourceCheck;
}
@property (nonatomic ,readonly) NSMutableArray *GresourseTaskList;
@property (nonatomic ,assign) id<TaskStatusDelegate> delegate;
@property (nonatomic ,copy)     NSString *GresourseURL;
@property (nonatomic ,copy)     NSString *GresourseMatchVersion;
@property (nonatomic ,assign)   long long GresourceSize;
@property (nonatomic ,assign)   BOOL cancelGresourceCheck;
+ (Plugin_GresourseManager *)sharedInstance;

//开始Gresourse检测
- (void)GresourseCheckStart;
//请求服务器当前旅游数据的版本
- (void)GresourseUpdateCheck;
//将本地数据添加到任务列表中
-(void)addLocalDataToList;

// 返回-1表示加入失败，>=0表示成功加入后在TaskManager中的索引
-(int)addTask:(Task*) task atFirst:(BOOL) first;

//将本地存在的地图数据添加到下载队列中，并把状态置为完成
-(int)addLocalTask:(Task*)task atFirst:(BOOL) first;

// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按某种策略选择一个任务来执行
// 2、有任务在执行：直接返回
-(BOOL)start;

// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按index来选择任务
// 2、有任务在执行：
//      分两种情况：
//      1、正在执行的任务就是index，那么直接返回；
//      2、正在执行的任务不是index，那么让正在执行的任务变为等待，转而执行index指定的任务
-(BOOL)start:(int)index;

// 停止TaskManager中正在执行的任务，整个TaskManager处于停止状态
-(BOOL)stop;

// 停止TaskManager中index对应的任务：注意：只有状态为TASK_STATUS_RUNNING的任务才能被stop
// 1、index对应的任务处于等待状态，那么直接返回
// 2、index对应的任务处于执行状态，那么让正在执行的任务变为等待
-(BOOL)stop:(int)index;

// 移除任务id的任务，该操作会删除该任务。
// 如果恰好该任务处于运行状态，removeTaskId后，整个TaskManager中将无任务在执行
-(BOOL)removeTaskId:(long) taskId;
// 把TaskManager中的所有任务信息保存到文件系统，一般是在退出程序时调用
-(BOOL)store;
// 从文件系统还原通过save保存的所有任务信息，一般是在进入程序时调用，该方法调用将把TaskManager中的所有任务更新为最后一次调用save保存的任务
-(BOOL)restore;
//网络检测
- (void)netWorkHandle;
- (void)GresourseCheckFuntion;
@end
