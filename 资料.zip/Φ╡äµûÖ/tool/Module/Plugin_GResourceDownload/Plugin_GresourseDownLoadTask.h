//
//  Plugin_GresourseDownLoadTask.h
//  AutoNavi
//
//  Created by huang longfeng on 13-5-6.
//
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-DownloadTask.h"

@interface Plugin_GresourseDownLoadTask : DownloadTask

@end
