//
//  Plugin_GresourseDownLoadTask.m
//  AutoNavi
//
//  Created by huang longfeng on 13-5-6.
//
//

#import "Plugin_GresourseDownLoadTask.h"
#import "ZipArchive.h"
#import "Utility.h"
#import "Plugin_GresourseManager.h"

#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]//文件最终存放目录


@implementation Plugin_GresourseDownLoadTask
// 删除任务以及任务相关的资源
- (void)erase
{
	// 停止下载任务
	[self stopconnection];
	
	NSError *error;

    NSString *temp_path = [self getFilename];
    temp_path = [[NSString alloc] initWithString:[DOCUMENTS_FOLDER stringByAppendingFormat:@"/%@.tmp",temp_path]];
	// 删除临时文件并初始化下载数据
	if (temp_path!=nil && [temp_path length]!=0)
	{
		if([[NSFileManager defaultManager] fileExistsAtPath:temp_path])
		{
			[[NSFileManager defaultManager] removeItemAtPath:temp_path error:&error];
		}
	}
}
// 解压线程
- (void)ZipArchive
{
	NSAutoreleasePool* pool =[[NSAutoreleasePool alloc] init];
	
	NSMutableDictionary* threadDict = [[NSThread mainThread] threadDictionary];
	NSString* destinctionPath = [[NSString alloc] initWithString:[threadDict valueForKey:@"destinctionPath"]];
	int admincode = [[threadDict valueForKey:@"admincode"] intValue];
	
	BOOL result = YES;//判断是否解压成功
    ZipArchive* za = [[ZipArchive alloc] init];
    
    
	if ([za UnzipOpenFile:destinctionPath])
	{
		int ret = [za getRetValue];
		if( ret!=UNZ_OK )
		{
			[za OutputErrorMessage:@"Failed"];
		}
        
		do
        {
			if([[NSThread currentThread] isCancelled])
			{
				result = NO;
                
                if ([[NSFileManager defaultManager] fileExistsAtPath:destinctionPath]) {
                    
                    [[NSFileManager defaultManager] removeItemAtPath:destinctionPath error:nil];// 解压成功后删除压缩文件
                }
				
				[NSThread exit];//终止线程
			}
            
			long long disksize = [Utility getCurDiskSpaceInBytes];
			NSDictionary *dic = [[NSFileManager defaultManager] attributesOfItemAtPath:destinctionPath error:nil];
            unsigned long long  size = [dic fileSize];
            if (disksize < size) {
                
                [delegate exception:self exception:[NSError errorWithDomain:@"error_storage" code:DOWNLOADHANDLETYPE_NOSPACE userInfo:nil]];
                
                result = NO;
                break;
            }
			int zaResult = [za UnzipFileTo:DOCUMENTS_FOLDER overWrite:YES retValue:&ret filesize:disksize];
			if (zaResult!=2)
			{
				if (zaResult==1)
                {
                    [delegate exception:self exception:[NSError errorWithDomain:@"error_storage" code:DOWNLOADHANDLETYPE_NOSPACE userInfo:nil]];
				}
				else
                {
					[delegate exception:self exception:[NSError errorWithDomain:@"error_ziparchive" code:DOWNLOADHANDLETYPE_UPZIPFAIL userInfo:nil]];
                }
                
				result = NO;
				break;
			}
		}while (ret==UNZ_OK && UNZ_OK!=UNZ_END_OF_LIST_OF_FILE) ;
		
		[za UnzipCloseFile];
	}
	[za release];
	
	if (result)
	{
		NSError *error;
        if ([[NSFileManager defaultManager] fileExistsAtPath:destinctionPath]) {
            
            [[NSFileManager defaultManager] removeItemAtPath:destinctionPath error:&error];// 解压成功后删除压缩文件
            
        }
		
        if ([delegate respondsToSelector:@selector(unZipFinish:)]) {
            [delegate unZipFinish:self];
        }
	}
	
    [destinctionPath release];
	[NSThread exit];
	
	[pool release];
}
@end
