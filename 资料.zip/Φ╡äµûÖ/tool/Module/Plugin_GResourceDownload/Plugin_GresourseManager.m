//
//  Plugin_GresourseManager.m
//  AutoNavi
//
//  Created by huang longfeng on 13-5-6.
//
//

#import "Plugin_GresourseManager.h"
#import "plugin-cdm-Task.h"
#import "Plugin_GresourseDownLoadTask.h"
#import "Utility.h"
#import "NSString+Category.h"
#import "DataVerify.h"

//Gresource--------------------------------------------------------------------------------------------
#define kGresourceURL                    @"iphonedata/gresourcematch_v2/"

static Plugin_GresourseManager *instance;
@implementation Plugin_GresourseManager
@synthesize GresourseTaskList,delegate,GresourseURL,GresourseMatchVersion,GresourceSize,cancelGresourceCheck;

+ (Plugin_GresourseManager *)sharedInstance
{
    if (instance == nil) {
        instance = [[Plugin_GresourseManager alloc] init];
        [instance restore];
    }
    return instance;
}
- (id)init
{
    if (self = [super init]) {
        GresourseTaskList = [[NSMutableArray alloc] init];
        
    }
    return self;
}
//网络检测
- (void)netWorkHandle
{
    int netType = NetWorkType;
    if (netType == 2) {
        if ([self isRunning]) {
            [self stop];
        }
        [self start];
    }
    else if(netType == 1 && netType != 2){
        if ([self isRunning]) {
            [self stop];
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:6]];
    }
    else {
        if ([self isRunning]) {
            [self stop];
        }

        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:3]];
    }
}
- (void)GresourseCheckFuntion
{
    GVERSION mapVer = {0};
    NSString *tmp;
    GSTATUS res;
    DataVerify *verify = [[DataVerify alloc] init];
    BOOL isWholeData = [verify checkIntegrativeDataExist];
    [verify release];
    if (isWholeData)	//一体化地图数据
	{
		res = GDBL_GetMapVersion((char*)[mapDataManage getIntegrateDataPath], &mapVer);
	}
	else	//分城市数据
	{
        res = GDBL_GetMapVersion((char*)[mapDataManage getDataPath], &mapVer);
	}
    if (res == GD_ERR_OK) {
        tmp = [NSString stringWithFormat:@"%s",mapVer.szVersion];
    }
    else{
        tmp = @"";
    }
    
    
    NSString *gresourceTmp = [Utility GetGResourseVersion:[NSString chinaFontStringWithCString:g_data_path]];
    NSString *stringt = @"V";
    NSRange range = [tmp rangeOfString:stringt];
    NSRange Grange = [gresourceTmp rangeOfString:stringt];
    NSString *Gversion;
    NSString *version;
    if (range.length != 0)
    {
        version = [tmp substringFromIndex:range.location+2];
        
    }
    else {
        version = @"";
    }
    if (Grange.length != 0) {
        Gversion = [gresourceTmp substringFromIndex:Grange.location+2];
    }
    else{
        Gversion = @"";
    }
    NSString *g_path = [NSString stringWithUTF8String:g_data_path];
    NSRange rangeModel = [g_path rangeOfString:@"Documents/"];
    g_path = [g_path substringFromIndex:rangeModel.location + rangeModel.length];
    g_path = [g_path substringToIndex:[g_path length] - 1];
    
	NSMutableDictionary *urlParams = [[NSMutableDictionary alloc] init];
    [urlParams setValue:[NSString stringWithFormat:@"%.1f",SOFTVERSIONNUM] forKey:@"client"];
    [urlParams setValue:g_path forKey:@"device"];
    [urlParams setValue:Gversion forKey:@"gresource"];
    [urlParams setValue:version forKey:@"dataversion"];
    
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = [kNetDomain stringByAppendingString:kGresourceURL];
    condition.requestType = RT_GresourceCheck;
    condition.httpMethod = @"GET";
    condition.urlParams = urlParams;
    
    [[NetExt sharedInstance] requestWithCondition:condition delegate:self];
    [urlParams release];

}
//请求服务器当前旅游数据的版本
- (void)GresourseUpdateCheck
{
    
    if ([GresourseTaskList count] > 0 && ((Task*)[GresourseTaskList objectAtIndex:0]).status != TASK_STATUS_FINISH) {
        [self netWorkHandle];
        return;
    }
    [self GresourseCheckFuntion];
}
//开始Gresourse检测
- (void)GresourseCheckStart
{
    NSLog(@"networkType:%d",NetWorkType);
    if (0 == NetWorkType) {
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:2]];
    }
    else {
        
        [self GresourseUpdateCheck];
        
    }
}
// 把TaskManager中的所有任务信息保存到文件系统，一般是在退出程序时调用
-(BOOL)store
{
    /*
     1、序列化整个mTaskList
     */
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"GresourseDownloadList.plist"];
	if (![NSKeyedArchiver archiveRootObject:GresourseTaskList toFile:filename]){
		return NO;
	}
	else {
		return YES;
	}
    
}

// 从文件系统还原通过save保存的所有任务信息，一般是在进入程序时调用，该方法调用将把TaskManager中的所有任务更新为最后一次调用save保存的任务
-(BOOL)restore
{
    /*
     1、反序列化各个Task对象，构建处mTaskList
     2、遍历mTaskList，把task.delegate = self;
     */
	
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:@"GresourseDownloadList.plist"];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	[GresourseTaskList removeAllObjects];
	[GresourseTaskList addObjectsFromArray:array];
	
    for (Task *task in GresourseTaskList) {
		task.delegate = self;
	}
	return YES;
	
}

#pragma mark - Gresourse
//将本地数据添加到任务列表中
-(void)addLocalDataToList
{
    Plugin_GresourseDownLoadTask *travelTask = [[Plugin_GresourseDownLoadTask alloc] init];
    
    travelTask.title = @"Gresource";
    
    travelTask.taskId = 0;
    travelTask.url = self.GresourseURL;
    travelTask.total = self.GresourceSize;
    [self addTask:travelTask atFirst:NO];
    [travelTask release];
    [self store];
}
// 返回-1表示加入失败，>=0表示成功加入后在TaskManager中的索引
-(int)addTask:(Task*) task atFirst:(BOOL) first
{
    if(NO==[self _taskExisted:task])
    {
        task.delegate = self;
        task.status = TASK_STATUS_READY;
        if(first)
        {
            [GresourseTaskList insertObject:task atIndex:0];
            return 0;
        }
        else
        {
            [GresourseTaskList addObject:task];
            return [GresourseTaskList count]-1;
        }
    }
    else
    {
        return -1;
    }
}
//将本地存在的地图数据添加到下载队列中，并把状态置为完成
-(int)addLocalTask:(Task*)task atFirst:(BOOL) first
{
    if(NO==[self _taskExisted:task])//任务列表中无，则添加
    {
        task.delegate = self;
        task.status = TASK_STATUS_FINISH;
        if(first)
        {
            [GresourseTaskList insertObject:task atIndex:0];
            return 0;
        }
        else
        {
            [GresourseTaskList addObject:task];
            return [GresourseTaskList count]-1;
        }
    }
    else if(YES==[self _taskExisted:task] )
    {
        for (Plugin_GresourseDownLoadTask *t in GresourseTaskList)
        {
            if (t.taskId == task.taskId)
            {
                if (t.status != TASK_STATUS_FINISH)//若用户拖入完整的城市数据，则删除对应未下载完成的文件
                {
                    NSString *stringt = @"/";
                    NSRange range = [t.url rangeOfString:stringt options:NSBackwardsSearch];
                    if (range.length != 0)
                    {
                        NSString *name = [t.url substringFromIndex:range.location+1];
                        //   NSString *name = [NSString stringWithFormat:@"%@",[t.url CutFromNSString:@"cityupdatedata/"]];
                        NSFileManager *fileManager = [NSFileManager defaultManager];
                        NSArray *paths;
                        NSError *error;
                        NSString *documentsDirectory;
                        paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                        documentsDirectory = [[NSString alloc] initWithFormat:@"%@", [paths objectAtIndex:0]];
                        NSString *filePath = [NSString stringWithFormat:@"%@/%@.tmp",documentsDirectory,name];
                        [documentsDirectory release];
                        if([fileManager fileExistsAtPath:filePath])
                        {
                            [[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
                            
                        }
                    }
                }
                t.status = TASK_STATUS_FINISH;
            }
	    }
        return 0;
    }
	else
    {
		return -1;
	}
    
}
// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按某种策略选择一个任务来执行
// 2、有任务在执行：直接返回
-(BOOL)start
{
    if([self isRunning])
    {
        return NO;
    }
    else
    {
        int index = [self _selectOneTaskToRun];
        if(index<0)
        {
            return NO;
        }
        else
        {
            return [self start:index];
        }
    }
}
// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按index来选择任务
// 2、有任务在执行：
//      分两种情况：
//      1、正在执行的任务就是index，那么直接返回；
//      2、正在执行的任务不是index，那么让正在执行的任务变为等待，转而执行index指定的任务
-(BOOL)start:(int)index
{
    int indexRunning = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (indexRunning == index) {
        return NO;
    }
    else
    {
        // 先停止正在执行的任务
        if (indexRunning >= 0)
        {
            
            Task* t = [GresourseTaskList objectAtIndex:indexRunning];
            t.status = TASK_STATUS_READY;
            [t stop];
        }
        
        
        Task* t = [GresourseTaskList objectAtIndex:index];
        t.status = TASK_STATUS_RUNNING;
        [t run];
        
        return YES;
    }
}
// 停止TaskManager中正在执行的任务，整个TaskManager处于停止状态
-(BOOL)stop
{
    int index = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (index>=0) {
        return [self stop:index];
    }
    return NO;
}
// 停止TaskManager中index对应的任务：注意：只有状态为TASK_STATUS_RUNNING的任务才能被stop
// 1、index对应的任务处于等待状态，那么直接返回
// 2、index对应的任务处于执行状态，那么让正在执行的任务变为等待
-(BOOL)stop:(int)index
{
    int count = [GresourseTaskList count];
    if(index>=0 && index<count)
    {
        // 只有状态为TASK_STATUS_RUNNING的任务才能被stop
        
        Task* t = [GresourseTaskList objectAtIndex:index];
        if(t.status==TASK_STATUS_RUNNING)
        {
            t.status = TASK_STATUS_READY;
            [t stop];
            return YES;
        }
    }
    return NO;
}

// 返回YES表示TaskManager中有任务正在运行
-(BOOL)isRunning
{
    return [self _firstIndexWithStatus:TASK_STATUS_RUNNING]<0?NO:YES;
}

// 移除索引为index处的任务，该操作会删除该任务。
// 如果恰好该任务处于运行状态，removeTask后，整个TaskManager中将无任务在执行
-(BOOL)removeTask:(int) index
{
    int count = [GresourseTaskList count];
    if(index>=0 && index < count)
    {
        Task* t = [GresourseTaskList objectAtIndex:index];
        [t erase];
        [GresourseTaskList removeObjectAtIndex:index];
        return  YES;
    }
    return NO;
}
// 移除任务id的任务，该操作会删除该任务。
// 如果恰好该任务处于运行状态，removeTaskId后，整个TaskManager中将无任务在执行
-(BOOL)removeTaskId:(long) taskId
{
    int count = [GresourseTaskList count];
	for (int i = 0; i < count; i++)
	{
        Task* t = [GresourseTaskList objectAtIndex:i];
		if (taskId == t.taskId) {
			if (taskId == 0) {
				[t erase];
				[GresourseTaskList removeAllObjects];
			}
			else {
				[t erase];
				[GresourseTaskList removeObjectAtIndex:i];
			}
			return YES;
		}
	}
    return NO;
}
// 从头开始向尾扫描mTaskList列表，直到遇到一个状态为TASK_STATUS_READY的任务对象
// 返回指<0则表示没找到可被执行的任务，否则表示所选任务的索引
-(int)_selectOneTaskToRun
{
    return [self _firstIndexWithStatus:TASK_STATUS_READY];
}


// 返回队列中，状态为status的第一个任务的索引
// 返回指<0则表示没找到可被执行的任务，否则表示任务的索引
-(int)_firstIndexWithStatus:(int)status
{
    int count = [GresourseTaskList count];
    for (int i=0;i<count;i++) {
        if(((Task*)[GresourseTaskList objectAtIndex:i]).status == status)
        {
            return i;
        }
    }
    return -1;
}

// 根据taskId来判断task是否已经存在队列中
-(BOOL)_taskExisted:(Task*)task
{
    for (Task* t in GresourseTaskList) {
        // 用任务id来比较
        if(t.taskId == task.taskId)
        {
            return YES;
        }
    }
    return NO;
}
//获取任务列表中所有任务需要的空间大小
-(long long)getNeedSize
{
	long long size;
	size = 0;
    
	int count = [GresourseTaskList count];
    for (int i=0;i<count;i++) {
        Task* t = [GresourseTaskList objectAtIndex:i];
        if(t.status == TASK_STATUS_READY || t.status == TASK_STATUS_RUNNING)
        {
            //	long long tmp = [t getNeedSize];
            size += (t.total - t.current);
        }
    }
    return size;
}
#pragma mark - TaskStatusDelegate委托回调

-(void)progress:(Task*)sender current:(long long)current total:(long long)total
{
    NSLog(@"%lld,%lld",current,total);
    static int count = 0;
    count ++;
    if (count == 20){
        count = 0;
        if (delegate && [delegate respondsToSelector:@selector(progress:current:total:)]) {
            [delegate progress:sender current:current total:total];
        }
    }
	
}

-(void)finished:(Task*)sender
{
	sender.status = TASK_STATUS_FINISH;
    
}

-(void)exception:(Task*)sender exception:(id)exception
{
    
    if (((NSError *)exception).code == DOWNLOADHANDLETYPE_UPZIPFAIL) {//解压失败，删除数据，重新下载
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:5]];
        
        [self removeTaskId:sender.taskId];
    
        [self addLocalDataToList];
        [self netWorkHandle];
    }
    else if( ((NSError *)exception).code == DOWNLOADHANDLETYPE_CURRENTLAGERTOTAL || ((NSError *)exception).code == DOWNLOADHANDLETYPE_NOSPACE || ((NSError *)exception).code == DOWNLOADHANDLETYPE_CURRENTSMALLTOTAL  ){//下载失败
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:4]];
        
        [self removeTaskId:sender.taskId];
    }
    
    else {
        [self netWorkHandle];
        
    }
        
    
    [self store];
    
}
- (void)unZipFinish:(Task*)sender
{
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:1]];
    [GresourseTaskList removeAllObjects];
    [self store];
    
}
#pragma mark - request
//服务器成功应答
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data
{
    
    if (data && [data length])
    {
        char *szResult = (char *)[data bytes];
        NSLog(@"GresourceCheckResult==%s",szResult);
        NSString *tmp = [NSString stringWithFormat:@"%s",szResult];
        
        NSString *result = [tmp CutFromNSString:@"<Result>" Tostring:@"</Result>"];
        if ([result isEqualToString:@"SUCCESS"]) {
            
            //gresourse匹配,进入程序
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:1]];
                           
        }
        else
        {
            if ([MWPreference sharedInstance].gresourceVersion && [[MWPreference sharedInstance].gresourceVersion length] > 0) {//当标记过后资源文件出现问题，把标记清空，下次进入程序还可以进行资源检测
                [MWPreference sharedInstance].gresourceVersion = @"";
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:2]];
            }
            else{
                self.GresourseMatchVersion = [tmp CutFromNSString:@"<Version>" Tostring:@"</Version>"];
                self.GresourceSize = [[tmp CutFromNSString:@"<Size>" Tostring:@"</Size>"] intValue];
                self.GresourseURL = [tmp CutFromNSString:@"<updateurl>" Tostring:@"</updateurl>"];
                if (self.GresourseURL && [self.GresourseURL length]) {
                    
                    [self addLocalDataToList];
                    [self netWorkHandle];
                }
                else{
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:2]];
                }
            }
            
            
        }
        
    }
    else{
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:2]];
    }
}
- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error
{
	
   [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GresourseCheckResult object:[NSNumber numberWithInt:3]];
}

@end
