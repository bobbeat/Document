//
//  Plugin_OnLineMapUtility.h
//  AutoNavi
//
//  Created by huang longfeng on 13-3-4.
//
//

#import <Foundation/Foundation.h>
#import "MAMapKit.h"
#import "MyCustomAnnotation.h"
#import "MASearch.h"
#import "PaintingView.h"
#import "Plugin_OnLineMapView.h"
#import "Plugin_OnlineStruct.h"

//传至主界面的消息，如进入地图下载界面，进入全程概览
#define Utility_EnterLoadView_Notify @"Utility_EnterLoadView_Notify"
#define Utility_EnterBrowse_Notify @"Utility_EnterBrowse_Notify"

#define ERROR_NET				@"网络连接失败,请确认网络状态"
#define HK_ERROR_NET			@"網絡連接失敗,請確認網絡狀態"
#define EN_ERROR_NET			@"Internet connection failure, please confirm"

#define ALERT_OK				@"确定"
#define HK_ALERT_OK             @"確定"
#define EN_ALERT_OK             @"OK"

#define ALERT_Cancel				@"取消"
#define HK_ALERT_Cancel             @"取消"
#define EN_ALERT_Cancel             @"Cancel"

#define NET_PATH  [NSHomeDirectory() stringByAppendingString:@"/Documents/NetPath.plist"]

@class Plugin_OnLineMapView;

@protocol onlineMapSearchDelegate <NSObject>

@optional

- (void)onlineMapSearchCenterWith:(MWPoi *)poi;

@end



@interface Plugin_OnLineMapUtility : NSObject<MASearchDelegate,MAMapViewDelegate,UIAlertViewDelegate>
{
    MAMapView *m_maMapView;
    PaintingView *m_drawingView;
    Plugin_OnLineMapView *m_onLineMapView;
    
    ShowMapViewWithState m_mapViewState;
    
    SAVE_POI_TYPE m_saveType;
    BOOL isAmapView;        //当前地图是否为网络地图
    BOOL mustAmapView; //临界点切换时，为了保证始终为网络地图
    
    int isTBTRouteData; //存在路径时，0为纯本地数据，1为纯网络数据，2为本网结合数据
    BOOL isChangingMap; //导航时，由本地向网络过渡中
    
    int m_iCurSegNum;       //!> 当前自车所在segment段，从0开始
    
    BOOL isMove;
    BOOL isEnd; //是否带有坐标传入的终点
    BOOL isEnterNewView; //是否进入开机新功能查看
    int isSettingDes;  //为加载网络地图时，是否正在加载起点或终点，0为未设置，1为设置终点，2为设置起点，3为设终点需要提示，4为设途经点
    BOOL isArriveWay;
    BOOL isAnimated; //是否在进行动画
    BOOL isSaveLocalDes; //是否设置本地POI为终点
    BOOL isAlertCCPAlert; //未移图时是否弹出加载网络地图询问。
    BOOL isAlertMOVEAlert; //移图时是否弹出加载网络地图询问。
    BOOL isChangePage; //是否正在过渡页面，如：点的详细信息界面，按下导航按钮后，至主界面，
    BOOL isHasGPS;
    BOOL isShowPopPoi; //是否可以显示poi信息面板
    
    ViewController_Type m_viewControllerType; //地图视图所在的父视图控制器类型
    FILE*   m_pFileRecordGps;
    NSArray *m_gpsInfoArray;
    NSDictionary  *absentCityCodeList;
    NSMutableArray *m_clickImageArray;
    id<onlineMapSearchDelegate> _searchDelegate;
@public
    struct ITBT *tbtNavi;
    struct CTBTFrame *tbtFrame;
    
}

@property (nonatomic,assign) ShowMapViewWithState m_mapViewState;
@property (nonatomic,assign) MAMapView *m_maMapView;
@property (nonatomic,assign) PaintingView *m_drawingView;
@property (nonatomic,assign) Plugin_OnLineMapView *m_onLineMapView;
@property (nonatomic,assign) int m_iCurSegNum;       //!> 当前自车所在segment段，从0开始
@property (nonatomic,assign) BOOL isAmapView;
@property (nonatomic,assign) BOOL mustAmapView; //临界点切换时，为了保证始终为网络地图
@property (nonatomic,assign) BOOL isEnterMap; //初始化时，是否还未进入主地图
@property (nonatomic,assign) BOOL isEnterNewView; //是否进入开机新功能查看,为了进入新功能介绍之后不弹出是否加载忘了地图
@property (nonatomic,assign) BOOL isChangingMap; //导航时，由本地向网络过渡中
@property (nonatomic,assign) BOOL isAnimated; //是否在进行动画
@property (nonatomic,assign) int isTBTRouteData; //存在路径时，0为纯本地数据，1为纯网络数据，2为本网结合数据中的本地数据
@property (nonatomic,assign) BOOL isMove;
@property (nonatomic,assign) int isSettingDes;  //为加载网络地图时，是否正在加载起点或终点，0为未设置，1为设置起点，2为设置终点
@property (nonatomic,assign) BOOL isArriveWay;
@property (nonatomic,assign) BOOL isSaveLocalDes; //是否设置本地POI为终点;
@property (nonatomic,assign) BOOL isAlertCCPAlert; //未移图时是否弹出加载网络地图询问。
@property (nonatomic,assign) BOOL isAlertMOVEAlert; //移图时是否弹出加载网络地图询问。
@property (nonatomic,assign) BOOL isChangePage; //是否正在过渡页面，如：点的详细信息界面，按下导航按钮后，至主界面，
@property (nonatomic,assign) BOOL isHasGPS;
@property (nonatomic,assign) BOOL isShowPopPoi; //是否可以显示poi信息面板
@property (nonatomic,copy) NSString* m_remainTime;
@property (nonatomic,copy) NSString* m_remainDistance;
@property (nonatomic,copy) NSString* m_remainSegDistance;
@property (nonatomic,copy) NSString* m_currentLoadName;
@property (nonatomic,copy) NSString* m_nextLoadName;
@property (nonatomic,copy) NSString* m_tollCount;
@property (nonatomic,assign) int m_iIcon;
@property (nonatomic,assign) ViewController_Type m_viewControllerType; //地图视图所在的父视图控制器类型
+ (Plugin_OnLineMapUtility *)sharedInstance;


#pragma mark 改变父视图
- (void)ChangeSuperView:(UIView *)supView ViewType:(ViewController_Type)type;
#pragma mark 设置是否显示用户位置
- (void)SetShowUserLocation:(BOOL)show;
#pragma mark 改变网络地图中心点
- (void)SetAmapCenterWithLon:(double)lon Lat:(double)lat;
#pragma mark 获取Amap视图中心点
- (CLLocationCoordinate2D)NET_GetAmapCenter;
#pragma mark 获取Amap地图比例尺
- (double)CalScale;

#pragma mark 获取Amap地图旋转角度
- (CGFloat)GetRotationDegree;
#pragma mark 设置Amap地图旋转角度
- (void)SetRotationDegree:(CGFloat)degree;

-(id)NET_GetMapInfoWithType:(NET_PARAMTYPE)type;

#pragma mark - 关闭电子眼 移动交通台等
- (void)Net_OpenCamera:(BOOL)open;
- (void)Net_OpenTrafficRadio:(BOOL)open;
- (void)Net_OpenTMC:(BOOL)open;
- (void)Net_OpenTrafficPanel:(BOOL)open;

#pragma mark 通过判断中心坐标是否有数据，显示当前地图（在线，本地）
- (void)ShowMapMode;
#pragma mark 放大或缩小至
- (void)MapZoomTO:(NSString *)scale;
#pragma mark 放大
- (void)MapZoomIN:(NSString *)scale;
#pragma mark 缩小
- (void)MapZoomOut:(NSString *)scale;
#pragma mark 由本地向网络偏移重算
- (void)NET_OffRouteWithLon:(double)lon Lat:(double)lat;
#pragma mark 根据类型,经纬度，设置点的类型，0为起点，6为终点，其余为途径点
- (void)SetPointWithType:(int)type andPOI:(GPOI)poi;
#pragma mark 根据类型设置点的类型，0为起点，6为终点，其余为途径点
- (void)SetPointWithType:(int)type;
#pragma mark 途经点设置接口
- (void)SetPassByWithCoord:(OnLinePOI *)passByCoord Count:(int)count;
- (void)NET_SetRouteWithLocalCoord;
#pragma mark 本地导航失败时，提示缺少数据，并询问用户是否导航
- (void)ShowAbsentCityNameWithTag:(int)tag;
#pragma mark 添加车标
- (void)NET_AddCarWithCoord:(CLLocationCoordinate2D)coord;
// 添加可点击图标
- (void)NET_AddClickImageWithCoord:(CLLocationCoordinate2D)coord image:(UIImage *)image delegate:(id<OnLineMapClickImageDelegate>)delegate tag:(int)tag;

/*
 网络地图添加可点击图标
 
 poi：添加的poi信息
 image:地图上显示的图片
 delegate：点击后的回调委托
 tag：标识
 
 */
- (void)NET_AddClickImageWith:(MWPoi *)poi image:(UIImage *)image delegate:(id<OnLineMapClickImageDelegate>)delegate tag:(int)tag;

/*
 网络地图清除所有可点击图标
 */
- (void)NET_ClearAllClickImage;

#pragma mark 设起点
- (void)SetCarPosition;
- (void)SetCarPositionWithLon:(double)lon Lat:(double)lat;
#pragma mark 设终点
- (void)SetEndPoint:(int)type;
#pragma mark 回车位
- (void)BackToCar;
#pragma mark 开始GPS导航
- (void)StartGPSNavi;
#pragma mark 开始模拟导航
- (void)StartEmulatorNaviWithSpeed:(int)speed;
#pragma mark 暂停模拟导航
- (void)PauseNavi;
#pragma mark 恢复模拟导航
- (void)ResumeNavi;
#pragma mark 停止模拟导航
- (void)StopEmulatorNavi;
#pragma mark 停止导航,删除所有路径
- (void)StopNavi;
#pragma mark 清除所有TBT信息，包括地图绘制信息
- (void)ClearInfo;
#pragma mark 收藏中心点
- (void)SaveCenterInfo;
#pragma mark 收藏当前点
- (void)SaveCurrentPoint;
#pragma mark 保存历史目的地
- (void)SaveHistoryDes;
#pragma mark 传入信息到行车电脑
-(void)NET_PassInfoToDrive;
#pragma mark 获取高德导航地图比例尺
- (double)GetAmapScaleFromGDmap:(NSString *)scale lastScale:(double *)lastscale nextScale:(double *)nextScale latScaleStr:(NSString **)lastscaleStr nextScaleStr:(NSString **)nextscaleStr;

#pragma mark 判断是否有路径
- (BOOL)ExistRouteLine;

#pragma mark 根据移动的矢量改变地图中心坐标
- (void)SetAmapCenterWithDragX:(float)drag_x DragY:(double)dra_y;
#pragma mark 根据移动的矢量改变地图中心坐标
- (CGPoint)ConvertCoordToScreenWithLon:(double)lon Lat:(double)lat;

#pragma mark 进入全程概览
- (void)EnterBrowse;
//起点是否有数据
- (int)IsStartIsNetMap;
#pragma mark 设置车标颜色
- (void)setCarColor:(BOOL)hasGPS;
#pragma mark 同步本地和网络的车标位置
- (void)SynLocalCarPositionWithNet;
#pragma mark 用本地车标 同步网络车标
- (void)SynNetCarPositionWithLocalCar;
#pragma mark 利用本地GPS信息设置网络地图在导航时的GPS信息
- (void)SetAmapGPSInfo:(GGPSINFOEX *)gpsInfo;
#pragma mark 设终点－填充poi值
- (void)NET_SetEndingPOI:(GPOI)endingPOI;

#pragma mark 获取地图中心点poi信息
- (void)NET_getPoiInfoWithCoord:(GCOORD)coord delegate:(id<onlineMapSearchDelegate>)searchDelegate;
@end
