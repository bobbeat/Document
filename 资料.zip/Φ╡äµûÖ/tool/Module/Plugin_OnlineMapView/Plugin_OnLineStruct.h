//
//  Plugin_OnLineStruct.h
//  AutoNavi
//
//  Created by gaozhimin on 13-5-6.
//
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

typedef enum ViewController_Type //当前所在的Controller类型
{
    ViewController_Local,   //此模式只显示本地地图
    ViewController_Main,   //主页面
    ViewController_MainDisappear, //地图从主界面消失
    ViewController_Browse,   //全程概览界面
    ViewController_Shared,   //微享界面
    ViewController_POI,   //查图界面
    ViewController_POIDisappear, //地图从查图界面
    ViewController_Judge, //只进行地图切换判断
}ViewController_Type;

typedef enum ShowMapViewWithState //当前Amap状态
{
    State_None = 0,     //无
    State_EmulatorNavi, //模拟导航
    State_Navi,         // 导航
    State_StopGuidance, //停止引导
    State_Guidance,     //引导
    State_SetStart,     //设起点
    State_SetPassBy,    //设途经点
    State_SetEnd        //设终点
}ShowMapViewWithState;

typedef enum NET_PARAMTYPE
{
    NET_TurnIcon       = 0, //获取转向图标
    NET_CurRoadName    = 1, //获取当前道路名
    NET_NextRoadName   = 2, //获取下一路口道路名
    NET_PathTotalTime  = 3, //获取路线的总历时
    NET_PathProportion = 4, //获取路线剩余距离百分比
    NET_PathDistance   = 5, //获取路线总距离
    NET_CurPOI         = 6,  //获取当前点
    NET_TollCount,           //收费站总数
    NET_RemainTime,            //路径剩余时间
    NET_RemainDistance,          //路径剩余距离
    NET_RemainSegDistance,            //当前路段路径剩余距离
    NET_PathDistance_NS,   //获取路线总距离 NSNumber
    NET_PathTotalTime_NS   //获取路线的总历时 NSNumber
}NET_PARAMTYPE;

typedef enum SAVE_POI_TYPE
{
    SAVE_NONE        = 0, //不保存
    SAVE_HistoryDES  = 1, //保存历史目的地
    SAVE_COLLECTION  = 2, //保存收藏点
    GET_CENTERINFP  = 3, //获取地图中心点信息
}SAVE_POI_TYPE;

typedef struct OnLinePOI
{
    CLLocationCoordinate2D offset;
    CLLocationCoordinate2D coord;
    char name[GMAX_POI_NAME_LEN+1];
}OnLinePOI;

@protocol OnLineMapClickImageDelegate <NSObject>

- (void)OnLineMapDidSelectImage:(int)tag;  //图片选中  回调
- (void)OnLineMapDeselectImage:(int)tag;   //取消图片选中 回调
@end
