//
//  Plugin_OnLineMapUtility.m
//  AutoNavi
//
//  Created by huang longfeng on 13-3-4.
//
//

#import "Plugin_OnLineMapUtility.h"
#import "ITBT.h"
#import "ANParamValue.h"
#import "ANDataSource.h"

#import "FaceOverlay.h"
#import "FaceOverlayView.h"
//#import "MainViewController.h"

#import "ANOperateMethod.h"

#import "plugin_SearchPoiOperate.h"
#import "mapDataManage.h"
#import "GDBL_TTS.h"
#import "MWPreference.h"
#import "MWGuideOperator.h"
#import "MWMapOperator.h"
#import "MyCLController.h"
#import "MWPoiOperator.h"
#import "GDAlertView.h"

#define SUPPORTSIMU 0
#define SupportPlayGPS 0

static Plugin_OnLineMapUtility *sharedPlugin_OnLineMapUtility = nil;

@interface Plugin_OnLineMapUtility()
{
    GPOI  m_desPOI;
}

@end
@implementation Plugin_OnLineMapUtility

@synthesize m_mapViewState,m_maMapView,m_drawingView,isAmapView,m_onLineMapView,m_iCurSegNum,m_iIcon,m_remainDistance,m_remainTime,m_remainSegDistance,m_currentLoadName,m_nextLoadName,m_tollCount,mustAmapView,isEnterMap,isMove,isEnterNewView;
@synthesize isTBTRouteData; //存在路径时，0为纯本地数据，1为纯网络数据，2为本网结合数据中的本地数据
@synthesize m_viewControllerType; //地图视图所在的父视图控制器类型
@synthesize isSettingDes;  //为加载网络地图时，是否正在加载起点或终点，0为未设置，1为设置起点，2为设置终点
@synthesize isChangingMap; //导航时，由本地向网络过渡中
@synthesize isArriveWay;
@synthesize isAnimated;
@synthesize isSaveLocalDes; //是否设置本地POI为终点
@synthesize isAlertMOVEAlert;
@synthesize isAlertCCPAlert;
@synthesize isChangePage; //是否正在过渡页面，如：点的详细信息界面，按下导航按钮后，至主界面，
@synthesize isHasGPS;
@synthesize isShowPopPoi;
+ (Plugin_OnLineMapUtility *)sharedInstance
{
    if (nil==sharedPlugin_OnLineMapUtility)
	{
		sharedPlugin_OnLineMapUtility = [[Plugin_OnLineMapUtility alloc] init];
	}
	return sharedPlugin_OnLineMapUtility;
}

- (id)init {
	
	self = [super init];
	if (self)
	{
		m_saveType = SAVE_NONE;
        m_maMapView = nil;
        m_onLineMapView = nil;
        m_drawingView = nil;
        self.isAmapView = NO;
        isEnterMap = NO;
        isEnterNewView = NO;
        isSettingDes = 0;
        isTBTRouteData = 0;
        isHasGPS = YES;
#if   SupportPlayGPS
        [self readGPSLog:nil];
#endif
        
	}
	return self;
}

- (NSString *)keyForSearch
{
    return AmapKeySring;
}

#pragma mark -
#pragma mark normal method
// 进入全程概览
- (void)EnterBrowse
{
    [[NSNotificationCenter defaultCenter] postNotificationName:Utility_EnterBrowse_Notify object:nil];
}

// 获取当前道路名，剩余时间，下一道路名等
-(id)NET_GetMapInfoWithType:(NET_PARAMTYPE)type
{
    id mapInfo = nil;
    switch (type) {
        case NET_TurnIcon:
        {
            // mapInfo = ;
        }
            break;
        case NET_CurRoadName:
        {
            mapInfo = self.m_currentLoadName?self.m_currentLoadName:@"";
        }
            break;
        case NET_NextRoadName:
        {
            mapInfo = self.m_nextLoadName?self.m_nextLoadName:@"";
        }
            break;
        case NET_PathTotalTime:
        {
            int time = tbtNavi->GetRouteTime();
            NSUInteger hour = (time/3600);
            NSUInteger minute = (time%3600/60);
            if (hour >0)
            {
                mapInfo = [NSString stringWithFormat:@"%d%@%d%@",hour,STR(@"Universal_hour", @"Localizable"),minute,STR(@"Universal_min", @"Localizable")];  //导航路径剩余时间
            }
            else
            {
                mapInfo = [NSString stringWithFormat:@"%d%@",minute,STR(@"Universal_min", @"Localizable")];
            }
        }
            break;
        case NET_PathProportion:
        {
            
        }
            break;
        case NET_PathDistance:
        {
            int distance = tbtNavi->GetRouteLength();
            if (distance > 1000)
            {
                if (distance > 1000000)
                {
                    mapInfo = [NSString stringWithFormat:@"%0.0f%@",distance/1000.0,STR(@"Universal_KM", @"Localizable")];  //导航路径距离
                }
                else
                {
                    mapInfo = [NSString stringWithFormat:@"%0.1f%@",distance/1000.0,STR(@"Universal_KM", @"Localizable")];  //导航路径距离
                }
                
            }
            else
            {
                mapInfo = [NSString stringWithFormat:@"%d%@",distance,STR(@"Universal_M", @"Localizable")];  //导航路径距离
            }
        }
            break;
        case NET_CurPOI:
        {
            
        }
            break;
        case NET_RemainDistance:
        {
            mapInfo = self.m_remainDistance;
        }
            break;
        case NET_RemainTime:
        {
            mapInfo = self.m_remainTime;
        }
            break;
        case NET_RemainSegDistance:
        {
            mapInfo = self.m_remainSegDistance;
        }
            break;
        case NET_TollCount:
        {
            mapInfo = self.m_tollCount;
            
        }
            break;
        case NET_PathDistance_NS:
        {
            int distance = tbtNavi->GetRouteLength();
            mapInfo = [NSNumber numberWithInt:distance];
            
        }
            break;
        case NET_PathTotalTime_NS:
        {
            int time = tbtNavi->GetRouteTime();
            mapInfo = [NSNumber numberWithInt:time];
            
        }
            break;
        default:
            break;
    }
    return mapInfo;
}

#pragma mark 设置是否显示用户位置
- (void)SetShowUserLocation:(BOOL)show
{
    if (!m_maMapView)
    {
        return;
    }
    if (!show)
    {
        [self setCarColor:NO];
    }
    
    
    if (m_mapViewState == State_Navi || m_mapViewState == State_Guidance)
    {
        [[MWGuideOperator sharedInstance] MW_GuidanceOperateWithMainID:0 GuideHandle:NULL];
    }
    else
    {
        if (![ANParamValue sharedInstance].isPath)
        {
            m_maMapView.showsUserLocation = show;
            if (show)
            {
                [self MapZoomTO:[[ANDataSource sharedInstance] GMD_GetCurrentScale]];
            }
        }
    }
}

#pragma mark 判断是否有路径
- (BOOL)ExistRouteLine
{
    if (tbtNavi)
    {
        int route_num = 0;
        tbtNavi->GetAllRouteID(route_num);
        if (route_num > 0)
        {
            return YES;
        }
    }
    return NO;
}

#pragma mark 获取Amap地图旋转角度
- (CGFloat)GetRotationDegree
{
    return (360.0 - m_maMapView.rotationDegree);
}

#pragma mark 设置Amap地图旋转角度
- (void)SetRotationDegree:(CGFloat)degree
{
    [m_maMapView setRotationDegree:degree];
}

#pragma mark 改变父视图
- (void)ChangeSuperView:(UIView *)supView ViewType:(ViewController_Type)type
{
    m_viewControllerType = type;
    if (ViewController_Local == type)
    {
        m_maMapView.hidden = YES;
        m_drawingView.hidden = NO;
        self.isAmapView = NO;
        return;
    }
    else if (ViewController_MainDisappear == type || ViewController_POIDisappear == type)
    {
        return;
    }
    else if (ViewController_Main == type)
    {
        m_onLineMapView.userInteractionEnabled = YES;
        m_drawingView.userInteractionEnabled = YES;
        [self ShowMapMode];
    }
    else if (ViewController_Browse == type)
    {
        m_drawingView.hidden = isTBTRouteData;
        m_maMapView.hidden = !isTBTRouteData;
        self.isAmapView = isTBTRouteData;
        m_onLineMapView.userInteractionEnabled = NO;
        m_maMapView.showsUserLocation = NO;
    }
    else if (ViewController_POI == type)
    {
        m_drawingView.hidden = NO;
        m_maMapView.hidden = YES;
        self.isAmapView = NO;
        [self performSelector:@selector(ShowMapMode) withObject:nil afterDelay:0.5f];
    }
    else if (ViewController_Judge == type)
    {
        [self ShowMapMode];
        return;
    }
    else
    {
        m_onLineMapView.userInteractionEnabled = YES;
        m_drawingView.userInteractionEnabled = YES;
    }
    
    UIView *view = [m_onLineMapView superview];
    if (view == supView || supView == nil)
    {
        
        return;
    }
    [m_onLineMapView retain];
    [m_onLineMapView removeFromSuperview];
    [supView addSubview:(UIView *)m_onLineMapView];
    [supView sendSubviewToBack:(UIView *)m_onLineMapView];
}

#pragma mark 改变视图中心
- (void)SetAmapCenterWithLon:(double)lon Lat:(double)lat
{
    if (lon == 0 || lat == 0)
    {
        return;
    }
    [m_maMapView setCenterCoordinate:CLLocationCoordinate2DMake(lat, lon) animated:NO];
}

#pragma mark 获取Amap视图中心点
- (CLLocationCoordinate2D)NET_GetAmapCenter
{
    CLLocationCoordinate2D center = {0};
    if (m_maMapView)
    {
        center = m_maMapView.centerCoordinate;
    }
    return center;
}

#pragma mark 根据移动的矢量改变地图中心坐标
- (void)SetAmapCenterWithDragX:(float)drag_x DragY:(double)dra_y
{
    CLLocationCoordinate2D center = m_maMapView.centerCoordinate;
    CGPoint center_point = [m_maMapView convertCoordinate:center toPointToView:m_maMapView];
    center_point.x += drag_x;
    center_point.y += dra_y;
    
    CLLocationCoordinate2D move_coord = [m_maMapView convertPoint:center_point toCoordinateFromView:m_maMapView];
    [m_maMapView setCenterCoordinate:move_coord animated:NO];
    isMove = YES;
    
    [m_onLineMapView ShowLableAndViewWithMapCenter:move_coord];
}

#pragma mark 根据坐标点改变地图中心坐标
- (CGPoint)ConvertCoordToScreenWithLon:(double)lon Lat:(double)lat
{
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat, lon);
    CGPoint point = [m_maMapView convertCoordinate:coord toPointToView:m_maMapView];
    [Plugin_OnLineMapUtility sharedInstance].isMove = YES;
    return point;
}

#pragma mark 通过判断中心坐标是否有数据，显示当前地图（在线，本地）
- (void)ShowMapMode
{
    if (![ANParamValue sharedInstance].netWorkMap || [ANParamValue sharedInstance].isNavi)
    {
        m_drawingView.hidden = NO;
        self.isAmapView = NO;
        return;
    }
    
    if (mustAmapView)
    {
        m_maMapView.hidden = NO;
        m_drawingView.hidden = YES;
        self.isAmapView = YES;
        return;
    }
    
    if (!isEnterMap)//未进入主地图，则返回
    {
        return;
    }
    if (isEnterNewView)//进入开机新功能浏览界面，则返回
    {
        return;
    }
    
    if (m_viewControllerType == ViewController_Browse || m_viewControllerType == ViewController_Local || m_viewControllerType == ViewController_MainDisappear || m_viewControllerType == ViewController_POIDisappear) //全程概览界面和只显示本地地图的界面,或者离开主界面，不做地图切换，则返回
    {
        return;
    }
    if (isChangingMap) //导航中正由本地地图向网络地图过渡。
    {
        return;
    }
    
    BOOL isAmap = NO;
    long lon;
    long lat;
    if (self.isAmapView)
    {
        lon = m_maMapView.centerCoordinate.longitude * 1000000;
        lat = m_maMapView.centerCoordinate.latitude * 1000000;
        isAmap = YES;
        if ([self ExistRouteLine]) {
            curMapCountType = 3;
        }
        else{
            curMapCountType = 2;
        }
        
    }
    else
    {
        isAmap = NO;
        if ([mapDataManage getMapDataType] != 0)
        {
            GMAPCENTERINFO mapinfo = {0};
            GDBL_GetMapCenterInfo(&mapinfo);
            lon = mapinfo.CenterCoord.x;
            lat = mapinfo.CenterCoord.y;
            if ([ANParamValue sharedInstance].isPath && ![ANParamValue sharedInstance].isNavi) {
                curMapCountType = 1;
            }
            else{
                curMapCountType = 0;
            }
        }
    }
    
    int sign;
    if ([ANParamValue sharedInstance].isPath) //如果为有路径状态
    {
        sign = [self IsStartIsNetMap];
        if (sign == 0)//有路径情况下车标处于有数据区域，则以地图中心点为依据判断是否切图
        {
            sign = [[ANDataSource sharedInstance] GMD_GetCurDrawMapViewTypeWithLon:lon Lat:lat];
        }
    }
    else
    {
        sign = [[ANDataSource sharedInstance] GMD_GetCurDrawMapViewTypeWithLon:lon Lat:lat];
    }
    
    if ([ANParamValue sharedInstance].isMove)
    {
        //        isAlertCCPAlert = NO;
    }
    else
    {
        if (m_viewControllerType == ViewController_Main)
        {
            isAlertMOVEAlert = NO;
        }
    }
    
    if (sign == 1 || sign ==2)
    {
        if (m_onLineMapView.isMapInit == 1) //网络地图正在初始化中
        {
            return;
        }
        if (m_maMapView == nil)
        {
            if ([ANParamValue sharedInstance].isMove)
            {
                if (!self.isAlertMOVEAlert)
                {
                    isAlertMOVEAlert = YES;
                    [m_onLineMapView NET_AskForUseNetMap];
                }
            }
            else
            {
                if (!self.isAlertCCPAlert)
                {
                    isAlertCCPAlert = YES;
                    [m_onLineMapView NET_AskForUseNetMap];
                }
            }
            
            return;
        }
        if (m_onLineMapView.isMapInit != 2) //未初始化结束
        {
            return;
        }
        
        if (sign == 1)
        {
            self.isAmapView = YES;
            m_maMapView.hidden = NO;
            m_drawingView.hidden = YES;
            if (!isAmap)
            {
                m_maMapView.centerCoordinate = CLLocationCoordinate2DMake((double)lat/1000000.0, (double)lon/1000000.0);
                [self MapZoomTO:[[ANDataSource sharedInstance] GMD_GetCurrentScale]];
                UIView *view = [m_onLineMapView superview];
                [view sendSubviewToBack:m_onLineMapView];
            }
            
        }
    }
    else
    {
        self.isAmapView = NO;
        m_drawingView.hidden = NO;
        m_maMapView.hidden = YES;
        if (isAmap)
        {
            if (!isMove)
            {
                
                [[MWMapOperator sharedInstance] MW_GoToCCP];
            }
            else
            {
                
                GCOORD coord = {lon,lat};
                GMOVEMAP moveMap;
                moveMap.eOP = MOVEMAP_OP_GEO_DIRECT;
                moveMap.deltaCoord = coord;
                [[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
                UIView *view = [m_onLineMapView superview];
                [view sendSubviewToBack:m_onLineMapView];
            }
        }
    }
    
}

#pragma mark 传入信息到行车电脑
-(void)NET_PassInfoToDrive
{
    if (!tbtNavi)
    {
        return;
    }
    if (isArriveWay)
    {
        return;
    }
    if (m_onLineMapView->isOffRoute)
    {
        return;
    }
    GCARINFO pCarInfo;
    GDBL_GetCarInfo(&pCarInfo);
    
    GGPSINFO pGpsInfo1 = {0};
    GDBL_GetGPSInfo(&pGpsInfo1);
    
    int iItenNum = 0;
    NaviGuideItem *naviGuideItem;
    naviGuideItem = tbtNavi->GetNaviGuideList(iItenNum);
    
    NSString *nextLoadName = nil;
    if (iItenNum <= m_iCurSegNum + 1)
    {
        m_iCurSegNum = iItenNum - 1;
        nextLoadName = @"目的地";
    }
    else
    {
        nextLoadName = [[[NSString alloc] initWithBytes:naviGuideItem[m_iCurSegNum+1].m_pwName length:naviGuideItem[m_iCurSegNum+1].m_iNameLengh*2 encoding:NSUTF16LittleEndianStringEncoding] autorelease];
    }
    
    if ([nextLoadName length] == 0)
    {
        nextLoadName = STR(@"Main_unNameRoad", @"Main");
    }
    
    if (m_iCurSegNum < 0)
    {
        m_iCurSegNum = 0;
    }
    NSDictionary *tmpNaviInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                 nextLoadName,@"roadName",
                                 [self NET_GetMapInfoWithType:NET_RemainSegDistance],@"distance",
                                 [[ANDataSource sharedInstance] GMD_GetIconWithAmapID:naviGuideItem[m_iCurSegNum].m_iIcon imageID:NULL],@"dir",
                                 [NSString stringWithFormat:@"%d",0],@"demospeed",
                                 [NSString stringWithFormat:@"%d",pGpsInfo1.nSpeed],@"speed",
                                 [NSNumber numberWithInt:(450- pCarInfo.nAzimuth)],@"cardirection",
                                 nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_PASSINFOTODRIVE object:nil userInfo:tmpNaviInfo
     ];
    tmpNaviInfo = nil;
}

#pragma mark 回车位
- (void)BackToCar
{
    if (!m_maMapView)
    {
        return;
    }
    if (m_mapViewState == State_EmulatorNavi)
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GOTOCPP object:nil];
        [m_onLineMapView Net_ActionWityType:NET_Action_GotoCCP object:nil];
        return;
    }
    if (m_mapViewState == State_Navi)
    {
        OnLinePOI poi = [m_onLineMapView Net_GetPoint:0];
        CLLocationCoordinate2D Coord = poi.coord;
        [m_maMapView setCenterCoordinate:Coord];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GOTOCPP object:nil];
        [m_onLineMapView Net_ActionWityType:NET_Action_GotoCCP object:nil];
        return;
    }
    
    
    OnLinePOI poi = [m_onLineMapView Net_GetPoint:0];
    CLLocationCoordinate2D Coord = poi.coord;
    [m_maMapView setCenterCoordinate:Coord];
    [m_maMapView setRotationDegree:0 animated:NO duration:0.0f];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GOTOCPP object:nil];
    [m_onLineMapView Net_ActionWityType:NET_Action_GotoCCP object:nil];
}


#pragma mark - 关闭电子眼 移动交通台等

- (void)Net_OpenCamera:(BOOL)open
{
    if (m_onLineMapView == NULL)
    {
        return;
    }
    else
    {
        if (m_onLineMapView->tbtNavi == NULL)
        {
            return;
        }
    }
    if (open)
    {
        m_onLineMapView->tbtNavi->OpenCamera();
    }
    else
    {
        m_onLineMapView->tbtNavi->CloseCamera();
    }
}

- (void)Net_OpenTrafficRadio:(BOOL)open
{
    if (m_onLineMapView == NULL)
    {
        return;
    }
    else
    {
        if (m_onLineMapView->tbtNavi == NULL)
        {
            return;
        }
    }
    if (open)
    {
        m_onLineMapView->tbtNavi->OpenTrafficRadio();
    }
    else
    {
        m_onLineMapView->tbtNavi->CloseTrafficRadio();
    }
}

- (void)Net_OpenTMC:(BOOL)open
{
    if (m_onLineMapView == NULL)
    {
        return;
    }
    else
    {
        if (m_onLineMapView->tbtNavi == NULL)
        {
            return;
        }
    }
    if (open)
    {
        m_onLineMapView->tbtNavi->OpenTMC();
    }
    else
    {
        m_onLineMapView->tbtNavi->CloseTMC();
    }
}

- (void)Net_OpenTrafficPanel:(BOOL)open
{
    if (m_onLineMapView == NULL)
    {
        return;
    }
    else
    {
        if (m_onLineMapView->tbtNavi == NULL)
        {
            return;
        }
    }
    if (open)
    {
        m_onLineMapView->tbtNavi->OpenTrafficPanel();
    }
    else
    {
        m_onLineMapView->tbtNavi->CloseTrafficPanel();
    }
}

#pragma mark - 放大 缩小
- (void)MapZoomTO:(NSString *)scale
{
    if (!m_maMapView)
    {
        return;
    }
    [m_onLineMapView Net_ActionWityType:NET_Action_ZoomTo object:scale];
}

- (void)MapZoomIN:(NSString *)scale
{
    if (!m_maMapView)
    {
        return;
    }
    [m_onLineMapView Net_ActionWityType:NET_Action_ZoomIN object:scale];
}

- (void)MapZoomOut:(NSString *)scale
{
    if (!m_maMapView)
    {
        return;
    }
    [m_onLineMapView Net_ActionWityType:NET_Action_ZoomOut object:scale];
}


// 获取Amap地图比例尺
- (double)CalScale
{
    double scale;
    //    1> 获取当前地图的可见区域
    MAMapRect visibleMapRect = m_maMapView.visibleMapRect;
    
    //    2> 获取地图左上角与右上角的投影坐标.
    MAMapPoint leftTopMapPoint  = visibleMapRect.origin;
    MAMapPoint rightTopMapPoint = MAMapPointMake(MAMapRectGetMaxX(visibleMapRect),MAMapRectGetMinY(visibleMapRect));
    
    //    3> 计算出左上角与右上角的真实距离(单位米)
    //    CLLocationDistance distance = 0.0;MAMetersBetweenMapPoints
    CLLocationDistance distance = MAMetersBetweenMapPoints(leftTopMapPoint, rightTopMapPoint);
    
    //    4> 根据比例尺view的width 按照比例来计算出对应的真实距离
    //    如：比例尺view的宽度为100, 则对应的真实距离 = 100 * distance / CGRectGetWidth(mapView.bounds).
    scale = distance/CGRectGetWidth(m_maMapView.bounds);
    return scale;
}



// 获取高德导航地图比例尺
- (double)GetAmapScaleFromGDmap:(NSString *)scale lastScale:(double *)lastscale nextScale:(double *)nextScale latScaleStr:(NSString **)lastscaleStr nextScaleStr:(NSString **)nextscaleStr
{
    double CurrentScale;
//    if ([scale isEqualToString:@"500km"])
//    {
//        CurrentScale = 13600;
//        *lastscale = 13600;
//        *nextScale = 5800;
//        *lastscaleStr = @"500km";
//        *nextscaleStr = @"200km";
//    }
//    else
    if ([scale isEqualToString:@"200km"])
    {
        CurrentScale = 5800;
        *lastscale = 5800;
        *nextScale = 530;
        *lastscaleStr = @"200km";
        *nextscaleStr = @"50km";
    }
    else if ([scale isEqualToString:@"50km"])
    {
        CurrentScale = 530;
        *lastscale = 5800;
        *nextScale = 120;
        *lastscaleStr = @"200km";
        *nextscaleStr = @"10km";
    }
    else if ([scale isEqualToString:@"10km"])
    {
        CurrentScale = 120;
        *lastscale = 530;
        *nextScale = 60;
        *lastscaleStr = @"50km";
        *nextscaleStr = @"5km";
    }
    else if ([scale isEqualToString:@"5km"])
    {
        CurrentScale = 60;
        *lastscale = 120;
        *nextScale = 24;
        *lastscaleStr = @"10km";
        *nextscaleStr = @"2km";
    }
    else if ([scale isEqualToString:@"2km"])
    {
        CurrentScale = 24;
        *lastscale = 60;
        *nextScale = 12;
        *lastscaleStr = @"5km";
        *nextscaleStr = @"1km";
    }
    else if ([scale isEqualToString:@"1km"])
    {
        CurrentScale = 12;
        *lastscale = 24;
        *nextScale = 6;
        *lastscaleStr = @"2km";
        *nextscaleStr = @"500m";
    }
    else if ([scale isEqualToString:@"500m"])
    {
        CurrentScale = 6;
        *lastscale = 12;
        *nextScale = 2.4;
        *lastscaleStr = @"1km";
        *nextscaleStr = @"200m";
    }
    else if ([scale isEqualToString:@"200m"])
    {
        CurrentScale = 2.4;
        *lastscale = 6;
        *nextScale = 1.2;
        *lastscaleStr = @"500m";
        *nextscaleStr = @"100m";
    }
    else if ([scale isEqualToString:@"100m"])
    {
        CurrentScale = 1.2;
        *lastscale = 2.4;
        *nextScale = 0.6;
        *lastscaleStr = @"200m";
        *nextscaleStr = @"50m";
    }
    else if ([scale isEqualToString:@"50m"])
    {
        CurrentScale = 0.6;
        *lastscale = 1.2;
        *nextScale = 0.3;
        *lastscaleStr = @"100m";
        *nextscaleStr = @"25m";
    }
    else if ([scale isEqualToString:@"25m"])
    {
        CurrentScale = 0.3;
        *lastscale = 0.6;
        *nextScale = 0.3;
        *lastscaleStr = @"50m";
        *nextscaleStr = @"25m";
    }
    else
    {
        CurrentScale = 24;
        *lastscale = 60;
        *nextScale = 12;
        *lastscaleStr = @"5km";
        *nextscaleStr = @"1km";
    }
    return CurrentScale;
}


#pragma mark - 根据类型,经纬度，设置点的类型，0为起点，6为终点;设置途径点

- (void)SetPointWithType:(int)type andPOI:(GPOI)desPOI
{
    isAlertMOVEAlert = YES;
    if (type == 0)
    {
        [self SetCarPositionWithLon:desPOI.Coord.x/1000000.0 Lat:desPOI.Coord.y/1000000.0];
        isMove = NO;
        //        [[MWMapOperator sharedInstance] MW_GoToCCP];
    }
    else if (type == 6)
    {
        GPOI PointInfo = {0};
        CLLocationCoordinate2D coord;
        GSTATUS res;
        if (!isAmapView)
        {
            GCARINFO carinfo = {0};
            GDBL_GetCarInfo(&carinfo);
            PointInfo.Coord.x = carinfo.Coord.x;
            PointInfo.Coord.y = carinfo.Coord.y;
        }
        else
        {
            OnLinePOI poi = [m_onLineMapView Net_GetPoint:0];
            
            PointInfo.Coord.x = poi.coord.longitude * 1000000.0;
            PointInfo.Coord.y = poi.coord.latitude * 1000000.0;
        }
        
        GDBL_AddJourneyPoint(GJOURNEY_START, &PointInfo);
        
        coord = CLLocationCoordinate2DMake(desPOI.Coord.y/1000000.0, desPOI.Coord.x/1000000.0);
        
        
        desPOI.Coord.x = coord.longitude * 1000000.0;
        desPOI.Coord.y = coord.latitude * 1000000.0;
   
        res = GDBL_AddJourneyPoint(GJOURNEY_GOAL, &desPOI);
        
        OnLinePOI poi = {0};
        poi.coord = coord;
        poi.offset.longitude = (float)desPOI.siELonOff/1000000.0;
        poi.offset.latitude = (float)desPOI.siELonOff/1000000.0;
        [m_onLineMapView Net_SetPoint:6 PoiInfo:poi];
        
        [self ShowAbsentCityNameWithTag:1];
    }
    else
    {
       
    }
    
}

- (void)SetPointWithType:(int)type;
{
    [m_onLineMapView Net_ClearPassBy];
    isAlertMOVEAlert = YES;
    if (type == 0)
    {
        [self SetCarPosition];
        isMove = NO;
    }
    else if (type == 6)
    {
        GPOI PointInfo = {0};
        CLLocationCoordinate2D coord;
        GSTATUS res;
        if (!isAmapView)
        {
            GCARINFO carinfo = {0};
            GDBL_GetCarInfo(&carinfo);
            PointInfo.Coord.x = carinfo.Coord.x;
            PointInfo.Coord.y = carinfo.Coord.y;
            
            GMAPCENTERINFO mapinfo = {0};
            GDBL_GetMapCenterInfo(&mapinfo);
            coord.longitude = (double)mapinfo.CenterCoord.x/1000000.0;
            coord.latitude = (double)mapinfo.CenterCoord.y/1000000.0;
        }
        else
        {
            OnLinePOI poi = [m_onLineMapView Net_GetPoint:0];
            PointInfo.Coord.x = poi.coord.longitude * 1000000.0;
            PointInfo.Coord.y = poi.coord.latitude * 1000000.0;
            
            CGPoint screenXY = CGPointMake(m_maMapView.bounds.size.width/2, m_maMapView.bounds.size.height/2);
            coord = [m_maMapView convertPoint:screenXY toCoordinateFromView:m_maMapView];
        }
        GDBL_AddJourneyPoint(GJOURNEY_START, &PointInfo);
        
        PointInfo.Coord.x = coord.longitude * 1000000.0;
        PointInfo.Coord.y = coord.latitude * 1000000.0;
        res = GDBL_AddJourneyPoint(GJOURNEY_GOAL, &PointInfo);
        
        OnLinePOI poi = {0};
        poi.coord = coord;
        [m_onLineMapView Net_SetPoint:6 PoiInfo:poi];
        
        [self ShowAbsentCityNameWithTag:1];
    }
    else
    {
        if (isTBTRouteData == 0)
        {
            plugin_PoiNode *node = [[MWGuideOperator sharedInstance] MW_GetJourneyPointWithID:6];
            
            CLLocationCoordinate2D temp = {0};
            temp.latitude = (double)node.lLat/1000000.0;
            temp.longitude = (double)node.lLon/1000000.0;
            
            OnLinePOI poi = {0};
            poi.coord = temp;
            [m_onLineMapView Net_SetPoint:6 PoiInfo:poi];
        }
        
        
        OnLinePOI coord[3];
        coord[0] = [m_onLineMapView Net_GetPoint:0];
        
        coord[2] = [m_onLineMapView Net_GetPoint:6];
        if (!isAmapView)
        {
            GMAPCENTERINFO mapinfo = {0};
            GDBL_GetMapCenterInfo(&mapinfo);
            coord[1].coord.longitude = (double)mapinfo.CenterCoord.x/1000000.0;
            coord[1].coord.latitude = (double)mapinfo.CenterCoord.y/1000000.0;
        }
        else
        {
            CGPoint screenXY = CGPointMake(m_maMapView.bounds.size.width/2, m_maMapView.bounds.size.height/2);
            coord[1].coord = [m_maMapView convertPoint:screenXY toCoordinateFromView:m_maMapView];
        }
        [self SetPassByWithCoord:coord Count:3];
    }
}

- (void)SetPassByWithCoord:(OnLinePOI *)passByCoord Count:(int)count
{
    [m_onLineMapView Net_ClearPassBy];
    
    for (int i = 0; i < count ; i++)
    {
        if (i != count - 1)
        {
            [m_onLineMapView Net_SetPoint:i PoiInfo:passByCoord[i]];
        }
        else
        {
            [m_onLineMapView Net_SetPoint:6 PoiInfo:passByCoord[i]];
        }
    }
    
    if (isTBTRouteData == 0)
    {
        [self ShowAbsentCityNameWithTag:2];
    }
    else
    {
        [self SetEndPoint:1];
    }
    
}

- (void)NET_SetRouteWithLocalCoord
{
    GPOI *ppJourneyPoint;
    GDBL_GetJourneyPoint(&ppJourneyPoint);
    
    GCARINFO pCarInfo;
    GDBL_GetCarInfo(&pCarInfo);
    strcpy(ppJourneyPoint[0].szName, pCarInfo.szRoadName);
    
    OnLinePOI poi[7] = {0};
    
    for (int i = 0; i < 7; i++)
    {
        poi[i].coord.longitude = (double)ppJourneyPoint[i].Coord.x / 1000000.0;
        poi[i].coord.latitude = (double)ppJourneyPoint[i].Coord.y / 1000000.0;
        poi[i].offset.longitude = (double)ppJourneyPoint[i].siELonOff / 1000000.0;
        poi[i].offset.latitude = (double)ppJourneyPoint[i].siELatOff / 1000000.0;
        strcpy(poi[i].name, ppJourneyPoint[i].szName);
    }
    
    [self SetPassByWithCoord:poi Count:7];
}

//判断点是否处于海的位置
- (BOOL)isInTheSeaWithLon:(double)lon Lat:(double)lat
{
    int sign = [[ANDataSource sharedInstance] GMD_GetCurDrawMapViewTypeWithLon:lon * 1000000.0 Lat:lat * 1000000.0];
    if (sign == 2)
    {
        [self MyalertView:STR(@"NetMap_FarFromTheRoad", @"NetMap") canceltext:nil othertext:STR(@"Universal_ok", @"Localizable") alerttag:-1 ];
        return YES;
    }
    return NO;
}

// 添加车标
- (void)NET_AddCarWithCoord:(CLLocationCoordinate2D)coord
{
    if (m_maMapView == nil)
    {
        return;
    }
    MyCustomAnnotation *CarPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_Car_Point] autorelease];
    CarPointAnn.coordinate = coord;
    [m_maMapView addAnnotation:CarPointAnn];
    [self SynLocalCarPositionWithNet];
}

/*
    网络地图添加可点击图标
    
 coord：添加的经纬度坐标
 image:地图上显示的图片
 delegate：点击后的回调委托
 tag：标识
 
 */
- (void)NET_AddClickImageWithCoord:(CLLocationCoordinate2D)coord image:(UIImage *)image delegate:(id<OnLineMapClickImageDelegate>)delegate tag:(int)tag
{
    if (m_maMapView == nil)
    {
        return;
    }
    MyCustomAnnotation *CarPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_ClickImage_Point] autorelease];
    CarPointAnn.coordinate = coord;
    CarPointAnn.m_onLineMapClickImageDelegate = delegate;
    CarPointAnn.m_tag = tag;
    CarPointAnn.m_clickImage = image;
    [m_maMapView addAnnotation:CarPointAnn];
    
    if (m_clickImageArray == nil)
    {
        m_clickImageArray = [[NSMutableArray alloc] init];
    }
    
    [m_clickImageArray addObject:CarPointAnn];
}

/*
 网络地图添加可点击图标
 
 poi：添加的poi信息
 image:地图上显示的图片
 delegate：点击后的回调委托
 tag：标识
 
 */
- (void)NET_AddClickImageWith:(MWPoi *)poi image:(UIImage *)image delegate:(id<OnLineMapClickImageDelegate>)delegate tag:(int)tag
{
    if (m_maMapView == nil)
    {
        return;
    }
    CLLocationCoordinate2D coord = {0};
    coord.longitude = (double)poi.longitude/1000000.0;
    coord.latitude = (double)poi.latitude/1000000.0;
    MyCustomAnnotation *CarPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_ClickPoi] autorelease];
    CarPointAnn.coordinate = coord;
    CarPointAnn.m_onLineMapClickImageDelegate = delegate;
    CarPointAnn.m_tag = tag;
    CarPointAnn.m_clickImage = image;
    [m_maMapView addAnnotation:CarPointAnn];
    
    if (m_clickImageArray == nil)
    {
        m_clickImageArray = [[NSMutableArray alloc] init];
    }
    
    [m_clickImageArray addObject:CarPointAnn];
}
/*
 网络地图清除所有可点击图标
 */
- (void)NET_ClearAllClickImage
{
    if (!m_maMapView)
    {
        return;
    }
    [m_maMapView removeAnnotations:m_clickImageArray];
    [m_clickImageArray release];
    m_clickImageArray = nil;
}


// 设置起点
- (void)SetCarPosition
{
    CLLocationCoordinate2D coord;
    if (m_maMapView == nil)
    {
        isSettingDes = 2;
        GMAPCENTERINFO mapinfo = {0};
        GDBL_GetMapCenterInfo(&mapinfo);
        coord.longitude = (double)mapinfo.CenterCoord.x/1000000.0;
        coord.latitude = (double)mapinfo.CenterCoord.y/1000000.0;
        
        OnLinePOI poi = {0};
        poi.coord = coord;
        [m_onLineMapView Net_SetPoint:0 PoiInfo:poi];
        
        [m_onLineMapView NET_AskForUseNetMap];
        return;
    }
    
    if (!isAmapView)
    {
        GMAPCENTERINFO mapinfo = {0};
        GDBL_GetMapCenterInfo(&mapinfo);
        coord.longitude = (double)mapinfo.CenterCoord.x/1000000.0;
        coord.latitude = (double)mapinfo.CenterCoord.y/1000000.0;
    }
    else
    {
        CGPoint screenXY = CGPointMake(m_maMapView.bounds.size.width/2, m_maMapView.bounds.size.height/2);
        coord = [m_maMapView convertPoint:screenXY toCoordinateFromView:m_maMapView];
    }
    
    if ([self isInTheSeaWithLon:coord.longitude Lat:coord.latitude])  //处于海则返回
    {
        return;
    }
    self.isTBTRouteData = 0;
    
    GDBL_StopGuidance();//每次设终点计算前都删除旧路线
    GDBL_ClearDetourRoad();//删除所有避让内容
    GDBL_ClearJourneyPoint();
    
    isMove = NO;
    
    MyCustomAnnotation *CarPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_Car_Point] autorelease];
    
    
    CarPointAnn.coordinate = coord;
    tbtNavi->SetCarLocation(2, coord.longitude, coord.latitude);
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_BEGINPOINT object:nil];
    [m_onLineMapView Net_ActionWityType:NET_Action_SetCarPosition object:CarPointAnn];
}

- (void)SetCarPositionWithLon:(double)lon Lat:(double)lat
{
    if (m_maMapView == nil)
    {
        isSettingDes = 2;
        CLLocationCoordinate2D center = {lat,lon};
        
        OnLinePOI poi = {0};
        poi.coord = center;
        [m_onLineMapView Net_SetPoint:0 PoiInfo:poi];
        
        [m_onLineMapView NET_AskForUseNetMap];
        return;
    }
    //此处的不需要设置状态，
    if ([self isInTheSeaWithLon:lon Lat:lat])  //处于海则返回
    {
        return;
    }
    self.isTBTRouteData = 0;
    
    //    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_BEGINPOINT object:nil];
    MyCustomAnnotation *CarPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_Car_Point] autorelease];
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat, lon);
    CarPointAnn.coordinate = coord;
    tbtNavi->SetCarLocation(2, coord.longitude, coord.latitude);
    [m_onLineMapView Net_ActionWityType:NET_Action_SetCarPosition object:CarPointAnn];
    if (m_onLineMapView.isMapInit == 2) // 地图初始化已结束
    {
        GDBL_StopGuidance();//每次设终点计算前都删除旧路线
        GDBL_ClearDetourRoad();//删除所有避让内容
        GDBL_ClearJourneyPoint();
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_BEGINPOINT object:nil];
    }
}
// 设置终点
/*
 type == 6为终点，否则都为途经点，途经点至多三个。
 */
- (void)SetEndPoint:(int)type
{
    if (type == 6)
    {
        if (m_maMapView == nil)
        {
            [m_onLineMapView NET_AskForUseNetMap];
            isSettingDes = 1;
            return;
        }
        
        m_mapViewState = State_SetEnd;
        
        OnLinePOI poi = [m_onLineMapView Net_GetPoint:6];
        CLLocationCoordinate2D coord;
        coord = poi.coord;
        
        if ([self isInTheSeaWithLon:coord.longitude Lat:coord.latitude])  //处于海则返回
        {
            return;
        }
        
        GDBL_StopGuidance();//每次设终点计算前都删除旧路线
        GDBL_ClearDetourRoad();//删除所有避让内容
        GDBL_ClearJourneyPoint();
        
        
        /*0	速度优先（推荐道路）
         1	费用优先（尽量避开收费道路）
         2	距离优先（距离最短）*/
        int net_route_option = -1;
        int local_route_option = [[MWPreference sharedInstance] getValue:PREF_ROUTE_OPTION];
        if( local_route_option == 0 || local_route_option == 1)
        {
            net_route_option = 0;
        }
        else if( local_route_option == 2)
        {
            net_route_option = 1;
        }
        else if( local_route_option == 3)
        {
            net_route_option = 2;
        }
        
        
        int sign = 0;
#if   SupportPlayGPS
        int count = [m_gpsInfoArray count];
        if (count < 1)
        {
            return;
        }
        NSString *GPS_info = [m_gpsInfoArray objectAtIndex:0];
        NSArray *array = [GPS_info componentsSeparatedByString:@","];
        int lon = [[array objectAtIndex:0] intValue];
        int lat = [[array objectAtIndex:1] intValue];
        double tempstart[2] = {(double)lon/1000000.0,(double)lat/1000000.0};
        
        
        for (int i = count - 1; i > 0; i--)
        {
            GPS_info = [m_gpsInfoArray objectAtIndex:i];
            if ([GPS_info length] > 10)
            {
                break;
            }
        }
        array = [GPS_info componentsSeparatedByString:@","];
        lon = [[array objectAtIndex:0] intValue];
        lat = [[array objectAtIndex:1] intValue];
        double tempEnd[2] = {(double)lon/1000000.0,(double)lat/1000000.0};
        sign = tbtNavi->RequestRouteWithStart(net_route_option, 1, tempstart, 1, tempEnd);
#else
        poi = [m_onLineMapView Net_GetPoint:0];
        double tempstart[2] = {poi.coord.longitude,poi.coord.latitude};
        double tempEnd[2] = {coord.longitude,coord.latitude};
        sign = tbtNavi->RequestRouteWithStart(net_route_option, 1, tempstart, 1, tempEnd);
#endif
        if (sign)
        {
            [m_onLineMapView Net_ActionWityType:NET_Action_SetEnd object:nil];
            OnLinePOI end_poi = {0};
            end_poi.coord = coord;
            [m_onLineMapView Net_SetPoint:6 PoiInfo:end_poi];
            if (!m_onLineMapView->isOffRoute)
            {
                [self SaveHistoryDes];
            }
        }
    }
    else
    {
        if (m_maMapView == nil)
        {
            [m_onLineMapView NET_AskForUseNetMap];
            isSettingDes = 4;
            return;
        }
        m_mapViewState = State_SetPassBy;
        GDBL_StopGuidance();//每次设终点计算前都删除旧路线
        GDBL_ClearDetourRoad();//删除所有避让内容
        GDBL_ClearJourneyPoint();
        
        CLLocationCoordinate2D coord;
        int passByCount = 0;
        double tempEnd[8] = {0};
        
        for (int i = 0; i < 3; i ++)
        {
            OnLinePOI poi = [m_onLineMapView Net_GetPoint:i + 1];
            coord = poi.coord;
            
            if (coord.latitude > 0 && coord.longitude > 0)
            {
                tempEnd[2 * passByCount] = coord.longitude;
                tempEnd[2 * passByCount + 1] = coord.latitude;
                passByCount ++;
                
                if ([self isInTheSeaWithLon:coord.longitude Lat:coord.latitude])  //处于海则返回
                {
                    return;
                }
            }
        }
        
        /*0	速度优先（推荐道路）
         1	费用优先（尽量避开收费道路）
         2	距离优先（距离最短）*/
        int net_route_option = -1;
        int local_route_option = [[MWPreference sharedInstance] getValue:PREF_ROUTE_OPTION];
        if( local_route_option == 0 || local_route_option == 1)
        {
            net_route_option = 0;
        }
        else if( local_route_option == 2)
        {
            net_route_option = 1;
        }
        else if( local_route_option == 3)
        {
            net_route_option = 2;
        }
        int sign = 0;
        OnLinePOI poi = [m_onLineMapView Net_GetPoint:0];
        double tempstart[2] = {poi.coord.longitude,poi.coord.latitude};
        
        poi = [m_onLineMapView Net_GetPoint:6];
        tempEnd[2 * passByCount] = poi.coord.longitude + poi.offset.longitude;
        tempEnd[2 * passByCount + 1] = poi.coord.latitude + poi.offset.latitude;
        passByCount++;
        
        sign = tbtNavi->RequestRouteWithStart(net_route_option, 1, tempstart, passByCount, tempEnd);
        if (sign)
        {
            [m_onLineMapView Net_ActionWityType:NET_Action_SetPassBy object:nil];
            [m_onLineMapView Net_SetPoint:6 PoiInfo:poi];
            if (!m_onLineMapView->isOffRoute)
            {
                [self SaveHistoryDes];
            }
        }
        
    }
    
}

// 设终点－填充poi值
- (void)NET_SetEndingPOI:(GPOI)endingPOI
{
    if (endingPOI.szName)
    {
        memset(m_desPOI.szName, 0, (GMAX_POI_NAME_LEN+1)*sizeof(Gchar));
        memcpy(m_desPOI.szName, endingPOI.szName, (GMAX_POI_NAME_LEN+1)*sizeof(Gchar));
    }
    if (endingPOI.szAddr)
    {
        memset(m_desPOI.szAddr, 0, (GMAX_POI_NAME_LEN+1)*sizeof(Gchar));
        memcpy(m_desPOI.szAddr, endingPOI.szAddr, (GMAX_POI_NAME_LEN+1)*sizeof(Gchar));
    }
    m_desPOI.Coord.x = endingPOI.Coord.x;
    m_desPOI.Coord.y = endingPOI.Coord.y;
    m_desPOI.siELonOff = endingPOI.siELonOff;
    m_desPOI.siELatOff = endingPOI.siELatOff;
    m_desPOI.lCategoryID = endingPOI.lCategoryID;
}

- (void)ShowAmapNaviAlertWithContent:(NSString *)content tag:(int)tag //弹出提示框是否使用网络导航
{
    
    __block id weakDelegate = self;
    GDAlertView* alert = [[GDAlertView alloc] initWithTitle:nil andMessage:content];

    [alert addButtonWithTitle:STR(@"NetMap_LoadData", @"NetMap") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView)
     {
         if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
         {
             [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:0];
         }
     }];
    
    [alert addButtonWithTitle:STR(@"NetMap_NetNavi", @"NetMap") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView)
     {
         if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
         {
             [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:1];
         }
     }];
    [alert addButtonWithTitle:STR(@"Universal_cancel", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView)
     {
         if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
         {
             [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:2];
         }
     }];
    alert.tag = tag;
    [alert show];
    [alert release];
}

#pragma mark 起点(车位点)是否有数据
- (int)IsStartIsNetMap //0为本地地图，1网络地图
{
    if (m_maMapView == nil)
    {
        return 0;
    }
    if (mustAmapView) //导航时车位到达临界点后，设定车位无数据
    {
        return 1;
    }
    
    OnLinePOI poi = [m_onLineMapView Net_GetPoint:0];
    
    long lon = poi.coord.longitude * 1000000.0;
    long lat = poi.coord.latitude * 1000000.0;
    int sign = [[ANDataSource sharedInstance] GMD_GetCurDrawMapViewTypeWithLon:lon Lat:lat];
    return sign;
}


#pragma mark 导航时，提示缺少数据，并询问用户是否导航
- (void)ShowAbsentCityNameWithTag:(int)tag
{
    NSMutableArray *province_array = [[NSMutableArray alloc] init];
    [province_array addObject:STR(@"NetMap_Current", @"NetMap")];
    GROUTEERRORINFO *pRouteErrorInfo;
    NSMutableArray *adminArray = [[NSMutableArray alloc] init];
    GSTATUS res =  GDBL_GetRouteErrorInfo(&pRouteErrorInfo);
    if (res == GD_ERR_OK)
    {
        [province_array removeAllObjects];
        int code;
       
        NSString *province = nil;
        
        for (int i = 0; i < pRouteErrorInfo->nNumberOfList; i ++)
        {
            code = [[ANDataSource sharedInstance] GMD_GetCityAdminCodeWithAdminCode:pRouteErrorInfo->pAdminCodeList[i]];
            
            
            [adminArray addObject:[NSString stringWithFormat:@"%d",code]];
            province = [[ANDataSource sharedInstance] GMD_GetCityNameWithAdminCode:pRouteErrorInfo->pAdminCodeList[i]];
            [province_array addObject:province];
            
            
        }
        
    }
    else{
        
        NSInteger m_admincode = [[ANDataSource sharedInstance] GMD_GetCurrentAdmincode];
        int adminCode = [[ANDataSource sharedInstance] GMD_GetCityAdminCodeWithAdminCode:m_admincode];
        [adminArray addObject:[NSString stringWithFormat:@"%d",adminCode]];
    }
    if (absentCityCodeList) {
        [absentCityCodeList release];
        absentCityCodeList = nil;
    }
    absentCityCodeList = [[NSDictionary alloc] initWithObjectsAndKeys:adminArray,@"city",nil];
    [adminArray release];
    adminArray = nil;
    
    NSString *name = @"";
    
    //只显示前两个缺失城市名
    int arrayCount = 0;
    if ([province_array count] > 1) {
        arrayCount = 2;
    }
    else{
        arrayCount = [province_array count];
    }
    
    for (int i = 0; i < arrayCount; i ++)
    {
        name = [name stringByAppendingString:[province_array objectAtIndex:i]];
        name = [name stringByAppendingString:@","];
    }
    if ([name length] > 0)
    {
        name = [name substringToIndex:[name length] - 1];
    }
    name = [NSString stringWithFormat:STR(@"NetMap_NameTip", @"NetMap"),name];
    [self ShowAmapNaviAlertWithContent:name tag:tag];
    [province_array release];
}

#pragma mark 由本地向网络偏移重算
- (void)NET_OffRouteWithLon:(double)lon Lat:(double)lat
{
    [GDBL_TTS GDBL_TTSPlayByStr:@"路径重算中"];
    m_onLineMapView->isOffRoute = YES;
    CLLocationCoordinate2D coord;
    coord = CLLocationCoordinate2DMake(lat, lon);
    
    OnLinePOI poi = {0};
    poi.coord = coord;
    [m_onLineMapView Net_SetPoint:6 PoiInfo:poi];
    
    [self SetEndPoint:6];
}

#pragma mark - 开始GPS导航 模拟导航 暂停模拟导航 恢复模拟导航 停止模拟导航 停止导航,删除所有路径
- (void)StartGPSNavi
{
    isArriveWay = NO;
    if(tbtNavi)
    {
        if ([[MWPreference sharedInstance] getValue:PREF_DISABLE_GPS])
        {
            if ([self IsStartIsNetMap] != 0 || mustAmapView)//如果车标处于有数据，则不开始TBT导航，只有到达临界点后才开始TBT导航.
            {
                m_mapViewState = State_Navi;
                m_maMapView.showsUserLocation = NO;
                tbtNavi->StartGPSNavi();
            }
            else
            {
                m_mapViewState = State_Guidance;
            }
        }
        else
        {
            m_mapViewState = State_Guidance;
        }
    }
    m_maMapView.userInteractionEnabled = YES;
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STARTGUIDANCE object:nil];
}

- (void)StartEmulatorNaviWithSpeed:(int)speed
{
    if(tbtNavi)
    {
        m_mapViewState = State_EmulatorNavi;
        m_maMapView.userInteractionEnabled = NO;
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_INSIMULATION object:nil];
        tbtNavi->SetEmulatorSpeed(speed);
        tbtNavi->StartEmulatorNavi();
    }
}

- (void)PauseNavi
{
    if (tbtNavi)
    {
        tbtNavi->PauseNavi();
    }
}

- (void)ResumeNavi
{
    if (tbtNavi)
    {
        tbtNavi->ResumeNavi();
    }
}

- (void)StopEmulatorNavi
{
    mustAmapView = NO;
    if (tbtNavi)
    {
        m_mapViewState = State_Navi;
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STARTGUIDANCE object:nil];
        m_maMapView.userInteractionEnabled = YES;
        tbtNavi->StopEmulatorNavi();
        [m_onLineMapView Net_ActionWityType:NET_Action_StopSimuNavi object:nil];
        [self StartGPSNavi];
    }
}

- (void)StopNavi
{
#if   PROJECTMODE
    if (m_pFileRecordGps)
    {
        fclose(m_pFileRecordGps);
        m_pFileRecordGps = NULL;
    }
#endif
    
    isTBTRouteData = 0;
    
    mustAmapView = NO;
    if (tbtNavi)
    {
        m_mapViewState = State_None;
        //        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
        m_maMapView.userInteractionEnabled = YES;
        tbtNavi->StopNavi();
        [m_onLineMapView Net_ActionWityType:NET_Action_StopNavi object:nil];;
    }
    //    [[MWMapOperator sharedInstance] MW_GoToCCP];
    if ([[MWPreference sharedInstance] getValue:PREF_DISABLE_GPS])
    {
        m_maMapView.showsUserLocation = YES;
    }
}

//清除所有TBT信息，包括地图绘制信息
- (void)ClearInfo
{
#if   PROJECTMODE
    if (m_pFileRecordGps)
    {
        fclose(m_pFileRecordGps);
        m_pFileRecordGps = NULL;
    }
#endif
    
    isTBTRouteData = 0;
    
    mustAmapView = NO;
    if (tbtNavi)
    {
        m_mapViewState = State_None;
        m_maMapView.userInteractionEnabled = YES;
        tbtNavi->StopNavi();
    }
    [m_onLineMapView Net_ActionWityType:NET_Action_StopNavi object:nil];
    if ([[MWPreference sharedInstance] getValue:PREF_DISABLE_GPS])
    {
        m_maMapView.showsUserLocation = YES;
    }
}

#pragma mark - 收藏地图中心信息  收藏当前点 保存历史目的地

#pragma mark 获取地图中心点poi信息
- (void)NET_getPoiInfoWithCoord:(GCOORD)coord delegate:(id<onlineMapSearchDelegate>)searchDelegate
{
    m_saveType = GET_CENTERINFP;
    _searchDelegate = searchDelegate;
    CLLocationCoordinate2D coord2d; 
    coord2d.longitude = (double)coord.x/1000000.0 ;
    coord2d.latitude = (double)coord.y/1000000.0 ;
    
    MASearch *search = [[MASearch alloc] initWithSearchKey:AmapKeySring Delegate:self];
    MAReverseGeocodingSearchOption *option = [[[MAReverseGeocodingSearchOption alloc] init] autorelease];
    option.config = @"SPAS";
    option.encode = @"UTF-8";
    option.x = [NSString stringWithFormat:@"%f",coord2d.longitude];
    option.y = [NSString stringWithFormat:@"%f",coord2d.latitude];
    [search reverseGeocodingSearchWithOption:option];
    
    [search release];
}


- (void)SaveCenterInfo
{
    m_saveType = SAVE_COLLECTION;
    CGPoint screenXY = CGPointMake(m_maMapView.bounds.size.width/2, m_maMapView.bounds.size.height/2);
    CLLocationCoordinate2D coord;
    coord = [m_maMapView convertPoint:screenXY toCoordinateFromView:m_maMapView];
    
    MASearch *search = [[MASearch alloc] initWithSearchKey:AmapKeySring Delegate:self];
    
    MAReverseGeocodingSearchOption *option = [[[MAReverseGeocodingSearchOption alloc] init] autorelease];
    option.config = @"SPAS";
    option.encode = @"UTF-8";
    option.x = [NSString stringWithFormat:@"%f",coord.longitude];
    option.y = [NSString stringWithFormat:@"%f",coord.latitude];
    [search reverseGeocodingSearchWithOption:option];
    
    [search release];
}

- (void)SaveCurrentPoint
{
    if (!m_maMapView)
    {
        return;
    }
    
    m_saveType = SAVE_COLLECTION;
    
    OnLinePOI poi = [m_onLineMapView Net_GetPoint:0];

    CLLocationCoordinate2D coord;
    coord = poi.coord;
    
    MASearch *search = [[MASearch alloc] initWithSearchKey:AmapKeySring Delegate:self];
    
    MAReverseGeocodingSearchOption *option = [[[MAReverseGeocodingSearchOption alloc] init] autorelease];
    option.config = @"SPAS";
    option.encode = @"UTF-8";
    option.x = [NSString stringWithFormat:@"%f",coord.longitude];
    option.y = [NSString stringWithFormat:@"%f",coord.latitude];
    [search reverseGeocodingSearchWithOption:option];
    
    [search release];
}

- (void)SaveHistoryDes
{
    if (!m_maMapView)
    {
        return;
    }
    if (isSaveLocalDes)
    {
        [MWPoiOperator collectPoiWith:GFAVORITE_CATEGORY_HISTORY icon:GFAVORITE_ICON_HISTORY poi:m_desPOI];
        isSaveLocalDes = NO;
        return;
    }
    m_saveType = SAVE_HistoryDES;
    
    OnLinePOI poi = [m_onLineMapView Net_GetPoint:6];
    CLLocationCoordinate2D coord;
    coord = poi.coord;
    
    MASearch *search = [[MASearch alloc] initWithSearchKey:AmapKeySring Delegate:self];
    
    MAReverseGeocodingSearchOption *option = [[[MAReverseGeocodingSearchOption alloc] init] autorelease];
    option.config = @"SPAS";
    //    option.x =[NSString stringWithFormat:@"116.232926845551"];
    //    option.y =[NSString stringWithFormat:@"39.9751660355901"];
    option.x = [NSString stringWithFormat:@"%f",coord.longitude];
    option.y = [NSString stringWithFormat:@"%f",coord.latitude];
    [search reverseGeocodingSearchWithOption:option];
    
    [search release];
}

-(void)search:(id)searchOption Error:(NSString*)errCode
{
    NSLog(@"Error:%@",errCode);
    if (m_saveType == GET_CENTERINFP)
    {
        MWPoi *mwpoi = [[MWPoi alloc] init];
        mwpoi.szAddr = nil;
        mwpoi.szName = STR(@"Main_unNameRoad", @"Main");
        mwpoi.longitude = m_maMapView.centerCoordinate.longitude * 1000000;
        mwpoi.latitude = m_maMapView.centerCoordinate.latitude * 1000000;
        if (_searchDelegate && [_searchDelegate respondsToSelector:@selector(onlineMapSearchCenterWith:)])
        {
            [_searchDelegate onlineMapSearchCenterWith:mwpoi];
        }
        [mwpoi release];
        _searchDelegate = nil;
    }
}

-(void)reverseGeocodingSearch:(MAReverseGeocodingSearchOption*)geoCodingSearchOption Result:(MAReverseGeocodingSearchResult*)result
{
    MAPOI *poi = nil;
    NSString *roadName = nil;
    if ([result.resultArray count] > 0)
    {
        MAReverseGeocodingInfo *first_result = [result.resultArray objectAtIndex:0];
        if ([first_result.pois count] > 0)
        {
            poi = [first_result.pois objectAtIndex:0];
        }
        else
        {
            if ([first_result.roads count] > 0)
            {
                MARoad *road = [first_result.roads objectAtIndex:0];
                roadName = road.name;
            }
            else
            {
                roadName = first_result.district.name;
            }
        }
    }
    if (m_saveType == GET_CENTERINFP)
    {
        if (poi != nil)
        {
            MWPoi *mwpoi = [[MWPoi alloc] init];
            mwpoi.szAddr = poi.address;
            mwpoi.szName = poi.name;
            mwpoi.longitude = [poi.x doubleValue] * 1000000;
            mwpoi.latitude = [poi.y doubleValue] * 1000000;
            mwpoi.szTel = poi.tel;
            mwpoi.lAdminCode = [poi.cityCode intValue];
            if (_searchDelegate && [_searchDelegate respondsToSelector:@selector(onlineMapSearchCenterWith:)])
            {
                [_searchDelegate onlineMapSearchCenterWith:mwpoi];
            }
            [mwpoi release];
            _searchDelegate = nil;
        }
        else
        {
            MWPoi *mwpoi = [[MWPoi alloc] init];
            mwpoi.szAddr = nil;
            mwpoi.szName = (!roadName && ![roadName isEqualToString:@""]) ? roadName : STR(@"Main_unNameRoad", @"Main");
            mwpoi.longitude = m_maMapView.centerCoordinate.longitude * 1000000;
            mwpoi.latitude = m_maMapView.centerCoordinate.latitude * 1000000;
            if (_searchDelegate && [_searchDelegate respondsToSelector:@selector(onlineMapSearchCenterWith:)])
            {
                [_searchDelegate onlineMapSearchCenterWith:mwpoi];
            }
            [mwpoi release];
            _searchDelegate = nil;
        }
    }
    else if (m_saveType == SAVE_COLLECTION)
    {
        
        MWFavoritePoi *favoritepoi = [[MWFavoritePoi alloc] init];
        favoritepoi.szAddr = poi.address;
        favoritepoi.szName = poi.name;
        favoritepoi.longitude = [poi.x doubleValue] * 1000000;
        favoritepoi.latitude = [poi.y doubleValue] * 1000000;
        favoritepoi.szTel = poi.tel;
        favoritepoi.eCategory = GFAVORITE_CATEGORY_DEFAULT;
        favoritepoi.eIconID = GFAVORITE_ICON_DEFAULT;
        int res;
        res = [MWPoiOperator collectPoiWith:favoritepoi];
        [favoritepoi release];
        if(res == GD_ERR_OK) {
           
            
        }
        else if(res == GD_ERR_DUPLICATE_DATA)
        {
           
            
        }
        else
        {
            
            
        }
        
    }
    else if (m_saveType == SAVE_HistoryDES)
    {
        NSString *str = STR(@"Main_unNameRoad", @"Main");
        GPOI  desPOI = {0};
        if (poi == nil)
        {
            strcpy(desPOI.szName, NSSTRING_TO_CSTRING(str));
            
            OnLinePOI temp_end = [m_onLineMapView Net_GetPoint:6];
            
            desPOI.Coord.x = temp_end.coord.longitude * 1000000;
            desPOI.Coord.y = temp_end.coord.latitude * 1000000;
        }
        else
        {
            if ([poi.address length] > 0)
            {
                strcpy(desPOI.szAddr,NSSTRING_TO_CSTRING(poi.address) );
            }
            if ([poi.name length] > 0)
            {
                strcpy(desPOI.szName,NSSTRING_TO_CSTRING(poi.name));
            }
            if ([poi.tel length] > 0)
            {
                strcpy(desPOI.szTel,NSSTRING_TO_CSTRING(poi.tel));
            }
            
            OnLinePOI temp_end = [m_onLineMapView Net_GetPoint:6];
            
            desPOI.Coord.x = temp_end.coord.longitude * 1000000;
            desPOI.Coord.y = temp_end.coord.latitude * 1000000;
        }
        [MWPoiOperator collectPoiWith:GFAVORITE_CATEGORY_HISTORY icon:GFAVORITE_ICON_HISTORY poi:desPOI];
    }
    
    m_saveType = SAVE_NONE;
}

#pragma mark -  同步本地和网络的车标位置 , 设置车标颜色
//用网络车标 同步 本地车标
- (void)SynLocalCarPositionWithNet
{
    GCOORD coord;
    OnLinePOI poi = [m_onLineMapView Net_GetPoint:0];
    
    coord.x = poi.coord.longitude * 1000000;
    coord.y = poi.coord.latitude * 1000000;
    GSTATUS res = GDMID_AdjustCar(coord, 0);
    if (res == GD_ERR_OK)
    {
        
    }
}

//用本地车标 同步 网络车标
- (void)SynNetCarPositionWithLocalCar
{
    if (!m_maMapView)
    {
        return;
    }
    if (!isAmapView)
    {
        return;
    }
    long lon;
    long lat;
    GCARINFO carinfo = {0};
    GDBL_GetCarInfo(&carinfo);
    lon = carinfo.Coord.x;
    lat = carinfo.Coord.y;
    CLLocationCoordinate2D coord ;
    coord.longitude = (double)lon/1000000.0;
    coord.latitude = (double)lat/1000000.0;
    
    OnLinePOI poi = {0};
    poi.coord = coord;
    strcpy(poi.name, carinfo.szRoadName);
    [m_onLineMapView Net_SetPoint:0 PoiInfo:poi];
    
    MyCustomAnnotation *annotation = m_onLineMapView.m_carView.annotation;
    if (annotation)
    {
        annotation.coordinate = coord;
    }
    else
    {
        [self NET_AddCarWithCoord:coord];
    }
    
}

//设置车标颜色
- (void)setCarColor:(BOOL)hasGPS
{
    if (hasGPS)
    {
        m_onLineMapView.m_carView.image = IMAGE(@"NAVICAR_A25.png", IMAGEPATH_TYPE_1);
        isHasGPS = YES;
    }
    else
    {
        m_onLineMapView.m_carView.image = IMAGE(@"NAVICAR_B25.png", IMAGEPATH_TYPE_1);
        isHasGPS = NO;
    }
}

#pragma mark - 利用本地GPS信息设置网络地图在导航时的GPS信息

-(void) recordGpsInfo
{
    GGPSINFOEX *gpsInfo = [[MyCLController sharedInstance] getGpsInfo];
    
    // 创建文件
    if (m_pFileRecordGps==NULL) {
        //  创建文件夹
        NSString *szFileDirectory = [NSString stringWithFormat:@"%@/NetGpsRecord", document_path_Engine];
        BOOL isDir = NO;
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL existed = [fileManager fileExistsAtPath:szFileDirectory isDirectory:&isDir];
        if ( !(isDir == YES && existed == YES) )
        {
            [fileManager createDirectoryAtPath:szFileDirectory withIntermediateDirectories:YES attributes:nil error:nil];
        }
        // 创建文件
        NSString*   szFileName = [NSString stringWithFormat:@"GPS%d-%d-%d-%d-%d-%d", gpsInfo->cYear,gpsInfo->cMonth,gpsInfo->cDay,gpsInfo->cHour,gpsInfo->cMinute,gpsInfo->cSecond];
        NSString *path = [NSString stringWithFormat:@"%@/NetGpsRecord/%@",document_path_Engine, szFileName];
        static int count = 0;
        if ([fileManager fileExistsAtPath:path])
        {
            path = [path stringByAppendingString:[NSString stringWithFormat:@"(%d)",count++]];
        }
        m_pFileRecordGps = fopen([path UTF8String], "a+");
    }
    
    // 文件写入操作
    else {
        //
        NSString* szData = [NSString stringWithFormat:@"%d,%d,%f,%f,%d,%d,%d,%d,%d,%d\r\n",
                            // GPS信息
                            gpsInfo->lLon, gpsInfo->lLat, gpsInfo->dSpeed, gpsInfo->dAzimuth,
                            gpsInfo->cYear, gpsInfo->cMonth, gpsInfo->cDay, gpsInfo->cHour, gpsInfo->cMinute,gpsInfo->cSecond//6
                            ];
        const char* szGpsData1 = [szData UTF8String];
        ////////////////
        fwrite(szGpsData1, strlen(szGpsData1), 1, m_pFileRecordGps);
        fflush(m_pFileRecordGps);
        
    }
}

-(void)readGPSLog:(id)data
{
    //    NSString* log = [[NSBundle mainBundle] pathForResource:@"gps" ofType:@"txt"];
    NSString *log = [NSString stringWithFormat:@"%@/gps.txt",document_path_Engine];
    //	NSFileHandle *file = [NSFileHandle fileHandleForReadingAtPath:log];
    NSData *file_data = [NSData dataWithContentsOfFile:log];
    
    if(!file_data)
    {
        return;
    }
    
    if(file_data)
    {
        NSData *data = file_data;
        NSString* aStr = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding];
        NSArray *logLine = [aStr componentsSeparatedByString:@"\r\n"];
        m_gpsInfoArray = [[NSArray alloc] initWithArray:logLine];
        [aStr release];
    }
    //    [self hideKeyboard];
}

- (void)SetAmapGPSInfo:(GGPSINFOEX *)gpsInfo
{
#if SupportPlayGPS
    
#else
    if (![[MWPreference sharedInstance] getValue:PREF_DISABLE_GPS] || [ANParamValue sharedInstance].isPath == NO || m_maMapView == nil) //未开启gps定位,没有路径,情况下，网络地图未加载情况下，无需使用本地GPS信息
    {
        return;
    }
#endif
    
    if (m_mapViewState == State_Navi)
    {
        if (tbtNavi)
        {
#if SupportPlayGPS
            static int i = 0;
            NSString *object = [m_gpsInfoArray objectAtIndex:i];
            i++;
            if (i >= [m_gpsInfoArray count])
            {
                i = 0;
            }
            NSArray *gpsPoint = [object componentsSeparatedByString:@","];
            if(tbtNavi && [gpsPoint count] > 9)
            {
                double lon = (double)[[gpsPoint objectAtIndex:0] intValue]/1000000.0;
                double lat = (double)[[gpsPoint objectAtIndex:1] intValue]/1000000.0;
                double speed = [[gpsPoint objectAtIndex:2] doubleValue];
                double dAzimuth = [[gpsPoint objectAtIndex:3] doubleValue];
                int year = [[gpsPoint objectAtIndex:4] intValue];
                int month = [[gpsPoint objectAtIndex:5] intValue];
                int day = [[gpsPoint objectAtIndex:6] intValue];
                int hour = [[gpsPoint objectAtIndex:7] intValue];
                int minute = [[gpsPoint objectAtIndex:8] intValue];
                int second = [[gpsPoint objectAtIndex:9] intValue];
                tbtNavi->SetGPSInfo(1,lon,lat,speed,dAzimuth,year,month,day,hour,minute,second);
            }
#else
            NSLog(@"SetNetMapGPSInfo");
            double lon = (double)gpsInfo->lLon/1000000.0;
            double lat = (double)gpsInfo->lLat/1000000.0;
            double speed = (double)gpsInfo->dSpeed;
            double dAzimuth = (double)gpsInfo->dAzimuth;
            int year = (double)gpsInfo->cYear;
            int month = (double)gpsInfo->cMonth;
            int day = (double)gpsInfo->cDay;
            int hour = (double)gpsInfo->cHour;
            int minute = (double)gpsInfo->cMinute;
            int second = (double)gpsInfo->cSecond;
            tbtNavi->SetGPSInfo(1,lon,lat,speed,dAzimuth,year,month,day,hour,minute,second);
#endif
            
#if   PROJECTMODE
            [self recordGpsInfo];
#endif
        }
    }
    else
    {
        [self SynNetCarPositionWithLocalCar];
    }
}

#pragma mark - 成员变量，set，get 方法的重写
- (void)setIsTBTRouteData:(int)_isTBTRouteData
{
    isTBTRouteData = _isTBTRouteData;
    [[ANOperateMethod sharedInstance] GMD_SetVoicePlayType:isTBTRouteData];
    if (isTBTRouteData == 0)
    {
        [[Plugin_OnLineMapUtility sharedInstance] ClearInfo]; //删除网络地图中的路径信息
    }
}

- (int)isTBTRouteData
{
    if (mustAmapView)//导航时车位到达临界点后，必使用网络数据
    {
        self.isTBTRouteData = 1;
        return isTBTRouteData;
    }
    if (isTBTRouteData == 1) //当路径由TBT计算出时，若车位点在本地数据，则用本地导航数据
    {
        if (![self IsStartIsNetMap] && !mustAmapView)
        {
            self.isTBTRouteData = 2;
            return isTBTRouteData;
        }
    }
    return isTBTRouteData;
}


- (void)setIsAmapView:(BOOL)_isAmapView
{
    isAmapView = _isAmapView;
    if (m_viewControllerType == ViewController_Local)
    {
        [[MWMapOperator sharedInstance] MW_SetMapType:0];
    }
    else
    {
        [[MWMapOperator sharedInstance] MW_SetMapType:isAmapView];
    }
}



- (BOOL)isAlertMOVEAlert
{
    if (![ANParamValue sharedInstance].netWorkMap || isChangePage)
    {
        return YES;
    }
    if ([ANParamValue sharedInstance].isUseNETMap)
    {
        return NO;
    }
    return isAlertMOVEAlert;
}

#pragma mark - Alert method and delegate
-(void)AlertWithoutClick:(NSString *)text
{
    GDAlertView* alert = [[GDAlertView alloc] initWithTitle:nil andMessage:text];
    [alert show];
    [alert release];
}
- (void)MyalertView:(NSString *)titletext canceltext:(NSString *)mycanceltext othertext:(NSString *)myothertext alerttag:(int)mytag
{
	
    __block id weakDelegate = self;
    GDAlertView* alert = [[GDAlertView alloc] initWithTitle:nil andMessage:titletext];
    if (mycanceltext)
    {
        [alert addButtonWithTitle:mycanceltext type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView)
         {
             if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
             {
                 [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:0];
             }
         }];
    }
    if (myothertext)
    {
        [alert addButtonWithTitle:myothertext type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView)
         {
             if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
             {
                 [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:1];
             }
         }];
    }
    alert.tag = mytag;
    [alert show];
    [alert release];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (alertView.tag)
    {
        case 1:
            switch (buttonIndex)
        {
                
            case 2:
                
                
                break;
                
            case 0:
                [[NSNotificationCenter defaultCenter] postNotificationName:Utility_EnterLoadView_Notify object:absentCityCodeList];
                break;
            case 1:
                [ANParamValue sharedInstance].isUseNETMap = YES;
                [self SetEndPoint:6];
                break;
            default:
                break;
        }
            
            break;
        case 2:
            switch (buttonIndex)
        {
                
            case 2:
                
                
                break;
                
            case 0:
                [[NSNotificationCenter defaultCenter] postNotificationName:Utility_EnterLoadView_Notify object:absentCityCodeList];
                break;
            case 1:
                [ANParamValue sharedInstance].isUseNETMap = YES;
                [self SetEndPoint:1];
                break;
            default:
                break;
        }
            
            break;
        default:
            break;
    }
}

@end
