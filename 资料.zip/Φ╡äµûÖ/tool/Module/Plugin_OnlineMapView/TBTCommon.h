//
//  TBTCommon.h
//  TBTDemo
//
//  Created by yuxinyan on 12-5-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TBTCommon <NSObject>

enum RequestRouteType
{
    RequestRouteType_Best   = 0,
    RequestRouteType_High   = 1,
    RequestRouteType_Dist   = 2,
    RequestRouteType_Norm   = 3,
    RequestRouteType_TMC    = 4,
    RequestRouteType_Multi  = 5
};

enum RequestRouteResult
{
    RequestRouteResult_Success          = 1,    // 路径计算成功       
    RequestRouteResult_TimeOut          = 2,    // 网络超时
    RequestRouteResult_NetError         = 3,    // 网络失败
    RequestRouteResult_RequestParError  = 4,    // 请求参数错误
    RequestRouteResult_DataFormatError  = 5,    // 返回数据格式错误
    RequestRouteResult_StartNoRoad      = 6,    // 起点周围没有道路
    RequestRouteResult_StartOnWalRoad   = 7,    // 起点在步行街
    RequestRouteResult_DestNoRoad       = 8,    // 终点周围没有道路
    RequestRouteResult_DestOnWalkRoad   = 9,    // 终点在步行街
    RequestRouteResult_ViaNoRoad        = 10,   // 途经点周围没有道路
    RequestRouteResult_ViaOnWalkRoad    = 11    // 途经点在步行街
};

@end
