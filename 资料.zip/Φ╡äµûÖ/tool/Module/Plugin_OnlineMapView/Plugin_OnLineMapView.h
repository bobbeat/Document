//
//  Plugin_OnLineMapView.h
//  AutoNavi
//
//  Created by huang longfeng on 13-3-4.
//
//

#import <UIKit/UIKit.h>
#import "MAMapKit.h"
#import "MASearch.h"
#import "PaintingView.h"
#import "MyCustomAnnotation.h"
#import "Plugin_OnlineStruct.h"

typedef enum NET_Action_Type
{
    NET_Action_SetCarPosition = 0,
    NET_Action_SetPassBy,
    NET_Action_SetEnd,
    NET_Action_ZoomIN,
    NET_Action_ZoomOut,
    NET_Action_ZoomTo,
    NET_Action_StopNavi,
    NET_Action_StopSimuNavi,
    NET_Action_GotoCCP,
}NET_Action_Type;


@interface Plugin_OnLineMapView : UIView<MASearchDelegate,MAMapViewDelegate,PaintingViewDelegate,UIGestureRecognizerDelegate>
{
    PaintingView *m_drawingView;
    MAMapView *m_maMapView;
    
    MyCustomAnnotation *m_startPointAnn;
    MyCustomAnnotation *m_endPointAnn;
    MyCustomAnnotation *m_poiPointAnn;
    
    NSMutableArray *m_passByPointAnnArray;
    
    OnLinePOI m_startCoord; //起点
    OnLinePOI m_endCoord;   //终点
    OnLinePOI m_passBy[3]; // 途经点
    NSMutableArray *overlays;
    int isSearch;   //0为未搜索，1为当前道路名搜索，2为起点位置搜索，3为终点位置搜索
    int isMapInit;  //地图初始化控制，0为未初始化，1正在初始化，2初始化完成
    BOOL isAlertASK;

    MAPinAnnotationView *m_carView;
    NSTimer *m_delayShowButton;
   
    CGFloat lastScale;
@public
    BOOL isOffRoute; //是否偏移重算
    struct ITBT *tbtNavi;
    struct CTBTFrame *tbtFrame;
    
    
}

@property (nonatomic,assign) id <PaintingViewDelegate> delegate;

@property (nonatomic,retain) MAPinAnnotationView *m_carView;
@property (nonatomic,assign) BOOL isAmapView;
@property (nonatomic,readonly) PaintingView *m_drawingView;
@property (nonatomic,readonly) int isMapInit;

#pragma mark 设终点，设起点，回车位，停止导航，设置车标位置
- (void)Net_ActionWityType:(NET_Action_Type)type object:(id)object;


#pragma mark 网络数据导航询问
- (void)NET_AskForUseNetMap;
- (void)AskForUseNetMap;

#pragma mark 添加在线地图
- (void)AddNetMapView;

- (void)MapZoomTO:(NSString *)scale;
- (void)MapZoomIN:(NSString *)scale;
- (void)MapZoomOut:(NSString *)scale;

- (void)TBT_updateDGNaviInfor:(NSDictionary *)infor;

#pragma mark 回车位
- (void)BackToCar;
#pragma mark 绘制路径
-(void)TBT_DrawPath;
#pragma mark 播放语音
- (void)TBT_PlayNaviSound:(NSString *)sound;
#pragma mark 开始模拟导航
- (void)StartEmulatorNaviWithSpeed:(int)speed;
#pragma mark 暂停模拟导航
- (void)PauseNavi;
#pragma mark 恢复模拟导航
- (void)ResumeNavi;
#pragma mark 停止模拟导航
- (void)StopEmulatorNavi;
#pragma mark 停止导航,删除所有路径
- (void)StopNavi;
#pragma mark 收藏中心点
- (int)SaveCenterInfo;
#pragma mark 偏移重算
- (void)TBT_OffRoute;
#pragma mark 传入信息到行车电脑
- (void)GMD_PassInfoToDrive;
#pragma mark 路径请求后的回调
- (void)TBT_SetRouteRequestState:(int)iState;

/**********************************************************************
 * 函数名称: setMyFrame
 * 功能描述: 设置地图显示区域
 * 输入参数: (CGRect)newFrame
 * 输出参数:
 * 返 回 值：
 * 其它说明:
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 **********************************************************************/
-(void) setmyFrame:(CGRect)newFrame;

- (void)ShowLableAndViewWithMapCenter:(CLLocationCoordinate2D)Mapcenter; //根据中心点显示距离和中心图标,用于全程概览

#pragma mark -
#pragma mark 设置起点，终点和获取起点终点
- (void)Net_SetPoint:(int)type PoiInfo:(OnLinePOI)poiInfo;
- (OnLinePOI)Net_GetPoint:(int)type;
- (void)Net_ClearPassBy;
@end
