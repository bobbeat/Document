//
//  RTNetConnection.m
//  TBTDemo
//
//  Created by yuxinyan on 12-5-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RTURLConnection.h"

@implementation RTURLConnection
@synthesize rtDelegate;

- (void)dealloc {
    [_url release];
    [_headerFields release];
    [_response release];
    [_data release];
    [super dealloc];
}

- (void)setNetworkActivityIndicatorVisible:(NSNumber *)visiable
{
//    if ([[NSThread currentThread] isMainThread]) {
//        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:[visiable boolValue]]; 
//    } else {
//        [self performSelectorOnMainThread:@selector(setNetworkActivityIndicatorVisible:) withObject:visiable waitUntilDone:NO];
//    }
}

- (NSURLResponse *)response
{
    return _response;
}

- (void)setResponse:(NSURLResponse *)value 
{
    if (_response != value) {
        [_response release];
        _response = [value retain];
    }
}

- (NSData *)data 
{
    return _data;
}

- (void)appendData:(NSData *)value 
{
    if (!_data) {
        _data = [[NSMutableData alloc] init];
    }
    [_data appendData:value];
}

- (BOOL)finished 
{
    return _finished;
}

- (void)setFinished:(BOOL)finished 
{
    _finished = finished;
}

- (void)setURL:(NSString *)url
{
    if (_url != url) {
        [_url release];
        _url = [url retain];
    }
}

- (void)setValue:(NSString *)value forHTTPHeaderField:(NSString *)field
{
    if (nil == _headerFields) {
        _headerFields = [[NSMutableDictionary alloc] initWithCapacity:0];
    }
    if (value && field){
        [_headerFields setObject:value forKey:field];
    }
}

- (void)setHTTPHeaderFields:(NSMutableURLRequest *)request
{
    if (_headerFields){
        NSArray *keys = [_headerFields allKeys];
        for (NSString *key in keys) {
            [request setValue:[_headerFields objectForKey:key] forHTTPHeaderField:key];
        }
        [_headerFields removeAllObjects];
    }
}

- (void)connection:(NSMutableURLRequest *)request
{
    [self setNetworkActivityIndicatorVisible:[NSNumber numberWithBool:YES]];
    [NSURLConnection connectionWithRequest:request delegate:self];
}

- (void)getRequest
{
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:_url]];
    
	[request setCachePolicy:NSURLRequestUseProtocolCachePolicy];
	[request setTimeoutInterval:20];
	[request setHTTPMethod:@"GET"];
    [self setHTTPHeaderFields:request];
	[self connection:request];
	[request release];
}

- (void)postContent:(NSData *)content
{
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:_url]];
    
	[request setCachePolicy:NSURLRequestUseProtocolCachePolicy];
	[request setTimeoutInterval:20];
    [request setHTTPMethod:@"POST"];
    [self setHTTPHeaderFields:request];
	[request setHTTPBody:content];  
    [self connection:request];
	[request release];
}



#pragma mark -
#pragma mark NSURLConnection Delegate Methods
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)aResponse 
{
    NSLog(@"%s", object_getClassName(aResponse));
	NSLog(@"connection didReceiveResponse %@:%@:%d:%lld",
          [aResponse MIMEType], 
          [aResponse textEncodingName],
          [(NSHTTPURLResponse *)aResponse statusCode],
          [aResponse expectedContentLength]);
    [self setResponse:aResponse];
	[self setFinished:NO];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)value 
{
	NSLog(@"connection didReceiveData");
	[self appendData:value];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error 
{
	NSLog(@"connection didFailWithError %@", [error description]);
	[self setNetworkActivityIndicatorVisible:[NSNumber numberWithBool:NO]];
	if ([rtDelegate respondsToSelector:@selector(rtURLConnection:didFailWithError:)]) {
		[rtDelegate rtURLConnection:self didFailWithError:error];
	}
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection 
{
	NSLog(@"connectionDidFinishLoading");
	[self setFinished:YES];
	[self setNetworkActivityIndicatorVisible:[NSNumber numberWithBool:NO]];
    
	if ([rtDelegate respondsToSelector:@selector(rtURLConnectionDidFinished:)]) {
		[rtDelegate rtURLConnectionDidFinished:self];
	}
}
@end

