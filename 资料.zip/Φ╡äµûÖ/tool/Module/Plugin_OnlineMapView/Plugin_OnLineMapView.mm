//
//  Plugin_OnLineMapView.m
//  AutoNavi
//
//  Created by huang longfeng on 13-3-4.
//
//

#import "Plugin_OnLineMapView.h"
//#import "MainViewController.h"
#import "Plugin_OnLineMapUtility.h"

#import "ANParamValue.h"
#import "TBTFrame.h"
#import "ITBT.h"
#import "FaceOverlay.h"
#import "FaceOverlayView.h"
#import "GDBL_TTS.h"
#import "mapDataManage.h"
#import "QLoadingView.h"
#import "ANOperateMethod.h"
#import "GDBL_NetCounter.h"
#import "MWPreference.h"
#import "MWMapOperator.h"
#import "MWMapAddIconOperator.h"

#define CenterLabelOffset 55
#define IPHONE_DEVICE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)?1:0

@interface Plugin_OnLineMapView()
{
    UILabel *m_distanceLable;
    UIImageView *m_centerView;
    CGRect m_frame;
    BOOL isRemindNetBreak;
    int Admin_code;
    //    FaceOverlay *m_guideLine;
    BOOL _ispan;     //是否正在平移地图
    BOOL _isLongPressed;    //是否长按
}

@end

@implementation Plugin_OnLineMapView

@synthesize isAmapView,m_carView,m_drawingView,isMapInit,delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        //        self.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        isOffRoute = NO;
        m_frame = frame;
        // Initialization code
        m_maMapView = nil;
        m_drawingView = nil;
        m_distanceLable = nil;
        m_centerView = nil;
        self.userInteractionEnabled = YES;
        
        m_drawingView = [[PaintingView alloc] initWithFrame:self.bounds];
        m_drawingView.delegate = self;
        m_drawingView.userInteractionEnabled = YES;
        [self addSubview:m_drawingView];
        [m_drawingView release];
        m_drawingView.hidden = NO;
        
        [Plugin_OnLineMapUtility sharedInstance].m_onLineMapView = self;
        [Plugin_OnLineMapUtility sharedInstance].m_drawingView = m_drawingView;
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];

    if (overlays)
    {
        [overlays release];
        overlays = nil;
    }
    if (m_delayShowButton)
    {
        [m_delayShowButton invalidate];
        m_delayShowButton = nil;
    }
    [super dealloc];
}

#pragma mark -
#pragma mark normal method
- (void)ButtonPressed
{
    
    
}

- (void)initView
{
    
    
    m_centerView = [[UIImageView alloc] initWithImage: IMAGE(@"CROSS_2D.png", IMAGEPATH_TYPE_1) ];
    m_centerView.hidden = YES;
    [m_maMapView addSubview:m_centerView];
    [m_centerView release];
    
    m_distanceLable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    m_distanceLable.textAlignment = NSTextAlignmentLeft;
    m_distanceLable.textColor = [UIColor blueColor];
    m_distanceLable.backgroundColor = [UIColor clearColor];
    m_distanceLable.hidden = YES;
    [m_maMapView addSubview:m_distanceLable];
    [m_distanceLable release];
    
    if (IPHONE_DEVICE)
    {
        m_distanceLable.font = [UIFont systemFontOfSize:12];
        m_centerView.frame = CGRectMake(0, 0, 20, 20);
    }
    else
    {
        m_distanceLable.font = [UIFont systemFontOfSize:18];
        m_centerView.frame = CGRectMake(0, 0, 28, 28);
    }
    m_centerView.center = CGPointMake(m_maMapView.bounds.size.width/2.0, m_maMapView.bounds.size.height/2.0);
    m_distanceLable.center = CGPointMake(m_maMapView.bounds.size.width/2.0 + m_centerView.frame.size.width/2 + CenterLabelOffset, m_maMapView.bounds.size.height/2.0);
}

- (NSString *)keyForSearch
{
    return AmapKeySring;
}

- (void)ShowLableAndViewWithMapCenter:(CLLocationCoordinate2D)Mapcenter //显示地图中心点至车标距离和中心图标
{
    if ([Plugin_OnLineMapUtility sharedInstance].m_viewControllerType == ViewController_Main)
    {
        m_distanceLable.hidden = NO;
        m_centerView.hidden = NO;
    }
    else
    {
        m_distanceLable.hidden = NO;
        m_centerView.hidden = NO;
    }
    MAMapPoint a = MAMapPointForCoordinate(Mapcenter);
    MAMapPoint b = MAMapPointForCoordinate(m_startCoord.coord);
    CLLocationDistance distancee = MAMetersBetweenMapPoints(a, b);
    if (distancee > 1000)
    {
        m_distanceLable.text = [NSString stringWithFormat:@"%0.1fkm",distancee/1000.0];
    }
    else
    {
        m_distanceLable.text = [NSString stringWithFormat:@"%0.0fm",distancee];
    }
}


- (void)AddStartAndDesAnnotation  //添加起点和终点标志，绿色旗子和G
{
    if (m_startPointAnn)
    {
        [m_maMapView removeAnnotation:m_startPointAnn];
        m_startPointAnn = nil;
    }
    m_startPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_Start_Point] autorelease];
    CLLocationCoordinate2D coord = m_startCoord.coord;
    m_startPointAnn.coordinate = coord;
    [m_maMapView addAnnotation:m_startPointAnn];
    
    if (m_endPointAnn)
    {
        [m_maMapView removeAnnotation:m_endPointAnn];
        m_endPointAnn = nil;
    }
    m_endPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_End_Point] autorelease];
    coord = m_endCoord.coord;
    m_endPointAnn.coordinate = coord;
    [m_maMapView addAnnotation:m_endPointAnn];
    
    if (m_passByPointAnnArray)
    {
        [m_maMapView removeAnnotations:m_passByPointAnnArray];
        [m_passByPointAnnArray release];
        m_passByPointAnnArray = nil;
    }
    m_passByPointAnnArray = [[NSMutableArray alloc] init];
    for (int i = 0; i < 3; i ++ )
    {
        coord = m_passBy[i].coord;
        if (coord.longitude > 0 && coord.latitude > 0)
        {
            MyCustomAnnotation *passByPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_PassBy_Point] autorelease];
            passByPointAnn.coordinate = coord;
            [m_passByPointAnnArray addObject:passByPointAnn];
        }
    }
    [m_maMapView addAnnotations:m_passByPointAnnArray];
}

double ConvertDegreesToRadians (double degrees)
{
    double radians = (M_PI / 180.0) * degrees;
    return (radians);
}


/**********************************************************************
 * 函数名称: setMyFrame
 * 功能描述: 设置地图显示区域
 * 输入参数: (CGRect)newFrame
 * 输出参数:
 * 返 回 值：
 * 其它说明:
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 **********************************************************************/
-(void) setmyFrame:(CGRect)newFrame
{
	[super setFrame:newFrame];
    [m_drawingView setFrame:newFrame];
    [m_drawingView setmyFrame:newFrame];
    m_distanceLable.center = CGPointMake(m_maMapView.bounds.size.width/2.0 + m_centerView.frame.size.width/2 + CenterLabelOffset, m_maMapView.bounds.size.height/2.0);
    m_centerView.center = CGPointMake(m_maMapView.bounds.size.width/2.0, m_maMapView.bounds.size.height/2.0);
    
}

- (void)MyalertView:(NSString *)titletext canceltext:(NSString *)mycanceltext othertext:(NSString *)myothertext alerttag:(int)mytag
{
	__block id weakDelegate = self;
    GDAlertView* alert = [[GDAlertView alloc] initWithTitle:nil andMessage:titletext];
    if (mycanceltext)
    {
        [alert addButtonWithTitle:mycanceltext type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView)
         {
             if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
             {
                 [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:0];
             }
         }];
    }
    if (myothertext)
    {
        [alert addButtonWithTitle:myothertext type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView)
         {
             if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
             {
                 [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:1];
             }
         }];
    }
    alert.tag = mytag;
    [alert show];
    [alert release];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	switch (alertView.tag)
    {
        case 1:
        {
            isAlertASK = NO;
            switch (buttonIndex)
            {
                case 2:
                {
                    [ANParamValue sharedInstance].isUseNETMap = NO;
                    [Plugin_OnLineMapUtility sharedInstance].isAmapView = NO;
                }
                    break;
                case 0:
                {
                    
                    NSMutableArray *cityArray = [[NSMutableArray alloc] init];
                    [cityArray addObject:[NSNumber numberWithInt:Admin_code]];
                    NSDictionary *cityAdmin = [[NSDictionary alloc] initWithObjectsAndKeys:cityArray,@"city",nil,@"province", nil];
                    [cityArray release];
                    [ANParamValue sharedInstance].isUseNETMap = NO;
                    [Plugin_OnLineMapUtility sharedInstance].isAmapView = NO;
                    [[NSNotificationCenter defaultCenter] postNotificationName:Utility_EnterLoadView_Notify object:cityAdmin];
                    [cityAdmin release];
                }
                    break;
                case 1:
                {
                    if ([ANParamValue sharedInstance].isPath) {
                        [GDBL_UserBehaviorCountNew shareInstance].networkNavi_InPath ++;
                    }
                    else{
                        [GDBL_UserBehaviorCountNew shareInstance].networkNavi ++;
                    }
                    [ANParamValue sharedInstance].isUseNETMap = YES;
                    [Plugin_OnLineMapUtility sharedInstance].isAmapView = YES;
                    [self AskForUseNetMap];
                }
                    break;
                default:
                    break;
            }
            break;
        }
        case 2:
        {
            isAlertASK = NO;
            switch (buttonIndex)
            {
                case 0:
                    [self NET_ClearContinueInfo];
                    break;
                case 1:
                    [self NET_ContinueRoute];
                    break;
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }
}

#pragma mark 设置Amap比例尺
- (void)setScale:(double)scale mapView:(MAMapView *)mapView animated:(BOOL)animated
{
    
    double distancex = scale * mapView.bounds.size.width;
    double distancey = scale * mapView.bounds.size.height;
    MACoordinateRegion region = MACoordinateRegionMakeWithDistance(mapView.centerCoordinate, distancey, distancex);
    [mapView setRegion:region animated:NO];
}

#pragma mark 添加网络地图询问,创建网络地图 初始化TBT
- (void)NET_AskForUseNetMap
{
    if ([NSThread isMainThread])
    {
        [self AskForUseNetMap];
    }
    else
    {
        [self performSelectorOnMainThread:@selector(AskForUseNetMap) withObject:nil waitUntilDone:NO];
    }
}


- (void)AskForUseNetMap
{
    if (![ANParamValue sharedInstance].isMove)
    {
        [Plugin_OnLineMapUtility sharedInstance].isMove = NO;
    }
    else
    {
        [Plugin_OnLineMapUtility sharedInstance].isMove = YES;
    }
    
    if ([ANParamValue sharedInstance].isUseNETMap)
    {
        [QLoadingView showDefaultLoadingView:STR(@"NetMap_LoadMap", @"NetMap")];
        isMapInit = 1;
        [Plugin_OnLineMapUtility sharedInstance].isAmapView = YES;
        [self performSelector:@selector(AddNetMapView) withObject:nil afterDelay:1.0f];
        
    }
    else
    {
        if (!isAlertASK  && [Plugin_OnLineMapUtility sharedInstance].m_viewControllerType != ViewController_POIDisappear)
        {
            isAlertASK = YES;
            Admin_code = [[ANDataSource sharedInstance] GMD_GetCurrentAdmincode];
            [self AlertForUseNetMap:STR(@"NetMap_LoadTip", @"NetMap")];
        }
        
    }
}

- (void)AlertForUseNetMap:(NSString *)content
{
    __block id weakDelegate = self;
    GDAlertView* alert = [[GDAlertView alloc] initWithTitle:nil andMessage:content];
    
    [alert addButtonWithTitle:STR(@"NetMap_LoadData", @"NetMap") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView)
     {
         if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
         {
             [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:0];
         }
     }];
    
    [alert addButtonWithTitle:STR(@"NetMap_OpenNetMap", @"NetMap") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView)
     {
         if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
         {
             [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:1];
         }
     }];
    [alert addButtonWithTitle:STR(@"Universal_cancel", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView)
     {
         if (weakDelegate && [weakDelegate respondsToSelector:@selector(alertView:clickedButtonAtIndex:)])
         {
             [weakDelegate alertView:(UIAlertView *)alertView clickedButtonAtIndex:2];
         }
     }];
    alert.tag = 1;
    [alert show];
    [alert release];
}

- (void)AddNetMapView
{
    if ([ANParamValue sharedInstance].netWorkMap)
    {
        if (!m_maMapView)
        {
            
            m_maMapView = [[MAMapView alloc] initWithFrame:self.bounds] ;
            m_maMapView.mapType = MAMapTypeStandard;
            m_maMapView.delegate = self;
            m_maMapView.showsUserLocation = YES;
            m_maMapView.zoomEnabled = NO;
            m_maMapView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
            
            long lon;
            long lat;
            GCARINFO carinfo = {0};
            GDBL_GetCarInfo(&carinfo);
            lon = carinfo.Coord.x;
            lat = carinfo.Coord.y;
            CLLocationCoordinate2D center = {(double)lat/1000000.0,(double)lon/1000000.0};
            
            if ([Plugin_OnLineMapUtility sharedInstance].isSettingDes != 2)
            {
                m_startCoord.coord = center;
            }
            else
            {
                center = m_startCoord.coord;
                [Plugin_OnLineMapUtility sharedInstance].isMove = NO;
            }
            
            if ([Plugin_OnLineMapUtility sharedInstance].isMove) //判断当前是否为移图状态
            {
                GMAPCENTERINFO mapinfo = {0};
                GDBL_GetMapCenterInfo(&mapinfo);
                center.longitude = (double)mapinfo.CenterCoord.x/1000000.0;
                center.latitude = (double)mapinfo.CenterCoord.y/1000000.0;
            }
            NSString *scale = [[ANDataSource sharedInstance] GMD_GetCurrentScale];
            /* 从本地地图获取初始的配置，起点，比例尺*/
            NSString *last_str,*next_str;
            double last,next;
            double current_scale = [[Plugin_OnLineMapUtility sharedInstance] GetAmapScaleFromGDmap:scale lastScale:&last nextScale:&next latScaleStr:&last_str nextScaleStr:&next_str];
            double distancex = current_scale * m_maMapView.bounds.size.width;
            double distancey = current_scale * m_maMapView.bounds.size.height;
            MACoordinateRegion region = MACoordinateRegionMakeWithDistance(center, distancey, distancex);
            [m_maMapView setRegion:region animated:NO];
            
            [self addSubview:m_maMapView];
            m_maMapView.hidden = YES;
            [m_maMapView release];
            
            [Plugin_OnLineMapUtility sharedInstance].m_maMapView = m_maMapView;
            
            //滑动、移图
            UIPanGestureRecognizer *panRecongnizer;
            panRecongnizer = [[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panRecongnizer:)] autorelease];
            panRecongnizer.delegate = self;
            [self addGestureRecognizer:panRecongnizer];
            
            UITapGestureRecognizer *singleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(TapRecongnizer:)];
            [singleClick setNumberOfTouchesRequired:1];//触摸点个数
            [singleClick setNumberOfTapsRequired:1];//点击次数
            singleClick.delegate = self;
            [self addGestureRecognizer:singleClick];
            [singleClick release];
            
            UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(TapRecongnizer:)];
            [tapGes setNumberOfTouchesRequired:1];//触摸点个数
            [tapGes setNumberOfTapsRequired:2];//点击次数
            tapGes.delegate = self;
            [self addGestureRecognizer:tapGes];
            [tapGes release];
            
            UITapGestureRecognizer *DoubleClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(TapRecongnizer:)];
            [DoubleClick setNumberOfTouchesRequired:2];//触摸点个数
            [DoubleClick setNumberOfTapsRequired:1];//点击次数
            DoubleClick.delegate = self;
            [self addGestureRecognizer:DoubleClick];
            [DoubleClick release];
            
            [singleClick requireGestureRecognizerToFail:tapGes];
            
            UILongPressGestureRecognizer *longPress =[[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longRecongnizer:)]autorelease];
            longPress.delegate = self;
            longPress.minimumPressDuration =0.2;
            [self addGestureRecognizer:longPress];
                        
            //两点触控,二指往內或往外拨动
            UIPinchGestureRecognizer *pinchRecognizer;
            pinchRecognizer = [[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchRecognizer:)] autorelease];
            lastScale = 1.0f;
            [pinchRecognizer setDelegate:self];
            [self addGestureRecognizer:pinchRecognizer];
            
            [DoubleClick requireGestureRecognizerToFail:pinchRecognizer];
            //            [pinchRecognizer requireGestureRecognizerToFail:panRecongnizer];
            
            [self sendSubviewToBack:m_maMapView];
            [Plugin_OnLineMapUtility sharedInstance].isAmapView = YES;
            [self performSelector:@selector(DelayInit) withObject:nil afterDelay:1.0f];
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeOrientation:) name:UIDeviceOrientationDidChangeNotification object:NULL];
            
            [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(UpdateGPSinfo) userInfo:nil repeats:YES];
            
        }
    }
    else
    {
        [Plugin_OnLineMapUtility sharedInstance].isAmapView = NO;
    }
}

- (void)DelayInit
{
    [self initView];
    if ([self initTBT]) //初始化TBT是否成功
    {
        [Plugin_OnLineMapUtility sharedInstance]->tbtNavi = tbtNavi;
    }
    long lon;
    long lat;
    /* 从本地地图获取初始的配置，起点，比例尺*/
    if ([Plugin_OnLineMapUtility sharedInstance].isSettingDes == 2)
    {
        lon = m_startCoord.coord.longitude * 1000000.0;
        lat = m_startCoord.coord.latitude * 1000000.0;
    }
    else
    {
        GCARINFO carinfo = {0};
        GDBL_GetCarInfo(&carinfo);
        lon = carinfo.Coord.x;
        lat = carinfo.Coord.y;
    }
    
    [[Plugin_OnLineMapUtility sharedInstance] NET_AddCarWithCoord:CLLocationCoordinate2DMake((double)lat/1000000.0, (double)lon/1000000.0)];
    
    
    if ([Plugin_OnLineMapUtility sharedInstance].isMove) //判断当前是否为移图状态
    {
        [self ShowLableAndViewWithMapCenter:m_maMapView.centerCoordinate];
        [Plugin_OnLineMapUtility sharedInstance].isShowPopPoi = YES;
        [self performSelectorOnMainThread:@selector(SendPoiNotificationWith:) withObject:[NSNumber numberWithInt:2] waitUntilDone:NO];
    }
    
    m_maMapView.hidden = NO;
    m_drawingView.hidden = YES;
    
    isMapInit = 2;
    [QLoadingView hideWithAnimated:NO];
    [[Plugin_OnLineMapUtility sharedInstance]  ShowMapMode];
    
    [self AddDestination];
    [[NSNotificationCenter defaultCenter] postNotificationName:Fresh_Poi object:nil];
}

- (void)AddDestination
{
    if ([Plugin_OnLineMapUtility  sharedInstance].isSettingDes == 1)
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetEndPoint:6];
    }
    else if ([Plugin_OnLineMapUtility  sharedInstance].isSettingDes == 3)
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:6];
    }
    else if ([Plugin_OnLineMapUtility  sharedInstance].isSettingDes == 4)
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetEndPoint:1];
    }
    else
    {
        [self NET_ReadContinueInfo];
        
    }
}

- (BOOL)initTBT
{
    tbtNavi = CTBTFactory::GetInstance();
    if(!tbtNavi)
    {
        return FALSE;
    }
    tbtFrame = new CTBTFrame(self);
    if(!tbtFrame)
    {
        return FALSE;
    }
    
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    int ret = tbtNavi->Init(tbtFrame, [[documentPath stringByAppendingString:@"/"] UTF8String], "AN_DaoHang_IOS_FC", "0", [deviceID UTF8String]);
    if(ret == 0)
    {
        return FALSE;
    }
    else
    {
        tbtNavi->OpenTrafficRadio();
        tbtNavi->OpenTMC();
        tbtNavi->OpenTrafficPanel();
        tbtNavi->OpenCamera();
        //        tbtNavi->CloseCamera();
        //        tbtNavi->CloseTMC();
        //        tbtNavi->CloseTrafficPanel();
        //        tbtNavi->CloseTrafficRadio();
    }
    
    return TRUE;
}

- (void)changeOrientation:(NSNotification *)notification
{
    __block Plugin_OnLineMapView *weakself = self;
    double delayInSeconds = 0.1;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void)
    {
        [weakself SendPoiNotificationWith:[NSNumber numberWithInt:3]];
    });
    
}
#pragma mark -
#pragma mark 清除地图上的overlay 及 annonation
- (void)ClearOverlayAndAnnonation
{
    if (m_passByPointAnnArray)
    {
        [m_maMapView removeAnnotations:m_passByPointAnnArray];
        [m_passByPointAnnArray release];
        m_passByPointAnnArray = nil;
    }
    if (m_endPointAnn)
    {
        [m_maMapView removeAnnotation:m_endPointAnn];
        m_endPointAnn = nil;
    }
    if (overlays)
    {
        [m_maMapView removeOverlays:overlays];
        overlays = nil;
    }
    if (m_startPointAnn)
    {
        [m_maMapView removeAnnotation:m_startPointAnn];
        m_startPointAnn = nil;
    }
}

#pragma mark -
#pragma mark 设置起点，途经点，终点 和 获取起点，途经点，终点 0：起点 6：终点 1 2 3：途经点
- (void)Net_SetPoint:(int)type PoiInfo:(OnLinePOI)poiInfo
{
    if (type == 0)
    {
        m_startCoord.coord = poiInfo.coord;
        strcpy(m_startCoord.name,poiInfo.name);
    }
    else  if (type == 6)
    {
        m_endCoord.coord = poiInfo.coord;
        m_endCoord.offset = poiInfo.offset;
        strcpy(m_endCoord.name,poiInfo.name);
    }
    else  if (type == 1)
    {
        m_passBy[0].coord = poiInfo.coord;
        strcpy(m_passBy[0].name,poiInfo.name);
    }
    else  if (type == 2)
    {
        m_passBy[1].coord = poiInfo.coord;
        strcpy(m_passBy[1].name,poiInfo.name);
    }
    else  if (type == 3)
    {
        m_passBy[2].coord = poiInfo.coord;
        strcpy(m_passBy[2].name,poiInfo.name);
    }
}

- (OnLinePOI)Net_GetPoint:(int)type
{
    OnLinePOI poi = {0};
    if (type == 0)
    {
        poi.coord = m_startCoord.coord;
        strcpy(poi.name,m_startCoord.name);
    }
    else  if (type == 6)
    {
        poi.coord = m_endCoord.coord;
        poi.offset = m_endCoord.offset;
        strcpy(poi.name,m_endCoord.name);
    }
    else  if (type == 1)
    {
        poi.coord = m_passBy[0].coord;
        strcpy(poi.name,m_passBy[0].name);
    }
    else  if (type == 2)
    {
        poi.coord = m_passBy[1].coord;
        strcpy(poi.name,m_passBy[1].name);
    }
    else  if (type == 3)
    {
        poi.coord = m_passBy[2].coord;
        strcpy(poi.name,m_passBy[2].name);
    }
    return poi;
}

- (void)Net_ClearPassBy
{
    CLLocationCoordinate2D coord = {0};
    m_passBy[0].coord = coord;
    m_passBy[1].coord = coord;
    m_passBy[2].coord = coord;
    memset(m_passBy[0].name, 0,GMAX_POI_NAME_LEN+1);
    memset(m_passBy[1].name, 0,GMAX_POI_NAME_LEN+1);
    memset(m_passBy[2].name, 0,GMAX_POI_NAME_LEN+1);
}

#pragma mark -
#pragma mark 设终点，设起点，回车位，停止导航，设置车标位置
- (void)Net_ActionWityType:(NET_Action_Type)type object:(id)object
{
    if (type == NET_Action_SetCarPosition)
    {
        [self NET_Action_SetCar:object];
    }
    else if (type == NET_Action_SetPassBy)
    {
        [self NET_Action_SetPassBy:object];
    }
    else if (type == NET_Action_SetEnd)
    {
        [self NET_Action_SetEnd:object];
    }
    else if (type == NET_Action_ZoomOut)
    {
        [self NET_Action_ZoomOut:object];
    }
    else if (type == NET_Action_ZoomIN)
    {
        [self NET_Action_ZoomIN:object];
    }
    else if (type == NET_Action_ZoomTo)
    {
        [self NET_Action_ZoomTo:object];
    }
    else if (type == NET_Action_StopNavi)
    {
        [self ClearOverlayAndAnnonation];
        [self NET_ClearContinueInfo];
    }
    else if (type == NET_Action_StopSimuNavi)
    {
        
    }
    else if (type == NET_Action_GotoCCP)
    {
        [self NET_Action_GotoCCP];
    }
}

- (void)NET_Action_SetCar:(MyCustomAnnotation *)annotation
{
    [self ClearOverlayAndAnnonation];
    MyCustomAnnotation * temp = annotation;
    m_startCoord.coord = temp.coordinate;
    
    if (self.m_carView)
    {
        MyCustomAnnotation *annotation = m_carView.annotation;
        if (annotation == nil)
        {
            [m_maMapView addAnnotation:temp];
        }
        else
        {
            annotation.coordinate = temp.coordinate;
        }
    }
    else
    {
        [m_maMapView addAnnotation:temp];
        
    }
    [[Plugin_OnLineMapUtility sharedInstance] SynLocalCarPositionWithNet];
    m_centerView.hidden = YES;
    m_distanceLable.hidden = YES;
}

- (void)NET_Action_SetPassBy:(MyCustomAnnotation *)annotation
{
    [QLoadingView showDefaultLoadingView:STR(@"NetMap_RouteLoading", @"NetMap")];

}

- (void)NET_Action_SetEnd:(MyCustomAnnotation *)annotation
{
    [QLoadingView showDefaultLoadingView:STR(@"NetMap_RouteLoading", @"NetMap")];
}

- (void)NET_Action_ZoomOut:(NSString *)scale
{
    NSString *last_str,*next_str;
    double last,next;
    [[Plugin_OnLineMapUtility sharedInstance] GetAmapScaleFromGDmap:scale lastScale:&last nextScale:&next latScaleStr:&last_str nextScaleStr:&next_str];
    [self setScale:last mapView:m_maMapView animated:YES];
}

- (void)NET_Action_ZoomIN:(NSString *)scale
{
    NSString *last_str,*next_str;
    double last,next;
    
    [[Plugin_OnLineMapUtility sharedInstance] GetAmapScaleFromGDmap:scale lastScale:&last nextScale:&next latScaleStr:&last_str nextScaleStr:&next_str];
    [self setScale:next mapView:m_maMapView animated:YES];
}

- (void)NET_Action_ZoomTo:(NSString *)scale
{
    NSString *last_str,*next_str;
    double last,next;
    double scale_num = [[Plugin_OnLineMapUtility sharedInstance] GetAmapScaleFromGDmap:scale lastScale:&last nextScale:&next latScaleStr:&last_str nextScaleStr:&next_str];
    [self setScale:scale_num mapView:m_maMapView animated:NO];
}

- (void)NET_Action_GotoCCP
{
    m_distanceLable.hidden = YES;
    m_centerView.hidden = YES;
    CGFloat angle = 0;
    CGAffineTransform at =CGAffineTransformMakeRotation(angle);
    [self.m_carView setTransform:at];
    [Plugin_OnLineMapUtility sharedInstance].isMove = NO;
}

#pragma mark - 保存，读取,清除续航信息，只需保存起点，终点

- (void)NET_SaveContinueInfo
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObject:[NSNumber numberWithDouble:m_startCoord.coord.longitude] forKey:@"start_lon"];
    [dic setObject:[NSNumber numberWithDouble:m_startCoord.coord.latitude] forKey:@"start_lat"];
    [dic setObject:[NSNumber numberWithDouble:m_endCoord.coord.longitude] forKey:@"end_lon"];
    [dic setObject:[NSNumber numberWithDouble:m_endCoord.coord.latitude] forKey:@"end_lat"];
    
	[dic writeToFile:NET_PATH atomically:YES];
    [dic release];
}

- (void)NET_ReadContinueInfo
{
    NSFileManager *file_manager = [NSFileManager defaultManager];
    if ([file_manager fileExistsAtPath:NET_PATH])
    {
        [self MyalertView:STR(@"NetMap_RouteContinue", @"NetMap") canceltext:STR(@"Universal_cancel", @"Localizable") othertext:STR(@"Universal_ok", @"Localizable") alerttag:2];
    }
    
}

- (void)NET_ContinueRoute
{
    NSFileManager *file_manager = [NSFileManager defaultManager];
    if ([file_manager fileExistsAtPath:NET_PATH])
    {
        CLLocationCoordinate2D coord = {0};
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithContentsOfFile:NET_PATH];
        coord.longitude = [[dic objectForKey:@"start_lon"] doubleValue];
        coord.latitude = [[dic objectForKey:@"start_lat"] doubleValue];
        m_startCoord.coord = coord;
        
        coord.longitude = [[dic objectForKey:@"end_lon"] doubleValue];
        coord.latitude = [[dic objectForKey:@"end_lat"] doubleValue];
        m_endCoord.coord = coord;
        [dic release];
        
        [[Plugin_OnLineMapUtility sharedInstance] SetEndPoint:6];
        [file_manager removeItemAtPath:NET_PATH error:nil];
    }
}

- (void)NET_ClearContinueInfo
{
    NSFileManager *file_manager = [NSFileManager defaultManager];
    NSString *path = NET_PATH;
    if ([file_manager fileExistsAtPath:path])
    {
        [file_manager removeItemAtPath:path error:nil];
    }
}
#pragma mark -
#pragma mark TBTFrame 回调通知
#pragma mark 播放语音 路径请求后的回调 绘制路径 更新导航，或者模拟导航位置信息 偏移重算 到达目的地
- (void)TBT_PlayNaviSound:(NSString *)sound
{
    if (0 == [[MWPreference sharedInstance] getValue:PREF_VOICERECONGNITION])
    {
        return;
    }
    
    [GDBL_TTS GDBL_TTSPlayByStr:sound];
}

/*
 1	路径计算成功
 2	网络超时
 3	网络失败
 4	请求参数错误
 5	返回数据格式错误
 6	起点周围没有道路
 7	起点在步行街
 8	终点周围没有道路
 9	终点在步行街
 10	途经点周围没有道路
 11	途经点在步行街
 */
- (void)TBT_SetRouteRequestState:(int)iState
{
    [QLoadingView hideWithAnimated:NO];
    NSString *tipText;
    NSString *btnContent;
    [self ClearOverlayAndAnnonation]; //删除原有路径
    
    switch (iState)
    {
        case 1:
            //TBT路径设置成功后
            m_maMapView.showTraffic = NO;
            [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData = 1; //由TBT计算出的路径，置为1。
            [self TBT_DrawPath]; //绘制新路径
            [self NET_SaveContinueInfo];
            break;
        case 2:
            [self NET_ClearContinueInfo];
            [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_NO_PATH object:nil];
            [self MyalertView:STR(@"Universal_networkError", @"Localizable") canceltext:STR(@"Universal_ok", @"Localizable") othertext:nil alerttag:-1];
            break;
        default:
            [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_NO_PATH object:nil];
            [self MyalertView:STR(@"NetMap_RouteError", @"NetMap") canceltext:STR(@"Universal_ok", @"Localizable") othertext:nil alerttag:-1];
            break;
    }
}

-(void)TBT_DrawPath
{
    if (overlays)
    {
        [m_maMapView removeOverlays:overlays];
        overlays = nil;
    }
    overlays=[[NSMutableArray alloc] init];
    
    int road_Num = 0;
    int *road_ID = tbtNavi->GetAllRouteID(road_Num);
    tbtNavi->SelectRoute(road_ID[0]);
    
    int segnum = tbtNavi->GetSegNum();
    double* coor;
    int pointNum = 0;
    
    int total_point = 0;
    for (int i = 0; i < segnum; i++)
    {
        tbtNavi->GetSegCoor(i, pointNum);
        total_point += pointNum;
    }
    
    int now_point = 0;
    //    CLLocationCoordinate2D location[total_point + 1];
    CLLocationCoordinate2D *location = (CLLocationCoordinate2D *)malloc(sizeof(CLLocationCoordinate2D) * (total_point + 1));
    memset(location,0,total_point + 1);
    GTBTNAVIINTEM pNaviItems[total_point];
    for (int i = 0; i < segnum; i++)
    {
        coor = tbtNavi->GetSegCoor(i, pointNum);
        for (int j = 0; j < pointNum; j++)
        {
            location[now_point + j].longitude = coor[2 * j];
            location[now_point + j].latitude = coor[2 * j + 1];
            pNaviItems[now_point + j].Coord.x = coor[2 * j] * 1000000;
            pNaviItems[now_point + j].Coord.y = coor[2 * j + 1] * 1000000;
            //            printf("(%f,%f)",coor[2 * j],coor[2 * j + 1]);
        }
        now_point += pointNum;
    }
    location[total_point].longitude = m_endCoord.coord.longitude;
    location[total_point].latitude = m_endCoord.coord.latitude;
    
    //    FaceOverlay *placeMark = [FaceOverlay faceWithhCoordinates:location count:total_point + 1];
    MAPolyline *placeMark=[MAPolyline polylineWithCoordinates:location count:total_point + 1];
    [m_maMapView addOverlay:placeMark];
    [overlays addObject:placeMark];
    [placeMark release];
    free(location);
    
    
    if ([[Plugin_OnLineMapUtility sharedInstance] IsStartIsNetMap] == 0) //起点有数据
    {
        GSTATUS res = GDBL_SetTBTNaviItems(pNaviItems,total_point);  //传入TBT路径信息至本地导航
        if (res == GD_ERR_OK) //倒入TBT路径成功
        {
            [Plugin_OnLineMapUtility sharedInstance].mustAmapView = NO; //若倒入TBT数据至本地导航成功，则说明是本网融合数据，可做地图的切换
        }
        else
        {
            [Plugin_OnLineMapUtility sharedInstance].mustAmapView = YES; //置为必须显示网络地图
            [[Plugin_OnLineMapUtility sharedInstance] StartGPSNavi];
        }
    }
    else
    {
        [Plugin_OnLineMapUtility sharedInstance].mustAmapView = YES; //置为必须显示网络地图
        [[Plugin_OnLineMapUtility sharedInstance] StartGPSNavi];
    }
    
    int time = tbtNavi->GetRouteTime();
    NSUInteger hour = (time/3600);
    NSUInteger minute = (time%3600/60);
    if (hour >0)
    {
        [Plugin_OnLineMapUtility sharedInstance].m_remainTime = [NSString stringWithFormat:@"%d%@%d%@",hour,STR(@"Universal_hour", @"Localizable"),minute,STR(@"Universal_min", @"Localizable")];  //导航路径剩余时间
    }
    else
    {
        [Plugin_OnLineMapUtility sharedInstance].m_remainTime = [NSString stringWithFormat:@"%d%@",minute,STR(@"Universal_min", @"Localizable")];
    }
    
    int distance = tbtNavi->GetRouteLength();
    if (distance > 1000)
    {
        if (distance > 1000000)
        {
            [Plugin_OnLineMapUtility sharedInstance].m_remainDistance = [NSString stringWithFormat:@"%0.0f%@",distance/1000.0,STR(@"Universal_KM", @"Localizable")];  //导航路径剩余距离
        }
        else
        {
            [Plugin_OnLineMapUtility sharedInstance].m_remainDistance = [NSString stringWithFormat:@"%0.1f%@",distance/1000.0,STR(@"Universal_KM", @"Localizable")];  //导航路径剩余距离
        }
        
    }
    else
    {
        [Plugin_OnLineMapUtility sharedInstance].m_remainDistance = [NSString stringWithFormat:@"%d%@",distance,STR(@"Universal_M", @"Localizable")];  //导航路径剩余距离
    }
    
    distance = tbtNavi->GetSegLength(0);
    if (distance > 1000)
    {
        [Plugin_OnLineMapUtility sharedInstance].m_remainSegDistance = [NSString stringWithFormat:@"%0.1f%@",distance/1000.0,STR(@"Universal_KM", @"Localizable")];  //当前路径剩余距离
    }
    else
    {
        [Plugin_OnLineMapUtility sharedInstance].m_remainSegDistance = [NSString stringWithFormat:@"%d%@",distance,STR(@"Universal_M", @"Localizable")];  //当前路径剩余距离
    }
    
    
    int iItenNum = 0;
    NaviGuideItem *naviGuideItem;
    
    [Plugin_OnLineMapUtility sharedInstance].m_currentLoadName = STR(@"Main_unNameRoad", @"Main");
    [Plugin_OnLineMapUtility sharedInstance].m_nextLoadName = STR(@"Main_unNameRoad", @"Main");
    
    int toll_count = 0;
    
    NSString *curLoadName = @"";
    NSString *nextLoadName = @"";
    naviGuideItem = tbtNavi->GetNaviGuideList(iItenNum);
    for (int i = 0; i < iItenNum; i++)
    {
        if (naviGuideItem[i].m_iIcon == 14)
        {
            toll_count++;
        }
    }
    [Plugin_OnLineMapUtility sharedInstance].m_tollCount = [NSString stringWithFormat:@"%d",toll_count];
    
    if (iItenNum > 0)
    {
        if (iItenNum == 1)
        {
            if (naviGuideItem[0].m_iNameLengh > 0)
            {
                curLoadName = [[NSString alloc] initWithBytes:naviGuideItem[0].m_pwName length:naviGuideItem[0].m_iNameLengh*2 encoding:NSUTF16LittleEndianStringEncoding];
                [Plugin_OnLineMapUtility sharedInstance].m_currentLoadName = curLoadName;
                [curLoadName release];
            }
            
        }
        else
        {
            if (naviGuideItem[0].m_iNameLengh > 0)
            {
                curLoadName = [[NSString alloc] initWithBytes:naviGuideItem[0].m_pwName length:naviGuideItem[0].m_iNameLengh*2 encoding:NSUTF16LittleEndianStringEncoding];
                [Plugin_OnLineMapUtility sharedInstance].m_currentLoadName = curLoadName;
                [curLoadName release];
            }
            
            if (naviGuideItem[1].m_iNameLengh > 0)
            {
                nextLoadName = [[NSString alloc] initWithBytes:naviGuideItem[1].m_pwName length:naviGuideItem[1].m_iNameLengh*2 encoding:NSUTF16LittleEndianStringEncoding];
                [Plugin_OnLineMapUtility sharedInstance].m_nextLoadName = nextLoadName;
                [nextLoadName release];
            }
        }
    }
    [Plugin_OnLineMapUtility sharedInstance].m_iCurSegNum = 0;
    [Plugin_OnLineMapUtility sharedInstance].m_iIcon = naviGuideItem[0].m_iIcon;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STARTGUIDANCE object:nil];
    
    [self SearchLoadNameWithType:2];
    [self AddStartAndDesAnnotation]; //添加起点和终点标志，绿色旗子和G
    [[MWMapOperator sharedInstance] MW_GoToCCP];
    if (!isOffRoute)  //偏移重算不进入全程概览
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:Utility_EnterBrowse_Notify object:nil];
    }
    isOffRoute = NO;
}

- (void)TBT_updataCARPosition:(NSDictionary *)info
{
    if ([Plugin_OnLineMapUtility sharedInstance].isArriveWay)
    {
        return;
    }
    CGAffineTransform at =CGAffineTransformMakeRotation(0);
    [self.m_carView setTransform:at];
    
    CLLocationCoordinate2D coord;
    coord.longitude = [[info objectForKey:@"m_dLongitude"] doubleValue];
    coord.latitude = [[info objectForKey:@"m_dLatitude"] doubleValue];
    
    
    MyCustomAnnotation *annotation = self.m_carView.annotation;
    if (annotation)
    {
        annotation.coordinate = coord;
    }
    else
    {
        [[Plugin_OnLineMapUtility sharedInstance] NET_AddCarWithCoord:coord];
    }
    m_startCoord.coord = coord;
    
    if (![Plugin_OnLineMapUtility sharedInstance].isMove)
    {
        [m_maMapView setCenterCoordinate:coord animated:NO];
    }
    
    
    int direction = [[info objectForKey:@"m_iCarDirection"] intValue];
    [m_maMapView setRotationDegree:direction animated:NO duration:0.5f];
    
    
    if ([[info objectForKey:@"m_iRouteRemainTime"] intValue] > 0)
    {
        int time = [[info objectForKey:@"m_iRouteRemainTime"] intValue];
        NSUInteger hour = (time/3600);
        NSUInteger minute = (time%3600/60);
        if (hour >0)
        {
            [Plugin_OnLineMapUtility sharedInstance].m_remainTime = [NSString stringWithFormat:@"%d%@%d%@",hour,STR(@"Universal_hour", @"Localizable"),minute,STR(@"Universal_min", @"Localizable")];  //导航路径剩余时间
        }
        else
        {
            [Plugin_OnLineMapUtility sharedInstance].m_remainTime = [NSString stringWithFormat:@"%d%@",minute,STR(@"Universal_min", @"Localizable")];
        }
    }
    
    if ([[info objectForKey:@"m_iRouteRemainDis"] intValue] > 0)
    {
        int distance = [[info objectForKey:@"m_iRouteRemainDis"] intValue];
        if (distance > 1000)
        {
            if (distance > 1000000)
            {
                [Plugin_OnLineMapUtility sharedInstance].m_remainDistance = [NSString stringWithFormat:@"%0.0f%@",(distance/1000.0),STR(@"Universal_KM", @"Localizable")];
            }
            else
            {
                [Plugin_OnLineMapUtility sharedInstance].m_remainDistance = [NSString stringWithFormat:@"%0.1f%@",(distance/1000.0),STR(@"Universal_KM", @"Localizable")];
            }
        }
        else
        {
            [Plugin_OnLineMapUtility sharedInstance].m_remainDistance = [NSString stringWithFormat:@"%d%@",distance,STR(@"Universal_M", @"Localizable")];
        }
    }
    
    if ([[info objectForKey:@"m_iSegRemainDis"] intValue] > 0)
    {
        int distance = [[info objectForKey:@"m_iSegRemainDis"] intValue];
        if (distance > 1000)
        {
            [Plugin_OnLineMapUtility sharedInstance].m_remainSegDistance = [NSString stringWithFormat:@"%0.1f%@",(distance/1000.0),STR(@"Universal_KM", @"Localizable")];
        }
        else
        {
            [Plugin_OnLineMapUtility sharedInstance].m_remainSegDistance = [NSString stringWithFormat:@"%d%@",distance,STR(@"Universal_M", @"Localizable")];
        }
    }
    
    if ([Plugin_OnLineMapUtility sharedInstance].isMove == NO)
    {

    }
    
    [Plugin_OnLineMapUtility sharedInstance].m_nextLoadName = STR(@"Main_unNameRoad", @"Main");
    
    if ([[info objectForKey:@"m_iCurNameLen"] intValue] > 0)
    {
        if ([Plugin_OnLineMapUtility sharedInstance].isMove == NO)
        {
//            [Plugin_OnLineMapUtility sharedInstance].m_currentLoadName = [info objectForKey:@"m_pwCurRoadName"];
        }
    }
    
    if ([[info objectForKey:@"m_iNextNameLen"] intValue] > 0)
    {
        [Plugin_OnLineMapUtility sharedInstance].m_nextLoadName = [info objectForKey:@"m_pwNextRoadName"];;
    }
    
    [Plugin_OnLineMapUtility sharedInstance].m_iIcon = [[info objectForKey:@"m_iIcon"] intValue];
    [Plugin_OnLineMapUtility sharedInstance].m_iCurSegNum = [[info objectForKey:@"m_iCurSegNum"] intValue];
    [self performSelectorOnMainThread:@selector(SendNotificationShowMap) withObject:nil waitUntilDone:NO];
    
    if ([[ANParamValue sharedInstance] isDriveComputer] == YES)
    {
        [[ANOperateMethod sharedInstance] GMD_PassInfoToDrive];
    }
    if ([[ANParamValue sharedInstance] isHud] == YES)
    {
        [[ANOperateMethod sharedInstance] GMD_PassInfoToHud];
    }
}

-(void)TBT_updateDGNaviInfor:(NSDictionary *)infor
{
    if ([NSThread isMainThread])
    {
        [self TBT_updataCARPosition:infor];
    }
    else
    {
        [self performSelectorOnMainThread:@selector(TBT_updataCARPosition:) withObject:infor waitUntilDone:FALSE];
    }
}

- (void)TBT_OffRoute
{
    if (tbtNavi)
    {
        isOffRoute = YES;
        tbtNavi->Reroute(0);
        if (1 == [[MWPreference sharedInstance] getValue:PREF_VOICERECONGNITION])
        {
            [GDBL_TTS GDBL_TTSPlayByStr:@"路径重算中"];
        }
    }
}

- (void)arriveWay
{
    [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData = 0 ;
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
}

- (void)Net_ArriveWay
{
    [Plugin_OnLineMapUtility sharedInstance].isArriveWay = YES;
    if ([NSThread isMainThread])
    {
        [self arriveWay];
    }
    else
    {
        [self performSelectorOnMainThread:@selector(arriveWay) withObject:nil waitUntilDone:NO];
    }
    
}

#pragma mark -
#pragma mark MASearchDelegate 逆定理编码搜索 更新地图中心位置信息
- (void)SearchLoadNameWithType:(int)type
{
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView && type == 1)
    {
        return;
    }
    if (isSearch != 0)
    {
        return;
    }
    isSearch = type;
    
    CLLocationCoordinate2D coord;
    if (isSearch == 1)
    {
        CGPoint screenXY = CGPointMake(m_maMapView.bounds.size.width/2, m_maMapView.bounds.size.height/2);
        coord = [m_maMapView convertPoint:screenXY toCoordinateFromView:m_maMapView];
    }
    else if (isSearch == 2)
    {
        coord = m_startCoord.coord;
    }
    else if (isSearch == 3)
    {
        coord = m_endCoord.coord;
    }
    
    
    MASearch *search = [[MASearch alloc] initWithSearchKey:AmapKeySring Delegate:self];
    
    MAReverseGeocodingSearchOption *option = [[[MAReverseGeocodingSearchOption alloc] init] autorelease];
    option.config = @"SPAS";
    option.encode = @"UTF-8";
    option.x = [NSString stringWithFormat:@"%f",coord.longitude];
    option.y = [NSString stringWithFormat:@"%f",coord.latitude];
    [search reverseGeocodingSearchWithOption:option];
    
    [search release];
}


-(void)reverseGeocodingSearch:(MAReverseGeocodingSearchOption*)geoCodingSearchOption Result:(MAReverseGeocodingSearchResult*)result
{
    if ([result.resultArray count] > 0)
    {
        MAReverseGeocodingInfo *first_result = [result.resultArray objectAtIndex:0];
        if (isSearch == 1)
        {
            if ([first_result.roads count] > 0)
            {
                MARoad *road = [first_result.roads objectAtIndex:0];
                NSString *str = road.name;
                [Plugin_OnLineMapUtility sharedInstance].m_currentLoadName = str;
                [self performSelectorOnMainThread:@selector(SendNotificationShowMap) withObject:nil waitUntilDone:NO];
                isSearch = 0;
                return;
            }
        }
        else if (isSearch == 2)
        {
            if ([first_result.pois count] > 0)
            {
                MAPOI *poi = [first_result.pois objectAtIndex:0];
                NSString *str = poi.name;
                if ([str length] > 0)
                {
                    strcpy(m_startCoord.name, NSSTRING_TO_CSTRING(str) ) ;
                }
                else
                {
                    strcpy(m_startCoord.name, NSSTRING_TO_CSTRING(STR(@"Main_unNameRoad", @"Main"))) ;
                }
                isSearch = 0;
                [self SearchLoadNameWithType:3];
                return;
            }
        }
        else if (isSearch == 3)
        {
            
            if ([first_result.pois count] > 0)
            {
                MAPOI *poi = [first_result.pois objectAtIndex:0];
                NSString *str = poi.name;
                if ([str length] > 0)
                {
                    strcpy(m_endCoord.name,NSSTRING_TO_CSTRING(str) ) ;
                }
                else
                {
                    strcpy(m_endCoord.name, NSSTRING_TO_CSTRING(STR(@"Main_unNameRoad", @"Main"))) ;
                }
                isSearch = 0;
                return;
            }
        }
        
    }
    if (isSearch == 1)
    {
        [Plugin_OnLineMapUtility sharedInstance].m_currentLoadName = STR(@"Main_unNameRoad", @"Main");
        [self performSelectorOnMainThread:@selector(SendNotificationShowMap) withObject:nil waitUntilDone:NO];
    }
    else if (isSearch == 2)
    {
        isSearch = 0;
        [self SearchLoadNameWithType:3];
        strcpy(m_startCoord.name, NSSTRING_TO_CSTRING(STR(@"Main_unNameRoad", @"Main"))) ;
    }
    else if (isSearch == 3)
    {
        strcpy(m_endCoord.name, NSSTRING_TO_CSTRING(STR(@"Main_unNameRoad", @"Main"))) ;
    }
    
    isSearch = 0;
    return;
}

- (void)SendNotificationShowMap
{
    if ([Plugin_OnLineMapUtility sharedInstance].isMove)
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_MOVEMAP object:nil];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_NET_SHOWMAP object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_UPDATE_VIEWINFO object:nil];
}

- (void)SendPoiNotificationWith:(id)object
{
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_NET_SHOWMAP object:object];
}

-(void)search:(id)searchOption Error:(NSString*)errCode
{
    NSLog(@"searchOption errCode：%@",errCode);
    NSString *name = STR(@"Main_unNameRoad", @"Main");
    if (isSearch == 1)
    {
        [Plugin_OnLineMapUtility sharedInstance].m_currentLoadName = name;
        [self performSelectorOnMainThread:@selector(SendNotificationShowMap) withObject:nil waitUntilDone:NO];
    }
    else if (isSearch == 2)
    {
        isSearch = 0;
        [self SearchLoadNameWithType:3];
        strcpy(m_startCoord.name, NSSTRING_TO_CSTRING(name) ) ;
    }
    else if (isSearch == 3)
    {
        strcpy(m_endCoord.name,NSSTRING_TO_CSTRING(name) ) ;
    }
    isSearch = 0;
}

-(void)poiSearch:(MAPoiSearchOption*)poiSearchOption Result:(MAPoiSearchResult*)result
{
    //    if ([result.pois count] > 0)
    //    {
    //        MAPOI *poi = [result.pois objectAtIndex:0];
    //    }
}

#pragma mark -
#pragma mark mapView delegate

/*!
 @brief 地图开始加载
 @param mapview 地图View
 */
- (void)mapViewWillStartLoadingMap:(MAMapView *)mapView
{
    NSLog(@"\nmapViewWillStartLoadingMap");
}

/*!
 @brief 地图加载成功
 @param mapView 地图View
 @param dataSize 数据大小
 */
- (void)mapViewDidFinishLoadingMap:(MAMapView *)mapView dataSize:(NSInteger)dataSize
{
    NSLog(@"\nmapViewDidFinishLoadingMap:%d",dataSize);
    if (dataSize > 0)
    {
        [GDBL_NetCounter shareInstance].byte = dataSize;//流量统计
    }
    isRemindNetBreak = NO;
}

/*!
 @brief 地图加载失败
 @param mapView 地图View
 @param error 错误信息
 */
- (void)mapViewDidFailLoadingMap:(MAMapView *)mapView withError:(NSError *)error
{
    if ([NSThread isMainThread])
    {
        [self ShowNetErrorAlert:error];
    }
    else
    {
        [self performSelectorOnMainThread:@selector(ShowNetErrorAlert:) withObject:error waitUntilDone:NO];
    }
}

- (void)ShowNetErrorAlert:(NSError *)error
{
    if (!isRemindNetBreak)
    {
        isRemindNetBreak = YES;
        
        [self MyalertView:STR(@"Universal_networkError", @"Localizable") canceltext:STR(@"Universal_ok", @"Localizable") othertext:nil alerttag:-1];
    }
}

- (void)DelayShowButton
{
    if (m_delayShowButton)
    {
        [m_delayShowButton invalidate];
        m_delayShowButton = nil;
    }
    UIView *superview = [self superview];
    [superview sendSubviewToBack:self];
}

- (void)mapView:(MAMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
    
}

- (void)mapView:(MAMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    if (isMapInit != 2)
    {
        return;
    }
    if ([Plugin_OnLineMapUtility sharedInstance].m_viewControllerType == ViewController_Main)
    {
        [self SearchLoadNameWithType:1];
    }
    else if ([Plugin_OnLineMapUtility sharedInstance].m_viewControllerType == ViewController_POI)
    {
        [self SearchLoadNameWithType:1];
        [self performSelectorOnMainThread:@selector(SendNotificationShowMap) withObject:nil waitUntilDone:NO];
    }
    
    CGPoint screenXY = CGPointMake(m_maMapView.bounds.size.width/2, m_maMapView.bounds.size.height/2);
    CLLocationCoordinate2D center;
    center = [m_maMapView convertPoint:screenXY toCoordinateFromView:m_maMapView];
    if ([Plugin_OnLineMapUtility sharedInstance].isMove)
    {
        
        [self ShowLableAndViewWithMapCenter:center];
    }
    else
    {
        
    }
    
}



- (MAOverlayView*)mapView:(MAMapView *)mapView viewForOverlay:(id<MAOverlay>)overlay
{
	if ([overlay isKindOfClass:[FaceOverlay class]])
    {
        FaceOverlay *faceoverlay = (FaceOverlay *)overlay;
        if (faceoverlay.m_drawLineType == Guide_Line)
        {
            FaceOverlayView *lineView = [[[FaceOverlayView alloc] initWithFaceOverlay:overlay]autorelease];
            lineView.lineWidth = 1.0f;
            lineView.strokeColor = [UIColor blueColor];
            lineView.fillColor = [UIColor blueColor];
            return lineView;
        }
		FaceOverlayView *lineView = [[[FaceOverlayView alloc] initWithFaceOverlay:overlay]autorelease];
        lineView.lineWidth = 5.0f;
        lineView.strokeColor = [UIColor blueColor];
        lineView.fillColor = [UIColor blueColor];
        lineView.lineDashPhase = 1;
        lineView.lineJoin = kCGLineJoinRound;
        lineView.lineCap = kCGLineCapRound;
        lineView.lineDashPattern = [NSArray arrayWithObjects:[NSNumber numberWithInt:10],[NSNumber numberWithInt:10],[NSNumber numberWithInt:20],[NSNumber numberWithInt:20],nil];
		return lineView;
	}
    else if ([overlay isKindOfClass:[MAPolyline class]]) {
		MAPolylineView *lineView = [[[MAPolylineView alloc] initWithPolyline:(MAPolyline *) overlay]autorelease];
        lineView.lineWidth = 8.0f;
        lineView.strokeColor = [UIColor blueColor];
        lineView.fillColor = [UIColor blueColor];
        lineView.lineDashPhase = 1;
        lineView.lineJoin = kCGLineJoinRound;
        lineView.lineCap = kCGLineCapRound;
        //        lineView.lineDashPattern = [NSArray arrayWithObjects:[NSNumber numberWithInt:10],[NSNumber numberWithInt:10],[NSNumber numberWithInt:20],[NSNumber numberWithInt:20],nil];
		return lineView;
	}
	else if ([overlay isKindOfClass:[MAPolygon class]]) {
		MAPolygonView *polygonView = [[[MAPolygonView alloc]initWithPolygon:(MAPolygon *) overlay]autorelease];
		return polygonView;
	}
	else if ([overlay isKindOfClass:[MACircle class]]) {
		MACircleView *circleView = [[[MACircleView alloc]initWithCircle:(MACircle *) overlay]autorelease];
		return circleView;
	}
	return nil;
}

- (MAAnnotationView*)mapView:(MAMapView *)mapView viewForAnnotation:(id <MAAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MyCustomAnnotation class]])
    {
        MyCustomAnnotation *temp = (MyCustomAnnotation *)annotation;
        if (temp.m_annotationType == Annotation_Start_Point)
        {
            static NSString *pointReuseIndetifier_start = @"start";
            MAPinAnnotationView *annotationView ;
            annotationView = [[[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier_start] autorelease];
            annotationView.image = IMAGE(@"start_point.png", IMAGEPATH_TYPE_1);
            annotationView.enabled = NO;
            return annotationView;
        }
        else if (temp.m_annotationType == Annotation_End_Point)
        {
            static NSString *pointReuseIndetifier_end = @"end";
            MAPinAnnotationView *annotationView = (MAPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier_end];
            if (annotationView == nil)
            {
                annotationView = [[[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier_end] autorelease];
                annotationView.image = IMAGE(@"end.png", IMAGEPATH_TYPE_1);
                annotationView.enabled = NO;
            }
            else
            {
                annotationView.annotation = annotation;
            }
            
            return annotationView;
        }
        else if (temp.m_annotationType == Annotation_PassBy_Point)
        {
            static NSString *pointReuseIndetifier_end = @"end";
            MAPinAnnotationView *annotationView = (MAPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier_end];
            if (annotationView == nil)
            {
                annotationView = [[[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier_end] autorelease];
                annotationView.image = IMAGE(@"end.png", IMAGEPATH_TYPE_1) ;
                annotationView.enabled = NO;
            }
            else
            {
                annotationView.annotation = annotation;
            }
            
            return annotationView;
        }
        else if (temp.m_annotationType == Annotation_Car_Point)
        {
            if (self.m_carView)
            {
                self.m_carView.annotation = annotation;
            }
            else
            {
                static NSString *pointReuseIndetifier_car = @"Car";
                MAPinAnnotationView *annotationView = [[[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier_car] autorelease];
                if ([[MWPreference sharedInstance] getValue:PREF_DISABLE_GPS])
                {
                    annotationView.image =IMAGE(@"NAVICAR_A25.png", IMAGEPATH_TYPE_1)  ;
                }
                else
                {
                    annotationView.image =IMAGE(@"NAVICAR_B25.png", IMAGEPATH_TYPE_1) ;
                }
                
                annotationView.enabled = NO;
                self.m_carView = annotationView;
            }
            
            return self.m_carView;
        }
        else if (temp.m_annotationType == Annotation_ClickImage_Point)
        {
            static NSString *pointReuseIndetifier_ClickImage = @"ClickImage";
            MAPinAnnotationView *annotationView = (MAPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier_ClickImage];
            if (annotationView == nil)
            {
                annotationView = [[[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier_ClickImage] autorelease];
                annotationView.image = temp.m_clickImage;
                annotationView.enabled = YES;
            }
            else
            {
                annotationView.annotation = annotation;
                annotationView.image = temp.m_clickImage;
                annotationView.enabled = YES;
            }
            return annotationView;
        }
        else if (temp.m_annotationType == Annotation_ClickPoi)
        {
            static NSString *pointReuseIndetifier_ClickPoi = @"Annotation_ClickPoi";
            MAPinAnnotationView *annotationView = (MAPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier_ClickPoi];
            if (annotationView == nil)
            {
                annotationView = [[[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier_ClickPoi] autorelease];
                
                UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
                [button setImage:temp.m_clickImage forState:UIControlStateNormal];
                [button setImage:temp.m_clickImage forState:UIControlStateHighlighted];
                [button addTarget:self action:@selector(PoiButtonPressed:) forControlEvents:UIControlEventTouchDown];
                [annotationView addSubview:button];
                [button release];
                annotationView.image = IMAGE(@"", IMAGEPATH_TYPE_1) ;
            }
            else
            {
                annotationView.image =IMAGE(@"", IMAGEPATH_TYPE_1);
                annotationView.annotation = annotation;
            }
            annotationView.frame = CGRectMake(0, 0, 40, 40);
            annotationView.enabled = YES;
            return annotationView;
        }
    }
    else
    {
        static NSString *pointReuseIndetifier_else = @"else";
        MAPinAnnotationView *annotationView = (MAPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier_else];
        if (annotationView == nil)
        {
            annotationView = [[[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier_else] autorelease];
            annotationView.enabled = NO;
        }
        else
        {
            annotationView.annotation = annotation;
        }
        if ([[annotation title] isEqualToString:@"当前位置"])
        {
            annotationView.image = IMAGE(@"1561", IMAGEPATH_TYPE_1);
        }
        return annotationView;
    }
    
	return nil;
}

- (void)mapView:(MAMapView *)mapView didSelectAnnotationView:(MAAnnotationView *)view
{
    id <MAAnnotation> annotation = view.annotation;
    
    if ([annotation isKindOfClass:[MyCustomAnnotation class]])
    {
        MyCustomAnnotation *temp = (MyCustomAnnotation *)annotation;
        if (temp.m_annotationType == Annotation_ClickImage_Point)
        {
            if ([temp.m_onLineMapClickImageDelegate respondsToSelector:@selector(OnLineMapDidSelectImage:)])
            {
                [temp.m_onLineMapClickImageDelegate OnLineMapDidSelectImage:temp.m_tag];
            }
        }
    }
}

- (void)mapView:(MAMapView *)mapView didDeselectAnnotationView:(MAAnnotationView *)view
{
    id <MAAnnotation> annotation = view.annotation;
    
    if ([annotation isKindOfClass:[MyCustomAnnotation class]])
    {
        MyCustomAnnotation *temp = (MyCustomAnnotation *)annotation;
        if (temp.m_annotationType == Annotation_ClickImage_Point)
        {
            if ([temp.m_onLineMapClickImageDelegate respondsToSelector:@selector(OnLineMapDeselectImage:)])
            {
                [temp.m_onLineMapClickImageDelegate OnLineMapDeselectImage:temp.m_tag];
            }
        }
    }
}

- (void)mapViewWillStartLocatingUser:(MAMapView *)mapView
{
    if ([mapDataManage getMapDataType] == 0)
    {
        return;
    }
}

-(void)mapView:(MAMapView *)mapView didUpdateUserLocation:(MAUserLocation *)userLocation
{
    
}

- (void)UpdateGPSinfo
{
    if (isMapInit != 2)
    {
        return;
    }
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView || ![Plugin_OnLineMapUtility sharedInstance].isHasGPS)
    {
        return;
    }
    if (!([Plugin_OnLineMapUtility sharedInstance].m_viewControllerType == ViewController_POI || [Plugin_OnLineMapUtility sharedInstance].m_viewControllerType == ViewController_Main))
    {
        return;
    }
    if ([Plugin_OnLineMapUtility sharedInstance].isAnimated)
    {
        return;
    }
    if (self.m_carView)
    {
        UIView *superView = self.m_carView.superview;
        [superView bringSubviewToFront:self.m_carView];
    }
    if ([Plugin_OnLineMapUtility sharedInstance].m_mapViewState == State_Navi)
    {
        return;
    }
    if (![[MWPreference sharedInstance] getValue:PREF_DISABLE_GPS])
    {
        m_maMapView.showsUserLocation = NO;
        return;
    }
    if (!m_maMapView.showsUserLocation)
    {
        return;
    }
    MAUserLocation *userLocation = m_maMapView.userLocation;
    if (userLocation.location.coordinate.latitude <= 0  || userLocation.location.coordinate.longitude <= 0)
    {
        return;
    }
    if (tbtNavi)
    {
        NSString *date = [[[NSString alloc] init] autorelease];
        NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
        long long time;
        [dateFormatter setDateFormat:@"YYYYMMddHHmmss"];
        date = [dateFormatter stringFromDate:userLocation.location.timestamp];
        time = [date longLongValue];
        
        tbtNavi->SetGPSInfo(2, userLocation.location.coordinate.longitude, userLocation.location.coordinate.latitude, userLocation.location.speed, userLocation.location.course, time / 10000000000 - 2000, time % 10000000000 / 100000000, time % 100000000 / 1000000, time % 1000000 / 10000, time % 10000 / 100, time % 100);
        
        if (userLocation.location.course > 0)
        {
            CGFloat degree = userLocation.location.course - m_maMapView.rotationDegree;
            if (degree < 0)
            {
                degree = 360.0 + degree;
            }
            CGFloat rotation = ConvertDegreesToRadians(degree);
            CGAffineTransform at =CGAffineTransformMakeRotation(rotation);
            [self.m_carView setTransform:at];
        }
    }
    m_startCoord.coord = userLocation.location.coordinate;
    
    [[Plugin_OnLineMapUtility sharedInstance] SynLocalCarPositionWithNet];
    if ([Plugin_OnLineMapUtility sharedInstance].isMove) //移图下
    {
        CGPoint screenXY = CGPointMake(m_maMapView.bounds.size.width/2, m_maMapView.bounds.size.height/2);
        CLLocationCoordinate2D coord;
        coord = [m_maMapView convertPoint:screenXY toCoordinateFromView:m_maMapView];
        [self ShowLableAndViewWithMapCenter:coord];
    }
    else
    {
        CLLocationCoordinate2D Coord = m_startCoord.coord;
        [m_maMapView setCenterCoordinate:Coord];
    }
    
    
    MyCustomAnnotation *annotation = self.m_carView.annotation;
    if (annotation == nil)
    {
        MyCustomAnnotation *CarPointAnn = [[[MyCustomAnnotation alloc] initWithType:Annotation_Car_Point] autorelease];
        CLLocationCoordinate2D coord = m_startCoord.coord;
        CarPointAnn.coordinate = coord;
        [m_maMapView addAnnotation:CarPointAnn];
    }
    else
    {
        annotation.coordinate = m_startCoord.coord;
    }
}

- (void)mapView:(MAMapView *)mapView didFailToLocateUserWithError:(NSError *)error
{
    
}

#pragma mark -
#pragma mark UIButton method

- (void)PoiButtonPressed:(UIButton *)sender
{
    MAAnnotationView *view = (MAAnnotationView *)sender.superview;
    if ([view isKindOfClass:[MAAnnotationView class]])
    {
        id <MAAnnotation> annotation = view.annotation;
        
        if ([annotation isKindOfClass:[MyCustomAnnotation class]])
        {
            MyCustomAnnotation *temp = (MyCustomAnnotation *)annotation;
            if (temp.m_annotationType == Annotation_ClickImage_Point || temp.m_annotationType == Annotation_ClickPoi)
            {
                if ([temp.m_onLineMapClickImageDelegate respondsToSelector:@selector(OnLineMapDidSelectImage:)])
                {
                    [temp.m_onLineMapClickImageDelegate OnLineMapDidSelectImage:temp.m_tag];
                }
            }
        }
    }
    CGPoint point = view.center;
    int x = point.x -  self.bounds.size.width/2;
    int y = point.y -  self.bounds.size.height/2;
    [[Plugin_OnLineMapUtility sharedInstance] SetAmapCenterWithDragX:x DragY:y];}

#pragma mark -
#pragma mark UIPanGestureRecognizer method

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    return YES;
}

- (void)panRecongnizer:(UIPanGestureRecognizer *)recognizer
{
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        return;
    }
	if (recognizer.state == UIGestureRecognizerStateBegan)
	{
        _ispan = YES;
        [Plugin_OnLineMapUtility sharedInstance].isShowPopPoi = NO;
        [Plugin_OnLineMapUtility sharedInstance].isMove = YES;
        [self ShowLableAndViewWithMapCenter:m_maMapView.centerCoordinate];
        [self performSelectorOnMainThread:@selector(SendNotificationShowMap) withObject:nil waitUntilDone:NO];
        [self performSelectorOnMainThread:@selector(SendPoiNotificationWith:) withObject:[NSNumber numberWithInt:1] waitUntilDone:NO];
		if (m_delayShowButton)
        {
            [m_delayShowButton invalidate];
            m_delayShowButton = nil;
        }
    }
	if (recognizer.state == UIGestureRecognizerStateChanged)
	{
        [self ShowLableAndViewWithMapCenter:m_maMapView.centerCoordinate];
        if ([Plugin_OnLineMapUtility sharedInstance].isAmapView && [Plugin_OnLineMapUtility sharedInstance].m_viewControllerType == ViewController_Main)
        {
            UIView *superview = [self superview];
            [superview bringSubviewToFront:self];
        }
          [self performSelectorOnMainThread:@selector(SendPoiNotificationWith:) withObject:[NSNumber numberWithInt:5] waitUntilDone:NO];
	}
    else if (recognizer.state == UIGestureRecognizerStateEnded)
	{
        _ispan = NO;
        if (m_delayShowButton)
        {
            [m_delayShowButton invalidate];
            m_delayShowButton = nil;
        }
        m_delayShowButton = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(DelayShowButton) userInfo:nil repeats:NO];
        [Plugin_OnLineMapUtility sharedInstance].isShowPopPoi = YES;
        [self performSelectorOnMainThread:@selector(SendPoiNotificationWith:) withObject:[NSNumber numberWithInt:2] waitUntilDone:NO];
    }
}

- (void)TapRecongnizer:(UITapGestureRecognizer *)recognizer
{
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        return;
    }
    if (recognizer.numberOfTapsRequired == 2 && recognizer.numberOfTouchesRequired == 1)
    {
        [[MWMapOperator sharedInstance] MW_ZoomMapView:GMAP_VIEW_TYPE_MAIN ZoomFlag:1 ZoomLevel:ZOOM_500_KM];
    }
    else if (recognizer.numberOfTapsRequired == 1 && recognizer.numberOfTouchesRequired == 2)
    {
        [[MWMapOperator sharedInstance] MW_ZoomMapView:GMAP_VIEW_TYPE_MAIN ZoomFlag:-1 ZoomLevel:ZOOM_500_KM];
    }
    else
    {
        if (_isLongPressed)
        {
            _isLongPressed = NO;
            return;
        }
        [self performSelectorOnMainThread:@selector(SendPoiNotificationWith:) withObject:[NSNumber numberWithInt:1] waitUntilDone:NO];
    }
}

- (void)pinchRecognizer:(UIPinchGestureRecognizer *)recognizer
{
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        return;
    }
	if([recognizer state] == UIGestureRecognizerStateBegan)
    {
        m_maMapView.rotateCameraEnabled = NO; //两指内缩和外拉，不支持抬仰角
		lastScale = 1.0f;
		return;
    }
	
	else if([recognizer state] == UIGestureRecognizerStateChanged)
    {
		if (abs(lastScale*100-recognizer.scale*100)>30)
		{
			if (lastScale<recognizer.scale)
			{
                [[MWMapOperator sharedInstance] MW_ZoomMapView:GMAP_VIEW_TYPE_MAIN ZoomFlag:1 ZoomLevel:ZOOM_500_KM];
			}
            else
			{
				[[MWMapOperator sharedInstance] MW_ZoomMapView:GMAP_VIEW_TYPE_MAIN ZoomFlag:-1 ZoomLevel:ZOOM_500_KM];
			}
			lastScale = recognizer.scale;
		}
		else
        {
            
		}
    }
	else if([recognizer state] == UIGestureRecognizerStateEnded)
	{
        m_maMapView.rotateCameraEnabled = YES;
		lastScale = 1.0;
	}
	else if([recognizer state] == UIGestureRecognizerStateFailed)
	{
        
	}
	
}

- (void)longRecongnizer:(UILongPressGestureRecognizer *)recognizer
{
    
//    if (![ANParamValue sharedInstance].isPath && ![[MWPreference sharedInstance] getValue:PREF_AUTO_GETPOIINFO] && [Plugin_OnLineMapUtility sharedInstance].m_viewControllerType == ViewController_Main)
    {
        if (_ispan)     //如果正在平移，则不识别长按
        {
            return;
        }
        if([recognizer state] == UIGestureRecognizerStateBegan)
        {
            _isLongPressed = YES;
            if (![[MWPreference sharedInstance] getValue:PREF_AUTO_GETPOIINFO]) {
                CGPoint point = [recognizer locationInView:self];
                int x = point.x -  self.bounds.size.width/2;
                int y = point.y -  self.bounds.size.height/2;
                [[Plugin_OnLineMapUtility sharedInstance] SetAmapCenterWithDragX:x DragY:y];
                [Plugin_OnLineMapUtility sharedInstance].isShowPopPoi = YES;
            }
            
            [self performSelectorOnMainThread:@selector(SendPoiNotificationWith:) withObject:[NSNumber numberWithInt:4] waitUntilDone:NO];
        }
        else if([recognizer state] == UIGestureRecognizerStateEnded)
        {
            NSLog(@"UILongPressGestureRecognizer Ended");
        }
    }
}

#pragma mark PaintingViewDelagate
-(void)mapView:(PaintingView *)mapView GestureRecognizer:(UIGestureRecognizer *)recognizer gestureType:(RECOGNIZETYPE)gesturetype  withParam:(int)param
{
    [delegate mapView:mapView GestureRecognizer:recognizer gestureType:gesturetype withParam:param];
}

@end
