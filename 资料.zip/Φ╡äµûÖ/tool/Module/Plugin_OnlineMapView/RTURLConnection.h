//
//  RTNetConnection.h
//  TBTDemo
//
//  Created by yuxinyan on 12-5-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class RTURLConnection;
@protocol IRTURLConnectionDelegate
- (void)rtURLConnectionDidFinished:(RTURLConnection *)conn;
- (void)rtURLConnection:(RTURLConnection *)conn didFailWithError:(NSError *)error;
@end

@interface RTURLConnection : NSObject {
	id rtDelegate;
@private
    BOOL _finished;
    NSString *_url;
    NSMutableDictionary *_headerFields;
    NSURLResponse *_response;
    NSMutableData *_data;
}

@property (nonatomic, assign) id<IRTURLConnectionDelegate> rtDelegate;

- (NSURLResponse *)response;

- (NSData *)data;

- (BOOL)finished;

- (void)setURL:(NSString *)url;

- (void)setValue:(NSString *)value forHTTPHeaderField:(NSString *)field;

- (void)getRequest;

- (void)postContent:(NSData *)content;
@end
