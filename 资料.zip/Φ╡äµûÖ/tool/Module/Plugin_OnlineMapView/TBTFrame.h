//
//  TBTFrame.h
//  TBTDemo
//
//  Created by yuxinyan on 12-5-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#ifndef __FRAME_TBT__
#define __FRAME_TBT__

#include "ITBT.h"
@class Plugin_OnLineMapView;

class CTBTFrame : public IFrameForTBT/*, public IFrameForNetSearch*/
{
public:
    CTBTFrame(Plugin_OnLineMapView* pstParent);
    ~CTBTFrame();
    
protected:

    void RequestHTTP(int iModuleID, int iConnectID, int iType, char* pstrUrl, char* pstrHead, BYTE* pData, int iDataLength);
    
    void UpdateNaviInfo(DGNaviInfo & stDGNaviInfo);
    
    void ShowCross(int iPicFormat, BYTE* pPicBuf1, BYTE* pPicBuf2, int iPicSize1, int iPicSize2);
    
    void HideCross();
    
    void ShowLaneInfo(BYTE* pLaneBackInfo, BYTE* pLaneSelectInfo);

    void HideLaneInfo();

    void PlayNaviSound(int iSoundType, WORD* pwSoundStr, int iLength);
    
    void EndEmulatorNavi();
    
    void ArriveWay(int iWayId);
    
    void OffRoute();
    
    void RerouteForTMC(int iRouteID);
    
    void RouteDestroy();
    
    void CarLocationChange(CarLocation  stCarLocation);
    
    void SetRouteRequestState(int iState);
    
    void TMCUpdate(int iHour, int iMinute, int iSecond);
    
    void ShowTrafficPanel(BYTE* pPanelBuf, int iSize);
    
    void HideTrafficPanel();
    
    int GetPlayState();
    
    void LockScreenNaviTips(WORD* pwSoundStr, int iLeng, int iTurnIcon, int iSegRemainLeng);
    
    
    
    bool SendHttpUrl(
                             const char* url
                             );
    
    void DoGetUrl(
                          const char* pcURL
                          );
    
    void DoPostUrl(
                           int iConnectID  ,					// [I] ¡¨Ω”ID£¨Frame«Î«ÛµΩ ˝æ›∫Û”√¥ÀIDΩ´ ˝æ›¥´∏¯TBT
                           char* pstrURL ,						// [I] «Î«ÛµƒURL¥Æ
                           char* pstrHead ,					// [I] HTTPÕ∑£¨ƒ¨»œŒ™ø’
                           char* pstrData ,					// [I] Post∑Ω ΩµƒData ˝æ›£¨ƒ¨»œŒ™ø’
                           int iDataLength 					// [I] Data ˝æ›≥§∂»£¨ƒ¨»œŒ™ø’
                           );
    
    BOOL GetServerAddr(
                               int iServerType,
                               char acUrl[],
                               int &nLen  // [I/O] ‰»Î ˝◊È¥Û–°£¨ ‰≥ˆŒ™ µº ƒ⁄»›≥§∂»
                               );
    
private:
    Plugin_OnLineMapView* m_pstParent;
    
};

#endif