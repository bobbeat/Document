//
//  TBTFrame.m
//  TBTDemo
//
//  Created by yuxinyan on 12-5-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TBTFrame.h"
#import "RTURLConnection.h"
#import "TBTCommon.h"
#import "Plugin_OnLineMapView.h"
#import "Plugin_OnLineMapUtility.h"

@interface TBTNetwork : NSObject<IRTURLConnectionDelegate> {
    int mid;
    int cid;
    ITBT *tbt;
    RTURLConnection *conn;
}
@property (nonatomic) int mid;
@property (nonatomic) int cid;
@end

@implementation TBTNetwork
@synthesize cid;
@synthesize mid;

- (void)setTBT:(ITBT *)aTbt
{
    tbt = aTbt;
}

- (void)dealloc
{
    if (conn)
    {
        [conn release];
        conn = nil;
    }
    [super dealloc];
}

- (void)getWithURL:(char *)URL andHeader:(char *)header
{  
    conn = [[RTURLConnection alloc] init];
    [conn setRtDelegate:self];
    if (URL)
    {
        [conn setURL:[NSString stringWithCString:URL encoding:NSUTF8StringEncoding]];
        if (header)
        {
            NSLog(@"NKTBTNetwork::getWithURL:%s", header);
        }
        [conn getRequest];
    } else
    {
    }
}

- (void)postWithURL:(char *)URL header:(char *)header andData:(char *)data dataLen:(int)length
{
    conn = [[RTURLConnection alloc] init];
    [conn setRtDelegate:self];
    if (URL)
    {
        [conn setURL:[NSString stringWithCString:URL encoding:NSUTF8StringEncoding]];
        if (header)
        {
            NSLog(@"NKTBTNetwork::postWithURL:%s", header);
        }
        NSData *data1 = nil;
        if (data && length > 0)
        {
            data1 = [[NSData alloc] initWithBytes:data length:length];
        }
        
        [conn postContent:data1];
        [data1 release];
    }
}

- (void)rtURLConnectionDidFinished:(RTURLConnection *)con
{
//    NSString *str = [[NSString alloc] initWithData:[con data] encoding:NSUTF8StringEncoding];
//    NSLog(@"NKTBTNetwork:%@",str);
//    [str release];
    if (NULL != tbt)
    {
        NSData *data = [con data];
        tbt->ReceiveNetData([self mid], [self cid], (BYTE *)[data bytes], [data length]);
        
    }
    [self release];
}

- (void)rtURLConnection:(RTURLConnection *)conn didFailWithError:(NSError *)error
{
    NSLog(@"NKTBTNetwork::rtURLConnection:didFailWithError");
    if (NULL != tbt)
    {
//        NSData *data = [conn data];
        tbt->SetNetRequestState([self mid], [self cid], 3);
    }
    [self release];
}

@end

typedef struct
{
    int nModuleID;
    int nConnectID;				// [I] 连接ID，Frame请求到数据后用此ID将数据传给TBT
    char* pURL;				    // [I] 请求的URL串
    char* pHead;		    // [I] HTTP头，默认为空
    char* pData;		    // [I] Post方式的Data数据，默认为空
    int nDataLength;		// [I] Data数据长度，默认为空
    bool bGetMode;        // [I] true为Get方式，false为post方式
}NetRequest_t;


@interface NKTBTRequest : NSObject {
    NetRequest_t request;
    ITBT *tbt;
}
@property NetRequest_t request;
- (void)action;
@end

@implementation NKTBTRequest
@synthesize request;
- (void)setTBT:(ITBT *)aTbt
{
    tbt = aTbt;
}

- (void)action
{
    TBTNetwork *net = [[TBTNetwork alloc] init];
    [net setCid:request.nConnectID];
    [net setMid:request.nModuleID];
    [net setTBT:tbt];
    if (request.bGetMode || !request.pData || request.nDataLength <= 0)
    {
        [net getWithURL:request.pURL andHeader:request.pHead];
    } else
    {
        [net postWithURL:request.pURL header:request.pHead andData:request.pData dataLen:request.nDataLength];
    }
}

- (void)dealloc
{
    if (request.pURL) {
        free(request.pURL);
        request.pURL = NULL;
    }
    if (request.pHead) {
        free(request.pHead);
        request.pHead = NULL;
    }
    if (request.pData) {
        free(request.pData);
        request.pData = NULL;
    }
    [super dealloc];
}
@end
CTBTFrame::CTBTFrame(Plugin_OnLineMapView* pstParent)
{
    m_pstParent = pstParent;
}

CTBTFrame::~CTBTFrame()
{
    
}

void CTBTFrame::RequestHTTP(int iModuleID, int iConnectID, int iType, char* pstrUrl, char* pstrHead, BYTE* pData, int iDataLength)
{
    ITBT *tbt = m_pstParent->tbtNavi;
    if(!tbt)
    {
        return;
    }
    
    NSLog(@"NetRequestHTTP %s %d", pstrUrl, [NSThread isMainThread]);
    NKTBTRequest *req = [[NKTBTRequest alloc] init];
    NetRequest_t it = {0};
    it.nModuleID = iModuleID;
    it.nConnectID = iConnectID;
    it.pURL = (char *)malloc(1024);
    strcpy(it.pURL, pstrUrl);
    if (pstrHead)
    {
        it.pHead = (char *)malloc(1024);
        strcpy(it.pHead, pstrHead);
    }
    if (pData && iDataLength > 0)
    {
        it.pData = (char *)malloc(1024);
        it.nDataLength = iDataLength;
        memcpy(it.pData, pData, iDataLength);
    }
    it.bGetMode = iType;
    [req setTBT:tbt];
    [req setRequest:it];
    
    
    if ([NSThread isMainThread])
    {
        [req action];
    }
    else
    {
        [req performSelectorOnMainThread:@selector(action) withObject:nil waitUntilDone:NO];
    }

    [req release];
    return;
}

void CTBTFrame::UpdateNaviInfo(DGNaviInfo & stDGNaviInfo)
{
    NSString *m_pwCurRoadName = [[NSString alloc] initWithBytes:stDGNaviInfo.m_pwCurRoadName length:stDGNaviInfo.m_iCurNameLen*2 encoding:NSUTF16LittleEndianStringEncoding];
    NSString *m_pwNextRoadName = [[NSString alloc] initWithBytes:stDGNaviInfo.m_pwNextRoadName length:stDGNaviInfo.m_iNextNameLen*2 encoding:NSUTF16LittleEndianStringEncoding];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         m_pwCurRoadName,@"m_pwCurRoadName",
                         m_pwNextRoadName,@"m_pwNextRoadName",
                         [NSNumber numberWithDouble:stDGNaviInfo.m_dLongitude],@"m_dLongitude",
                         [NSNumber numberWithDouble:stDGNaviInfo.m_dLatitude],@"m_dLatitude",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iType],@"m_iType",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iSAPADist],@"m_iSAPADist",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iCameraDist],@"m_iCameraDist",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iIcon],@"m_iIcon",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iRouteRemainDis],@"m_iRouteRemainDis",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iRouteRemainTime],@"m_iRouteRemainTime",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iSegRemainDis],@"m_iSegRemainDis",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iSegRemainTime],@"m_iSegRemainTime",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iCarDirection],@"m_iCarDirection",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iCurSegNum],@"m_iCurSegNum",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iCurLinkNum],@"m_iCurLinkNum",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iCurPointNum],@"m_iCurPointNum",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iCurNameLen],@"m_iCurNameLen",
                         [NSNumber numberWithInt:stDGNaviInfo.m_iNextNameLen],@"m_iNextNameLen",
                         nil];
//    NSLog(@"%d",stDGNaviInfo.m_iCurLinkNum);
    [m_pstParent TBT_updateDGNaviInfor:dic];
    [m_pwNextRoadName release];
    [m_pwCurRoadName release];
}

void CTBTFrame::ShowCross(int iPicFormat, BYTE* pPicBuf1, BYTE* pPicBuf2, int iPicSize1, int iPicSize2)
{
    NSLog(@"ShowCross\n");
}

void CTBTFrame::HideCross()
{
    NSLog(@"HideCross\n");
}

void CTBTFrame::ShowLaneInfo(BYTE* pLaneBackInfo, BYTE* pLaneSelectInfo)
{
    for(int i = 0; i < 8; i++)
    {
        NSLog(@"ShowLaneInfo_%d = %d,%d\n", i, pLaneBackInfo[i], pLaneSelectInfo[i]);
    }
}

void CTBTFrame::HideLaneInfo()
{
    NSLog(@"HideLaneInfo\n");
}

void CTBTFrame::PlayNaviSound(int iSoundType, WORD* pwSoundStr, int iLength)
{
    NSString *playString = [[NSString alloc] initWithBytes:pwSoundStr length:iLength*2 encoding:NSUTF16LittleEndianStringEncoding];
    [m_pstParent TBT_PlayNaviSound:playString];
    [playString release];
    
}

void CTBTFrame::EndEmulatorNavi()
{
    NSLog(@"EndEmulatorNavi\n");
    [[Plugin_OnLineMapUtility sharedInstance] StopEmulatorNavi];
}

void CTBTFrame::ArriveWay(int iWayId)
{
    NSLog(@"ArriveWay = %d\n", iWayId);
    [m_pstParent Net_ArriveWay];
}

void CTBTFrame::OffRoute()
{
    NSLog(@"Reroute\n");
    [m_pstParent TBT_OffRoute];
}

void CTBTFrame::RerouteForTMC(int iRouteID)
{
    NSLog(@"RerouteForTMC\n");
}

void CTBTFrame::RouteDestroy()
{
    NSLog(@"RouteDestroy\n");
}

void CTBTFrame::CarLocationChange(CarLocation  stCarLocation)
{
//    [m_pstParent updateGPSSpeed:stCarLocation.m_iSpeed direction:stCarLocation.m_iCarDir
//                      locationX:stCarLocation.m_dLongitude locationY:stCarLocation.m_dLatitude];
//    printf("GPS %f %f %d\n", stCarLocation.m_dLongitude, stCarLocation.m_dLatitude, stCarLocation.m_iSpeed);
}

void CTBTFrame::SetRouteRequestState(int iState)
{
    [m_pstParent TBT_SetRouteRequestState:iState];
}

void CTBTFrame::TMCUpdate(int iHour, int iMinute, int iSecond)
{
    NSLog(@"TMCUpdate\n");
    ITBT *tbt = m_pstParent->tbtNavi;
    if(tbt)
    {
        tbt->SelectRoute(1);
        int iItemCount = 0;
        TMCBarItem* pstlist = tbt->CreateTMCBar(0, 2000, iItemCount);
        for(int i = 0; i < iItemCount; i++)
        {
            TMCBarItem* ptemp = pstlist + i;
        }
    }
}

void CTBTFrame::ShowTrafficPanel(BYTE* pPanelBuf, int iSize)
{
    NSLog(@"ShowTrafficPanel\n");
}

void CTBTFrame::HideTrafficPanel()
{
    NSLog(@"HideTrafficPanel\n");
}

int CTBTFrame::GetPlayState()
{
    return 0;
}

void CTBTFrame::LockScreenNaviTips(WORD* pwSoundStr, int iLeng, int iTurnIcon, int iSegRemainLeng)
{
    
}

bool CTBTFrame::SendHttpUrl(
                 const char* url
                 )
{
/*
    NKTBTRequest *req = [[NKTBTRequest alloc] init];
    NetRequest_t it = {0};
    it.nConnectID = iConnectID;
    it.pURL = (char *)malloc(1024);
    strcpy(it.pURL, pstrUrl);
    if (pstrHead)
    {
        it.pHead = (char *)malloc(1024);
        strcpy(it.pHead, pstrHead);
    }
    if (pData && iDataLength > 0)
    {
        it.pData = (char *)malloc(1024);
        it.nDataLength = iDataLength;
        memcpy(it.pData, pData, iDataLength);
    }
    it.bGetMode = iType;
    [req setTBT:tbt];
    [req setRequest:it];
    
    if ([NSThread isMainThread])
    {
        [req action];
    }*/
}

void CTBTFrame::DoGetUrl(
              const char* pcURL
              )
{
    
}

void CTBTFrame::DoPostUrl(
               int iConnectID  ,					// [I] ¡¨Ω”ID£¨Frame«Î«ÛµΩ ˝æ›∫Û”√¥ÀIDΩ´ ˝æ›¥´∏¯TBT
               char* pstrURL ,						// [I] «Î«ÛµƒURL¥Æ
               char* pstrHead ,					// [I] HTTPÕ∑£¨ƒ¨»œŒ™ø’
               char* pstrData ,					// [I] Post∑Ω ΩµƒData ˝æ›£¨ƒ¨»œŒ™ø’
               int iDataLength 					// [I] Data ˝æ›≥§∂»£¨ƒ¨»œŒ™ø’
               )
{
    
}

BOOL CTBTFrame::GetServerAddr(
                   int iServerType,
                   char acUrl[],
                   int &nLen  // [I/O] ‰»Î ˝◊È¥Û–°£¨ ‰≥ˆŒ™ µº ƒ⁄»›≥§∂»
                   )
{
    return NULL;
}