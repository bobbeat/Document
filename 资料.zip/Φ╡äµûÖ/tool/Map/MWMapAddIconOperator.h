//
//  MWMapAddIcon.h
//  AutoNavi
//
//  Created by gaozhimin on 13-9-4.
//
//

#import <Foundation/Foundation.h>
#import "MWPoiOperator.h"

#define Fresh_Poi @"Fresh_Poi"


@interface MWMapPoi : MWPoi

/**
 *	经纬度转换后的屏幕坐标 内部使用
 */
@property (nonatomic,assign) CGPoint scPoint;

@end

@protocol MWMapPoiAddIconDelegate <NSObject>

@optional

/**
 *	点击地图ICON响应函数
 *
 *	@param	mapPoi	点击Icon的信息
 */
- (void)tapMapPoiIconnWith:(MWMapPoi *)mapPoi;

@end

/*!
 @brief 地图添加标签图标类
 */
@interface MWMapAddIconOperator : NSObject


/**
 *	判断是否在图面上有绘制图标
 *
 *	@return	有图标为yes 无图标为no
 */
+ (BOOL)ExistIconInMap;

/**
 *	清除地图图标
 */
+(void)ClearMapIcon;

/**
 *	初始化方法
 *
 *	@param	image	在地图上绘制的图标
 *	@param	array	绘制在地图上的点  存储对象为 MWMapPoi
 *	@param	view	添加地图的父视图
 *	@param	delegate	点击Icon响应委托。
 *
 */
- (id)initWithImage:(UIImage *)image poiArray:(NSArray *)array inView:(UIView *)view delegate:(id<MWMapPoiAddIconDelegate>)delegate;

/**
 *	重新刷新poi数组
 *
 *	@param	array	新的poi数组
 */
- (void)freshPoiArray:(NSArray *)array;

@end
