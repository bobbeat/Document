//
//  MWMapAddIcon.m
//  AutoNavi
//
//  Created by gaozhimin on 13-9-4.
//
//

#import "MWMapAddIconOperator.h"
#import "GDBL_typedef.h"
#import "GDMID_Interface.h"
#import "MWPoiOperator.h"
#import "Plugin_OnLineMapUtility.h"


#define CUSTOMELEMENT_NUM 1000

static MWMapAddIconOperator *g_mapAddIconView = nil;

@interface MWMapPoiTapView : UIView

@property (nonatomic,retain) MWMapPoi *mapPoi;


@end

@implementation MWMapPoiTapView

@synthesize mapPoi;
- (void)dealloc
{
    self.mapPoi = nil;
    [super dealloc];
}

@end

@interface MWMapAddIconOperator()<OnLineMapClickImageDelegate>
{
    GBITMAP   *_currentBitmap;
    GCUSTOMELEMENT  pCustomElement[CUSTOMELEMENT_NUM];
    id<MWMapPoiAddIconDelegate> _delegate;  //响应委托
    UIView *_superView;                     //添加button的View
    NSMutableArray          *_subViewArray; //子视图数组
    NSArray *_poiArray;                     //显示在地图上的poi
    float mapScale;                         //缩放比例，高清为2，标清为1
    UIImage *_imageIcon;
}

@property (nonatomic,retain) NSArray *poiArray;                     //显示在地图上的poi
/**
 *	将数据转换成引擎数据
 *
 *	@param	ppElements	传入引擎的元素数据
 *	@param	count       传入引擎的元素个数
 */
- (void)getElementData:(GCUSTOMELEMENT **)ppElements count:(Gint32 *)count;

@end

#pragma mark - show map icon callback
static void MWMapGetElement(GCUSTOMELEMENT **ppElements, Gint32 *pNumberOfElement)
{
    [g_mapAddIconView getElementData:ppElements count:pNumberOfElement];
}


#pragma mark - MWMapAddIconOperator
@implementation MWMapAddIconOperator

@synthesize poiArray = _poiArray;

/**
 *	判断是否在图面上有绘制图标
 *
 *	@return	有图标为yes 无图标为no
 */
+ (BOOL)ExistIconInMap
{
    if (g_mapAddIconView)
    {
        if ([g_mapAddIconView.poiArray  count] > 0)
        {
            return YES;
        }
    }
    return NO;
}

/**
 *	清除地图图标
 */
+(void)ClearMapIcon
{
    if (g_mapAddIconView)
    {
        if ([g_mapAddIconView.poiArray  count] > 0)
        {
            g_mapAddIconView.poiArray = [NSArray array];
        }
    }
    if ([ANParamValue sharedInstance].isUseNETMap) {
        [[Plugin_OnLineMapUtility sharedInstance] NET_ClearAllClickImage];
    }
}

- (id)init
{
    return [self initWithImage:nil poiArray:nil inView:nil delegate:nil];
}

- (void)dealloc
{
    [[Plugin_OnLineMapUtility sharedInstance] NET_ClearAllClickImage];
    [_imageIcon release];
    _imageIcon = nil;
    if (_currentBitmap)
    {
        if (_currentBitmap->pAlpha)
        {
            free(_currentBitmap->pAlpha);
        }
        if (_currentBitmap->pData)
        {
            free(_currentBitmap->pData);
        }
        free(_currentBitmap);
    }
    for (UIView *view in _subViewArray)
    {
        [view removeFromSuperview];
    }
    [_subViewArray release];
    self.poiArray = nil;
    GDMID_SetGetElementCB(NULL);
    g_mapAddIconView = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

/**
 *	初始化方法
 *
 *	@param	image	在地图上绘制的图标
 *	@param	array	绘制在地图上的点  存储对象为 MWMapPoi
 *	@param	view	添加地图的父视图    目前此参数废弃，内部赋值
 *
 */
- (id)initWithImage:(UIImage *)image poiArray:(NSArray *)array inView:(UIView *)view  delegate:(id<MWMapPoiAddIconDelegate>)delegate
{
    
    if (self = [super init])
    {
        if (g_mapAddIconView)
        {
            [g_mapAddIconView freshPoiArray:array];
        }
        _imageIcon = [image retain];

        g_mapAddIconView = self;
        _delegate = delegate;
        _superView = [Plugin_OnLineMapUtility sharedInstance].m_drawingView;
        
        NSLog(@"%f,%f",view.bounds.size.width,view.bounds.size.height);
        
        _poiArray = [array retain];
        _currentBitmap = (GBITMAP*)malloc(sizeof(GBITMAP));
        memset(_currentBitmap, 0, sizeof(GBITMAP));
        [self setBitMapWith:_currentBitmap image:image];
        
        GETELEMENT pFun = GNULL;
        pFun = MWMapGetElement;
        GDMID_SetGetElementCB(pFun);
        
        _subViewArray = [[NSMutableArray alloc] init];
        
        mapScale= (([UIScreen instancesRespondToSelector:@selector(scale)]==YES)?(([[UIScreen mainScreen] scale] == 2.0)?2.0:1.0):1.0 );
        
        if ([ANParamValue sharedInstance].isUseNETMap)
        {
            for (int i = 0; i < [array count]; i++)
            {
                MWMapPoi *poi = [array objectAtIndex:i];
                [[Plugin_OnLineMapUtility sharedInstance] NET_AddClickImageWith:poi image:image delegate:self tag:i];
            }
            
        }
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationReceived:) name:Fresh_Poi object:nil];
    }
    return self;
}

/**
 *	重新刷新poi数组
 *
 *	@param	array	新的poi数组
 */
- (void)freshPoiArray:(NSArray *)array
{
    if ([array count] > 0)
    {
        self.poiArray = array;
        g_mapAddIconView = self;
        GETELEMENT pFun = GNULL;
        pFun = MWMapGetElement;
        GDMID_SetGetElementCB(pFun);
    }
    else
    {
        for (UIView *view in _subViewArray)
        {
            [view removeFromSuperview];
        }
        g_mapAddIconView = nil;
        GDMID_SetGetElementCB(GNULL);
    }
    if ([ANParamValue sharedInstance].isUseNETMap)
    {
        [[Plugin_OnLineMapUtility sharedInstance] NET_ClearAllClickImage];
        for (int i = 0; i < [array count]; i++)
        {
            MWMapPoi *poi = [array objectAtIndex:i];
            [[Plugin_OnLineMapUtility sharedInstance] NET_AddClickImageWith:poi image:_imageIcon delegate:self tag:i];
        }
    }
}

#pragma mark = online delegate

- (void)OnLineMapDidSelectImage:(int)tag
{
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        return;
    }
    MWMapPoi *tapPoi =  [self.poiArray objectAtIndex:tag];
    if (_delegate && [_delegate respondsToSelector:@selector(tapMapPoiIconnWith:)])
    {
        [_delegate tapMapPoiIconnWith:tapPoi];
    }
}

- (void)OnLineMapDeselectImage:(int)tag
{
    
}

#pragma mark - UITapGestureRecognizer method

- (void)poiTapRecongnizer:(UITapGestureRecognizer *)recognizer
{
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        return;
    }
    if (recognizer.numberOfTapsRequired == 1 && recognizer.numberOfTouchesRequired == 1)
    {
        MWMapPoiTapView *tapView =  (MWMapPoiTapView *)recognizer.view;
        if (_delegate && [_delegate respondsToSelector:@selector(tapMapPoiIconnWith:)])
        {
            [_delegate tapMapPoiIconnWith:tapView.mapPoi];
        }
        NSLog(@"tap success : %ld,%ld",tapView.mapPoi.longitude,tapView.mapPoi.latitude);
    }
}

#pragma mark - public method


#pragma mark -
#pragma mark notification
-(void)notificationReceived:(NSNotification*) notification
{
    if ([[notification name] isEqualToString:Fresh_Poi])
    {
        if ([ANParamValue sharedInstance].isUseNETMap)
        {
            for (int i = 0; i < [self.poiArray count]; i++)
            {
                MWMapPoi *poi = [self.poiArray objectAtIndex:i];
                [[Plugin_OnLineMapUtility sharedInstance] NET_AddClickImageWith:poi image:_imageIcon delegate:self tag:i];
            }
            [[Plugin_OnLineMapUtility sharedInstance] SetAmapCenterWithDragX:0 DragY:0];
        }
    }
}


#pragma mark - private method

/**
 *	将数据转换成引擎数据
 *
 *	@param	ppElements	传入引擎的元素数据
 *	@param	count       传入引擎的元素个数
 */
- (void)getElementData:(GCUSTOMELEMENT **)ppElements count:(Gint32 *)count;
{
    NSArray *screenArray = [self getScreenPoiArray];
    
    *count = [screenArray count];
    
    GCUSTOMELEMENT *temp = [self getElementData:screenArray];
    *ppElements = temp;
    
    [self addTapGesture:screenArray];
}

/**
 *	根据屏幕上的点添加手势响应区域
 */
- (void)addTapGesture:(NSArray *)screenArray
{
    for (UIView *view in _subViewArray)
    {
        [view removeFromSuperview];
    }
    for (int i = 0; i < [screenArray count]; i++)
    {
        MWMapPoi *mapPoi = [screenArray objectAtIndex:i];
        MWMapPoiTapView *tapView = [[MWMapPoiTapView alloc] initWithFrame:CGRectMake(0, 0, _currentBitmap->cxWidth, _currentBitmap->cyHeight)];
        tapView.backgroundColor = [UIColor clearColor];
//        tapView.backgroundColor = RGBACOLOR(0.2, 0.2, 0.2, 0.5);
        tapView.center = mapPoi.scPoint;
        tapView.mapPoi = mapPoi;
        [_superView addSubview:tapView];
        [tapView release];
        [_subViewArray addObject:tapView];
        
        UITapGestureRecognizer *singalClick = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(poiTapRecongnizer:)];
        [singalClick setNumberOfTouchesRequired:1];//触摸点个数
        [singalClick setNumberOfTapsRequired:1];//点击次数
        [tapView addGestureRecognizer:singalClick];
        [singalClick release];
    }
}

/**
 *	获取poi数组中屏幕中的点
 *
 *	@return	屏幕中poi的点
 */
- (NSMutableArray *)getScreenPoiArray
{
    NSMutableArray *screenArray = [NSMutableArray array];
    
    CGRect mapRect = _superView.bounds;
    for (int i = 0; i < [_poiArray count]; i++)
    {
        MWMapPoi *mapPoi = [_poiArray objectAtIndex:i];
        GCOORD geoCoord = {0};
        geoCoord.x = mapPoi.longitude;
        geoCoord.y = mapPoi.latitude;
        
        CGPoint point = [self transCoordConvertWith:geoCoord HMapView:GMAP_VIEW_TYPE_MAIN];
        mapPoi.scPoint = point;
//        NSLog(@"%f,%f",point.x,point.y);
        if(YES==CGRectContainsPoint(mapRect, mapPoi.scPoint))
        {
            [screenArray addObject:mapPoi];
        }
    }
    
    return screenArray;
}

//经纬坐标转换屏幕坐标
-(CGPoint)transCoordConvertWith:(GCOORD)layerCoord HMapView:(GMAPVIEWTYPE)mapView
{
	GCOORD scrCoord;
	GCOORD pgdCoord;
	CGPoint layerPoint;
	pgdCoord.x = layerCoord.x;
	pgdCoord.y = layerCoord.y;
	GSTATUS gRet;
    GHMAPVIEW mapHandle;
    GDBL_GetMapViewHandle(mapView,&mapHandle);
    
	gRet=GDBL_CoordConvert(GCC_GEO_TO_SCR, &scrCoord, &pgdCoord,mapHandle);
    
    if (GD_ERR_OK==gRet) {
        layerPoint = CGPointMake(scrCoord.x/mapScale, scrCoord.y/mapScale);
    }else
    {
        layerPoint = CGPointMake(-1, -1);//转换失败或3D模式下的天空区域内
    }
	return layerPoint;
}

/**
 *	获取传入引擎的数据
 *
 *	@param	screenArray	屏幕中poi的点
 *
 *	@return 传入引擎的数据
 */
- (GCUSTOMELEMENT *)getElementData:(NSArray *)screenArray
{
    memset(pCustomElement, 0, sizeof(GCUSTOMELEMENT) * CUSTOMELEMENT_NUM);
    for (int i = 0; i < [screenArray count]; i++)
    {
        MWMapPoi *poi = [screenArray objectAtIndex:i];
        pCustomElement[i].pImage = _currentBitmap;
        pCustomElement[i].x = poi.scPoint.x * mapScale + _currentBitmap->cxWidth/2;
        pCustomElement[i].y = poi.scPoint.y * mapScale + _currentBitmap->cyHeight/2;
    }
    return pCustomElement;
}

/**
 *	将图片数据转换引擎数据
 *
 *	@param	bitMap	引擎图片结构
 *	@param	img	需要显示的图片
 */
- (void)setBitMapWith:(GBITMAP*)bitMap image:(UIImage *)img
{
    CGImageRef inImage = img.CGImage;
    // Create off screen bitmap context to draw the image into. Format ARGB is 4 bytes for each pixel: Alpa, Red, Green, Blue
    CGContextRef cgctx = [self createARGBBitmapContextFromImage:inImage];
    if (cgctx == NULL)
    {
        return ; /* error */
    }

    size_t w = CGImageGetWidth(inImage);
    size_t h = CGImageGetHeight(inImage);
    CGRect rect = {{0,0},{(float)w,(float)h}};
    static int i = 0x40000005;
    bitMap->nID=i;                                   // ID标识
    bitMap->cxWidth =(int)w;
    bitMap->cyHeight =(int)h;
    bitMap->cbxPitch =2;
    bitMap->cbyPicth =2*((int)w);
    
    int nDataCount=w*h*2;
    Guint8 *tmpRGBData= (Guint8*)malloc(nDataCount*sizeof(Guint8));
    Guint8 *rgbData = tmpRGBData;
    
    int nAlphaLen= nDataCount/2;
    Guint8 *tmpAlpha = (Guint8*)malloc(nAlphaLen);
    Guint8 *alpha=tmpAlpha;
    
    CGContextClearRect(cgctx,rect);
    // Draw the image to the bitmap context. Once we draw, the memory
    // allocated for the context for rendering will then contain the
    // raw image data in the specified color space.
    CGContextDrawImage(cgctx, rect, inImage);
    
    // Now we can get a pointer to the image data associated with the bitmap
    // context.
    unsigned char* data = (unsigned char*)CGBitmapContextGetData (cgctx);
    if (data != NULL)
    {
        //offset locates the pixel in the data from x,y.
        //4 for 4 bytes of data per pixel, w is width of one row of data.
        @try {
            unsigned short int write_data;
            
            for (int offset=0; offset<nDataCount*2;) {
                *tmpAlpha = (data[offset]*32/256);
                tmpAlpha++;
                write_data = (data[offset+3] >> 3)  | (( data[offset+2] & 0xFC) << 3) |(( data[offset+1] & 0xF8) << 8);
                //                write_data = (data[offset+1] >> 3)  | (((data[offset+2]<<8)& 0xFC) << 3) |((( data[offset+3]<<16) & 0xF8) << 8);
                *tmpRGBData = (write_data&0xffffffff);
                tmpRGBData++;
                *tmpRGBData = (write_data>>8);
                tmpRGBData++;
                offset+=4;
            }
            
            bitMap->pData = (Guint8*)malloc(nDataCount*sizeof(Guint8));
            memcpy(bitMap->pData, rgbData, nDataCount);
            //            currentBitmap->pData =rgbData;
            
            bitMap->pAlpha= (Guint8*)malloc(nAlphaLen*sizeof(Guint8));
            memcpy(bitMap->pAlpha, alpha, nAlphaLen);
            //            currentBitmap->pAlpha =alpha;
            free(rgbData);
            tmpRGBData = NULL;
            free(alpha);
            tmpAlpha = NULL;
        }
        @catch (NSException * e) {
            NSLog(@"exception %s\n",[[e reason] UTF8String]);
        }
        @finally
        {
            
        }
    }
    // When finished, release the context
    CGContextRelease(cgctx);
    // Free image data memory for the context
    if (data)
    {
        free(data);
    }
    
}

- (CGContextRef) createARGBBitmapContextFromImage:(CGImageRef) inImage {
    
    CGContextRef    context = NULL;
    CGColorSpaceRef colorSpace;
    void *          bitmapData;
    int             bitmapByteCount;
    int             bitmapBytesPerRow;
    
    // Get image width, height. We'll use the entire image.
    size_t pixelsWide = CGImageGetWidth(inImage);
    size_t pixelsHigh = CGImageGetHeight(inImage);
    
    // Declare the number of bytes per row. Each pixel in the bitmap in this
    // example is represented by 4 bytes; 8 bits each of red, green, blue, and
    // alpha.
    bitmapBytesPerRow   = (pixelsWide * 4);
    bitmapByteCount     = (bitmapBytesPerRow * pixelsHigh);
    
    // Use the generic RGB color space.
    colorSpace = CGColorSpaceCreateDeviceRGB();
    
    if (colorSpace == NULL)
    {
        fprintf(stderr, "Error allocating color space\n");
        return NULL;
    }
    
    // Allocate memory for image data. This is the destination in memory
    // where any drawing to the bitmap context will be rendered.
    bitmapData = malloc( bitmapByteCount );
    if (bitmapData == NULL)
    {
        fprintf (stderr, "Memory not allocated!");
        CGColorSpaceRelease( colorSpace );
        return NULL;
    }
    
    // Create the bitmap context. We want pre-multiplied ARGB, 8-bits
    // per component. Regardless of what the source image format is
    // (CMYK, Grayscale, and so on) it will be converted over to the format
    // specified here by CGBitmapContextCreate.
    context = CGBitmapContextCreate (bitmapData,
                                     pixelsWide,
                                     pixelsHigh,
                                     8,      // bits per component
                                     bitmapBytesPerRow,
                                     colorSpace,
                                     kCGImageAlphaPremultipliedFirst);
    if (context == NULL)
    {
        free (bitmapData);
        fprintf (stderr, "Context not created!");
    }
    
    // Make sure and release colorspace before returning
    CGColorSpaceRelease( colorSpace );
    
    return context;
}

@end

@implementation MWMapPoi

@synthesize scPoint;

@end