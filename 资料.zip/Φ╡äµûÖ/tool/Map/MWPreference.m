//
//  MWPreference.m
//  AutoNavi
//
//  Created by yu.liao on 13-7-29.
//
//

#import "MWPreference.h"
#import "GDBL_TTS.h"
#import "GDBL_Location.h"
#import "Plugin_OnLineMapUtility.h"
#import "TrafficEventManager.h"
#import "ANDataSource.h"
#import "ANParamValue.h"
#import "GDBL_TMC.h"
#import "GDBL_PCD.h"
#import "ANOperateMethod.h"
#import "GDBL_DataVerify.h"
#import "MWMapOperator.h"
#import "MWSkinDownloadManager.h"
#import "MWDialectDownloadManage.h"
#import "GDCacheManager.h"

static MWPreference* instance = nil;

#define oldPreferenceFilePath [NSHomeDirectory() stringByAppendingString:@"/Documents/NaviSetting.plist"]
#define preferenceFilePath [NSHomeDirectory() stringByAppendingString:@"/Documents/NaviSettingModel.plist"]

@interface MWPreference()
{
}

@property (nonatomic,setter = setBackgroundNavi:) BOOL backgroundNavi;//后台导航开关

@property (nonatomic,setter = setSpeakTraffic:) BOOL speakTraffic;//路况播报开关

@end

@implementation MWPreference

@synthesize gresourceVersion = _gresourceVersion, mapVersion = _mapVersion, deviceToken = _deviceToken;
@synthesize backgroundNavi = _backgroundNavi;
+(MWPreference*)sharedInstance
{
    @synchronized(self)
    {
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    }
    return instance;
}

+(void)releaseInstance
{
    @synchronized(self)
    {
        if (instance != nil)
        {
            [instance release];
            instance = nil;
        }
    }
}

- (id)init
{
    self = [super init];
    if(self!=nil)
    {
        
    }
	
    return self;
}
#pragma mark -
#pragma mark public Method

-(BOOL)loadPreference
{
    static BOOL st_bReadData = FALSE;
    if(FALSE == st_bReadData)
    {
        st_bReadData = TRUE;
    }
    else if(TRUE == st_bReadData)
    {
        return YES;
    }
    //参数读取－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－
    NSFileManager *fileManager = [NSFileManager defaultManager];
	if([fileManager fileExistsAtPath:oldPreferenceFilePath])//读取旧版本参数
	{
        [self readOldPreference];
        [fileManager removeItemAtPath:oldPreferenceFilePath error:nil];
    }
    else{
        
        if([fileManager fileExistsAtPath:preferenceFilePath]){
            
            [self readPreference];//读取参数
            
            if(fabs(SOFTVERSIONNUM-_softVersion)>0.01f)
            {
                [self preferenceHandle:HANDLE_UPDATE];//版本升级参数设置
                
            }
            [GDBL_TTS GDBL_TTSChangeRole:_ttsRoleIndex];
            [GDBL_TTS GDBL_TTSSetDialectType:_isLZLDialect];
        }
        else{
            [self preferenceHandle:HANDLE_INIT];//初始化
        }
        
    }
    return YES;
}

-(BOOL)savePreference
{
    NSMutableDictionary *prefDic = [[NSMutableDictionary alloc] init];
    [prefDic setValue:[NSNumber numberWithFloat:_softVersion] forKey:@"_softVersion"];
    [prefDic setValue:[NSNumber numberWithInt:_walkMode] forKey:@"_walkMode"];
    [prefDic setValue:[NSNumber numberWithBool:_startupWarning] forKey:@"_startupWarning"];
    [prefDic setValue:[NSNumber numberWithBool:_newFunIntroduce] forKey:@"_newFunIntroduce"];
    [prefDic setValue:[NSNumber numberWithBool:_shakeToChangeTheme] forKey:@"_shakeToChangeTheme"];
    [prefDic setValue:[NSNumber numberWithBool:_interfaceState] forKey:@"_interfaceState"];
    [prefDic setValue:[NSNumber numberWithInt:_interfaceOrientation] forKey:@"_interfaceOrientation"];
    [prefDic setValue:[NSNumber numberWithBool:_ctrip] forKey:@"_ctrip"];
    [prefDic setValue:[NSNumber numberWithBool:_voiceRecongnition] forKey:@"_voiceRecongnition"];
    [prefDic setValue:[NSNumber numberWithBool:_mapDataUpdateNewImage] forKey:@"_mapDataUpdateNewImage"];
    [prefDic setValue:[NSNumber numberWithBool:_mapDataUpdateReminder] forKey:@"_mapDataUpdateReminder"];
    [prefDic setValue:[NSNumber numberWithInt:_currentMonthForUsage] forKey:@"_currentMonthForUsage"];
    [prefDic setValue:[NSNumber numberWithInt:_upgradeMonthForMapUpdate] forKey:@"_upgradeMonthForMapUpdate"];
    [prefDic setValue:[NSNumber numberWithBool:_weSharePush] forKey:@"_weSharePush"];
    [prefDic setValue:[NSNumber numberWithBool:_autoNaviPush] forKey:@"_autoNaviPush"];
    [prefDic setValue:[NSNumber numberWithBool:_positionPush] forKey:@"_positionPush"];
    [prefDic setValue:[NSNumber numberWithInt:_ttsRoleIndex] forKey:@"_ttsRoleIndex"];
    [prefDic setValue:[NSNumber numberWithBool:_uploadLocation] forKey:@"_uploadLocation"];
    [prefDic setValue:[NSNumber numberWithBool:_layerFood] forKey:@"_layerFood"];
    [prefDic setValue:[NSNumber numberWithBool:_layerTourism] forKey:@"_layerTourism"];
    [prefDic setValue:[NSNumber numberWithBool:_clientUGC] forKey:@"_clientUGC"];
    [prefDic setValue:[NSNumber numberWithInt:_UILanguage] forKey:@"_UILanguage"];
    [prefDic setValue:[NSNumber numberWithBool:_englishMap] forKey:@"_englishMap"];
    [prefDic setValue:[NSNumber numberWithBool:_layerTravelNewImageClick] forKey:@"_layerTravelNewImageClick"];
    [prefDic setValue:[NSNumber numberWithBool:_datamanageTravelNewImageClick] forKey:@"_datamanageTravelNewImageClick"];
    [prefDic setValue:[NSNumber numberWithBool:_travelUpdate] forKey:@"_travelUpdate"];
    [prefDic setValue:[NSNumber numberWithBool:_setLanguageManually] forKey:@"_setLanguageManually"];
    [prefDic setValue:[NSNumber numberWithBool:_set95190] forKey:@"_set95190"];
    [prefDic setValue:[NSNumber numberWithBool:_golf] forKey:@"_golf"];
    [prefDic setValue:[NSNumber numberWithBool:_speakTraffic] forKey:@"_speakTraffic"];
    [prefDic setValue:[NSNumber numberWithBool:_trafficMessage] forKey:@"_trafficMessage"];
    [prefDic setValue:[NSNumber numberWithBool:_backgroundNavi] forKey:@"_backgroundNavi"];
    [prefDic setValue:[NSNumber numberWithInt:_PSCountOfUnread] forKey:@"_PSCountOfUnread"];
    [prefDic setValue:[NSNumber numberWithBool:_PSNewCustomerServicePrompt] forKey:@"_PSNewCustomerServicePrompt"];
    [prefDic setValue:[NSNumber numberWithBool:_trafficEvent] forKey:@"_trafficEvent"];
    [prefDic setValue:[NSNumber numberWithBool:_firstStart] forKey:@"_firstStart"];
    [prefDic setValue:[NSNumber numberWithBool:_firstEnterSetUpView] forKey:@"_firstEnterSetUpView"];
    [prefDic setValue:[NSNumber numberWithBool:_backgroundDownload] forKey:@"_backgroundDownload"];
    [prefDic setValue:[NSNumber numberWithBool:_realTimeTraffic] forKey:@"_realTimeTraffic"];
    [prefDic setValue:[NSNumber numberWithBool:_HUDDisplayOrientation] forKey:@"_HUDDisplayOrientation"];
    [prefDic setValue:[NSNumber numberWithBool:_autoGetPOIInfo] forKey:@"_autoGetPOIInfo"];
    [prefDic setValue:[NSNumber numberWithBool:_isFirstEnterSkin] forKey:@"_isFirstEnterSkin"];
    [prefDic setValue:[NSNumber numberWithBool:_isDownloadNewSkin] forKey:@"_isDownloadNewSkin"];
    [prefDic setValue:[NSNumber numberWithInt:_skinType] forKey:@"_skinType"];
    [prefDic setValue:self.gresourceVersion forKey:@"_gresourceVersion"];
    [prefDic setValue:self.deviceToken forKey:@"_deviceToken"];
    [prefDic setValue:self.mapVersion forKey:@"_mapVersion"];
    [prefDic setValue:[NSNumber numberWithBool:_isOldUser] forKey:@"_isOldUser"];
    [prefDic setValue:[NSNumber numberWithBool:_hightPraiseAlert] forKey:@"_hightPraiseAlert"];
    [prefDic setValue:[NSNumber numberWithInt:_nextHightPraiseCount] forKey:@"_nextHightPraiseCount"];
    [prefDic setValue:[NSNumber numberWithBool:_switchedVoice] forKey:@"_switchedVoice"];
    [prefDic setValue:[NSNumber numberWithBool:_isPowerVoicePlay] forKey:@"_isPowerVoicePlay"];
    [prefDic setValue:[NSNumber numberWithInt:_powerVoiceID] forKey:@"_powerVoiceID"];
    [prefDic setValue:[NSNumber numberWithBool:_autoSwitchDialect] forKey:@"_autoSwitchDialect"];
    [prefDic setValue:[NSNumber numberWithInt:_isLZLDialect] forKey:@"_isLZLDialect"];
    [prefDic setValue:[NSNumber numberWithBool:_searchType] forKey:@"_searchType"];
    
    [prefDic writeToFile:preferenceFilePath atomically:YES];
    [prefDic release];
    return YES;
}

-(int)getValue:(PRETYPE)type
{
    int value = -1;
    switch (type)
	{
		case PREF_UILANGUAGE://获取地图语言模式
		{
            value = _UILanguage;
		}
			break;
		case PREF_FONTSIZE://获取地图字体大小
		{
			Gint32 MapFontSize;
			if (GD_ERR_OK == GDBL_GetParam(G_MAP_FONT_SIZE, &MapFontSize))
		    {
				if (MapFontSize == GMAP_FONT_SIZE_BIG)
                {
					value = 0;
                }
				else if (MapFontSize == GMAP_FONT_SIZE_NORMAL)
                {
					value = 1;
                }
				else if (MapFontSize == GMAP_FONT_SIZE_SMALL)
                {
					value = 2;
                }
				else
                {
					value = 1;
                }
				
			}
		}
			break;
			
		case PREF_MAPVIEWMODE://获取地图模式
		{
			GMAPVIEWMODE eMapViewMode;
			GDBL_GetParam(G_MAP_VIEW_MODE, &eMapViewMode);
			value = (int)eMapViewMode;
		}
			break;
			
		case PREF_POIDENSITY://获取地图详细度
		{
			GMAPPOIDENSITY eMapPoiDensity;
			GDBL_GetParam(G_MAP_POI_DENSITY, &eMapPoiDensity);
			value = (int)eMapPoiDensity;
		}
			break;
			
		case PREF_MAPDAYNIGHTMODE://获取昼夜模式
		{
			GMAPDAYNIGHTMODE eMapDayNightMode;
			GDBL_GetParam(G_MAP_DAYNIGHT_MODE, &eMapDayNightMode);
			value = (int)eMapDayNightMode;
		}
			break;
			
		case PREF_TTSROLEINDEX://获取语言选择
		{
            _ttsRoleIndex = [GDBL_TTS GDBL_TTSGetRole];
            value = _ttsRoleIndex;
		}
			break;
		case PREF_PROMPTOPTION://获取语音频率
		{
			GPROMPTOPTION ePromptOption;
			GDBL_GetParam(G_PROMPT_OPTION, &ePromptOption);
			value = (int)ePromptOption;
		}
			break;
		case PREF_WALKMODE://获取出行方式
		{
			value = _walkMode;
		}
			break;
		case PREF_MAPPOIPRIORITY://获取优先模式
		{
			
			GMAPPOIPRIORITY eMapPoiPriority;
			GDBL_GetParam(G_MAP_POI_PRIORITY, &eMapPoiPriority);
			value = (int)eMapPoiPriority;
		}
			break;
        case PREF_BACKGROUND_MODE://后台
        {
            GDBL_GetParam(G_BACKGROUND_MODE, &value);
        }
            break;
        case PREF_MAPSHOWCURSOR://移图游标
        {
            GDBL_GetParam(G_MAP_SHOW_CURSOR, &value);
        }
			break;
        case PREF_DEMO_SPEED://模拟导航速度
        {
            GDEMOSPEED eDemoSpeed = 0;
            GDBL_GetParam(G_DEMO_SPEED, &eDemoSpeed);
            value = eDemoSpeed;
        }
            break;
        case PREF_MAP_SHOW_GUIDEPOST://高速路牌显示
        {
            GDBL_GetParam(G_MAP_SHOW_GUIDEPOST, &value);
        }
            break;
        case PREF_SHOW_SAFETY_ICON://是否显示电子狗图标
        {
            GDBL_GetParam(G_SHOW_SAFETY_ICON, &value);
        }
            break;
        case PREF_SHOW_MAP_GRAY_BKGND://实时交通显示灰色地图
        {
            GDBL_GetParam(G_SHOW_MAP_GRAY_BKGND, &value);
        }
            break;
        case PREF_MAP_TMC_SHOW_OPTION://控制是城市TMC还是路径线TMC
        {
            GDBL_GetParam(G_MAP_TMC_SHOW_OPTION, &value);
        }
            break;
		case PREF_ROUTE_OPTION:
		{//获取路径规划原则
            GROUTEOPTION routeRule;
            GDBL_GetParam(G_ROUTE_OPTION, &routeRule);
			value = routeRule;
		}
			break;
        case PREF_DISABLE_GPS://GPS开关
		{
            int bReceiveGPS;
            GDBL_GetParam(G_DISABLE_GPS, &bReceiveGPS);
			value = bReceiveGPS;
            if (value == 1)
            {
                value = 0;
            }
            else  if (value == 0)
            {
                value = 1;
            }
		}
			break;
		case PREF_TRACK_RECORD://自动记录轨迹开关
		{
            int useTrack;
            GDBL_GetParam(G_TRACK_RECORD, &useTrack);
			value = useTrack;
		}
			break;
		case PREF_MAP_CONTENT://街区图开关
		{
            int useStreet;
            GDBL_GetParam(G_MAP_CONTENT, &useStreet);
			value = useStreet;
		}
			break;
		case PREF_MUTE://语音提示开关
		{
            int bMute;
            GDBL_GetParam(G_MUTE , &bMute);
            value = bMute;
            if (value == 1)
            {
                value = 0;
            }
            else  if (value == 0)
            {
                value = 1;
            }
		}
			break;
        case PREF_DISABLE_ECOMPASS://电子罗盘开关
		{
            int e_compass = value;
            GDBL_GetParam(G_DISABLE_ECOMPASS, &e_compass);
            value = e_compass;
            if (value == 1)
            {
                value = 0;
            }
            else  if (value == 0)
            {
                value = 1;
            }
		}
			break;
        case PREF_SPEAK_SAFETY://电子眼播报开关
        {
            GDBL_GetParam(G_SPEAK_SAFETY, &value);
        }
            break;
        case PREF_SHOW_TMCSTREAM://交通流图标开关
        {
            GDBL_GetParam(G_SHOW_TMCSTREAM, &value);
        }
            break;
        case PREF_SHOW_TMCEVENT://事件图标开关
        {
            GDBL_GetParam(G_SHOW_TMCEVENT, &value);
        }
            break;
        case PREF_DAYNIGHTMODE:
        {
            GDBL_GetParam(G_AUTO_MODE_DAYNIGHT, &value);
        }
            break;
        case PREF_CTRIP://携程服务开关
		{
			return _ctrip;
		}
			break;
        case PREF_VOICERECONGNITION://语音识别开关
		{
			return _voiceRecongnition;
		}
			break;
		case PREF_NEWFUNINTRODUCE://开机新功能是否已经查看标志
		{
			return _newFunIntroduce;
		}
			break;
		case PREF_MAPDATAUPDATENEWIMAGE://地图数据升级new图标显示标志
		{
			return _mapDataUpdateNewImage;
		}
			break;
		case PREF_MAPDATAUPDATEREMINDER://地图数据升级提醒开关标志
		{
			return _mapDataUpdateReminder;
		}
			break;
		case PREF_SHAKETOCHANGETHEME://摇晃切换地图配色开关
		{
			return _shakeToChangeTheme;
		}
			break;
		case PREF_STARTUPWARNING://警告提示开关
		{
			return _startupWarning;
		}
			break;
		case PREF_INTERFACESTATE://横竖屏开关
		{
			return _interfaceState;
		}
			break;
		case PREF_INTEFACEORIENTATION://界面方向
		{
			return _interfaceOrientation;
		}
			break;
		case PREF_AUTONAVIPUSH://高德push标志
		{
			return _autoNaviPush;
		}
			break;
		case PREF_POSITIONPUSH://位置推送标志
		{
			return _positionPush;
		}
			break;
        case PREF_LAYERTRAVELNEWIMAGECLICK://图层按钮旅游数据new点击标志
		{
			return _layerTravelNewImageClick;
		}
			break;
        case PREF_DATAMANAGETRAVELNEWIMAGECLICK://数据管理旅游数据new点击标志
		{
			return _datamanageTravelNewImageClick;
		}
			break;
        case PREF_TRAVELUPDATE://数据界面是否显示更新按钮
		{
			return _travelUpdate;
		}
			break;
        case PREF_LAYERFOOD://餐饮图层
		{
			return _layerFood;
		}
			break;
        case PREF_LAYERTOURISM://旅游图层
		{
			return _layerTourism;
		}
			break;
        case PREF_CLIENTUGC://客户UGC
		{
			return _clientUGC;
		}
			break;
        case PREF_GOLF://高尔夫球会
        {
            return _golf;
        }
            break;
        case PREF_SPEAKTRAFFIC://路况播报
        {
            return _speakTraffic;
        }
            break;
        case PREF_TRAFFICMESSAGE://路况信息条
        {
            return _trafficMessage;
        }
            break;
        case PREF_SET95190://是否开启95190
        {
            return _set95190;
        }
            break;
        case PREF_BACKGROUNDNAVI://后台导航
        {
            return _backgroundNavi;
        }
            break;
        case PREF_PSNEWCUSTOMERSERVICEPROMPT:
        {
            return _PSNewCustomerServicePrompt;
        }
            break;
        case PREF_TRAFFICEVENT://交通事件显示
        {
            return _trafficEvent;
            
        }
            break;
        case PREF_FIRSTSTART://第一次进入
        {
            
            return _firstStart;
            
        }
            break;
        case PREF_FIRSTENTERSETUPVIEW://第一次进入设置界面
        {
            
            return _firstEnterSetUpView;
            
        }
            break;
        case PREF_BACKGROUNDDOWNLOAD://后台下载开关
        {
            
            return _backgroundDownload;
            
        }
            break;
        case PREF_SETLANGUAGEMANUALLY://手动设置了导航语言
        {
            return _setLanguageManually;
        }
            break;
        case PREF_ENGLISHMAP://英文版开关
        {
            return _englishMap;
        }
            break;
        case PREF_UPLOADLOCATION://上传定位信息
        {
            return _uploadLocation;
        }
            break;
        case PREF_WESHAREPUSH://主界面微享new提示标志
        {
            return _weSharePush;
        }
            break;
        case PREF_CURRENTMONTH://保存流量统计月份
        {
            return _currentMonthForUsage;
        }
            break;
        case PREF_UPGRADEMONTH://保存地图数据升级月份
        {
            return _upgradeMonthForMapUpdate;
        }
            break;
        case PREF_REALTIME_TRAFFIC://实时交通开关
        {
            return _realTimeTraffic;
        }
            break;
        case PREF_HUD_DISPLAYORIENTATION://HUD图面显示方向
        {
            return _HUDDisplayOrientation;
        }
            break;
        case PREF_AUTO_GETPOIINFO:
        {
            return _autoGetPOIInfo;
        }
            break;
        case PREF_PSCOUNTOFUNREAD:      /*未读用户反馈回复*/
        {
            return _unreadedCount;
        }
            break;
        case PREF_IS_DOWNLOAD_NEWSKIN:  //是否下载了新的皮肤
        {
            return _isDownloadNewSkin;
        }
            break;
        case PREF_IS_FIRSTENTERSKIN:    //是否进入了皮肤界面
        {
            return _isFirstEnterSkin;
        }
            break;
        case PREF_SKINTYPE:
        {
            return _skinType;
        }
            break;
        case PREF_IS_OLD_USERS:
        {
            return _isOldUser;
        }
            break;
        case PREF_NEXT_HIGHTPRAISE_COUNT:
        {
            return _nextHightPraiseCount;
        }
            break;
        case PREF_HIGHTPRAISE_ALERT:
        {
            return _hightPraiseAlert;
        }
            break;
        case PREF_SWITCHEDVOICE:
        {
            return _switchedVoice;
        }
            break;
        case PREF_IS_POWERVOICE_PLAY:
        {
            return _isPowerVoicePlay;
        }
            break;
        case PREF_POWERVOICEID:
        {
            return _powerVoiceID;
        }
            break;
        case PREF_AUTOSWITCHDIALECT:
        {
            return _autoSwitchDialect;
        }
            break;
        case PREF_IS_LZLDIALECT:
        {
            return _isLZLDialect;
        }
            break;
        case PREF_SEARCHTYPE:
        {
            return _searchType;
        }
            break;
		default:
			break;
	}
	
	return value;
}

-(int)setValue:(PRETYPE)type Value:(NSInteger)value
{
    switch (type)
	{
		case PREF_UILANGUAGE://UI保存当前的语言选项0简体1繁体2英文
        {
            _UILanguage = value;
            [ANOperateMethod sharedInstance].localizeType = value;
            // 设置地图语言模式
            GLANGUAGE nMapLanguage;//0简体1英文2繁体
            int nTTSLanguage;
            if (value==0) {//0简体
                nMapLanguage = 0;
                nTTSLanguage = 0;
                
                if ([self getValue:PREF_IS_LZLDIALECT] == 0) {
                    
                   // [self setValue:PREF_TTSROLEINDEX Value:0];//设置播放者
                    [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];
                }
                
			}
            else if(value==1)//1繁体
			{
                nMapLanguage = 2;
                nTTSLanguage = 1;
                
                if ([self getValue:PREF_IS_LZLDIALECT] == 0) {
                    
                    //[self setValue:PREF_TTSROLEINDEX Value:0];//设置播放者
                    [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];
                }
            }
            else
            {//2英文
                
                nMapLanguage = 1;
                nTTSLanguage = 2;
                
                if ([self getValue:PREF_TTSROLEINDEX] > 1) {
                    [self setValue:PREF_TTSROLEINDEX Value:0];//设置播放者
                }
                
                [self setValue:PREF_IS_LZLDIALECT Value:0];
                
                [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];
                
                
            }
			GDBL_SetParam(G_LANGUAGE, &nMapLanguage);
            [GDBL_TTS GDBL_TTSSetLanguageIndex:nTTSLanguage];//主要是为了区分英语和简体、繁体的语音播报资源不同
		}
			break;
		case PREF_FONTSIZE://设置字体大小
		{
            
			GDBL_SetParam(G_MAP_FONT_SIZE, &value);
		}
			break;
		case PREF_MAPVIEWMODE://设置地图模式
		{
			GMAPVIEWMODE eMapViewMode = (GMAPVIEWMODE)value;
			GDBL_SetParam(G_MAP_VIEW_MODE, &eMapViewMode);
		}
			break;
		case PREF_POIDENSITY://设置地图详细度
		{
			GMAPPOIDENSITY eMapPoiDensity = (GMAPPOIDENSITY)value;
			GDBL_SetParam(G_MAP_POI_DENSITY, &eMapPoiDensity);
		}
			break;
		case PREF_MAPDAYNIGHTMODE://设置白天黑夜模式
		{
			GMAPDAYNIGHTMODE eMapDayNightMode = (GMAPDAYNIGHTMODE)value;
			GDBL_SetParam(G_MAP_DAYNIGHT_MODE, &eMapDayNightMode);
            if (eMapDayNightMode != GMAP_DAYNIGHT_MODE_AUTO) {//设置主界面白天黑夜ui
                [UIImage setImageDayNightMode:value];
            }
		}
			break;
		case PREF_TTSROLEINDEX://设置语音选择
		{
            
            [GDBL_TTS GDBL_TTSChangeRole:value];
            _ttsRoleIndex = value;
		}
			break;
		case PREF_PROMPTOPTION://设置语音提示频率
		{
			GPROMPTOPTION ePromptOption = (GPROMPTOPTION)value;
			GDBL_SetParam(G_PROMPT_OPTION, &ePromptOption);
		}
			break;
		case PREF_WALKMODE://设置出行方式
		{
			_walkMode = value;
		}
			break;
		case PREF_MAPPOIPRIORITY://设置信息优先显示
		{
			GMAPPOIPRIORITY eMapPoiPriority = (GMAPPOIPRIORITY)value;
			GDBL_SetParam(G_MAP_POI_PRIORITY, &eMapPoiPriority);
		}
			break;
        case PREF_BACKGROUND_MODE://后台
        {
            GDBL_SetParam(G_BACKGROUND_MODE, &value);
        }
            break;
        case PREF_MAPSHOWCURSOR://移图游标
        {
            GDBL_SetParam(G_MAP_SHOW_CURSOR, &value);
        }
			break;
        case PREF_DEMO_SPEED://模拟导航速度
        {
            GDBL_SetParam(G_DEMO_SPEED, &value);
        }
            break;
        case PREF_MAP_SHOW_GUIDEPOST://高速路牌显示
        {
            GDBL_SetParam(G_MAP_SHOW_GUIDEPOST, &value);
        }
            break;
        case PREF_SHOW_SAFETY_ICON://是否显示电子狗图标
        {
            GDBL_SetParam(G_SHOW_SAFETY_ICON, &value);
        }
            break;
        case PREF_SHOW_MAP_GRAY_BKGND://实时交通显示灰色地图
        {
            GDBL_SetParam(G_SHOW_MAP_GRAY_BKGND, &value);
        }
            break;
        case PREF_MAP_TMC_SHOW_OPTION://控制是城市TMC还是路径线TMC
        {
            GDBL_SetParam(G_MAP_TMC_SHOW_OPTION, &value);
        }
            break;
		case PREF_ROUTE_OPTION://设置路径规划原则
		{
            GROUTEOPTION routeRule = value;
            GDBL_SetParam(G_ROUTE_OPTION, &routeRule);
		}
			break;
        case PREF_DISABLE_GPS://GPS开关
		{
            if (value == 1)
            {
                value = 0;
            }
            else if (value == 0)
            {
                value = 1;
            }
			int bReceiveGPS = value;
            GDBL_SetParam(G_DISABLE_GPS, &bReceiveGPS);
            [[Plugin_OnLineMapUtility sharedInstance] SetShowUserLocation:!value];
        }
			break;
		case PREF_TRACK_RECORD://自动记录轨迹开关
		{
            int useTrack = value;
            GDBL_SetParam(G_TRACK_RECORD, &useTrack);
		}
			break;
		case PREF_MAP_CONTENT://街区图开关
		{
            int useStreet = value;
            GDBL_SetParam(G_MAP_CONTENT, &useStreet);
		}
			break;
		case PREF_MUTE://语音提示开关
		{
            //路况播报
            self.speakTraffic = value;
            [[Plugin_OnLineMapUtility sharedInstance] Net_OpenTrafficRadio:value];
            //电子眼播报
            GDBL_SetParam(G_SPEAK_SAFETY, &value);
            GDBL_SetParam(G_SPEAK_USER_SAFETY, &value);
            [[Plugin_OnLineMapUtility sharedInstance] Net_OpenCamera:value];
            //开机语音

            _switchedVoice = value;
            if (value==0)
			{
				value = 1;
			}
			else if (value==1)
			{
			    value = 0;
            }
            int bMute = value;
            GDBL_SetParam(G_MUTE , &bMute);
            
            
            
            
		}
			break;
            
        
        case PREF_DISABLE_ECOMPASS://电子罗盘开关
		{
            if (value == 1)
            {
                value = 0;
                [[GDBL_Location sharedInstance]   Heading_Startup];
            }
            else if (value == 0)
            {
                value = 1;
                [[GDBL_Location sharedInstance]   Heading_Cleanup];
            }
			int e_compass = value;
            GDBL_SetParam(G_DISABLE_ECOMPASS, &e_compass);
            
		}
			break;
        case PREF_SPEAK_SAFETY://电子眼播报开关
        {
             GDBL_SetParam(G_SPEAK_SAFETY, &value);
             GDBL_SetParam(G_SPEAK_USER_SAFETY, &value);
            [[Plugin_OnLineMapUtility sharedInstance] Net_OpenCamera:value];
        }
            break;
        case PREF_SHOW_TMCSTREAM:
        {
            GDBL_SetParam(G_SHOW_TMCSTREAM, &value);
        }
            break;
        case PREF_SHOW_TMCEVENT:
        {
            GDBL_SetParam(G_SHOW_TMCEVENT, &value);
        }
            break;
        case PREF_DISPLAY_ORIENTATION:
        {
            GDISPLAYORIENTATION Value;
            
            switch (value)
            {
                case 0:
                {
                    Value = G_DISPLAY_ORIENTATION_H;
                }
                    break;
                    
                case 1:
                {
                    Value = G_DISPLAY_ORIENTATION_V;
                }
                    break;
                    
                case 2:
                {
                    Value = G_DISPLAY_ORIENTATION_H;
                }
                    break;
                    
                case 3:
                {
                    Value = G_DISPLAY_ORIENTATION_V;
                }
                    break;
                    
                default:
                    break;
            }
            
            GDBL_SetParam(G_DISPLAY_ORIENTATION, &Value);
        }
            break;
        case PREF_CTRIP://携程服务开关
		{
			_ctrip = value;
		}
			break;
        case PREF_VOICERECONGNITION://语音识别开关
		{
			_voiceRecongnition = value;
		}
			break;
		case PREF_NEWFUNINTRODUCE://开机新功能是否已经查看标志
		{
			_newFunIntroduce = value;
		}
			break;
		case PREF_MAPDATAUPDATENEWIMAGE://地图数据升级new图标显示标志
		{
			_mapDataUpdateNewImage = value;
		}
			break;
		case PREF_MAPDATAUPDATEREMINDER://地图数据升级提醒开关标志
		{
			_mapDataUpdateReminder = value;
		}
			break;
		case PREF_SHAKETOCHANGETHEME://摇晃切换地图配色开关
		{
			_shakeToChangeTheme = value;
		}
			break;
		case PREF_STARTUPWARNING://警告提示开关
		{
			_startupWarning = value;
		}
			break;
		case PREF_INTERFACESTATE://横竖屏开关
		{
			_interfaceState  = value;
		}
			break;
		case PREF_INTEFACEORIENTATION://界面方向
		{
			_interfaceOrientation  = value;
		}
			break;
		case PREF_AUTONAVIPUSH://高德push标志
		{
			_autoNaviPush = value;
		}
			break;
		case PREF_POSITIONPUSH://位置推送标志
		{
			_positionPush = value;
		}
			break;
        case PREF_LAYERTRAVELNEWIMAGECLICK://图层按钮旅游数据new点击标志
		{
			_layerTravelNewImageClick = value;
		}
			break;
        case PREF_DATAMANAGETRAVELNEWIMAGECLICK://数据管理旅游数据new点击标志
		{
			_datamanageTravelNewImageClick = value;
		}
			break;
        case PREF_TRAVELUPDATE://数据界面是否显示更新按钮
		{
			_travelUpdate = value;
		}
			break;
        case PREF_LAYERFOOD://餐饮图层
		{
			_layerFood = value;
		}
			break;
        case PREF_LAYERTOURISM://旅游图层
		{
			_layerTourism = value;
		}
			break;
        case PREF_CLIENTUGC://客户UGC
		{
			_clientUGC = value;
		}
			break;
        case PREF_GOLF://高尔夫球会
        {
            _golf = value;
        }
            break;
        case PREF_SPEAKTRAFFIC://路况播报
        {
            self.speakTraffic = value;
            [[Plugin_OnLineMapUtility sharedInstance] Net_OpenTrafficRadio:value];
        }
            break;
        case PREF_TRAFFICMESSAGE://路况信息条
        {
            _trafficMessage = value;
        }
            break;
        case PREF_SET95190://是否开启95190
        {
            _set95190 = value;
        }
            break;
        case PREF_BACKGROUNDNAVI://后台导航
        {
           self.backgroundNavi = value;
        }
            break;
        case PREF_PSNEWCUSTOMERSERVICEPROMPT:
        {
            _PSNewCustomerServicePrompt = value;
        }
            break;
        case PREF_TRAFFICEVENT://交通事件显示
        {
            _trafficEvent = value;
            [self setValue:PREF_SHOW_TMCEVENT Value:value];
        }
            break;
        case PREF_FIRSTSTART://第一次进入
        {
            if(value == 0)
            {
                _firstStart = NO;
            }
            else
            {
                _firstStart = YES;
            }
        }
            break;
        case PREF_FIRSTENTERSETUPVIEW://第一次进入设置界面
        {
            if(value == 0)
            {
                _firstEnterSetUpView = NO;
            }
            else
            {
                _firstEnterSetUpView = YES;
            }
        }
            break;
        case PREF_BACKGROUNDDOWNLOAD://后台下载开关
        {
            if(value == 0)
            {
                _backgroundDownload = NO;
            }
            else
            {
                _backgroundDownload = YES;
            }
        }
            break;
        case PREF_SETLANGUAGEMANUALLY://手动设置了导航语言
        {
            _setLanguageManually = value;
        }
            break;
        case PREF_ENGLISHMAP://英文版开关
        {
            _englishMap = value;
        }
            break;
        case PREF_UPLOADLOCATION://上传定位信息
        {
            _uploadLocation = value;
        }
            break;
        case PREF_WESHAREPUSH://主界面微享new提示标志
        {
            _weSharePush = value;
        }
            break;
        case PREF_CURRENTMONTH://保存流量统计月份
        {
            _currentMonthForUsage = value;
        }
            break;
        case PREF_UPGRADEMONTH://保存地图数据升级月份
        {
            _upgradeMonthForMapUpdate = value;
        }
            break;
        case PREF_REALTIME_TRAFFIC://实时交通开关
        {
            _realTimeTraffic = value;
        }
            break;
        case PREF_HUD_DISPLAYORIENTATION://HUD 图面方向
        {
            _HUDDisplayOrientation = value;
        }
            break;
        case PREF_AUTO_GETPOIINFO:
        {
            _autoGetPOIInfo = value;
        }
            break;
        case PREF_PSCOUNTOFUNREAD:      /*未读用户反馈回复*/
        {
            _unreadedCount = value;
        }
            break;
        case PREF_IS_FIRSTENTERSKIN://第一次进入
        {
            if(value == 0)
            {
                _isFirstEnterSkin = NO;
            }
            else
            {
                _isFirstEnterSkin = YES;
            }
        }
            break;
        case PREF_IS_DOWNLOAD_NEWSKIN://是否进行新皮肤的下载
        {
            if(value == 0)
            {
                _isDownloadNewSkin = NO;
            }
            else
            {
                _isDownloadNewSkin = YES;
            }
        }
            break;
        case PREF_SKINTYPE:
        {
            _skinType = value;
            GDBL_SetParamExt(SKINTYPE, &value);
        }
            break;
        case PREF_IS_OLD_USERS:
        {
            _isOldUser = value;
        }
            break;
        case PREF_NEXT_HIGHTPRAISE_COUNT:
        {
            _nextHightPraiseCount = value;
        }
            break;
        case PREF_HIGHTPRAISE_ALERT:
        {
            _hightPraiseAlert = value;
        }
            break;
        case PREF_SWITCHEDVOICE:
        {
            _switchedVoice = value;
        }
            break;
        case PREF_IS_POWERVOICE_PLAY:
        {
            _isPowerVoicePlay = value;
        }
            break;
        case PREF_POWERVOICEID:
        {
            _powerVoiceID = value;
        }
            break;
        case PREF_AUTOSWITCHDIALECT:
        {
            _autoSwitchDialect = value;
        }
            break;
        case PREF_IS_LZLDIALECT:
        {
            [GDBL_TTS GDBL_TTSSetDialectType:value];
            _isLZLDialect = value;
            
        }
            break;
        case PREF_SEARCHTYPE:
        {
            _searchType = value;
        }
            break;
		default:
			break;
	}
    return 0;
}

-(BOOL)reset
{
    [self preferenceHandle:HANDLE_RESET];
    return YES;
}


#pragma mark -
#pragma mark private
- (void)readOldPreference
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [paths objectAtIndex:0];
    NSArray *array = [[[NSArray alloc] initWithContentsOfFile:[documentPath stringByAppendingPathComponent:@"NaviSetting.plist"]] autorelease];
	if ([array count] == 0)
	{
        [self preferenceHandle:HANDLE_INIT];
    }
	else {
        BOOL beUpdate = NO;
        
        int i = 0;
        _softVersion = [[array objectAtIndex:i] floatValue];//软件版本 0
        i++;
        if (i == [array count]) {
            return;
        }
		_walkMode = [[array objectAtIndex:i] boolValue];//出行方式 1
        i++;
        if (i == [array count]) {
            return;
        }
		_startupWarning = [[array objectAtIndex:i] intValue];//敬告提示 2
        i++;
        if (i == [array count]) {
            return;
        }
		_newFunIntroduce = [[array objectAtIndex:i] intValue];//新功能介绍 3
        i++;
        if (i == [array count]) {
            return;
        }
		_shakeToChangeTheme = [[array objectAtIndex:i] boolValue];//摇晃切换地图颜色 4
        i++;
        if (i == [array count]) {
            return;
        }
		_interfaceState = [[array objectAtIndex:i] boolValue];//横竖屏开关 5
        i++;
        if (i == [array count]) {
            return;
        }
		_interfaceOrientation = [[array objectAtIndex:i] intValue];//界面方向 6
        i++;
        if (i == [array count]) {
            return;
        }
		_ctrip = [[array objectAtIndex:i] boolValue];//携程 7
        i++;
        if (i == [array count]) {
            return;
        }
		_voiceRecongnition = [[array objectAtIndex:i] boolValue];//语音识别 8
        i++;
        if (i == [array count]) {
            return;
        }
		
        i++;
        if (i == [array count]) {
            return;
        }
		
        i++;
        if (i == [array count]) {
            return;
        }
		
        i++;
        if (i == [array count]) {
            return;
        }
		
        i++;
        if (i == [array count]) {
            return;
        }
		_mapDataUpdateNewImage = [[array objectAtIndex:i] boolValue];//地图数据升级new图标显示标志 13
        i++;
        if (i == [array count]) {
            return;
        }
		_mapDataUpdateReminder = [[array objectAtIndex:i] boolValue];//地图数据升级提醒开关标志 14
        i++;
        if (i == [array count]) {
            return;
        }
		_currentMonthForUsage = [[array objectAtIndex:i] intValue];//保存当前月份 15
        i++;
        if (i == [array count]) {
            return;
        }
		_upgradeMonthForMapUpdate = [[array objectAtIndex:i] intValue];//保存升级月份 16
        i++;
        if (i == [array count]) {
            return;
        }
		
        i++;
        if (i == [array count]) {
            return;
        }
		_weSharePush = [[array objectAtIndex:i] boolValue];//主界面微享new提示标志 18
        i++;
        if (i == [array count]) {
            return;
        }
		_autoNaviPush = [[array objectAtIndex:i] boolValue];//高德push标志 19
        i++;
        if (i == [array count]) {
            return;
        }
		_positionPush = [[array objectAtIndex:i] boolValue];//位置推送标志 20
        i++;
        if (i == [array count]) {
            return;
        }
        _ttsRoleIndex = [[array objectAtIndex:i] intValue];//语音播放角色索引 21
        [GDBL_TTS GDBL_TTSChangeRole:_ttsRoleIndex];
        i++;
        if (i == [array count]) {
            return;
        }
        self.deviceToken = [array objectAtIndex:i];
        i++;
        if (i == [array count]) {
            return;
        }
        
        i++;
        if (i == [array count]) {
            return;
        }
        _uploadLocation = [[array objectAtIndex:i] boolValue];//定位后上传位置信息 24
        
        if(fabs(SOFTVERSIONNUM-_softVersion)>0.01f)
        {
            beUpdate = YES;
            [self preferenceHandle:HANDLE_OLDUPDATE];
            
            // 打开新版本检测
            [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:MWSoftWareUpdateReminderKey];
            //系统升级时删除旧的路径文件，解决路径文件不兼容问题
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%s",route_path]])
            {
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%s",route_path] error:nil];
            }
            
            [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:NO] forKey:MWUploadTokenSuccess];
            [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:NO] forKey:MWUploadTokenAutoNaviSuccess];
            
        }
        i++;
        if (i == [array count]) {
            return;
        }
        self.mapVersion = [array objectAtIndex:i];//地图数据版本
        i++;
        if (i == [array count]) {
            return;
        }
        _layerFood = [[array objectAtIndex:i] boolValue];//餐饮图层 26
        i++;
        if (i == [array count]) {
            return;
        }
        _layerTourism = [[array objectAtIndex:i] boolValue];//旅游图层 27
        i++;
        if (i == [array count]) {
            return;
        }
        _clientUGC = [[array objectAtIndex:i] boolValue];//客户UGC 28
        i++;
        if (i == [array count]) {
            return;
        }
        _UILanguage = [[array objectAtIndex:i] intValue];//  当前语言 29
        i++;
        if (i == [array count]) {
            return;
        }
        
        _englishMap = [[array objectAtIndex:i] intValue];//  UI为英文下地图语言30
        i++;
        if (i == [array count]) {
            return;
        }
        
        _layerTravelNewImageClick = [[array objectAtIndex:i] boolValue];//图层按钮旅游数据new点击标志31
        i++;
        if (i == [array count]) {
            return;
        }
        
        _datamanageTravelNewImageClick = [[array objectAtIndex:i] boolValue];//数据管理按钮旅游数据new点击标志32
        i++;
        if (i == [array count]) {
            return;
        }
        
        _travelUpdate = [[array objectAtIndex:i] boolValue];//数据管理界面是否显示更新按钮 33
        i++;
        if (i == [array count]) {
            return;
        }
        
        _setLanguageManually = [[array objectAtIndex:i] boolValue];//是否手动设置了导航语言 34
        i++;
        if (i == [array count]) {
            return;
        }
        _set95190 = [[array objectAtIndex:i] boolValue];// 是否开启95190 35
        i++;
        if (i == [array count]) {
            return;
        }
        _golf = [[array objectAtIndex:i] boolValue];//是否开启高尔夫球会 36
        i++;
        if (i == [array count]) {
            return;
        }
        self.speakTraffic = [[array objectAtIndex:i] boolValue];//是否开启路况播报 37
        i++;
        if (i == [array count]) {
            return;
        }
        _trafficMessage = [[array objectAtIndex:i] boolValue];//是否开启路况信息条 38
        i++;
        if (i == [array count]) {
            return;
        }
        i++;
        if (i == [array count]) {
            return;
        }
        
        self.gresourceVersion = [array objectAtIndex:i];//Gresourse数据 41
        if (beUpdate) {
            [self preferenceHandle:HANDLE_OLDUPDATE];
        }
        
        i++;
        if (i == [array count]) {
            return;
        }
        
        i++;
        if (i == [array count]) {
            return;
        }
        self.backgroundNavi = [[array objectAtIndex:i] boolValue];//是否支持后台模式 43
        i++;
        if (i == [array count]) {
            return;
        }
        _PSCountOfUnread = [[array objectAtIndex:i] intValue];//未读用户反馈回复44
        i++;
        if (i == [array count]) {
            return;
        }
        _PSNewCustomerServicePrompt = [[array objectAtIndex:i] boolValue];//新的客服提示45
        i++;
        if (i == [array count]) {
            return;
        }
        
        i++;
        if (i == [array count]) {
            return;
        }
        _trafficEvent = [[array objectAtIndex:i] boolValue];//交通事件显示 47
        i++;
        if (i == [array count]) {
            return;
        }
        _firstStart = [[array objectAtIndex:i] boolValue];//是否第一次进入程序 48
        i++;
        if (i == [array count]) {
            return;
        }
        _firstEnterSetUpView = [[array objectAtIndex:i] boolValue];//是否第一次进入设置界面 49
        i++;
        if (i == [array count]) {
            return;
        }
        _backgroundDownload = [[array objectAtIndex:i] boolValue];//是否进行后台下载  50
        i++;
        if (i == [array count]) {
            return;
        }
        
	}
}

- (BOOL)readPreference
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:preferenceFilePath];
    if(dic != nil)
    {
        NSNumber *softVersion = [dic objectForKey:@"_softVersion"];
        if(softVersion)
            _softVersion = [softVersion floatValue];
        NSNumber *walkMode = [dic objectForKey:@"_walkMode"];
        if(walkMode)
            _walkMode = [walkMode intValue];
        NSNumber *startupWarning = [dic objectForKey:@"_startupWarning"];
        if(startupWarning )
            _startupWarning = [startupWarning boolValue];
        NSNumber *newFunIntroduce = [dic objectForKey:@"_newFunIntroduce"];
        if(newFunIntroduce)
            _newFunIntroduce = [newFunIntroduce boolValue];
        NSNumber *shakeToChangeTheme = [dic objectForKey:@"_shakeToChangeTheme"];
        if(shakeToChangeTheme)
            _shakeToChangeTheme = [shakeToChangeTheme boolValue];
        NSNumber *interfaceState = [dic objectForKey:@"_interfaceState"];
        if(interfaceState)
            _interfaceState = [interfaceState boolValue];
        NSNumber *interfaceOrientation = [dic objectForKey:@"_interfaceOrientation"];
        if(interfaceOrientation)
            _interfaceOrientation = [interfaceOrientation intValue];
        NSNumber *ctrip = [dic objectForKey:@"_ctrip"];
        if(ctrip)
            _ctrip = [ctrip boolValue];
        NSNumber *voiceRecongnition = [dic objectForKey:@"_voiceRecongnition"];
        if(voiceRecongnition)
            _voiceRecongnition = [voiceRecongnition boolValue];
        NSNumber *mapDataUpdateNewImage = [dic objectForKey:@"_mapDataUpdateNewImage"];
        if(mapDataUpdateNewImage)
            _mapDataUpdateNewImage = [mapDataUpdateNewImage boolValue];
        
        NSNumber *mapDataUpdateReminder = [dic objectForKey:@"_mapDataUpdateReminder"];
        if(mapDataUpdateReminder)
            _mapDataUpdateReminder = [mapDataUpdateReminder boolValue];
        NSNumber *currentMonthForUsage = [dic objectForKey:@"_currentMonthForUsage"];
        if(currentMonthForUsage)
            _currentMonthForUsage = [currentMonthForUsage intValue];
        NSNumber *upgradeMonthForMapUpdate = [dic objectForKey:@"_upgradeMonthForMapUpdate"];
        if(upgradeMonthForMapUpdate)
            _upgradeMonthForMapUpdate = [upgradeMonthForMapUpdate intValue];
        NSNumber *weSharePush = [dic objectForKey:@"_weSharePush"];
        if(weSharePush)
            _weSharePush = [weSharePush boolValue];
        NSNumber *autoNaviPush = [dic objectForKey:@"_autoNaviPush"];
        if(autoNaviPush)
            _autoNaviPush = [autoNaviPush boolValue];
        NSNumber *positionPush = [dic objectForKey:@"_positionPush"];
        if(positionPush)
            _positionPush = [positionPush boolValue];
        NSNumber *ttsRoleIndex = [dic objectForKey:@"_ttsRoleIndex"];
        if(ttsRoleIndex)
            _ttsRoleIndex = [ttsRoleIndex intValue];
        NSNumber *uploadLocation = [dic objectForKey:@"_uploadLocation"];
        if(uploadLocation)
            _uploadLocation = [uploadLocation boolValue];
        NSNumber *layerFood = [dic objectForKey:@"_layerFood"];
        if(layerFood)
            _layerFood = [layerFood boolValue];
        NSNumber *layerTourism = [dic objectForKey:@"_layerTourism"];
        if(layerTourism)
            _layerTourism = [layerTourism boolValue];
        NSNumber *clientUGC = [dic objectForKey:@"_clientUGC"];
        if(clientUGC)
            _clientUGC = [clientUGC boolValue];
        NSNumber *UILanguage = [dic objectForKey:@"_UILanguage"];
        if(UILanguage)
            _UILanguage = [UILanguage intValue];
        NSNumber *englishMap = [dic objectForKey:@"_englishMap"];
        if(englishMap)
            _englishMap = [englishMap boolValue];
        NSNumber *layerTravelNewImageClick = [dic objectForKey:@"_layerTravelNewImageClick"];
        if(layerTravelNewImageClick)
            _layerTravelNewImageClick = [layerTravelNewImageClick boolValue];
        NSNumber *datamanageTravelNewImageClick = [dic objectForKey:@"_datamanageTravelNewImageClick"];
        if(datamanageTravelNewImageClick)
            _datamanageTravelNewImageClick = [datamanageTravelNewImageClick boolValue];
        NSNumber *travelUpdate = [dic objectForKey:@"_travelUpdate"];
        if(travelUpdate)
            _travelUpdate = [travelUpdate boolValue];
        NSNumber *setLanguageManually = [dic objectForKey:@"_setLanguageManually"];
        if(setLanguageManually)
            _setLanguageManually = [setLanguageManually boolValue];
        NSNumber *set95190 = [dic objectForKey:@"_set95190"];
        if(set95190)
            _set95190 = [set95190 boolValue];
        NSNumber *golf = [dic objectForKey:@"_golf"];
        if(golf)
            _golf = [golf boolValue];
        NSNumber *tmpSpeakTraffic = [dic objectForKey:@"_speakTraffic"];
        if(tmpSpeakTraffic)
            [self setValue:PREF_SPEAKTRAFFIC Value:[tmpSpeakTraffic boolValue]];
        else
              [self setValue:PREF_SPEAKTRAFFIC Value:YES];
        NSNumber *trafficMessage = [dic objectForKey:@"_trafficMessage"];
        if(trafficMessage)
            _trafficMessage = [trafficMessage boolValue];
        else
            _trafficMessage = YES;
        NSNumber *tmpBackgroundNavi = [dic objectForKey:@"_backgroundNavi"];
        if(tmpBackgroundNavi)
            self.backgroundNavi = [tmpBackgroundNavi boolValue];
        else
            self.backgroundNavi = YES;
        NSNumber *PSCountOfUnread = [dic objectForKey:@"_PSCountOfUnread"];
        if(PSCountOfUnread)
            _PSCountOfUnread = [PSCountOfUnread intValue];
        NSNumber *PSNewCustomerServicePrompt = [dic objectForKey:@"_PSNewCustomerServicePrompt"];
        if(PSNewCustomerServicePrompt)
            _PSNewCustomerServicePrompt = [PSNewCustomerServicePrompt boolValue];
        NSNumber *trafficEvent = [dic objectForKey:@"_trafficEvent"];
        if(trafficEvent)
            _trafficEvent = [trafficEvent boolValue];
        else
            _trafficEvent = NO;
        
        NSNumber *firstStart = [dic objectForKey:@"_firstStart"];
        if(firstStart)
            _firstStart = [firstStart boolValue];
        NSNumber *firstEnterSetUpView = [dic objectForKey:@"_firstEnterSetUpView"];
        if(firstEnterSetUpView)
            _firstEnterSetUpView = [firstEnterSetUpView boolValue];
        NSNumber *backgroundDownload = [dic objectForKey:@"_backgroundDownload"];
        if(backgroundDownload)
            _backgroundDownload = [backgroundDownload boolValue];
        else
            _backgroundDownload = YES;
        NSNumber *realTimeTraffic = [dic objectForKey:@"_realTimeTraffic"];
        if(realTimeTraffic)
            _realTimeTraffic = [realTimeTraffic boolValue];
        
        NSNumber *HUDDisplayOrientation = [dic objectForKey:@"_HUDDisplayOrientation"];
        if(HUDDisplayOrientation)
            _HUDDisplayOrientation = [HUDDisplayOrientation boolValue];
        else
            _HUDDisplayOrientation = YES;
        
        NSNumber *autoGetPOIInfo = [dic objectForKey:@"_autoGetPOIInfo"];
        if(autoGetPOIInfo)
            _autoGetPOIInfo = [autoGetPOIInfo boolValue];
        else
            _autoGetPOIInfo = YES;
        
        self.gresourceVersion = [dic objectForKey:@"_gresourceVersion"];
        self.deviceToken = [dic objectForKey:@"_deviceToken"];
        self.mapVersion = [dic objectForKey:@"_mapVersion"];

        NSNumber *isFirstEnterSkin = [dic objectForKey:@"_isFirstEnterSkin"];
        if(isFirstEnterSkin)
        {
            _isFirstEnterSkin = [isFirstEnterSkin boolValue];
        }
        else{
            _isFirstEnterSkin = YES;
        }
        NSNumber *isDownloadNewSkin = [dic objectForKey:@"_isDownloadNewSkin"];
        if(isDownloadNewSkin)
        {
            _isDownloadNewSkin = [isDownloadNewSkin boolValue];
        }
        else{
            _isDownloadNewSkin = YES;
        }
        
        NSNumber *skintype = [dic objectForKey:@"_skinType"];
        if(skintype)
        {
            _skinType = [skintype intValue];
            GDBL_SetParamExt(SKINTYPE, &_skinType);
        }
        
        NSNumber *isOldUser = [dic objectForKey:@"_isOldUser"];
        if(isOldUser)
        {
            _isOldUser = [isOldUser boolValue];
        }
        
        NSNumber *nextHightPraiseCount = [dic objectForKey:@"_nextHightPraiseCount"];
        if(nextHightPraiseCount)
        {
            _nextHightPraiseCount = [nextHightPraiseCount intValue];
        }
        
        NSNumber *hightPraiseAlert = [dic objectForKey:@"_hightPraiseAlert"];
        if(hightPraiseAlert)
        {
            _hightPraiseAlert = [hightPraiseAlert boolValue];
        }
        
        NSNumber *switchedVoice = [dic objectForKey:@"_switchedVoice"];
        if(switchedVoice)
        {
            _switchedVoice = [switchedVoice boolValue];
        }
        
        NSNumber *isPowerVoicePlay = [dic objectForKey:@"_isPowerVoicePlay"];
        if(isPowerVoicePlay)
        {
            _isPowerVoicePlay = [isPowerVoicePlay boolValue];
        }
        
        NSNumber *powerVoiceID = [dic objectForKey:@"_powerVoiceID"];
        if(powerVoiceID)
        {
            _powerVoiceID = [powerVoiceID intValue];
        }
        
        NSNumber *autoSwitchDialect = [dic objectForKey:@"_autoSwitchDialect"];
        if(autoSwitchDialect)
        {
            _autoSwitchDialect = [autoSwitchDialect boolValue];
        }
        
        NSNumber *isLZLDialect = [dic objectForKey:@"_isLZLDialect"];
        if(isLZLDialect)
        {
            _isLZLDialect = [isLZLDialect intValue];
        }
        
        NSNumber *searchType = [dic objectForKey:@"_searchType"];
        if(searchType)
        {
            _searchType = [searchType boolValue];
        }
        
    }
    return YES;
}

- (void)preferenceHandle:(PREF_HANDLETYPE)type
{
    switch (type) {
        case HANDLE_INIT://系统初始化(无配置文件时调用)
        {
            _softVersion = SOFTVERSIONNUM;
            [self setValue:PREF_WALKMODE Value:PREF_NAVIMODE_CAR];
            [self setValue:PREF_STARTUPWARNING Value:YES];
            [self setValue:PREF_NEWFUNINTRODUCE Value:NO];
            [self setValue:PREF_SHAKETOCHANGETHEME Value:NO];
            [self setValue:PREF_INTERFACESTATE Value:1];
            [self setValue:PREF_INTEFACEORIENTATION Value:YES];
            [self setValue:PREF_CTRIP Value:YES];
            [self setValue:PREF_VOICERECONGNITION Value:YES];
            [self setValue:PREF_MAPDATAUPDATEREMINDER Value:YES];
            [self setValue:PREF_UPGRADEMONTH Value:0];
            [self setValue:PREF_TTSROLEINDEX Value:PREF_SPEAKER_XIAOYAN];
            [self setValue:PREF_UPLOADLOCATION Value:YES];
            [self setValue:PREF_LAYERFOOD Value:YES];
            [self setValue:PREF_LAYERTOURISM Value:YES];
            [self setValue:PREF_CLIENTUGC Value:YES];
            [self setValue:PREF_ENGLISHMAP Value:NO];
            [self setValue:PREF_LAYERTRAVELNEWIMAGECLICK Value:NO];
            [self setValue:PREF_DATAMANAGETRAVELNEWIMAGECLICK Value:NO];
            [self setValue:PREF_TRAVELUPDATE Value:NO];
            [self setValue:PREF_SETLANGUAGEMANUALLY Value:NO];
            [self setValue:PREF_SET95190 Value:NO];
            [self setValue:PREF_GOLF Value:YES];
            [self setValue:PREF_SPEAKTRAFFIC Value:YES];
            [self setValue:PREF_TRAFFICMESSAGE Value:YES];
            [self setValue:PREF_BACKGROUNDNAVI Value:YES];
            [self setValue:PREF_PSNEWCUSTOMERSERVICEPROMPT Value:NO];
            [self setValue:PREF_TRAFFICEVENT Value:NO];
            [self setValue:PREF_FIRSTSTART Value:YES];
            [self setValue:PREF_FIRSTENTERSETUPVIEW Value:YES];
            [self setValue:PREF_BACKGROUNDDOWNLOAD Value:YES];
            [self setValue:PREF_REALTIME_TRAFFIC Value:NO];
            [self setValue:PREF_HUD_DISPLAYORIENTATION Value:NO];
            [self setValue:PREF_AUTO_GETPOIINFO Value:YES];
            [self setValue:PREF_IS_FIRSTENTERSKIN Value:NO];
            [self setValue:PREF_IS_DOWNLOAD_NEWSKIN Value:YES];
            [self setValue:PREF_SKINTYPE Value:0];
            [self setValue:PREF_IS_OLD_USERS Value:NO];
            [self setValue:PREF_NEXT_HIGHTPRAISE_COUNT Value:0];
            [self setValue:PREF_HIGHTPRAISE_ALERT Value:YES];
            [self setValue:PREF_SWITCHEDVOICE Value:YES];
            [self setValue:PREF_IS_POWERVOICE_PLAY Value:NO];
            [self setValue:PREF_POWERVOICEID Value:0];
            [self setValue:PREF_AUTOSWITCHDIALECT Value:NO];
            [self setValue:PREF_IS_LZLDIALECT Value:0];
            [self setValue:PREF_SEARCHTYPE Value:NO];
            [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];
           
        }
            break;
        case HANDLE_UPDATE://软件升级处理
        {
            _softVersion = SOFTVERSIONNUM;
            self.gresourceVersion = @"";
            self.deviceToken = @"";
            [self setValue:PREF_UPLOADLOCATION Value:YES];
            [self setValue:PREF_NEWFUNINTRODUCE Value:NO];
            [self setValue:PREF_UPGRADEMONTH Value:0];
            [self setValue:PREF_IS_OLD_USERS Value:YES];
            [self setValue:PREF_NEXT_HIGHTPRAISE_COUNT Value:0];
            [self setValue:PREF_HIGHTPRAISE_ALERT Value:YES];
            [self setValue:PREF_FIRSTSTART Value:YES];
            [self setValue:PREF_SWITCHEDVOICE Value:YES];
            [self setValue:PREF_IS_POWERVOICE_PLAY Value:NO];
            [self setValue:PREF_POWERVOICEID Value:0];
            [self setValue:PREF_AUTOSWITCHDIALECT Value:NO];
            
            // 打开新版本检测
            [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:MWSoftWareUpdateReminderKey];
            //系统升级时删除旧的路径文件，解决路径文件不兼容问题
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%s",route_path]])
            {
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%s",route_path] error:nil];
            }
            //上传设备令牌参数重置
            [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:NO] forKey:MWUploadTokenSuccess];
            [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:NO] forKey:MWUploadTokenAutoNaviSuccess];
            
            //删除未下载完成的皮肤
            [[MWSkinDownloadManager sharedInstance] removeTasksForStatus:TASK_STATUS_READY];
            [[MWSkinDownloadManager sharedInstance] removeTasksForStatus:TASK_STATUS_RUNNING];
            [[MWSkinDownloadManager sharedInstance] removeTasksForStatus:TASK_STATUS_BLOCK];
            
            //删除未下载完成的方言
            [[MWDialectDownloadManage sharedInstance] removeTasksForStatus:TASK_STATUS_READY];
            [[MWDialectDownloadManage sharedInstance] removeTasksForStatus:TASK_STATUS_RUNNING];
            [[MWDialectDownloadManage sharedInstance] removeTasksForStatus:TASK_STATUS_BLOCK];
            
            //删除皮肤更新保存的皮肤版本号
            [[MWSkinDownloadManager sharedInstance].updateVersionDictionary removeAllObjects];
            
            //清除缓存
            [[GDCacheManager globalCache] clearCache];

            //删除上一版本的皮肤plist文件
            if ([[NSFileManager defaultManager] fileExistsAtPath:skinConfigDocumentPath])
            {
                [[NSFileManager defaultManager] removeItemAtPath:skinConfigDocumentPath error:nil];
            }
        }
            break;
        case HANDLE_RESET://恢复出厂设置
        {
            [self setValue:PREF_WALKMODE Value:PREF_NAVIMODE_CAR];
            [self setValue:PREF_STARTUPWARNING Value:YES];
            [self setValue:PREF_SHAKETOCHANGETHEME Value:NO];
            [self setValue:PREF_INTERFACESTATE Value:1];
            [self setValue:PREF_INTEFACEORIENTATION Value:YES];
            [self setValue:PREF_CTRIP Value:YES];
            [self setValue:PREF_VOICERECONGNITION Value:YES];
            [self setValue:PREF_MAPDATAUPDATEREMINDER Value:YES];
            [self setValue:PREF_UPGRADEMONTH Value:0];
            [self setValue:PREF_TTSROLEINDEX Value:PREF_SPEAKER_XIAOYAN];
            [self setValue:PREF_UPLOADLOCATION Value:YES];
            [self setValue:PREF_LAYERFOOD Value:YES];
            [self setValue:PREF_LAYERTOURISM Value:YES];
            [self setValue:PREF_CLIENTUGC Value:YES];
            [self setValue:PREF_UILANGUAGE Value:LANGUAGE_SIMPLE_CHINESE];
            [self setValue:PREF_ENGLISHMAP Value:NO];
            [self setValue:PREF_LAYERTRAVELNEWIMAGECLICK Value:NO];
            [self setValue:PREF_DATAMANAGETRAVELNEWIMAGECLICK Value:NO];
            [self setValue:PREF_TRAVELUPDATE Value:NO];
            [self setValue:PREF_SETLANGUAGEMANUALLY Value:NO];
            [self setValue:PREF_SET95190 Value:NO];
            [self setValue:PREF_GOLF Value:YES];
            [self setValue:PREF_SPEAKTRAFFIC Value:YES];
            [self setValue:PREF_TRAFFICMESSAGE Value:YES];
            [self setValue:PREF_BACKGROUNDNAVI Value:YES];
            [self setValue:PREF_PSNEWCUSTOMERSERVICEPROMPT Value:NO];
            [self setValue:PREF_TRAFFICEVENT Value:NO];
            [self setValue:PREF_FIRSTENTERSETUPVIEW Value:YES];
            [self setValue:PREF_BACKGROUNDDOWNLOAD Value:YES];
            [self setValue:PREF_REALTIME_TRAFFIC Value:NO];
            [self setValue:PREF_HUD_DISPLAYORIENTATION Value:NO];
            [self setValue:PREF_AUTO_GETPOIINFO Value:YES];
            [self setValue:PREF_DISABLE_GPS Value:YES];
            [self setValue:PREF_SKINTYPE Value:0];
            [self setValue:PREF_SWITCHEDVOICE Value:YES];
            [self setValue:PREF_IS_LZLDIALECT Value:0];
            [self setValue:PREF_SEARCHTYPE Value:NO];
            [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];
            
            [self setValue:PREF_FONTSIZE Value:GMAP_FONT_SIZE_NORMAL];
            [self setValue:PREF_MAPDAYNIGHTMODE Value:GMAP_DAYNIGHT_MODE_AUTO];
            [self setValue:PREF_PROMPTOPTION Value:GPROMPT_OPTION_MUCH];
            [self setValue:PREF_MAPPOIPRIORITY Value:GMAP_POI_PRIORITY_AUTO];
            [self setValue:PREF_TRACK_RECORD Value:0];
            [self setValue:PREF_MAP_CONTENT Value:2];
            [self setValue:PREF_DISABLE_ECOMPASS Value:0];
            [self setValue:PREF_SPEAK_SAFETY Value:1];
            [self setValue:PREF_DEMO_SPEED Value:GDEMO_SPEED_NORMAL];
            [self setValue:PREF_MUTE Value:1];
            [self setValue:PREF_MAPPOIPRIORITY Value:0];
            [self setValue:PREF_ROUTE_OPTION Value:0]; //路线规划原则设置为推荐
            
            
            if([[ANParamValue sharedInstance] GMD_isTMCOn])//恢复出厂设置关闭实时交通
            {
                [[ANOperateMethod sharedInstance] GMD_CloseTMC];
            }
            
            [[MWMapOperator sharedInstance]  MW_SetMapViewMode:GMAP_VIEW_TYPE_MAIN Type:0 MapMode:GMAPVIEW_MODE_NORTH];//恢复地图视图模式为北首上
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:[NSNumber numberWithInt:UIUpdate_SkinTypeChange] userInfo:@{CONFIG_SKIN_ID: [NSNumber numberWithInt:[[MWPreference sharedInstance] getValue:PREF_SKINTYPE]] }];//恢复皮肤
            
            [[ANOperateMethod sharedInstance] setTheme:0];//恢复色盘
            
            
        }
            break;
        case HANDLE_OLDUPDATE://兼容7.6及之前版本
        {
            _softVersion = SOFTVERSIONNUM;
            self.gresourceVersion = @"";
            self.deviceToken = @"";
            [self setValue:PREF_UPLOADLOCATION Value:YES];
            [self setValue:PREF_NEWFUNINTRODUCE Value:NO];
            [self setValue:PREF_UPGRADEMONTH Value:0];
            [self setValue:PREF_SPEAKTRAFFIC Value:YES];
            [self setValue:PREF_PSNEWCUSTOMERSERVICEPROMPT Value:NO];
            [self setValue:PREF_TRAFFICEVENT Value:NO];
            [self setValue:PREF_TRAFFICMESSAGE Value:YES];
            [self setValue:PREF_BACKGROUNDNAVI Value:YES];
            [self setValue:PREF_BACKGROUNDDOWNLOAD Value:YES];
            [self setValue:PREF_SPEAK_SAFETY Value:1];
            [self setValue:PREF_REALTIME_TRAFFIC Value:NO];
            [self setValue:PREF_HUD_DISPLAYORIENTATION Value:NO];
            [self setValue:PREF_AUTO_GETPOIINFO Value:YES];
            [self setValue:PREF_IS_DOWNLOAD_NEWSKIN Value:YES];
            [self setValue:PREF_IS_FIRSTENTERSKIN Value:NO];
            [self setValue:PREF_IS_OLD_USERS Value:YES];
            [self setValue:PREF_NEXT_HIGHTPRAISE_COUNT Value:0];
            [self setValue:PREF_HIGHTPRAISE_ALERT Value:YES];
            [self setValue:PREF_FIRSTSTART Value:YES];
            [self setValue:PREF_SWITCHEDVOICE Value:YES];
            [self setValue:PREF_IS_POWERVOICE_PLAY Value:NO];
            [self setValue:PREF_POWERVOICEID Value:0];
            [self setValue:PREF_AUTOSWITCHDIALECT Value:NO];
            [self setValue:PREF_IS_LZLDIALECT Value:0];
            [self setValue:PREF_SEARCHTYPE Value:NO];
            [GDBL_TTS GDBL_TTSStartUpWithResourcePath:tts_path];
            
        }
            break;
        default:
            break;
    }
}

/**********************************************************************
 * 函数名称: MW_SetFeedbackPush
 * 功能描述: 设置用户反馈推送内容
 * 输入参数: feedbackDic:推送内容
 * 输出参数:
 * 返 回 值: 
 **********************************************************************/
- (void)MW_SetFeedbackPush:(NSMutableDictionary *)feedbackDic
{
   
    NSMutableDictionary *pushUserFeedback = [[NSMutableDictionary alloc] initWithDictionary:feedbackDic];
    // 解析数据
    //	“asp”:{
    //        “alert”:提示信息
    //        “badge”:消息总数
    //        “sound”:消息声音
    //    }
    //	“ex”:{
    //        “sc”:类别：1:好友位置分享 2:留言 3:更新提醒 4:用户反馈回复
    //        “unreadCount”:未读回复数
    //    }
    //}
    NSDictionary* pSubDictionary = [pushUserFeedback objectForKey:@"ex"];
    NSString* szUnreadCount = [pSubDictionary objectForKey:@"unreadCount"];
    _PSCountOfUnread = [szUnreadCount intValue];
    _PSNewCustomerServicePrompt = YES;

    [pushUserFeedback release];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_HandleUIUpdate object:nil userInfo:nil];
}


-(void)setGresourceVersion:(NSString *)gresourceVersion
{
    if (gresourceVersion != _gresourceVersion) {
        [_gresourceVersion release];
        _gresourceVersion = [gresourceVersion copy];
    }
    [[NSUserDefaults standardUserDefaults] setObject: gresourceVersion forKey:PARAMGRESOURCEVERSIONKEY];
}

-(void)setDeviceToken:(NSString *)deviceToken
{
    if (deviceToken != _deviceToken) {
        [_deviceToken release];
        _deviceToken = [deviceToken copy];
    }
    NSString *tmpID = @"";
    if (deviceToken) {
        tmpID = [NSString stringWithFormat:@"%@",deviceToken];
    }
    
    GDBL_SetParamExt(DEVICETOKEN, (void *)[tmpID UTF8String]);
}

-(void)setBackgroundNavi:(BOOL)param
{
    _backgroundNavi = param;
    GDBL_SetParamExt(BACKGROUND_NAVI, &param);
}

-(void)setSpeakTraffic:(BOOL)param
{
    _speakTraffic = param;
    GDBL_SetParamExt(VOICE_TRAFFIC, &param);
}

@end
