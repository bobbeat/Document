//
//  MWMapOperator.m
//  AutoNavi
//
//  Created by yu.liao on 13-7-29.
//
//

#import "MWMapOperator.h"
#import "TrafficEventManager.h"
#import "TrafficEventReport.h"
#import "Plugin_OnLineMapUtility.h"
#import "ANDataSource.h"
#import "GDBL_TMC.h"

static MWMapOperator *instance = nil;

@implementation MWMapOperator
@synthesize mapOperate;

+(MWMapOperator*)sharedInstance
{
    @synchronized(self)
    {
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    }
    return instance;
}

+(void)releaseInstance
{
    @synchronized(self)
    {
        if (instance != nil)
        {
            [instance release];
            instance = nil;
        }
    }
}

- (id)init
{
    self = [super init];
    if(self!=nil)
    {
        
    }
	
    return self;
}
#pragma mark 查看指定地图
/**********************************************************************
 * 函数名称: MW_ShowMapView
 * 功能描述: 查看指定地图
 * 参    数: [IN] eViewType 视图类型
 *			[IN] Param1, Param2, Param3 扩展参数，参见说明。
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、	该接口可以完全取代GDBL_ViewMap。后续只对该接口进行功能扩充。
 *			2、	视图类型与参数对应表：
 *			序号   | 功能               eViewType	                    nParam1                    nParam2            nParam3
 *			1	   | 单路线主地图	    GMAP_VIEW_TYPE_MAIN	          | N/A                        N/A                N/A
 *			2	   | 单路线全程概览	    GMAP_VIEW_TYPE_WHOLE	      | N/A                        N/A                N/A
 *			3	   | 多路线主地图	    GMAP_VIEW_TYPE_MULTI	      | N/A                        N/A                N/A
 *			4	   | 多路线全程概览	    GMAP_VIEW_TYPE_MULTIWHOLE	  | N/A                        N/A                N/A
 *			5	   | 查看POI	        GMAP_VIEW_TYPE_POI	          | GPOI* pPOI	               Gbool bAutoAdjust  N/A
 *			6	   | 查看SP码点	        GMAP_VIEW_TYPE_SP	          | Gchar* szSPCode	           Gbool bAutoAdjust  N/A
 *			7	   | 查看引导机动点	    GMAP_VIEW_TYPE_MANEUVER_POINT | GGUIDEROADINFO中的nID字段  N/A                N/A
 *			8	   | 路径TMC概览	    GMAP_VIEW_TYPE_ROUTE_TMC      | GGUIDEROADTMCLIST数组序号  N/A                N/A
 *			9	   | 多路线不同处概览	GMAP_VIEW_TYPE_MULTI_DIFF     | -1 : 所有不同              N/A                N/A
 **********************************************************************/
-(int)MW_ShowMapView:(GMAPVIEWTYPE)eViewType WithParma1:(Gint32)param1 WithParma2:(Gint32)param2 WithParma3:(Gint32)param3
{
    
    return GDBL_ShowMapView(eViewType,param1,param2,param3);
    
}

#pragma mark 强制刷新一次地图视图
/**********************************************************************
 * 函数名称: MW_RefreshMapView
 * 功能描述: 强制刷新一次地图视图
 * 参    数:
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_RefreshMapView:(GMAPVIEWTYPE)mapViewType
{
    GSTATUS res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(mapViewType,&mapHandle);
    if (GD_ERR_OK == res) {
        return GDBL_RefreshMapView(mapHandle);
    }
    return res;
    
}

#pragma mark 缩放地图 2D
/**********************************************************************
 * 函数名称: MW_ZoomMapView
 * 功能描述: 缩放地图视图
 * 参    数: [IN] mapHandle 地图视图句柄
 *			[IN] flag 缩放标识，-1缩小一个比例级别，0缩放到eLevel比例级别，1放大一个比例级别。
 *			[IN] level 比例级别，当nFlag为0时才有意义，参见nFlag参数。
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 **********************************************************************/
-(int)MW_ZoomMapView:(GMAPVIEWTYPE)eViewMap ZoomFlag:(Gint32)flag ZoomLevel:(GZOOMLEVEL)level
{
    Gint32 typeForMap;
    GHMAPVIEW handleForMap;
    GDBL_GetCurrentMapViewType(&typeForMap);
    GDBL_GetMapViewHandle(typeForMap, &handleForMap);
    GMAPVIEWINFO stMapObjectInfo;
	GDMID_GetMapObjectInfo(handleForMap, &stMapObjectInfo);
    if ([[MWPreference sharedInstance] getValue:PREF_MAPVIEWMODE] == MAP_3D && ![Plugin_OnLineMapUtility sharedInstance].isAmapView && [Plugin_OnLineMapUtility sharedInstance].m_viewControllerType != ViewController_Browse && GMAP_VIEW_TYPE_MAIN == stMapObjectInfo.eViewType)//3D调节仰角
    {
        if (1 == flag) {
            [self MW_RotateMapView:eViewMap bAbsolute:Gfalse WithX:10.0 WithY:0 WithZ:0];
        }
        else if (-1 == flag){
            [self MW_RotateMapView:eViewMap bAbsolute:Gfalse WithX:-10.0 WithY:0 WithZ:0];
        }
        
    }
    else
    {
        GSTATUS res;
        GHMAPVIEW mapHandle;
        res = GDBL_GetMapViewHandle(eViewMap,&mapHandle);
        if (GD_ERR_OK == res) {
            
            int i =  GDBL_ZoomMapView(mapHandle,flag,level);
        
            if (flag == 0)
            {
                [[Plugin_OnLineMapUtility sharedInstance] MapZoomTO:[[ANDataSource sharedInstance] GMD_GetCurrentScale]];
            }
            else if (flag == 1)
            {
                [[Plugin_OnLineMapUtility sharedInstance] MapZoomIN:[[ANDataSource sharedInstance] GMD_GetCurrentScale]];
            }
            else if (flag == -1)
            {
                [[Plugin_OnLineMapUtility sharedInstance] MapZoomOut:[[ANDataSource sharedInstance] GMD_GetCurrentScale]];
            }
            return i;
        }
        return res;
    }
    return 0;
    
}

#pragma mark 移图
/**********************************************************************
 * 函数名称: MW_MoveMapView
 * 功能描述: 移图
 * 参    数: [IN] mapHandle 地图视图句柄
 *			[IN] typeCoord 结构体GMOVEMAP指针，用于标识当前移图操作类型和相关参数。
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_MoveMapView:(GMAPVIEWTYPE)eViewMap TypeAndCoord:(GMOVEMAP *)typeCoord
{
    
    if (([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:typeCoord->deltaCoord.x Lat:typeCoord->deltaCoord.y] != 0 && [ANParamValue sharedInstance].isUseNETMap) || [Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        if (typeCoord->eOP == MOVEMAP_OP_DRAG)
        {
            typeCoord->deltaCoord.x = typeCoord->deltaCoord.x<5?0:typeCoord->deltaCoord.x;
            typeCoord->deltaCoord.y = typeCoord->deltaCoord.x<5?0:typeCoord->deltaCoord.y;
            [[Plugin_OnLineMapUtility sharedInstance] SetAmapCenterWithDragX:typeCoord->deltaCoord.x DragY:typeCoord->deltaCoord.y];
        }
        else if (typeCoord->eOP == MOVEMAP_OP_GEO_DIRECT)
        {
            [[Plugin_OnLineMapUtility sharedInstance] SetAmapCenterWithLon:(double)typeCoord->deltaCoord.x/1000000.0 Lat:(double)typeCoord->deltaCoord.y/1000000.0];
        }
    }
    
    GSTATUS res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(eViewMap,&mapHandle);
    if (GD_ERR_OK == res) {
        res = GDBL_MoveMapView(mapHandle,typeCoord);
        if (GD_ERR_OK == res) {
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_MOVEMAP object:nil];
        }
        
    }
    return res;
}

#pragma mark 移图(长按地图界面显示点详细信息面板时，面板位置改变时，移动地图)
/**********************************************************************
 * 函数名称: MW_moveMapWithMapType
 * 功能描述: 移图(长按地图界面显示点详细信息面板时，面板位置改变时，移动地图)
 * 参    数: [IN] mapType 视图结构体类型
 *			[IN] flag 面板移动类型
            [IN] point 查看的poi屏幕坐标
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
- (int)MW_moveMapWithMapType:(GMAPVIEWTYPE)mapType Flag:(int)flag Point:(CGPoint)point
{
    static int u = 0;
    static int lon = 0;
    static int lat = 0;
    if (u == 0) {
        GMAPCENTERINFO mapinfo = {0};
        [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
        lon = mapinfo.CenterCoord.x;
        lat = mapinfo.CenterCoord.y;
        u ++;
    }
    GCOORD tmp = [[ANDataSource sharedInstance] GMD_CoordConvert:GCC_GEO_TO_SCR Lon:lon Lat:lat HMapView:GMAP_VIEW_TYPE_MAIN];
    
    point.x = tmp.x;
    point.y = tmp.y;
    
    switch (flag) {
        case 0://面板向上，遮盖一小部分
        {
            
            if (point.y > 340.0) {
                int dX = point.x - SCREENWIDTH/2.0;
                int dY = point.y - SCREENHEIGHT/2.0;
                GMOVEMAP moveMap;
                moveMap.eOP = MOVEMAP_OP_DRAG;
                moveMap.deltaCoord.x = dX*[ANParamValue sharedInstance].scaleFactor;
                moveMap.deltaCoord.y = dY*[ANParamValue sharedInstance].scaleFactor;
                [[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
            }

        }
            break;
        case 1://面板向上，遮盖一大部分
        {
            if (point.x == 0 || point.x > SCREENWIDTH || point.y == 0 || point.y > 150.0) {
                int dX = point.x - SCREENWIDTH/2.0;
                int dY = point.y - 80.0;
                GMOVEMAP moveMap;
                moveMap.eOP = MOVEMAP_OP_DRAG;
                moveMap.deltaCoord.x = dX*[ANParamValue sharedInstance].scaleFactor;
                moveMap.deltaCoord.y = dY*[ANParamValue sharedInstance].scaleFactor;
                [[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
            }
        }
            break;
        case 2://面板向下，遮盖一小部分
        {
            int dX = point.x - SCREENWIDTH/2.0;
            int dY = point.y - SCREENHEIGHT/2.0;
            GMOVEMAP moveMap;
            moveMap.eOP = MOVEMAP_OP_DRAG;
            moveMap.deltaCoord.x = dX*[ANParamValue sharedInstance].scaleFactor;
            moveMap.deltaCoord.y = dY*[ANParamValue sharedInstance].scaleFactor;
            [[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
        }
            break;
        
        default:
            break;
    }
    return 1;
}

#pragma mark 旋转地图
/**********************************************************************
 * 函数名称: MW_RotateMapView
 * 功能描述: 旋转地图视图
 * 参    数: [IN] mapHandle 地图视图句柄
 *			[IN] bAbsolute 是否为绝对角度值，Gtrue表示xa、ya、za为绝对角度值，否则为相对角度值。
 *			[IN] xAngle、yAngle、zAngle 角度值，可以为负值。
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_RotateMapView:(GMAPVIEWTYPE)eViewMap bAbsolute:(Gbool)bAbsolute WithX:(Gfloat32)xAngle WithY:(Gfloat32)yAngle WithZ:(Gfloat32)zAngle
{
    GSTATUS res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(eViewMap,&mapHandle);
    if (GD_ERR_OK == res) {
        return GDBL_RotateMapViewEx(mapHandle,bAbsolute,xAngle,yAngle,zAngle,0);
    }
    return res;
    
}

#pragma mark 调整车位
/**********************************************************************
 * 函数名称: MW_AdjustCar
 * 功能描述: 调整车位
 * 参    数: [IN] eViewMap 地图类型
 *			[IN] coord 经纬度
 *			[IN] angle 车位角度
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_AdjustCar:(GMAPVIEWTYPE)eViewMap Gcoord:(GCOORD)coord Angle:(Gint32)angle
{
    GSTATUS res = GDBL_AdjustCar(coord,angle);
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView && [Plugin_OnLineMapUtility sharedInstance].m_maMapView) //同步网络车标位置
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:0];
    }
    return res;
}

#pragma mark 切换地图视图模式
/**********************************************************************
 * 函数名称: MW_SetMapViewMode
 * 功能描述: 切换地图视图模式
 * 参    数: [IN] mapHandle 地图视图句柄
 *			[IN] type 模式标识，-1前一个模式，0切换到eMapViewMode模式，1下一个模式。
 *			[IN] mapMode 视图模式，当type为0时才有意义，参见type参数说明。
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_SetMapViewMode:(GMAPVIEWTYPE)eViewMap Type:(Gint32)type MapMode:(GMAPVIEWMODE)mapMode
{
    GSTATUS res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(eViewMap,&mapHandle);
    if (GD_ERR_OK == res) {
        return GDBL_SetMapViewMode(mapHandle,type,mapMode);
    }
    return res;
    
}

#pragma mark 重置地图视图
/**********************************************************************
 * 函数名称: MW_ResetMapView
 * 功能描述: 重置地图视图
 * 参    数: [IN] mapHandle 地图视图句柄
 *			[IN] mapFlag 需要重置的参数，参见GMAPVIEWFLAG枚举类型。
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_ResetMapView:(GMAPVIEWTYPE)eViewMap MapFlag:(GMAPVIEWFLAG)mapFlag
{
    GSTATUS res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(eViewMap,&mapHandle);
    if (GD_ERR_OK == res) {
        return GDBL_ResetMapView(mapHandle,mapFlag);
    }
    return res;
}

#pragma mark 设置地图操作类型
/**********************************************************************
 * 函数名称: MW_SetMapOperateType
 * 功能描述: 设置地图操作类型
 * 参    数: [IN] type 地图操作类型
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
- (void)MW_SetMapOperateType:(NSInteger)type {
	
	mapOperate = type;
}

/**********************************************************************
 * 函数名称: MW_SetMapType
 * 功能描述: 设置地图类型
 * 参    数: [IN] type 0:本地地图 1:网络地图
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
- (int)MW_SetMapType:(NSInteger)type{
    GSTATUS res;
    res = GDBL_SetMapType(type);
    return res;
}

#pragma mark 设置地图竖屏区域
/**********************************************************************
 * 函数名称: MW_SetMapViewVRect
 * 功能描述: 设置地图竖屏区域
 * 参    数: [IN] V_Rect 竖屏区域
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
- (void)MW_SetMapViewVRect:(CGRect)V_Rect
{
    GRECT V_MAP_VIEW_RECT;
	V_MAP_VIEW_RECT.left= (Gint32)V_Rect.origin.x;
	V_MAP_VIEW_RECT.top = (Gint32)V_Rect.origin.y;
	V_MAP_VIEW_RECT.right = (Gint32)((V_Rect.size.width + V_Rect.origin.x)*[ANParamValue sharedInstance].scaleFactor-1);
	V_MAP_VIEW_RECT.bottom= (Gint32)((V_Rect.size.height + V_Rect.origin.y)*[ANParamValue sharedInstance].scaleFactor-1);
	GDBL_SetParam(G_V_MAP_VIEW_RECT, &V_MAP_VIEW_RECT);
    
}

#pragma mark 设置地图横屏区域
/**********************************************************************
 * 函数名称: MW_SetMapViewHRect
 * 功能描述: 设置地图横屏区域
 * 参    数: [IN] H_Rect 横屏区域
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
- (void)MW_SetMapViewHRect:(CGRect)H_Rect
{
    GRECT H_MAP_VIEW_RECT;
	H_MAP_VIEW_RECT.left= (Gint32)H_Rect.origin.x;
	H_MAP_VIEW_RECT.top = (Gint32)H_Rect.origin.y;
	H_MAP_VIEW_RECT.right = (Gint32)((H_Rect.size.width + H_Rect.origin.x)*[ANParamValue sharedInstance].scaleFactor-1);
	H_MAP_VIEW_RECT.bottom= (Gint32)((H_Rect.size.height + H_Rect.origin.y)*[ANParamValue sharedInstance].scaleFactor-1);
	GDBL_SetParam(G_H_MAP_VIEW_RECT, &H_MAP_VIEW_RECT);
    
}

#pragma mark 回车位
/**********************************************************************
 * 函数名称: MW_GoToCCP
 * 功能描述: 回车位
 * 参    数:
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
- (void)MW_GoToCCP
{
    if (![[ANParamValue sharedInstance] isInit])
    {
        return;
    }
    GSTATUS res;
    res = GDBL_GoToCCP();
    if (GD_ERR_OK==res)
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_GOTOCPP object:nil];
    }
    [[Plugin_OnLineMapUtility sharedInstance] SynNetCarPositionWithLocalCar];
	[[Plugin_OnLineMapUtility sharedInstance] BackToCar];
}

#pragma mark 获取地图句柄
/**********************************************************************
 * 函数名称: MW_GetMapViewHandle
 * 功能描述: 获取指定地图视图句柄
 * 参    数: [IN] eViewType 枚举GMAPVIEWTYPE类型，用于指定视图类型。
 *			[OUT] mapHandle 地图视图句柄
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、地图视图句柄是用来管理地图视图的，使用该句柄可以进行地图
 *			视图的缩放、移图、模式切换等操作。
 **********************************************************************/
-(int)MW_GetMapViewHandle:(GMAPVIEWTYPE)eViewMap MapHandle:(GHMAPVIEW *)mapHandle
{
    return GDBL_GetMapViewHandle(eViewMap,mapHandle);
}

#pragma mark 获取当前地图信息(地图类型,地图中心,地图模式,地图角度,地图仰角,对应的比例数值,比例级别)
/**********************************************************************
 * 函数名称: MW_GetMapViewInfo
 * 功能描述: 获取当前地图信息(地图类型,地图中心,地图模式,地图角度,地图仰角,对应的比例数值,比例级别)
 * 参    数: [IN] eViewType 枚举GMAPVIEWTYPE类型，用于指定视图类型。
 *			[OUT] mapViewInfo 当前地图信息
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 
 **********************************************************************/
-(int)MW_GetMapViewInfo:(GMAPVIEWTYPE)eViewMap MapViewInfo:(GMAPVIEWINFO *)mapViewInfo
{
    GSTATUS res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(eViewMap,&mapHandle);
    if (GD_ERR_OK == res) {
        return GDBL_GetMapViewInfo(mapHandle,mapViewInfo);
    }
    return res;
}

#pragma mark 缓存当前地图信息
/**********************************************************************
 * 函数名称: MW_SaveInfoForCurrrentMapView
 * 功能描述: 缓存当前地图信息
 * 参    数: 
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
- (void)MW_SaveInfoForCurrrentMapView
{
    Gint32 typeForMap;
    GHMAPVIEW handleForMap;
    GSTATUS nStatus;
    nStatus = GDBL_GetCurrentMapViewType(&typeForMap);
    nStatus = GDBL_GetMapViewHandle(typeForMap, &handleForMap);
    nStatus = GDBL_GetMapViewInfo(handleForMap, &m_stMapViewInfo);
}

#pragma mark 对比缓存的地图信息判断是否有移图
/**********************************************************************
 * 函数名称: MW_CheckIfChangeOnMapViewInfo
 * 功能描述: 判断是否有移图
 * 参    数:
 * 返 回 值: YES:有移图 NO:无移图
 * 其它说明: 对比缓存的地图信息判断是否有移图
 **********************************************************************/
- (BOOL)MW_CheckIfChangeOnMapViewInfo
{
    Gint32 typeForMap;
    GHMAPVIEW handleForMap;
    GSTATUS nStatus;
    GMAPVIEWINFO stMapViewInfo={0};
    nStatus = GDBL_GetCurrentMapViewType(&typeForMap);
    nStatus = GDBL_GetMapViewHandle(typeForMap, &handleForMap);
    nStatus = GDBL_GetMapViewInfo(handleForMap, &stMapViewInfo);
    if (nStatus==GD_ERR_OK) {
        if (stMapViewInfo.MapCenter.x!=m_stMapViewInfo.MapCenter.x||stMapViewInfo.eScaleLevel!=m_stMapViewInfo.eScaleLevel||stMapViewInfo.MapCenter.y!=m_stMapViewInfo.MapCenter.y) {
            return YES;
        }
    }
    return NO;
}

#pragma mark 获取地图中心点信息
/**********************************************************************
 * 函数名称: MW_GetMapViewCenterInfo
 * 功能描述: 获取地图中心点信息
 * 参    数: [IN] eViewType 枚举GMAPVIEWTYPE类型，用于指定视图类型。
 *			[OUT] pMapCenterInfo 当前地图中心点信息
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_GetMapViewCenterInfo:(GMAPVIEWTYPE)eViewMap mapCenterInfo:(GMAPCENTERINFO *)pMapCenterInfo
{
    GSTATUS res;
    GHMAPVIEW mapHandle;
    res = GDBL_GetMapViewHandle(eViewMap,&mapHandle);
    if (GD_ERR_OK == res) {
        return GDBL_GetMapViewCenterInfo(mapHandle,pMapCenterInfo);
    }
    return res;
}

#pragma mark 缩放到指定级别比例尺
/**********************************************************************
 * 函数名称: MW_ZoomTo
 * 功能描述: 缩放到指定级别比例尺
 * 参    数: [IN] level 比例尺级别
            [IN] animated 是否有动画
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
-(void)MW_ZoomTo:(GZOOMLEVEL)level Animated:(BOOL)animated
{
    if (animated) {
        GDBL_ZoomTo(level);
    }
    else{
        GDMID_ZoomTo(level);
    }
	
}

#pragma mark 固定3d仰角
/**********************************************************************
 * 函数名称: MW_Keep3DElevation
 * 功能描述: 固定3d仰角
 * 参    数: 
 * 返 回 值: YES:成功 NO:失败
 * 其它说明:
 **********************************************************************/
-(BOOL)MW_Keep3DElevation
{
    GMAPVIEWMODE eMapViewMode;
    GDBL_GetParam(G_MAP_VIEW_MODE, &eMapViewMode);
    if ( eMapViewMode == GMAPVIEW_MODE_3D)
    {
        Gint32 curAngle;
        GDBL_GetParam(G_MAP_ELEVATION, &curAngle);
        
        Gint32 deltaAngle = 0;
        UIInterfaceOrientation ori = [[UIApplication sharedApplication] statusBarOrientation];
        if (ori == UIInterfaceOrientationPortrait || ori == UIInterfaceOrientationPortraitUpsideDown)
        {
            deltaAngle = 50 - curAngle;//竖屏3d仰角默认50度
        }
        else  if (ori == UIInterfaceOrientationLandscapeLeft || ori == UIInterfaceOrientationLandscapeRight)
        {
            deltaAngle = 40 - curAngle;//横屏3d仰角默认40度
        }
        GDBL_AdjustMapElevation(deltaAngle);
    }
    return YES;
}

#pragma mark 开启实时交通
/**********************************************************************
 * 函数名称: MW_ShowTMC
 * 功能描述: 开启实时交通
 * 参    数:
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (BOOL)MW_ShowTMC
{
    BOOL isPath = NO;
    GDBL_GetParam(G_GUIDE_STATUS, &isPath); //有路径下 提升定位精度
    if (isPath) {
        [GDBL_UserBehaviorCountNew shareInstance].realTimeTraffic_InPath ++;
    }
    else{
        [GDBL_UserBehaviorCountNew shareInstance].realTimeTraffic ++;
    }
    if (isPath) {
        [GDBL_UserBehaviorCountNew shareInstance].trafficEventDisplay_InPath ++;
    }
    else{
        [GDBL_UserBehaviorCountNew shareInstance].trafficEventDisplay ++;
    }
    
	[[GDBL_TMC shareInstance] TMC_Startup];
    return NO;
}
@end
