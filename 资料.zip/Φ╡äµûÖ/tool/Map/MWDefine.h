//
//  MWDefine.h
//  AutoNavi
//
//  Created by huang longfeng on 13-7-30.
//
//
#import "ANOperateMethod.h"
#import "MWPreference.h"
#import "ANDataSource.h"
#import "NSString+Category.h"
#import "UIImage+Category.h"
#import "GDSkinColor.h"
#import "Utility.h"
#import "UIDevice+Category.h"

#ifndef AutoNavi_MWDefine_h
#define AutoNavi_MWDefine_h

#define PARAMDEVICEIDKEY          @"deviceidkey"
#define PARAMGRESOURCEVERSIONKEY  @"gresourceversionkey"
#define PARAMDATAPATHKEY          @"datapathkey"

#pragma mark 软件相关=======================================================================

#define g_data_path (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)?([UIScreen instancesRespondToSelector:@selector(scale)] ? (([[UIScreen mainScreen] scale] == 2.0)?(([[UIScreen mainScreen] currentMode].size.height == 960)?[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPhone4/"]  UTF8String]:[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPhone5/"]  UTF8String]):[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPhone3/"]  UTF8String]) : [[NSHomeDirectory() stringByAppendingString:@"/Documents/iPhone3/"]  UTF8String]):([UIScreen instancesRespondToSelector:@selector(scale)] ? (([[UIScreen mainScreen] scale] == 2.0)?[[NSHomeDirectory() stringByAppendingString:@"/Documents/NewiPad/"]  UTF8String]:[[NSHomeDirectory() stringByAppendingString:@"/Documents/iPad/"]  UTF8String]) : [[NSHomeDirectory() stringByAppendingString:@"/Documents/iPad/"]  UTF8String])

#define SOFTVERSIONNUM                8.4f

#define fontType                  (int)[[MWPreference sharedInstance] getValue:PREF_UILANGUAGE]   //字体类型

#define Interface_Flag            (int)[[ANDataSource sharedInstance] GMD_GetDeviceOrientation]  //横竖屏方向

#define OrientationSwitch         [[MWPreference sharedInstance] getValue:PREF_INTERFACESTATE]  //横竖屏开关

#define Orientation               [[MWPreference sharedInstance] getValue:PREF_INTEFACEORIENTATION]  //界面方向

#define deviceTokenEx             ([MWPreference sharedInstance].deviceToken)? [MWPreference sharedInstance].deviceToken : @"0123456789012345678901234567890123456789012345678901234567890123"        //获取deviceToken

#define deviceID                  [[ANDataSource sharedInstance] GMD_GetDeviceID]               //获取设备id

#define VendorID                  [Utility GetVendorID]//服务商id

//字符转换
#define CSTRING_TO_NSSTRING(cString) [NSString stringWithCString:cString encoding: CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000)]
#define NSSTRING_TO_CSTRING(string)	[string cStringUsingEncoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000)]

//调用示例：IMAGE(@"a.png",IMAGEPATH_TYPE_1) 说明：目前imagePathType有两个枚举类型，IMAGEPATH_TYPE_1、IMAGEPATH_TYPE_2；IMAGEPATH_TYPE_1表示图片资源从bundle中获取，IMAGEPATH_TYPE_2表示图片资源从指定路径获取
#define IMAGE(name,imagePathType) [UIImage imageWithName:name pathType:imagePathType]



//调用示例：STR(@"alert",@"name")
#define STR(key,tableName)        [[ANOperateMethod sharedInstance] GMD_SetLocalizeKey:key table:tableName]
#define Setting_STR(key) STR(key,@"SettingLocalizable")

//网络连接类型:0-无网络; 1-3G; 2-WIFI
#define NetWorkType               [[ANDataSource sharedInstance] isNetConnecting]

//BarButtonItem
#define LEFTBARBUTTONITEM(TITLE, SELECTOR)	[[[VCTranslucentBarButtonItem alloc] initWithType:VCTranslucentBarButtonItemTypeBackward title:TITLE target:self action:SELECTOR] autorelease]
#define RIGHTBARBUTTONITEM(TITLE, SELECTOR) [[[VCTranslucentBarButtonItem alloc] initWithType:VCTranslucentBarButtonItemTypeNormal title:TITLE target:self action:SELECTOR] autorelease]
#define RIGHTBARBUTTONITEM1(TITLE, SELECTOR) [[[VCTranslucentBarButtonItem alloc] initWithType:VCTranslucentBarButtonItemTypeRedColor title:TITLE target:self action:SELECTOR] autorelease]

//通用高度
#define kHeight1     38     
#define kHeight2     48//通用单元格高度(一行)
#define kHeight3     65
#define kHeight4     35
#define kHeight5     56//通用单元格高度(两行)

//通用字体大小
#define kSize1       20
#define kSize2       17 //通用text字体大小
#define kSize3       13
#define kSize4       19
#define kSize5       17 //通用detailtext字体大小
#define kSize6       13


#pragma mark 系统相关========================================================================

//当前设备分辨率名称（iPhone3,iPhone4,iPhone5,iPad,NewPad）
#define DeviceResolutionName [UIDevice currentResolutionName]

// 是否iPad
#define isPad (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
// 是否iPhone
#define isiPhone (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)

// 是否模拟器
#define isSimulator (NSNotFound != [[[UIDevice currentDevice] model] rangeOfString:@"Simulator"].location)

//屏幕宽度
#define SCREENWIDTH [[UIScreen mainScreen] bounds].size.width
//屏幕高度
#define SCREENHEIGHT [[UIScreen mainScreen] bounds].size.height

//应用程序宽度
#define APPWIDTH [[UIScreen mainScreen] applicationFrame].size.width
//应用程序宽度
#define APPHEIGHT [[UIScreen mainScreen] applicationFrame].size.height
//应用程序分辨率比例，可以用来判断是否高清
#define SCALE ([[UIScreen mainScreen] respondsToSelector:@selector(displayLinkWithTarget:selector:)] ? [[UIScreen mainScreen] scale] : 1.0)
#define ISRETINA ((SCALE == 2.0) ? 1 : 0)
//根window
#define MainWindow ((UIWindow *)[[UIApplication sharedApplication].windows objectAtIndex:0]).rootViewController.view

// --- 从plist中获取颜色。a —— 获取颜色所使用的key值(类型 —— NSString)  ---
#define GETSKINCOLOR(a) ([[GDSkinColor sharedInstance] getColorByKey:(a)])

#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]

#define IMAGECOLOR(name,type) [UIColor colorWithPatternImage:IMAGE(name,type)]

#define NAVICTR_V 44.0 //竖屏导航栏高度
#define NAVICTR_H (isiPhone ? 32.0 : 44.0) //横屏导航栏高度

#define CONTENTHEIGHT_V ([[UIScreen mainScreen] applicationFrame].size.height-44.0) //竖屏，扣除导航栏、状态栏，剩余的页面高度
#define CONTENTHEIGHT_H (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? ([[UIScreen mainScreen] applicationFrame].size.width-44.0):([[UIScreen mainScreen] applicationFrame].size.width-32.0)) //横屏，扣除导航栏、状态栏，剩余的页面高度

#define iPhoneOffset  ((int)[[UIScreen mainScreen] currentMode].size.height % 480)/2.0  //iphone5位置偏移
#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)

//获取系统版本
#define IOS_VERSION [[[UIDevice currentDevice] systemVersion] floatValue]
#define CurrentSystemVersion [[UIDevice currentDevice] systemVersion]
#define deviceModel [[UIDevice currentDevice] model]
#define IsSteal  [[ANDataSource sharedInstance] GMD_GetIsSteal]
#define IOS_7   (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1)

#pragma mark NSUSERDEFAULT KEY==============================================================
//软件升级检测
#define MWSoftWareUpdateReminderKey         @"SoftWareUpdateReminderKey"
//上传设备令牌
#define MWUploadTokenSuccess                @"MWUploadTokenSuccess"
#define MWUploadTokenAutoNaviSuccess        @"MWUploadTokenAutoNaviSuccess"
//地图数据下载页面点击更新保存最新版本，用于控制new图标是否显示
#define MWDataUpdateSaveNewVersion          @"MWDataUpdateSaveNewVersion"
//KEY



//Notify
#define  MWDISMISSMODLEVIEWCONTROLLER        @"MWDismissModelViewcontroller"
#pragma mark 


#endif
