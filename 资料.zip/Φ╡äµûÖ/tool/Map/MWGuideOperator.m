//
//  MWGuideOperator.m
//  AutoNavi
//
//  Created by huang longfeng on 13-7-31.
//
//

#import "MWGuideOperator.h"
#import "Plugin_OnLineMapUtility.h"
#import "ANParamValue.h"
#import "MWMapOperator.h"
#import "MWDialectDownloadManage.h"
#import "DefineNotificationParam.h"
#import "ANOperateMethod.h"
#import "NSString+Category.h"
#import "ANDataSource.h"
#import "GDBL_Location.h"
#import "TrafficEventManager.h"
#import "TrafficEventReport.h"
#import "mapDataManage.h"
#import "GDAlertView.h"
#import "MWMapAddIconOperator.h"
#import "GDBL_TTS.h"

@implementation GuideRouteFavItem
@synthesize startName,desName,distance,totalTime;
@end

static MWGuideOperator *instance = nil;

@interface MWGuideOperator()
{
    
    BOOL                 isSelectedNormal;
    BOOL                 isChooseRoad;  //点击 是和否 之后为YES，之后在行程点回调中据此判断已经选择出道路。
    int                  _alertRouteChoeseCount;    //弹出选择道路框的个数
    GPOI                 desPOI;
    GGUIDEROADLIST       *ppGuideRoadList;//路线详情列表
    GDEMOMODELLIST       *ppDemoModelList;//演示模型列表
    GDEMOJOURNEYLIST     *ppDemoJourneyList;//演示路线列表
    Guint32              pNumberOfList;//演示模型个数
    GPOI                 wayPointNode[10];
    GTRACKINFOLIST       *ppTrackList;       //轨迹列表
}


@property (nonatomic,assign) BOOL isSelectedNormal;
@property (nonatomic,assign) BOOL isChooseRoad;


-(void)threadUploadLocationInfo;

Gint32 GetJunyPointRoadInfo(GROADINFO *pRoadInfo, Gint32 nNumberOfRoadInfo, Gvoid *lpVoid);
@end

@implementation MWGuideOperator

@synthesize m_journeyType,isSelected,isSelectedNormal,wayPoint,isChooseRoad;

+(MWGuideOperator*)sharedInstance
{
    @synchronized(self)
    {
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    }
    return instance;
}

+(void)releaseInstance
{
    @synchronized(self)
    {
        if (instance != nil)
        {
            [instance release];
            instance = nil;
        }
    }
}

- (id)init
{
    self = [super init];
    if(self)
    {
        _alertRouteChoeseCount = 0;
        isChooseRoad = NO;
        isSelected = YES;
        wayPoint = 10;
        GDBL_SetAddJourneyPointCB(GetJunyPointRoadInfo,NULL);
    }
	
    return self;
}
#pragma mark -
#pragma mark 路线相关============================================================================
#pragma mark -
#pragma mark 启动路径规划
/**********************************************************************
 * 函数名称: MW_StartRouteCalculation:(BOOL)bMutilRoute
 * 功能描述: 启动路径规划
 * 参    数: [IN] bMutilRoute: NO 单路线 YES 多路线
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、该接口将返回引导路径句柄，计算完毕不会进行引导,每次设终点完，或者进行规避都必须调用此接口重新计算路径
 **********************************************************************/
-(int)MW_StartRouteCalculation:(BOOL)bMutilRoute
{
    NSLog(@"MW_StartRouteCalculation=======");
    if (bMutilRoute) {//多路线计算用老接口
        return GDBL_StartRouteCalculation(Gtrue);
    }
    else{
        return GDBL_StartRouteCalculation2();
    }
    
}

#pragma mark 添加一条引导路径到引导路径管理表
/**********************************************************************
 * 函数名称: MW_AddGuideRoute
 * 功能描述: 添加一条引导路径到引导路径管理表
 * 参    数: [IN] guideRouteHandle 引导路径句柄
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_AddGuideRoute:(GHGUIDEROUTE)guideRouteHandle
{
    return GDBL_AddGuideRoute(guideRouteHandle);
}

#pragma mark 删除一条引导路径
/**********************************************************************
 * 函数名称: MW_DelGuideRoute
 * 功能描述: 删除一条引导路径
 * 参    数: [IN] guideRouteHandle 引导路径句柄
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、	删除该条引导路径，同时从路径管理表中移除。
 *			2、	删除后该条引导路径将不可再用。
 *			3、	正在引导的引导路径不能删除。
 *			4、	要删除正在引导的引导路径，必须先停止引导。
 **********************************************************************/
-(int)MW_DelGuideRoute:(GHGUIDEROUTE)guideRouteHandle
{
    return GDBL_DelGuideRoute(guideRouteHandle);
}

#pragma mark 从引导路径管理表中移除一条引导路径
/**********************************************************************
 * 函数名称: MW_RemoveGuideRoute
 * 功能描述: 从引导路径管理表中移除一条引导路径
 * 参    数: [IN] guideRoute 引导路径句柄
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、	移除操作并不做实际的删除引导路径。
 *			2、	正在引导的引导路径不能移除。
 *			3、	要移除正在引导的引导路径，必须先停止引导。
 **********************************************************************/
-(int)MW_RemoveGuideRoute:(GHGUIDEROUTE)guideRoute
{
    return GDBL_RemoveGuideRoute(guideRoute);
}

#pragma mark 启动驾驶引导
/**********************************************************************
 * 函数名称: MW_StartGuide
 * 功能描述: 启动驾驶引导
 * 参    数: [IN] hGuideRoute 引导路径句柄
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、	引导指定的路径，上一个路径引导将被自动停止。
 *			2、	启动驾驶引导，生成引导路径信息。
 **********************************************************************/
-(int)MW_StartGuide:(GHGUIDEROUTE)guideRouteHandle
{
    //进入全程概览播报：路径规划完成全程xxx公里/米预计需要XX分钟/小时
    //延时1s，是为了等进度条走完之后才播报
    double delayInSeconds = 1.0;
    NSString *ttsString = [NSString stringWithFormat:STR(@"Route_ttsPlayRoute", @"RouteOverview"),
                           [[ANDataSource sharedInstance] GMD_GetPathStatisticInfoWithMainID:1 GuideHandel:guideRouteHandle],
                           [[ANDataSource sharedInstance] GMD_GetPathStatisticInfoWithMainID:2 GuideHandel:guideRouteHandle]];
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        NSLog(@"%@",ttsString);
        [GDBL_TTS  GDBL_TTSSetCodeType:1];
        [GDBL_TTS GDBL_TTSPlayByCStr:[ttsString UTF8String]];
    });
    return GDBL_StartGuide(guideRouteHandle);
}

#pragma mark 结束驾驶引导
/**********************************************************************
 * 函数名称: MW_StopGuide
 * 功能描述: 结束驾驶引导
 * 参    数:
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、结束路径引导，不删除引导路径。
 **********************************************************************/
-(int)MW_StopGuide
{
    return GDBL_StopGuide();
}

#pragma mark 获取引导路径列表
/**********************************************************************
 * 函数名称: MW_GetGuideRouteList
 * 功能描述: 获取引导路径列表
 * 参    数: 1.[OUT] phGuideRoute 引导路径句柄缓冲区
 *			2.[IN]  nCount 引导路径句柄缓冲区大小
 *			3.[OUT] pNumberOfGuideRoute 实际获取的引导路径条数
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_GetGuideRouteList:(GHGUIDEROUTE *)guideRouteHandle Num:(Gint32)num Count:(Gint32 *)nCount
{
    return GDBL_GetGuideRouteList(guideRouteHandle,num,nCount);
}

#pragma mark 清空引导路径管理表
/**********************************************************************
 * 函数名称: MW_ClearGuideRoute
 * 功能描述: 清空引导路径管理表
 * 参    数:
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、	清空操作是对引导路径管理表中的路径做删除操作。
 *			2、	如果有引导路径正在引导，则该条引导路径不做删除。
 **********************************************************************/
-(int)MW_ClearGuideRoute
{
    return GDBL_ClearGuideRoute();
}

#pragma mark 选择一条路径作为当前路径
/**********************************************************************
 * 函数名称: MW_SelectGuideRoute
 * 功能描述: 选择一条路径作为当前路径
 * 参    数: [IN] guideHandle 引导路径句柄
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 1、	选择一条引导路径并不代表引导的就是这条路径。
 *			2、	选择功能只是在多条路径时，选择一条后，可以高亮显示，以供查看。
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/12/25			1.0			陈其义
 **********************************************************************/
-(int)MW_SelectGuideRoute:(GHGUIDEROUTE)guideHandle
{
    return GDBL_SelectGuideRoute(guideHandle);
}

#pragma mark 点击选择一条路径高亮显示
/**********************************************************************
 * 函数名称:	MW_SelectElementsByHit
 * 功能描述:	地图选择任意地图元素
 * 输入参数:	[in] pSelectParam	输入参数：视图类型、位置、命令
 *			[out] pElements	元素缓冲区
 *			[out] pNumberOfElements 实际返回的元素个数
 * 返回值:	成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 命令与返回值一一对应，如下：
 *		GSELECT_CMD_ROUTE 无返回值，内部直接高亮当前选中路径
 *		GSELECT_CMD_EVENT 返回GEVENTINFO数组
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2013/08/20		6.1
 **********************************************************************/
- (int) MW_SelectElementsByHit:(GSELECTPARAM *)pSelectParam Elements:(void **)pElements NumberOfElements:(Gint32 *)pNumberOfElements
                                   
{
    GSTATUS res;
	res = GDBL_SelectElementsByHit(pSelectParam, pElements,pNumberOfElements);
    
    return res;
}

#pragma mark 点击路线上事件，交通流图标避让
/**********************************************************************
 * 函数名称: MW_AddAvoidEventInfo
 * 功能描述: 增加避让TMC事件信息
 * 输入参数: [IN]pEventInfo		要避让的TMC事件信息
 * 输出参数:
 * 返 回 值：成功返回GD_ERR_OK，异常情况返回 GSTATUS 对应出错码
 * 其它说明:
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 **********************************************************************/
- (GSTATUS)MW_AddAvoidEventInfo:(GEVENTINFO *)pEventInfo
{
	return GDBL_AddAvoidEventInfo(pEventInfo);
}

#pragma mark 获取引导路径相关信息
/**********************************************************************
 * 函数名称: MW_GetGuideRouteInfo
 * 功能描述: 该函数用于获取引导路径相关信息。
 * 参    数: [IN] guideRouteHandle 引导路径句柄
 *			[OUT] routeInfo 引导路径信息
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_GetGuideRouteInfo:(GHGUIDEROUTE)guideRouteHandle RouteInfo:(GGUIDEROUTEINFO *)routeInfo
{
    return GDBL_GetGuideRouteInfo(guideRouteHandle,routeInfo);
}

#pragma mark 判断是否有收藏的路径
/**********************************************************************
 * 函数名称: MW_bGuideRoute
 * 功能描述: 判断是否有收藏的路径
 * 参    数: guideRoute 路线句柄 (传入GNULL则判断当前引导路线是否收藏)
 * 返 回 值: 有返回YES, 没有返回NO
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 **********************************************************************/
- (BOOL)MW_bGuideRoute:(GHGUIDEROUTE)guideRoute
{
    
    GSTATUS res;
    if (guideRoute) {
        GGUIDEROUTEINFO curRouteInfo = {0};
        res = GDBL_GetGuideRouteInfo(guideRoute, &curRouteInfo);
        if (GD_ERR_OK == res) {
            int curRule = 0;
            
            NSArray *files = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:guideRoute_path error:nil];
            
            GDBL_GetParam(G_ROUTE_OPTION, &curRule);
            
            for (NSString *fileName in files) {
                char tmpPath[256] = {0};
                const char *mpath = [[NSString stringWithFormat:@"%@%@",guideRoute_path,fileName] UTF8String];
                strcpy(tmpPath, mpath);
                GHGUIDEROUTE guideRouteHandle = {0};
                res = GDBL_LoadGuideRoute(tmpPath,&guideRouteHandle);
                if (GD_ERR_OK == res) {
                    GGUIDEROUTEINFO routeInfo = {0};
                    res = GDBL_GetGuideRouteInfo(guideRouteHandle, &routeInfo);
                    if (GD_ERR_OK == res) {
                        if (routeInfo.nRule != curRule) {
                            continue;
                        }
                        BOOL bContinue = NO;
                        for (int i = 0; i < 7; i ++) {
                            if (curRouteInfo.JourneyPoints[i].Coord.x != routeInfo.JourneyPoints[i].Coord.x || curRouteInfo.JourneyPoints[i].Coord.y != routeInfo.JourneyPoints[i].Coord.y) {
                                bContinue = YES;
                                break;
                            }
                            
                        }
                        if (bContinue) {
                            continue;
                        }
                        return YES;
                    }
                }
            }
        }
    }
    else{
        
        GPOI *journeyPoint = {0};
        res = GDBL_GetJourneyPoint(&journeyPoint);
        
        if (GD_ERR_OK == res) {
            int curRule = 0;
            
            NSArray *files = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:guideRoute_path error:nil];
            
            GDBL_GetParam(G_ROUTE_OPTION, &curRule);
            
            for (NSString *fileName in files) {
                char tmpPath[256] = {0};
                const char *mpath = [[NSString stringWithFormat:@"%@%@",guideRoute_path,fileName] UTF8String];
                strcpy(tmpPath, mpath);
                GHGUIDEROUTE guideRouteHandle = {0};
                res = GDBL_LoadGuideRoute(tmpPath,&guideRouteHandle);
                if (GD_ERR_OK == res) {
                    GGUIDEROUTEINFO routeInfo = {0};
                    res = GDBL_GetGuideRouteInfo(guideRouteHandle, &routeInfo);
                    if (GD_ERR_OK == res) {
                        if (routeInfo.nRule != curRule) {
                            continue;
                        }
                        BOOL bContinue = NO;
                        for (int i = 0; i < 7; i ++) {
                            NSLog(@"%@",[NSString chinaFontStringWithCString:journeyPoint[i].szName]);
                            NSLog(@"%@",[NSString chinaFontStringWithCString:routeInfo.JourneyPoints[i].szName]);
                            if (journeyPoint[i].Coord.x != routeInfo.JourneyPoints[i].Coord.x || journeyPoint[i].Coord.y != routeInfo.JourneyPoints[i].Coord.y) {
                                bContinue = YES;
                                break;
                            }
                            
                        }
                        if (bContinue) {
                            continue;
                        }
                        
                        return YES;
                    }
                }
            }
            
        }
    
    }
    
    
    return NO;
}

#pragma mark 删除收藏的路径(删除最后收藏的路径,删除指定索引的收藏路径,删除全部收藏路径)
/**********************************************************************
 * 函数名称: MW_deleteFavGuideRouteWithType
 * 功能描述: 删除收藏的路径(删除最后收藏的路径,删除指定索引的收藏路径,删除全部收藏路径)
 * 参    数:[IN] deleteType 删除类型：0 删除续航的路径 1 删除指定索引的收藏路径 2 删除全部收藏路径
 *			[IN] index 删除路径索引，只有当删除类型为1时才需传入相应值
 * 返 回 值: 成功返回YES, 失败返回NO
 * 其它说明: 文件名是绝对路径
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 **********************************************************************/
- (BOOL)MW_deleteFavGuideRouteWithType:(int)deleteType Index:(int)index
{
    switch (deleteType) {
        case 0://删除续航的路径
        {
           
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%s",route_path]])
            {
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%s",route_path] error:nil];
                
            }
            
            GDBL_ClearDetourRoad();//删除所有避让内容
            return YES;
        }
            break;
        case 1://删除指定索引的收藏路径
        {
            NSArray *files = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:guideRoute_path error:nil];
            if (files && [files count] > 0 && index < [files count]) {
                BOOL result = NO;
                if([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@%@",guideRoute_path,[files objectAtIndex:index]]])
                {
                    result = [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@%@",guideRoute_path,[files objectAtIndex:index]] error:nil];
                }
                if (result) {
                    return YES;
                }
            
            }
        }
            break;
        case 2://删除全部收藏路径
        {
            BOOL result = NO;
            if([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@",guideRoute_path]])
            {
                result = [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@",guideRoute_path] error:nil];
            }
            if (result)
                return YES;
        }
            break;
        default:
            break;
    }
    return NO;
}

#pragma mark 加载引导路径
/**********************************************************************
 * 函数名称: MW_GetFavoriteGuideRouteList
 * 功能描述: 该函数用于获取收藏的路径线的信息（起点名称，终点名称，总长度，总耗时）
 * 参    数:[OUT]  路径线列表
 *			
 * 返 回 值: 
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 **********************************************************************/
- (NSMutableArray *)MW_GetFavoriteGuideRouteList
{
    NSMutableArray *routeList = [[NSMutableArray alloc] init];
    
    NSArray *files = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:guideRoute_path error:nil];
    char tmpPath[256] = {0};
    
    GSTATUS res;
    
    for (NSString *fileName in files) {
        
        const char *mpath = [[NSString stringWithFormat:@"%@%@",guideRoute_path,fileName] UTF8String];
        strcpy(tmpPath, mpath);
        GHGUIDEROUTE guideRouteHandle = {0};
        
        res = GDBL_LoadGuideRoute(tmpPath,&guideRouteHandle);
        
        if (GD_ERR_OK == res) {
            
            GGUIDEROUTEINFO routeInfo = {0};
            GPATHSTATISTICLIST *stateInfoList = {0};
            GSTATUS result;
            
            result = GDBL_GetGuideRouteInfo(guideRouteHandle, &routeInfo);
            res = GDBL_GetPathStatisticInfo(guideRouteHandle, Gtrue, Gfalse, &stateInfoList);
            
            if (GD_ERR_OK == res && GD_ERR_OK == result) {
                GuideRouteFavItem *routeItem = [[GuideRouteFavItem alloc] init];
                
                routeItem.startName = [NSString chinaFontStringWithCString:routeInfo.JourneyPoints[0].szName];
                routeItem.desName = [NSString chinaFontStringWithCString:routeInfo.JourneyPoints[6].szName];
                routeItem.distance = stateInfoList->pPathStat->nTotalDis;
                routeItem.totalTime = stateInfoList->pPathStat->nTime;
                [routeList addObject:routeItem];
                [routeItem release];
            }
        }
    }
    
    return [routeList autorelease];
}
#pragma mark 加载收藏引导路径
/**********************************************************************
 * 函数名称: MW_LoadGuideRoute
 * 功能描述: 该函数用于加载引导路径
 * 参    数:[IN] loadType 加在类型：0 返回指定路径线句柄 1 加载续航路径线
            [IN] index 获取指定路径线句柄，只有当loadType类型为0才需要传入
 *			[OUT] guideRouteHandle 引导路径句柄
 * 返 回 值: 成功返回GD_ERR_OK, 失败返回对应出错码
 * 其它说明: 文件名是绝对路径,第二个参数传入gnull，则会把路线加入路线管理列表，否则不会加入路线管理列表，只返回句柄，通过句柄再去做相应的操作。
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 **********************************************************************/
-(BOOL)MW_LoadGuideRoute:(GHGUIDEROUTE *)guideRouteHandle Type:(int)loadType Index:(int)index
{
    
    GSTATUS res = GD_ERR_FAILED;
    char tmpPath[256] = {0};
    
    NSFileManager *fileManage = [NSFileManager defaultManager];
    NSArray *files = [fileManage subpathsOfDirectoryAtPath:guideRoute_path error:nil];
    
    
        if (loadType) {
            [[MWPreference sharedInstance] setValue:PREF_MAP_TMC_SHOW_OPTION Value:YES];//设置路径tmc
            strcpy(tmpPath, route_path);
            
            res = GDBL_LoadGuideRoute(tmpPath,guideRouteHandle);
            
        }
        else{
            if (files && [files count] > 0) {
                if (index > (int)(files.count - 1)) {
                    return NO;
                }
                NSString *fileName = files[index];
                const char *mpath = [[NSString stringWithFormat:@"%@%@",guideRoute_path,fileName] UTF8String];
                strcpy(tmpPath, mpath);
                
                res = GDBL_LoadGuideRoute(tmpPath,guideRouteHandle);
                
            }
        }
    
    if (GD_ERR_OK == res) {
        return YES;
    }
    return NO;
}

#pragma mark 保存引导路线
/**********************************************************************
 * 函数名称: MW_SaveGuideRoute
 * 功能描述: 该函数用于保存引导路线。
 * 参    数: [IN]guideRoute 引导路线句柄
             [IN] type 保持类型 0 收藏路线 1 续航保持路线
 * 返 回 值: 成功返回YES, 失败返回NO
 * 其它说明:
 **********************************************************************/
-(GSTATUS)MW_SaveGuideRoute:(GHGUIDEROUTE)guideRoute Type:(int)type
{
    char tmpPath[256] = {0};
   
    if (type) {
        GSTATUS res;
        strcpy(tmpPath, route_path);
        res = GDBL_SaveGuideRoute(guideRoute,tmpPath,1);
        NSLog(@"%d",res);
        return res;
        
    }
    else{
        NSError *myError;
        NSDictionary *DirectoryAttrib = [NSDictionary dictionaryWithObject:[NSNumber numberWithUnsignedLong:0777UL] forKey:NSFilePosixPermissions];
        
        if (![[NSFileManager defaultManager] fileExistsAtPath:guideRoute_path] ) {
            [[NSFileManager defaultManager] createDirectoryAtPath:guideRoute_path withIntermediateDirectories:YES attributes:DirectoryAttrib error:&myError];
        }
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"YYYYMMddhhmmss"];
        NSString *pathName = [NSString stringWithFormat:@"%@",[formatter stringFromDate: [NSDate date]]];
        [formatter release];
        
        const char *path = [[NSString stringWithFormat:@"%@%@.dat",guideRoute_path,pathName] UTF8String];
        strcpy(tmpPath,path);
        
        return GDBL_SaveGuideRoute(guideRoute,tmpPath,1);
        
    }
    
}

#pragma mark -
#pragma mark  路线详情相关======================================================================================
#pragma mark -

#pragma mark 获取路线详情列表(参数为路线的信息类型:0-转向ID 1-下路口距离和路口名称 2-转向ID图片 3-下路口距离 4-路口名称 5-路口ID 6-交通信息情况)
/**********************************************************************
 * 函数名称: MW_GetGuideRoadListInfoWithID
 * 功能描述: 获取路线详情列表
 * 参    数:[IN] ID:信息类别 0-转向ID 1-下路口距离和路口名称 2-转向ID图片 3-下路口距离 4-路口名称 5-路口ID 6-交通信息情况
 * 返 回 值: 返回相对应的数组信息
 * 其它说明:
 **********************************************************************/
- (NSArray *)MW_GetGuideRoadListInfoWithID:(NSInteger)ID {
    
	NSMutableArray *RoadListInfo = [[NSMutableArray alloc] init];
	
	GDBL_GetGuideRoadList(NULL,Gfalse, &ppGuideRoadList);
	
	switch (ID)
	{
		case 0://转向ID
		{
			for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++)
			{
				[RoadListInfo addObject:[NSString stringWithFormat:@"%d",ppGuideRoadList->pGuideRoadInfo[i].nTurnID]];
			}
		}
			break;
			
		case 1://下路口距离和路口名称
		{
			for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++)
			{
				NSString *tmp = [NSString chinaFontStringWithCString:ppGuideRoadList->pGuideRoadInfo[i].szCurRoadName];
				if ((ppGuideRoadList->pGuideRoadInfo[i].nNextDis)<1000)
				{
					[RoadListInfo addObject:[NSString stringWithFormat:@"%6dm      %@",(ppGuideRoadList->pGuideRoadInfo[i].nNextDis),tmp]];
				}
				else
				{
                    [RoadListInfo addObject:[NSString stringWithFormat:@"%.2fkm      %@",(ppGuideRoadList->pGuideRoadInfo[i].nNextDis)/1000.0,tmp]];
                }
            }
		}
			break;
			
		case 2://转向ID图片
		{
			for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++)
			{
				[RoadListInfo addObject:[self MW_GetTurnIconWithID:ppGuideRoadList->pGuideRoadInfo[i].nTurnID flag:1]];
			}
		}
			break;
			
		case 3://下路口距离
		{
			for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++)
			{
				if (ppGuideRoadList->pGuideRoadInfo[i].nNextDis < 1000)
				{
					[RoadListInfo addObject:[NSString stringWithFormat:@"%dm",ppGuideRoadList->pGuideRoadInfo[i].nNextDis]];
				}
				else
				{
					[RoadListInfo addObject:[NSString stringWithFormat:@"%.2fkm",(ppGuideRoadList->pGuideRoadInfo[i].nNextDis)/1000.0]];
				}
			}
		}
			break;
			
		case 4://路口名称
		{
			for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++)
			{
				NSString *tmp = [NSString chinaFontStringWithCString:ppGuideRoadList->pGuideRoadInfo[i].szCurRoadName];
				[RoadListInfo addObject:[NSString stringWithFormat:@"%@",tmp]];
			}
		}
			break;
        case 5://路口ID
        {
            for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++)
			{
				[RoadListInfo addObject:[NSNumber numberWithInt:ppGuideRoadList->pGuideRoadInfo[i].nID]];
                NSLog(@"%d",ppGuideRoadList->pGuideRoadInfo[i].nID);
			}
        }
        case 6://交通信息情况
        {
            for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++) {
                int nTrafficStatus = 0;
                // UI层只定义4个情况 1 畅通；2,3 缓行；4,5拥堵；6,7无数据
                if (ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=1) {
                    nTrafficStatus = 1;
                }else if(ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=3) {
                    nTrafficStatus = 2;
                }else if(ppGuideRoadList->pGuideRoadInfo[i].eTrafficStream<=5) {
                    nTrafficStatus = 3;
                }else{
                    nTrafficStatus = 4;
                }
                [RoadListInfo addObject:[NSNumber numberWithInt:nTrafficStatus]];
                //
                NSLog(@"%d",ppGuideRoadList->pGuideRoadInfo[i].nID);
            }
        }
            break;
		default:
			break;
	}
	
	return [RoadListInfo autorelease];
}

#pragma mark 避让道路(参数为索引值)
/**********************************************************************
 * 函数名称: MW_DetourRoadWithID
 * 功能描述: 避让道路
 * 参    数:[IN] index:避让道路索引值
 * 返 回 值: 成功返回YES, 失败返回NO
 * 其它说明:
 **********************************************************************/
- (BOOL)MW_DetourRoadWithID:(NSInteger)index {
    
    // 时间
    NSDate *dateStartTime = [[NSDate alloc] init];
    NSDate *dateEndTime = [[NSDate alloc] initWithTimeIntervalSinceNow:86400];// 一天24*60*60
    NSCalendar *chineseCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSUInteger CalendarFlags = NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit|NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;
    NSDateComponents* dcpStartTime = [chineseCalendar components:CalendarFlags fromDate:dateStartTime];
    NSDateComponents* dcpEndTime = [chineseCalendar components:CalendarFlags fromDate:dateEndTime];
    [dateStartTime release];
    [dateEndTime release];
    [chineseCalendar release];
    //
	GDETOURROADINFO pDetourRoad;
    GDBL_GetGuideRoadList(NULL,Gfalse, &ppGuideRoadList);
    
	pDetourRoad.eOption = GDETOUR_OPTION_FOREVER;
	pDetourRoad.nMeshRoadID = ppGuideRoadList->pGuideRoadInfo[index].nMeshRoadID;
    pDetourRoad.nMeshID = ppGuideRoadList->pGuideRoadInfo[index].nMeshID;
	strcpy(pDetourRoad.szRoadName, ppGuideRoadList->pGuideRoadInfo[index].szCurRoadName);
    // 开始时间
    pDetourRoad.StartTime.date.day = [dcpStartTime day];
    pDetourRoad.StartTime.date.month = [dcpStartTime month];
    pDetourRoad.StartTime.date.year = [dcpStartTime year];
    pDetourRoad.StartTime.time.hour = [dcpStartTime hour];
    pDetourRoad.StartTime.time.minute = [dcpStartTime minute];
    pDetourRoad.StartTime.time.second = [dcpStartTime second];
    // 结束时间
    pDetourRoad.EndTime.date.day = [dcpEndTime day];
    pDetourRoad.EndTime.date.month = [dcpEndTime month];
    pDetourRoad.EndTime.date.year = [dcpEndTime year];
    pDetourRoad.EndTime.time.hour = [dcpEndTime hour];
    pDetourRoad.EndTime.time.minute = [dcpEndTime minute];
    pDetourRoad.EndTime.time.second = [dcpEndTime second];
    
    GSTATUS nStatus = GDBL_AddDetourRoad(&pDetourRoad);
    if (nStatus == GD_ERR_OK) {
        return YES;
    }
    return FALSE;
    
}

#pragma mark 清空规避道路
/**********************************************************************
 * 函数名称: MW_ClearDetour
 * 功能描述: 清空规避道路
 * 参    数:
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
- (void)MW_ClearDetour
{
    GDBL_ClearDetourRoad();
}

#pragma mark 判断是否有规避道路
/**********************************************************************
 * 函数名称: MW_HaveDetour
 * 功能描述: 判断是否有规避道路
 * 参    数:
 * 返 回 值: YES 有, NO 无
 * 其它说明:
 **********************************************************************/
- (BOOL)MW_HaveDetour
{
    GDETOURROADLIST* pDetourRoadList=nil;
    GDBL_GetDetourRoadList(&pDetourRoadList);
    if (pDetourRoadList!=nil) {
        if (pDetourRoadList->nNumberOfDetourRoad>0) {
            return YES;
        }
    }
    return NO;
}

#pragma mark 避让指定范围内的道路id
/**********************************************************************
 * 函数名称: MW_DetourRoadIdFrom
 * 功能描述: 避让指定范围内的道路id
 * 参    数:
 * 返 回 值: 成功返回YES, 失败返回NO
 * 其它说明:
 **********************************************************************/
- (BOOL)MW_DetourRoadIdFrom:(NSInteger)nStart to:(NSInteger)nEnd
{
    // 时间
    NSDate *dateStartTime = [[NSDate alloc] init];
    NSDate *dateEndTime = [[NSDate alloc] initWithTimeIntervalSinceNow:86400];// 一天24*60*60
    NSCalendar *chineseCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSUInteger CalendarFlags = NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit|NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;
    NSDateComponents* dcpStartTime = [chineseCalendar components:CalendarFlags fromDate:dateStartTime];
    NSDateComponents* dcpEndTime = [chineseCalendar components:CalendarFlags fromDate:dateEndTime];
    [dateStartTime release];
    [dateEndTime release];
    [chineseCalendar release];
    //
    GDBL_GetGuideRoadList(NULL,TRUE, &ppGuideRoadList);
    GSTATUS nStatus = FALSE;
    // 添加判断，避免造成个数不对
    for (int i=0;i<=ppGuideRoadList->nNumberOfRoad-1;i++) {
        // 查看道路ID是否在start和end之间
        if (ppGuideRoadList->pGuideRoadInfo[i].nID>nEnd||ppGuideRoadList->pGuideRoadInfo[i].nID<nStart) {
            continue;
        }
        //
        GDETOURROADINFO pDetourRoad;
        pDetourRoad.eOption = GDETOUR_OPTION_TODAY;
        pDetourRoad.nMeshRoadID = ppGuideRoadList->pGuideRoadInfo[i].nMeshRoadID;
        pDetourRoad.nMeshID = ppGuideRoadList->pGuideRoadInfo[i].nMeshID;
        strcpy(pDetourRoad.szRoadName, ppGuideRoadList->pGuideRoadInfo[i].szCurRoadName);
        // 开始时间
        pDetourRoad.StartTime.date.day = (char)[dcpStartTime day];
        pDetourRoad.StartTime.date.month = (char)[dcpStartTime month];
        pDetourRoad.StartTime.date.year = (unsigned)[dcpStartTime year];
        pDetourRoad.StartTime.time.hour = (char)[dcpStartTime hour];
        pDetourRoad.StartTime.time.minute = (char)[dcpStartTime minute];
        pDetourRoad.StartTime.time.second = (char)[dcpStartTime second];
        // 结束时间
        pDetourRoad.EndTime.date.day = (char)[dcpEndTime day];
        pDetourRoad.EndTime.date.month = (char)[dcpEndTime month];
        pDetourRoad.EndTime.date.year = (unsigned)[dcpEndTime year];
        pDetourRoad.EndTime.time.hour = (char)[dcpEndTime hour];
        pDetourRoad.EndTime.time.minute = (char)[dcpEndTime minute];
        pDetourRoad.EndTime.time.second = (char)[dcpEndTime second];
        
        nStatus = GDBL_AddDetourRoad(&pDetourRoad);
    }
    if (nStatus!=GD_ERR_OK) {
        return FALSE;
    }
    return TRUE;
    
}

#pragma mark 判断车位在当前道路上
/**********************************************************************
 * 函数名称: MW_CarOnTheCurrentRoad
 * 功能描述: 判断车位在当前道路上
 * 参    数:
 * 返 回 值: YES 是, NO 不是
 * 其它说明:
 **********************************************************************/
- (BOOL)MW_CarOnTheCurrentRoad:(NSInteger)ID
{
    
    GDBL_GetGuideRoadList(NULL,TRUE, &ppGuideRoadList);
    if(ppGuideRoadList->nNumberOfRoad>ID)
    {
        if(ppGuideRoadList->pGuideRoadInfo[ID].eFlag&0x04)
        {
            return  YES;
        }
    }
    return NO;
}

#pragma mark 获取当前车位的道路id
/**********************************************************************
 * 函数名称: MW_GetRoadIDCarPositon
 * 功能描述: 获取当前车位的道路id
 * 参    数:
 * 返 回 值: 道路id
 * 其它说明:
 **********************************************************************/
- (int) MW_GetRoadIDCarPositon
{
    GSTATUS nStatus = GDBL_GetGuideRoadList(NULL,TRUE, &ppGuideRoadList);
    if (nStatus == GD_ERR_OK) {
        for (int i=0; i<ppGuideRoadList->nNumberOfRoad; i++) {
            if(ppGuideRoadList->pGuideRoadInfo[i].eFlag&0x04)
            {
                return  ppGuideRoadList->nNumberOfRoad-1-i;
            }
        }
    }
    return 0;
}

#pragma mark 获取行程点(参数:0:起点6:终点)
/**********************************************************************
 * 函数名称: MW_GetJourneyPointWithID
 * 功能描述: 获取行程点(参数:0:起点6:终点)
 * 参    数:
 * 返 回 值: plugin_PoiNode类型行程点
 * 其它说明:
 **********************************************************************/
- (plugin_PoiNode *)MW_GetJourneyPointWithID:(NSInteger)ID {
	
	plugin_PoiNode *node = [[plugin_PoiNode alloc] init];
	
	GPOI *ppJourneyPoint;
	GDBL_GetJourneyPoint(&ppJourneyPoint);
	
	node.lLon = ppJourneyPoint[ID].Coord.x;
	node.lLat = ppJourneyPoint[ID].Coord.y;
	node.lCategoryID = ppJourneyPoint[ID].lCategoryID;
	node.lDistance = ppJourneyPoint[ID].lDistance;
	node.lMatchCode = ppJourneyPoint[ID].lMatchCode;
	node.lHilightFlag = ppJourneyPoint[ID].lHilightFlag;
	node.lAdminCode = ppJourneyPoint[ID].lAdminCode;
	node.lPoiId = ppJourneyPoint[ID].lPoiId;
	node.siELonOff = ppJourneyPoint[ID].siELonOff;
	node.siELatOff = ppJourneyPoint[ID].siELatOff;
	node.szName = [NSString chinaFontStringWithCString:ppJourneyPoint[ID].szName];
	node.szAddr = [NSString chinaFontStringWithCString:ppJourneyPoint[ID].szAddr];
	node.szTel = [NSString chinaFontStringWithCString:ppJourneyPoint[ID].szTel];
	node.lPoiIndex = ppJourneyPoint[ID].lPoiIndex;
	node.ucFlag = ppJourneyPoint[ID].ucFlag;
	node.ucNodeType = ppJourneyPoint[ID].Reserved;
	node.usNodeId = ppJourneyPoint[ID].usNodeId;
	
	return [node autorelease];
}

#pragma mark 删除指定行程点
/**********************************************************************
 * 函数名称: MW_DelJourneyPoint
 * 功能描述: 删除指定行程点
 * 参    数:
 * 返 回 值: 成功返回0, 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
-(int)MW_DelJourneyPoint:(GJOURNEYPOINTTYPE)type
{
    return GDBL_DelJourneyPoint(type);
}


/**********************************************************************
 * 函数名称: releaseRgba
 * 功能描述: 释放内存
 * 参    数:
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
void releaseRgba(void *info, const void *data, size_t size)
{
    free((void*)data);
}

#pragma mark 获取转向ID的图片(参数为转向ID)
/**********************************************************************
 * 函数名称: MW_GetTurnIconWithID
 * 功能描述: 获取转向ID的图片(参数为转向ID)
 * 参    数:
 * 返 回 值: 图片
 * 其它说明:
 **********************************************************************/
- (UIImage *)MW_GetTurnIconWithID:(NSInteger)ID flag:(NSInteger)nflag{
    
	GBITMAP *ppBitmap;
	GSTATUS res =  GDBL_GetTurnIcon(ID, nflag, &ppBitmap);
	if(GD_ERR_OK != res || ppBitmap->pData == NULL || ppBitmap->pAlpha == NULL)
    {
        return nil;
    }
    
    char *argb = (char *)LoadBMP565(ppBitmap->pData, ppBitmap->cxWidth * ppBitmap->cyHeight *2, ppBitmap->pAlpha);
    
	int bitsPerComponent = 8;
	int bitsPerPixel = 32;
	int bytesPerRow = ppBitmap->cxWidth * 4;
	CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
	CGBitmapInfo bitmapInfo = kCGImageAlphaLast;
	CGColorRenderingIntent renderingIntent = kCGRenderingIntentDefault;
	
	CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, argb, ppBitmap->cxWidth*ppBitmap->cyHeight, releaseRgba);
    CGImageRef   imageRef = CGImageCreate(ppBitmap->cxWidth, ppBitmap->cyHeight, bitsPerComponent, bitsPerPixel, bytesPerRow,  colorSpaceRef, bitmapInfo, provider, NULL, true, renderingIntent);
	// then make the uiimage from that
	UIImage *myImage = [UIImage imageWithCGImage:imageRef];
    
	CGImageRelease(imageRef);
    CGColorSpaceRelease(colorSpaceRef);
    CGDataProviderRelease(provider);
    //free(argb);
    
	return myImage;
}

#pragma mark 查看路口(参数为索引值)
/**********************************************************************
 * 函数名称: MW_ViewCrossWithID
 * 功能描述: 查看路口(参数为索引值)
 * 参    数:
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
- (void)MW_ViewCrossWithID:(int)ID {
	
	GDBL_ViewCross(ID);
}

#pragma mark -
#pragma mark 设置:起点－终点-途经点==================================================================
#pragma mark 

#pragma mark - 设起点(包含有无数据判断，上层可直接调用此接口)
/**********************************************************************
 * 函数名称: MW_SetStart
 * 功能描述: 设起点
 * 参    数:
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_SetStartWithLon:(int)lon Lat:(int)lat
{
    if ([ANParamValue sharedInstance].isPath) {
        [GDBL_UserBehaviorCountNew shareInstance].figureMapSetSatar_InPath ++;
    }
    else{
        [GDBL_UserBehaviorCountNew shareInstance].figureMapSetSatar ++;
    }
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        if ([mapDataManage getMapDataType] == 2)
        {//是分城市数据
            if ( [[ANOperateMethod sharedInstance] GMD_checkIsExistData:0 flag:0] == 0 && [Plugin_OnLineMapUtility sharedInstance].isAlertMOVEAlert)
            {
                GDAlertView *alertView=[[[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Main_NoDataPerformed",@"Main")] autorelease];
                [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeCancel handler:nil];
                [alertView show];
                
                return;
            }
        }
        
    }
    [self MW_SetStartingPointWithLon:lon Lat:lat];
}
#pragma mark 设起点（以当前地图中心点为起点）
/**********************************************************************
 * 函数名称: MW_SetStartingPoint
 * 功能描述: 设起点（以当前地图中心点为起点）
 * 参    数:
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
- (void)MW_SetStartingPoint
{
	if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:0];
    }
    else
    {
        
        //获取地图中心信息
        GMAPCENTERINFO mapinfo = {0};
        [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
        
        GDBL_ClearJourneyPoint();
        GPOI PointInfo = {0};
        PointInfo.Coord = mapinfo.CenterCoord;
        
        GSTATUS res;
        m_journeyType = GJOURNEY_START;
        res = GDBL_AddJourneyPoint(GJOURNEY_START, &PointInfo);
        if (GD_ERR_OK==res)
        {
            [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData = 0; //删除网络地图中的路径信息
            if ([[ANParamValue sharedInstance] isPath])
            {
                GSTATUS res;
                res = GDBL_StopGuidance();
                
                if (GD_ERR_OK==res)
                {
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
                }
            }
            [[MWMapOperator sharedInstance] MW_AdjustCar:GMAP_VIEW_TYPE_MAIN Gcoord:mapinfo.CenterCoord Angle:0];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_BEGINPOINT object:nil];
            
            
        }
        else
        {
            if ([ANParamValue sharedInstance].netWorkMap)
            {
                if ([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:PointInfo.Coord.x Lat:PointInfo.Coord.y] != 0
                    && ![Plugin_OnLineMapUtility sharedInstance].isAlertMOVEAlert) //本地地图下，判断起点终点是否都有数据
                {
                    [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:0];
                    return;
                }
            }
            DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
            msg.flag = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_INVALIDPOSITION object:msg];
            [msg release];
        }
    }
	
    
}

#pragma mark 设起点（查图界面）
/**********************************************************************
 * 函数名称: MW_SetStartingPointWithLon:(int)lon Lat:(int)lat
 * 功能描述: 设起点（查图界面）
 * 参    数: lon:经度 lat:纬度
 * 返 回 值: YES:成功 NO:失败
 * 其它说明:
 **********************************************************************/
- (BOOL)MW_SetStartingPointWithLon:(int)lon Lat:(int)lat {
    // 公交下
    GSTATUS nStatus;
	
	//获取地图中心信息
    GPOI PointInfo = {0};
    if (lon==0 && lat==0)
    {// 地图中心
        GMAPCENTERINFO mapinfo = {0};
        [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
        PointInfo.Coord = mapinfo.CenterCoord;
    }
    else
    {
        GCOORD Coord = {0};
        Coord.x = lon;
        Coord.y = lat;
        PointInfo.Coord = Coord;
    }
        
	if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:0 andPOI:PointInfo];
        return YES;
    }
    else
    {
        m_journeyType = GJOURNEY_START;
        nStatus = GDBL_AddJourneyPoint(GJOURNEY_START, &PointInfo);
        if (GD_ERR_OK==nStatus)
        {
            [Plugin_OnLineMapUtility sharedInstance].isTBTRouteData = 0; //删除网络地图中的路径信息
            if ([[ANParamValue sharedInstance] isPath])
            {
                GDBL_StopGuidance();
                GDBL_ClearJourneyPoint();
                GDBL_ClearDetourRoad();//删除所有避让内容
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
            }
            [[MWMapOperator sharedInstance] MW_AdjustCar:GMAP_VIEW_TYPE_MAIN Gcoord:PointInfo.Coord Angle:0];
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_BEGINPOINT object:nil];
        }
        else
        {
            if ([ANParamValue sharedInstance].netWorkMap)
            {
                if ([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:PointInfo.Coord.x Lat:PointInfo.Coord.y] != 0
                    && ![Plugin_OnLineMapUtility sharedInstance].isAlertMOVEAlert) //本地地图下，判断起点终点是否都有数据
                {
                    [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:0 andPOI:PointInfo];
                    return YES;
                }
            }
            DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
            msg.flag = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_INVALIDPOSITION object:msg];
            [msg release];
        }
    }
	
    // 返回值
    BOOL bReturn = FALSE;
    if (nStatus == GD_ERR_OK) {
        bReturn = TRUE;
    }
    return bReturn;
}

#pragma mark 缓存终点信息(配合GMD_SetDesWithType使用)
/**********************************************************************
 * 函数名称: MW_CacheDesPOI
 * 功能描述: 缓存终点信息(配合GMD_SetDesWithType使用)
 * 参    数: endingPOI：终点信息
 * 返 回 值: 
 * 其它说明:
 **********************************************************************/
- (void)MW_CacheDesPOI:(GPOI)endingPOI
{
    strcpy(desPOI.szName, endingPOI.szName);
    strcpy(desPOI.szAddr, endingPOI.szAddr);
    desPOI.Coord.x = endingPOI.Coord.x;
    desPOI.Coord.y = endingPOI.Coord.y;
    desPOI.siELonOff = endingPOI.siELonOff;
    desPOI.siELatOff = endingPOI.siELatOff;
    desPOI.lCategoryID = endingPOI.lCategoryID;
}

#pragma mark 设终点-查图下－需要传入poi(注：调用此接口需先调用MW_CacheDesPOI缓存终点信息)
/**********************************************************************
 * 函数名称: MW_SetDesWithType
 * 功能描述: 设终点-查图下－需要传入poi(注：调用此接口需先调用MW_CacheDesPOI缓存终点信息)
 * 参    数: type：6-终点 1－5为途经点
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void) MW_SetDesWithType:(int)type
{
    
    GCARINFO carinfo = {0};
    GDBL_GetCarInfo(&carinfo);
    
    GPOI pointInfo = {0};
    pointInfo.Coord.x = desPOI.Coord.x;
    pointInfo.Coord.y = desPOI.Coord.y;
    pointInfo.siELonOff = desPOI.siELonOff;
    pointInfo.siELatOff = desPOI.siELatOff;
    pointInfo.lCategoryID = desPOI.lCategoryID;
    strcpy(pointInfo.szName, desPOI.szName);
    strcpy(pointInfo.szAddr, desPOI.szAddr);
    
    BOOL netRoute = NO;
    if (![Plugin_OnLineMapUtility sharedInstance].isAlertMOVEAlert  && [ANParamValue sharedInstance].netWorkMap) //本地地图下，判断起点终点是否都有数据
    {
        if ([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:carinfo.Coord.x Lat:carinfo.Coord.y] != 0
            )
        {
            netRoute = YES;
        }
        else
        {
            if ([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:pointInfo.Coord.x Lat:pointInfo.Coord.y] != 0)
            {
                netRoute = YES;
            }
        }
    }
    
    if (netRoute)
    {
        [Plugin_OnLineMapUtility sharedInstance].isSaveLocalDes = YES;
        [[Plugin_OnLineMapUtility sharedInstance] NET_SetEndingPOI:desPOI];
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:type andPOI:pointInfo];
    }
    else
    {
        if (type == 6) {
            GDBL_ClearJourneyPoint();
        }
        
        GSTATUS res;
        m_journeyType = type;
        res = GDBL_AddJourneyPoint(type, &pointInfo);
        
        if (res == GD_ERR_OK)
        {
            [MWPoiOperator collectPoiWith:GFAVORITE_CATEGORY_HISTORY icon:GFAVORITE_ICON_HISTORY poi:pointInfo];
            if (isSelected )
            {
                GDBL_StopGuidance();//每次设终点计算前都删除旧路线
                GDBL_ClearDetourRoad();//删除所有避让内容
                [self MW_StartRouteCalculation:NO];
            }
        }
        else
        {//路线演算失败
            NSArray* param=[[NSArray alloc] initWithObjects:[NSNumber numberWithInt:0],[NSNumber numberWithInt:1],nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STARTTODEMO2 object:param];
            [param release];
        }

        
    }
	
}

#pragma mark 设终点-获取地图中心点(参数mainID:为终点类型)
/**********************************************************************
 * 函数名称: MW_SetDesPointWithMainID
 * 功能描述: 设终点-获取地图中心点(参数mainID:为终点类型)
 * 参    数: mainID：终点类型
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_SetDesPointWithMainID:(int)mainID
{
    if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData != 0 && mainID != 6)//路径为网络路径时设途径点
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:mainID];
        return;
    }
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:mainID];
    }
    else
    {
        GDBL_StopAllRecognizeEvent();
        //获取地图中心信息
        GMAPCENTERINFO mapinfo = {0};
        [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
        
        if ([ANParamValue sharedInstance].netWorkMap)
        {
            GCARINFO carinfo = {0};
            GDBL_GetCarInfo(&carinfo);
            if (([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:carinfo.Coord.x Lat:carinfo.Coord.y] != 0
                 || [[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:mapinfo.CenterCoord.x Lat:mapinfo.CenterCoord.y] != 0)
                && ![Plugin_OnLineMapUtility sharedInstance].isAlertMOVEAlert) //本地地图下，判断起点终点是否都有数据
            {
                [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:mainID];
                return;
            }
        }
        
        GPOI PointInfo = {0};
        PointInfo.Coord = mapinfo.CenterCoord;
        strcpy(PointInfo.szName, mapinfo.szRoadName);
        
        
        if (mainID == 6) {
            GDBL_ClearJourneyPoint();
        }
        GSTATUS res;
        m_journeyType = mainID;
        res = GDBL_AddJourneyPoint(mainID, &PointInfo);
		[[ANParamValue sharedInstance] setAddHistory:YES];
		[[ANDataSource sharedInstance] GetNearPOI:GMAP_VIEW_TYPE_MAIN];
        
        if (res == GD_ERR_OK)
        {
            [MWPoiOperator collectPoiWith:GFAVORITE_CATEGORY_HISTORY icon:GFAVORITE_ICON_HISTORY poi:PointInfo];
            if (isSelected)
            {
                GDBL_StopGuidance();//每次设终点计算前都删除旧路线
                GDBL_ClearDetourRoad();//删除所有避让内容
                [self MW_StartRouteCalculation:NO];
            }
        }
        else
        {
            DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
            msg.flag = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_INVALIDPOSITION object:msg];
            [msg release];
        }
    }
}

#pragma mark 设终点-查图下(需要保存点的名称)公交设终点
/**********************************************************************
 * 函数名称: MW_SetDesPointWithMainID
 * 功能描述: 设终点-查图下(需要保存点的名称)公交设终点
 * 参    数: mainID：终点类型 lon:经度 lat:纬度 roadName:道路名
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_SetDesPointWithMainID:(int)mainID
                             POI:(GPOI )PointInfo
{
	GCARINFO carInfo = {0};
    GDBL_GetCarInfo(&carInfo);
    
    GCOORD desCoord;
    desCoord.x = PointInfo.Coord.x;
    desCoord.y = PointInfo.Coord.y;
    
    if (![Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        if ([mapDataManage getMapDataType] == 2)
        {//是分城市数据
            int adminCode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:PointInfo.Coord.x Lat:PointInfo.Coord.y];
            if ( [[ANOperateMethod sharedInstance] GMD_checkIsExistData:adminCode flag:1] == 0 && [Plugin_OnLineMapUtility sharedInstance].isAlertMOVEAlert)
            {
                GDAlertView *alertView=[[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Main_NoDataForCity", @"Main")] ;
                [alertView addButtonWithTitle:STR(@"Main_OK", @"Main") type:GDAlertViewButtonTypeCancel handler:nil];
                [alertView show];
                [alertView release];
                
                return;
            }
        }
        
    }

    if ([[ANDataSource sharedInstance] GMD_CalculateDistanceWithStart:carInfo.Coord  Des:desCoord] < 100)
    {
        
        [POICommon showAutoHideAlertView:STR(@"Main_tooShort", @"Main") showTime:2.0f];
        return;
    }
    
	GCOORD Coord = {0};
	Coord.x = PointInfo.Coord.x;
	Coord.y = PointInfo.Coord.y;
    
   
    
    BOOL netRoute = NO;
    if (![Plugin_OnLineMapUtility sharedInstance].isAlertMOVEAlert && [ANParamValue sharedInstance].netWorkMap) //本地地图下，判断起点终点是否都有数据
    {
        if ([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:carInfo.Coord.x Lat:carInfo.Coord.y] != 0
            )
        {
            netRoute = YES;
        }
        else
        {
            if ([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:Coord.x Lat:Coord.y] != 0)
            {
                netRoute = YES;
            }
        }
    }
    
    if (netRoute)
    {
        
        [Plugin_OnLineMapUtility sharedInstance].isSaveLocalDes = YES;
        [[Plugin_OnLineMapUtility sharedInstance] NET_SetEndingPOI:PointInfo];
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:mainID andPOI:PointInfo];
    }
    else
    {
        
        if (mainID == 6) {
            GDBL_ClearJourneyPoint();
        }
        
        GSTATUS res;
        m_journeyType = mainID;
        res = GDBL_AddJourneyPoint(mainID, &PointInfo);
        if (res == GD_ERR_OK)
        {
            
            [MWPoiOperator collectPoiWith:GFAVORITE_CATEGORY_HISTORY icon:GFAVORITE_ICON_HISTORY poi:PointInfo];
            if (isSelected )
            {
                GDBL_StopGuidance();//每次设终点计算前都删除旧路线
                GDBL_ClearDetourRoad();//删除所有避让内容
                [self MW_StartRouteCalculation:NO];
            }
        }
        else
        {//路线演算失败
            NSArray* param=[[NSArray alloc] initWithObjects:[NSNumber numberWithInt:0],[NSNumber numberWithInt:1],nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STARTTODEMO2 object:param];
            [param release];
        }

    }
	
	
}

#pragma mark 设终点移图-点的详情界面(主要为了保存点的名称)
/**********************************************************************
 * 函数名称: MW_SetDesAndMoveMapWithName
 * 功能描述: 设终点移图-点的详情界面(主要为了保存点的名称)
 * 参    数: name：poi名称 lon:经度 lat:纬度 
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_SetDesAndMoveMapWithName:(char *)name Lon:(int)lon Lat:(int)lat
{
    
	GSTATUS res;
    GMOVEMAP moveMap;
    moveMap.eOP = MOVEMAP_OP_GEO_DIRECT;
    moveMap.deltaCoord.x = lon;
    moveMap.deltaCoord.y = lat;
    res = [[MWMapOperator sharedInstance] MW_MoveMapView:GMAP_VIEW_TYPE_MAIN TypeAndCoord:&moveMap];
    
	[[MWMapOperator sharedInstance] MW_SetMapOperateType:5];
    
	if (GD_ERR_OK==res)
	{
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_MOVEMAP object:nil];
    }
    
}

#pragma mark 设终点（多途径点）
/**********************************************************************
 * 函数名称: MW_wayPointCalcRoute
 * 功能描述: 设终点(多途径点)
 * 参    数: pointArray 行程点数组
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (GSTATUS) MW_wayPointCalcRoute:(NSMutableArray *)pointArray
{
    int arrayCount = pointArray ? pointArray.count : 0;
    for (int i = 0 ; i < arrayCount ; i++) {
        MWPoi *tmpPOI = [pointArray objectAtIndex:i];
        for (int j = i+1; j < arrayCount ; j++) {
            MWPoi *_tmpPOI = [pointArray objectAtIndex:j];
            if (tmpPOI.longitude == _tmpPOI.longitude && tmpPOI.latitude == _tmpPOI.latitude && _tmpPOI.longitude != 0 && _tmpPOI.latitude != 0 && !((arrayCount > 2) && (i == 0) && (j == arrayCount - 1))) {
                [POICommon showAutoHideAlertView:STR(@"Route_calcFail", @"RouteOverview")];
                return GD_ERR_INVALID_PARAM;
            }
        }
    }
    if (!pointArray || pointArray.count == 0) {
        return GD_ERR_INVALID_PARAM;
    }
    NSMutableArray *_arrayTableData = [NSMutableArray arrayWithArray:pointArray];
    //没有输入起点
    if(((MWPoi *)[_arrayTableData objectAtIndex:0]).latitude == 0
       && ((MWPoi *)[_arrayTableData objectAtIndex:0]).longitude == 0)
    {
        GDAlertView *alertView=[[[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Main_inputStart", @"Main")] autorelease];
        [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeCancel handler:nil];
        [alertView show];
        
        return GD_ERR_INVALID_PARAM;
    }
    //没有输入终点
    if(((MWPoi *)[_arrayTableData lastObject]).latitude == 0
       && ((MWPoi *)[_arrayTableData lastObject]).longitude == 0)
    {
        GDAlertView *alertView=[[[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Main_inputDes", @"Main")] autorelease];
        [alertView addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeCancel handler:nil];
        [alertView show];
        return GD_ERR_INVALID_PARAM;
    }
    //每次计算前，删除所有的点
    GDBL_ClearJourneyPoint();
    GSTATUS res;
    GPOI PointInfo = {0};
    
    [MWPoiOperator MWPoiToGPoi:((MWPoi *)[_arrayTableData objectAtIndex:0]) GPoi:&PointInfo];
    
    
    int admincode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:PointInfo.Coord.x
                                                                    Lat:PointInfo.Coord.y];
    //设起点
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView ||
        ([ANParamValue sharedInstance].isUseNETMap
         && [[ANOperateMethod sharedInstance] GMD_checkIsExistData:admincode flag:1] == 0) )//网络地图
    {
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:0 andPOI:PointInfo];
        
    }
    else
    {
        m_journeyType = GJOURNEY_START;
        res = GDBL_AddJourneyPoint(GJOURNEY_START, &PointInfo);
        
        if(res != GD_ERR_OK)
        {
            NSLog(@"----------起点路径添加失败");
            [POICommon showAutoHideAlertView:STR(@"Route_calcFail", @"RouteOverview")];
            return GD_ERR_FAILED;
        }
        else
        {
            [[MWMapOperator sharedInstance] MW_AdjustCar:GMAP_VIEW_TYPE_MAIN Gcoord:PointInfo.Coord Angle:0];
        }
        
        //添加途径点
        for (int i = 1 ; i < _arrayTableData.count-1; i++) {
            if(((MWPoi *)[_arrayTableData objectAtIndex:i]).latitude != 0
               && ((MWPoi *)[_arrayTableData objectAtIndex:i]).longitude != 0)
            {
                GPOI wayPointInfo = {0};
                
                [MWPoiOperator MWPoiToGPoi:((MWPoi *)[_arrayTableData objectAtIndex:i]) GPoi:&wayPointInfo];
                
                //设途经点
                m_journeyType = (GJOURNEYPOINTTYPE)i;
                res = GDMID_AddJourneyPoint(i, &wayPointInfo);
                
                if(res != GD_ERR_OK)
                {
                    NSLog(@"----------途经点***%d***路径添加失败",i);
                    [POICommon showAutoHideAlertView:STR(@"Route_calcFail", @"RouteOverview")];
                    return GD_ERR_FAILED;
                }
            }
        }
        
    }
    
    //设终点
    GPOI desPointInfo = {0};
    
    [MWPoiOperator MWPoiToGPoi:((MWPoi *)[_arrayTableData lastObject]) GPoi:&desPointInfo];
    
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView ||
        ([ANParamValue sharedInstance].isUseNETMap
         && [[ANOperateMethod sharedInstance] GMD_checkIsExistData:admincode flag:1] == 0) )
    {
        [Plugin_OnLineMapUtility sharedInstance].isSaveLocalDes = YES;
        
        
        
        [[Plugin_OnLineMapUtility sharedInstance] NET_SetEndingPOI:desPointInfo];
        [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:6 andPOI:desPointInfo];
    }
    else
    {
        
        if ([ANParamValue sharedInstance].netWorkMap)
        {
            GCARINFO carinfo = {0};
            GDBL_GetCarInfo(&carinfo);
            if (([[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:carinfo.Coord.x Lat:carinfo.Coord.y] != 0
                 || [[ANOperateMethod sharedInstance] GMD_CheckExistDataWithLon:desPointInfo.Coord.x Lat:desPointInfo.Coord.y] != 0)
                && ![Plugin_OnLineMapUtility sharedInstance].isAlertMOVEAlert) //本地地图下，判断起点终点是否都有数据
            {
                [Plugin_OnLineMapUtility sharedInstance].isSaveLocalDes = YES;
                
                [[Plugin_OnLineMapUtility sharedInstance] NET_SetEndingPOI:desPointInfo];
                [[Plugin_OnLineMapUtility sharedInstance] SetPointWithType:6 andPOI:desPointInfo];
                return GD_ERR_OK;
            }
        }
        m_journeyType = GJOURNEY_GOAL;
        res = GDMID_AddJourneyPoint(GJOURNEY_GOAL, &desPointInfo);
        if(res == GD_ERR_OK)
        {
            if (isSelected )
            {
                GDBL_StopGuidance();//每次设终点计算前都删除旧路线
                GDBL_ClearDetourRoad();//删除所有避让内容
                [self MW_StartRouteCalculation:NO];
                return GD_ERR_OK;
            }
        }
        else
        {
            NSLog(@"----------终点路径添加失败");
            [POICommon showAutoHideAlertView:STR(@"Route_calcFail", @"RouteOverview")];
            return GD_ERR_FAILED;
        }
    }
    
        
    return GD_ERR_OK;
    
}
#pragma mark 途径点管理
/**********************************************************************
 * 函数名称: MW_WayPointManagerWithID
 * 功能描述: 途径点管理
 * 参    数: ID:操作类型 index:索引 pointObject:途径点信息
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (id)MW_WayPointManagerWithID:(NSInteger)ID Index:(NSInteger)index Object:(plugin_PoiNode *)pointObject
{
	switch (ID)
	{
		case 0://清空途径点信息
		{
			wayPoint = index;
			
			if (index==4)
			{
				wayPoint = 6;
			}
			
			if (index==10)
			{
				for (int i=0; i<10; i++)
				{
					GPOI tmp = {0};
					wayPointNode[i] = tmp;
				}
                
                if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData != 0)
                {
                    OnLinePOI poi = {0};
                    for (int i = 0; i < 7; i++)
                    {
                        poi = [[Plugin_OnLineMapUtility sharedInstance].m_onLineMapView Net_GetPoint:i];
                        GPOI gpoi = {0};
                        gpoi.Coord.x = poi.coord.longitude * 1000000.0;
                        gpoi.Coord.y = poi.coord.latitude * 1000000.0;
                        if (poi.coord.latitude != 0 && poi.coord.latitude != 0)
                        {
                            if (strlen(poi.name) > 0)
                            {
                                strcpy(gpoi.szName, poi.name);
                            }
                            else
                            {
                                
                                strcpy(gpoi.szName, NSSTRING_TO_CSTRING(STR(@"Main_unNameRoad", @"Main"))) ;
                            }
                            
                        }
                        
                        wayPointNode[i] = gpoi;
                    }
                }
                else
                {
                    GPOI *ppJourneyPoint;
                    GDBL_GetJourneyPoint(&ppJourneyPoint);
                    
                    GCARINFO pCarInfo;
                    GDBL_GetCarInfo(&pCarInfo);
                    strcpy(ppJourneyPoint[0].szName, pCarInfo.szRoadName);
                    
                    for (int i = 0; i < 7; i++)
                    {
                        wayPointNode[i] = ppJourneyPoint[i];
                        NSLog(@"%s",ppJourneyPoint[i].szName);
                    }
                }
				
			}
		}
			break;
			
		case 1://设置点
		{
			wayPointNode[wayPoint].Coord.x = pointObject.lLon;
			wayPointNode[wayPoint].Coord.y = pointObject.lLat;
			strcpy(wayPointNode[wayPoint].szName, NSSTRING_TO_CSTRING(pointObject.szName));
		}
			break;
			
		case 2://确认
		{
			[[MWGuideOperator sharedInstance] MW_GuidanceOperateWithMainID:1 GuideHandle:NULL];
			wayPoint = 10;
            
            if(wayPointNode[1].Coord.x == 0 )//主要为了把中途点往前面移，不然会导致路线演算失败
            {
                wayPointNode[1] = wayPointNode[2];
                wayPointNode[2] = wayPointNode[3];
                memset(& wayPointNode[3], 0x0, sizeof(GPOI));
                if (wayPointNode[1].Coord.x == 0)
                {
                    wayPointNode[1] = wayPointNode[2];
                    memset(& wayPointNode[2], 0x0, sizeof(GPOI));
                }
            }
            
            
            int count = 0;
            BOOL isNet = NO;
			for (int i = 0; i < 7; i++)
			{
				GSTATUS res = -1;
                if (wayPointNode[i].Coord.x != 0 && wayPointNode[i].Coord.y != 0)
                {
                    if ([[ANDataSource sharedInstance] GMD_GetCurDrawMapViewTypeWithLon:wayPointNode[i].Coord.x Lat:wayPointNode[i].Coord.y])
                    {
                        isNet = YES;
                        break;
                    }
                    [MWGuideOperator sharedInstance].m_journeyType =  (GJOURNEYPOINTTYPE)i;
                    res = GDBL_AddJourneyPoint((GJOURNEYPOINTTYPE)i, &wayPointNode[i]);
                }
                
                NSLog(@"res =%d %d %d",res,wayPointNode[i].Coord.x,wayPointNode[i].Coord.y);
                if (i == 0 && res == GD_ERR_OK)
                {
                    GDBL_AdjustCar(wayPointNode[i].Coord, 0);
                }
			}
            if (isNet)
            {
                OnLinePOI coord[7] = {0};
                for (int i = 0; i < 7; i++)
                {
                    coord[count].coord.longitude = (double)wayPointNode[i].Coord.x/1000000.0;
                    coord[count].coord.latitude = (double)wayPointNode[i].Coord.y/1000000.0;
                    strcpy(coord[count].name, wayPointNode[i].szName);
                    count++;
                }
                [[Plugin_OnLineMapUtility sharedInstance] SetPassByWithCoord:coord Count:count];
                return [NSNumber numberWithBool:NO];
            }
		}
			break;
			
		case 3://删除
		{
			GPOI tmp = {0};
			if (index==4)
			{
				index = 6;
			}
			wayPointNode[index] = tmp;
		}
			break;
			
		case 4://名称
		{
			return [NSString chinaFontStringWithCString:wayPointNode[index].szName];
		}
			break;
        case 5://经纬度
		{
            NSDictionary *tmp = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:wayPointNode[index].Coord.x],@"lon",[NSNumber numberWithInt:wayPointNode[index].Coord.y],@"lat",nil];
            
			return tmp;
		}
			break;
			
		default:
		{
			
		}
			break;
	}
	
	return [NSNumber numberWithBool:YES];
}

- (void)MyalertView:(NSString *)titletext canceltext:(NSString *)mycanceltext othertext:(NSString *)myothertext alerttag:(int)mytag
{
	
	UIAlertView *Myalert;
	
	Myalert = [[UIAlertView alloc] initWithTitle:titletext
									     message:nil
										delegate:self
							   cancelButtonTitle:mycanceltext
							   otherButtonTitles:myothertext,nil];
	
	Myalert.tag = mytag;
	[Myalert show];
	[Myalert release];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (alertView.tag)
    {
        case 1:
            isChooseRoad = NO;
            switch (buttonIndex)
        {
            case 0:
                isSelectedNormal = YES;
                break;
            case 1:
                isSelectedNormal = NO;
                break;
            default:
                break;
        }
            isSelected = YES;
            plugin_PoiNode *node = [self MW_GetJourneyPointWithID:m_journeyType];
            
            GPOI PointInfo = {0};
            PointInfo.Coord.x = node.lLon;
            PointInfo.Coord.y = node.lLat;
            PointInfo.siELonOff = node.siELonOff;
            PointInfo.siELatOff = node.siELatOff;
            
            GDBL_AddJourneyPoint(m_journeyType, &PointInfo);
            
            GDBL_StopGuidance();//每次设终点计算前都删除旧路线
            GDBL_ClearDetourRoad();//删除所有避让内容
            [self MW_StartRouteCalculation:NO];
            break;
            
        default:
            break;
    }
}

/**********************************************************************
 * 函数名称: ChooseJunyPoint
 * 功能描述: 是否设置在高架桥上提示
 * 参    数: 
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)ChooseJunyPoint:(GJOURNEYPOINTTYPE)pointType
{
    _alertRouteChoeseCount++;
    
    GDAlertView *alertView = nil;
    if (pointType == GJOURNEY_GOAL)
    {
        alertView =[[[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Universal_fastRoadAlert", @"Localizable")] autorelease];
    }
    else
    {
        alertView =[[[GDAlertView alloc] initWithTitle:nil andMessage:[NSString stringWithFormat:STR(@"Universal_passbyRoadAlert", @"Localizable"),pointType]] autorelease];
    }
    
    [alertView addButtonWithTitle:STR(@"Universal_no", @"Localizable") type:GDAlertViewButtonTypeCancel handler:^(GDAlertView *alertView)
    {
        _alertRouteChoeseCount--;
        isSelectedNormal = YES;
        plugin_PoiNode *node = [self MW_GetJourneyPointWithID:pointType];
        
        GPOI PointInfo = {0};
        if (node.szName) {
            strcpy(PointInfo.szName,NSSTRING_TO_CSTRING(node.szName));
        }
        if (node.szAddr) {
            strcpy(PointInfo.szAddr,NSSTRING_TO_CSTRING(node.szAddr));
        }
        
        PointInfo.Coord.x = node.lLon;
        PointInfo.Coord.y = node.lLat;
        PointInfo.siELonOff = node.siELonOff;
        PointInfo.siELatOff = node.siELatOff;
        
        isChooseRoad = YES;
        GDBL_AddJourneyPoint(pointType, &PointInfo);
        
        if (_alertRouteChoeseCount == 0)
        {
            isSelected = YES;
            GDBL_StopGuidance();//每次设终点计算前都删除旧路线
            GDBL_ClearDetourRoad();//删除所有避让内容
            [self MW_StartRouteCalculation:NO];
        }
        
    }];
    [alertView addButtonWithTitle:STR(@"Universal_yes", @"Localizable") type:GDAlertViewButtonTypeDefault handler:^(GDAlertView *alertView){
        
        _alertRouteChoeseCount--;
        isSelectedNormal = NO;
        plugin_PoiNode *node = [self MW_GetJourneyPointWithID:pointType];
        
        GPOI PointInfo = {0};
        if (node.szName) {
            strcpy(PointInfo.szName,NSSTRING_TO_CSTRING(node.szName));
        }
        if (node.szAddr) {
            strcpy(PointInfo.szAddr,NSSTRING_TO_CSTRING(node.szAddr));
        }
        PointInfo.Coord.x = node.lLon;
        PointInfo.Coord.y = node.lLat;
        PointInfo.siELonOff = node.siELonOff;
        PointInfo.siELatOff = node.siELatOff;
        
        isChooseRoad = YES;
        GDBL_AddJourneyPoint(pointType, &PointInfo);
        
        if (_alertRouteChoeseCount == 0)
        {
            isSelected = YES;
            GDBL_StopGuidance();//每次设终点计算前都删除旧路线
            GDBL_ClearDetourRoad();//删除所有避让内容
            [self MW_StartRouteCalculation:NO];
        }
    }];
    [alertView show];
    
}

#pragma mark 添加行程点时的回调
/**********************************************************************
 * 函数名称: GetJunyPointRoadInfo
 * 功能描述: 添加行程点时的回调
 * 参    数: pRoadInfo：道路信息 nNumberOfRoadInfo:道路信息条数 
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
Gint32 GetJunyPointRoadInfo(GROADINFO *pRoadInfo, Gint32 nNumberOfRoadInfo, Gvoid *lpVoid)
{
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        return 0;
    }

    BOOL isExistNormal = NO;
    BOOL isEXistHigh = NO;
    int high = -1;
    int normal = -1;
    for (int i = 0; i < nNumberOfRoadInfo; i++)
    {
        if (pRoadInfo[i].nRoadType == 10 || pRoadInfo[i].nRoadType == 11)
        {
            if (high == -1)
            {
                isEXistHigh = YES;
                high = i;
            }
        }
        else
        {
            if (normal == -1)
            {
                isExistNormal = YES;
                normal = i;
            }
        }
        
        if (isExistNormal && isEXistHigh)
        {
            if (![MWGuideOperator sharedInstance].isChooseRoad)
            {
                [MWGuideOperator sharedInstance].isSelected = NO;
                [[MWGuideOperator sharedInstance] ChooseJunyPoint:[MWGuideOperator sharedInstance].m_journeyType];
            }
            else
            {
                [MWGuideOperator sharedInstance].isChooseRoad = NO;
                if (![MWGuideOperator sharedInstance].isSelectedNormal)
                {
                    return high;
                }
                else
                {
                    return normal;
                }
            }
            
            break;
        }
    }
    return 0;
}
#pragma mark -
#pragma mark 轨迹相关================================================================================
#pragma mark -

#pragma mark 获取轨迹列表
/**********************************************************************
 * 函数名称: MW_GetTrackList
 * 功能描述: 获取轨迹列表
 * 参    数:
 * 返 回 值: 轨迹列表
 * 其它说明:
 **********************************************************************/
- (NSArray *)MW_GetTrackList {
	
	GSTATUS res;
	res = GDBL_GetTrackList(&ppTrackList);
	
	if (0!=res)
	{
		return nil;
	}
	
	NSMutableArray *trackList = [[NSMutableArray alloc] init];
	
	for (int i=0; i<ppTrackList->nNumberOfTrack; i++)
	{
        
        NSStringEncoding encode = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        NSString *nameStr = [[NSString alloc] initWithCString:ppTrackList->pTrackInfo[i].szTrackName encoding:encode];
		[trackList addObject:nameStr];
        [nameStr release];
	}
	
	return [trackList autorelease];
}

#pragma mark 轨迹操作（设置，删除，清空，轨迹回放，加载轨迹，编辑轨迹，停止轨迹回放，卸载轨迹，判断是否加载）
/**********************************************************************
 * 函数名称: MW_TrackOperationWithID
 * 功能描述: 轨迹操作（设置，删除，清空，轨迹回放，加载轨迹，编辑轨迹，停止轨迹回放，卸载轨迹，判断是否加载）
 * 参    数:[IN]ID:操作类型 index:轨迹索引
 * 返 回 值: 成功返回YES,失败返回NO
 * 其它说明:
 **********************************************************************/
- (id)MW_TrackOperationWithID:(NSInteger)ID Index:(NSInteger)index {
	
	static int trackIndex = 0;
	static int trackReplay = 0;
    static int trackReplaying = 0;
	
	GSTATUS res;
	
	switch (ID)
	{
		case 0://设置
		{
			trackIndex = index;
			return [NSNumber numberWithBool:YES];
		}
			break;
			
		case 1://删除
		{
			Gint32 nIndex = ppTrackList->pTrackInfo[trackIndex].nIndex;
			GSTATUS res = GDBL_DelTrack(&nIndex, 1);
			if (GD_ERR_OK==res)
			{
				return [NSNumber numberWithBool:YES];
			}
		}
			break;
			
		case 2://清空
		{
			GSTATUS res;
			res = GDBL_ClearTrack();
			if (GD_ERR_OK==res)
			{
				return [NSNumber numberWithBool:YES];
			}
		}
			break;
			
		case 3://轨迹回放
		{
            if ([[ANParamValue sharedInstance] isPath]) {
                [[MWGuideOperator sharedInstance] MW_GuidanceOperateWithMainID:1 GuideHandle:NULL];
            }
			trackReplay = 0;
            
			res = GDBL_LoadTrack(ppTrackList->pTrackInfo[trackIndex].szTrackName);
            
			if (GD_ERR_OK==res)
			{
                
				res = GDBL_StartTrackReplay(ppTrackList->pTrackInfo[trackIndex].szTrackName);
                
				if (GD_ERR_OK==res)
				{
                    trackReplaying = 1;
					[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_INSIMULATION object:
					 [NSNumber numberWithInt:2]];
					return [NSNumber numberWithBool:YES];
				}
			}
		}
			break;
			
		case 4://加载轨迹
		{
            
			res = GDBL_LoadTrack(ppTrackList->pTrackInfo[index].szTrackName);
			if (GD_ERR_OK==res)
			{
                
                ppTrackList->pTrackInfo[trackIndex].bLoaded = Gtrue;
				return [NSNumber numberWithBool:YES];
			}
		}
			break;
			
		case 5://编辑
		{
			return [NSNumber numberWithInt:trackIndex];
		}
			break;
			
		case 6://停止轨迹回放
		{
			
            if (trackReplaying == 1)
            {
                trackReplaying = 0;
                trackReplay = 0;
                
                res = GDBL_StopTrackReplay();
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_EXSIMULATION object:nil];
                if (GD_ERR_OK==res)
                {
                    
                    GDBL_UnloadTrack(ppTrackList->pTrackInfo[trackIndex].szTrackName);
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
                    return [NSNumber numberWithBool:YES];
				}
			}
        }
			
			break;
			
		case 7:
		{
			trackReplay++;
			if (trackReplay%2)
			{
				res = GDBL_PauseTrackReplay();
				if (GD_ERR_OK==res)
				{
					return [NSNumber numberWithBool:YES];
				}
			}
			else
			{
				res = GDBL_ContinueTrackReplay();
				if (GD_ERR_OK==res)
				{
					return [NSNumber numberWithBool:YES];
				}
			}
		}
			break;
			
		case 8:
		{
			
		}
			break;
			
		case 9://卸载轨迹
		{
            
			GSTATUS status = GDBL_UnloadTrack(ppTrackList->pTrackInfo[trackIndex].szTrackName);
            if (status == GD_ERR_OK)
            {
                ppTrackList->pTrackInfo[trackIndex].bLoaded = Gfalse;
                return [NSNumber numberWithBool:YES];
            }
            
		}
			break;
            
		case 10://判断是否加载
        {
            Gbool tmpBool = Gfalse;
            GDBL_TrackIsLoaded(ppTrackList->pTrackInfo[trackIndex].szTrackName, &tmpBool);
            if(tmpBool == Gfalse)
            {
                return [NSNumber numberWithBool:NO];
            }
            else
            {
                return [NSNumber numberWithBool:YES];
            }
        }
            break;
		default:
			break;
	}
	
	return [NSNumber numberWithBool:NO];
}

#pragma mark 修改轨迹名
/**********************************************************************
 * 函数名称: MW_EditTrackName
 * 功能描述: 修改轨迹名
 * 参    数:[IN]trackName:轨迹名
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (id)MW_EditTrackName:(NSString *)trackName {
    
	int index = [(NSNumber *)[self MW_TrackOperationWithID:5 Index:0] intValue];
	GTRACKINFO tmp;
	tmp.nIndex = ppTrackList->pTrackInfo[index].nIndex;
	strcpy(tmp.szTrackName, NSSTRING_TO_CSTRING(trackName));
	NSLog(@"trackname=%s",tmp.szTrackName);
	GSTATUS res = GDBL_EditTrack(&tmp);
    NSLog(@"res=%d",res);
	if (res==GD_ERR_OK)
	{
		return [NSNumber numberWithBool:YES];
	}
	return [NSNumber numberWithBool:NO];
}

#pragma mark -
#pragma mark 导航相关=============================================================================

#pragma mark 开始模拟导航
/**********************************************************************
 * 函数名称: MW_BeginSimulationNavigation
 * 功能描述: 开始模拟导航
 * 参    数: 
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_BeginSimulationNavigation
{
	
    if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 1)
    {
//        [[Plugin_OnLineMapUtility sharedInstance] StartEmulatorNaviWithSpeed:100];
    }
    else
    {
        GSTATUS res;
        res = GDBL_StartDemo();
        GDBL_GoToCCP();
        if (GD_ERR_OK==res)
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_INSIMULATION object:nil];
        }
    }
	
}

#pragma mark 设置模拟速度－0:加速 1:减速
/**********************************************************************
 * 函数名称: MW_SetDemoSpeed
 * 功能描述: 设置模拟速度－0:加速 1:减速
 * 参    数: type：0:加速 1:减速
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (NSInteger)MW_SetDemoSpeed:(int)type {
	
	GDEMOSPEED eDemoSpeed = 0;
    eDemoSpeed = [[MWPreference sharedInstance] getValue:PREF_DEMO_SPEED];
	NSLog(@"sped1=%d",eDemoSpeed);
	if (type == 0) {
		if (eDemoSpeed!=3)
		{
			eDemoSpeed++;
		}
	}
	else if(type == 1) {
		if (eDemoSpeed!=0)
		{
			eDemoSpeed--;
		}
	}
	NSLog(@"sped2=%d",eDemoSpeed);
    //	GDBL_SetParam(G_DEMO_SPEED, &eDemoSpeed);
    [[MWPreference sharedInstance] setValue:PREF_DEMO_SPEED Value:eDemoSpeed];
	return eDemoSpeed;
}

#pragma mark 暂停或继续模拟导航
/**********************************************************************
 * 函数名称: MW_PauseORContinueSimulationNavigationWithMainID
 * 功能描述: 暂停或继续模拟导航
 * 参    数: mainID：0 暂停 1 继续
 * 返 回 值: 成功返回 YES 失败返回 NO
 * 其它说明:
 **********************************************************************/
- (BOOL)MW_PauseORContinueSimulationNavigationWithMainID:(int)mainID {
	
	GSTATUS res;
	switch (mainID)
	{
		case 0:
		{
            if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
            {
                [[Plugin_OnLineMapUtility sharedInstance] PauseNavi];
                return YES;
            }
            else
            {
                res = GDBL_PauseDemo();
                if (GD_ERR_OK==res)
                {
                    return YES;
                }
            }
			
		}
			break;
			
		case 1:
		{
            if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
            {
                [[Plugin_OnLineMapUtility sharedInstance] ResumeNavi];
                return YES;
            }
            else
            {
                res = GDBL_ContinueDemo();
                if (GD_ERR_OK==res)
                {
                    return YES;
                }
            }
			
		}
			break;
			
		default:
			break;
	}
	return NO;
}

#pragma mark 停止模拟导航
/**********************************************************************
 * 函数名称: MW_StopSimulationNavigation
 * 功能描述: 停止模拟导航
 * 参    数: 
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_StopSimulationNavigation
{
	if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        [[Plugin_OnLineMapUtility sharedInstance] StopEmulatorNavi];
    }
    else
    {
        GSTATUS res;
        res = GDBL_StopDemo();
        GDBL_GoToCCP();
        if (GD_ERR_OK==res)
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_EXSIMULATION object:nil];
        }
    }
}

#pragma mark 导航操作(参数mainID:0:开始导航,1:停止导航)
/**********************************************************************
 * 函数名称: MW_GuidanceOperateWithMainID
 * 功能描述: 导航操作(参数mainID:0:开始导航,1:停止导航)
 * 参    数: mainID：0:开始导航,1:停止导航 guideHandle:句柄
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_GuidanceOperateWithMainID:(NSInteger)mainID GuideHandle:(GHGUIDEROUTE)guideHandle {
    
	switch (mainID)
	{
		case 0:
		{
            if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 1)
            {
                [[Plugin_OnLineMapUtility sharedInstance] StartGPSNavi]; //开始TBT导航
            }
            else
            {
                GSTATUS res;
                res = GDBL_StartGuidance();
                
                if (GD_ERR_OK==res)
                {
                    if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 2) //本网结合导航时，本地导航时，网络导航处于引导状态，用于更新车标位置
                    {
                        [Plugin_OnLineMapUtility sharedInstance].m_mapViewState = State_Guidance;
                    }
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STARTGUIDANCE object:nil];
                }
                [[MWMapOperator sharedInstance] MW_GoToCCP];
            }
		}
			break;
			
		case 1:
		{
            
            //删除路线清空周边图面小红点
            MWMapAddIconOperator *_mapAddIcon =  [[MWMapAddIconOperator alloc] initWithImage:nil poiArray:nil inView:nil delegate:nil];
            
            [_mapAddIcon freshPoiArray:nil];
            [_mapAddIcon release];
            
            [[MWPreference sharedInstance] setValue:PREF_MAP_TMC_SHOW_OPTION Value:NO];//设置路径tmc
            if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 0)
            {
                GSTATUS res;
                res = GDBL_StopGuidance();
                GDBL_ClearDetourRoad();//删除所有避让内容
                
                GDBL_ClearJourneyPoint();
                if (GD_ERR_OK==res)
                {
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
                }
            }
            else if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 1)
            {
                [[Plugin_OnLineMapUtility sharedInstance] StopNavi]; //删除TBT所有路径
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
            }
            else if ([Plugin_OnLineMapUtility sharedInstance].isTBTRouteData == 2)
            {
                GSTATUS res;
                res = GDBL_StopGuidance();
                GDBL_ClearDetourRoad();//删除所有避让内容
                
                GDBL_ClearJourneyPoint();
                if (GD_ERR_OK==res)
                {
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
                }
                [[Plugin_OnLineMapUtility sharedInstance] StopNavi]; //删除TBT所有路径
            }
            [[MWMapOperator sharedInstance] MW_GoToCCP];
            if (UIApplicationStateBackground == [[UIApplication sharedApplication] applicationState] || UIApplicationStateInactive == [[UIApplication sharedApplication] applicationState]) {//进入后台删除路径改变定位精度
                [[GDBL_Location sharedInstance] backgroundLocationHandle];
            }
            
            [[MWDialectDownloadManage sharedInstance] autoSwitchTTSPath];
            
        }
			break;
			
		default:
			break;
	}
    if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%s",route_path]])
    {
        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%s",route_path] error:nil];
    }
}

#pragma mark 获取导航状态相对应的标志(路口放大 高速路牌 蓝色看板)
/**********************************************************************
 * 函数名称: MW_GetGuideFlags
 * 功能描述: 获取导航状态相对应的标志(G_GUIDE_FLAGS_CROSSZOOM:路口放大 G_GUIDE_FLAGS_GUIDEPOST:高速路牌 G_GUIDE_FLAGS_SIGNPOST:蓝色看板)
 * 参    数: 
 * 返 回 值: 导航状态标志
 * 其它说明:
 **********************************************************************/
-(int)MW_GetGuideFlags
{
    GGUIDEFLAGS pFlags;
    GSTATUS flag = GDBL_GetGuideFlags(&pFlags);
    if (flag == 0)
    {
        return pFlags;
    }
    else
    {
        return 0;
    }
}

#pragma mark -
#pragma mark 3D演示模型=============================================================================
#pragma mark -
#pragma mark 获取3D演示模型(参数1000为section名称数组，其他数字为section索引值)
/**********************************************************************
 * 函数名称: MW_GetDemoModelListWithMainID
 * 功能描述: 获取3D演示模型(参数1000为section名称数组，其他数字为section索引值)
 * 参    数: mainID：1000为section名称数组，其他数字为section索引值
 * 返 回 值: 名称数组
 * 其它说明:
 **********************************************************************/
- (NSArray *)MW_GetDemoModelListWithMainID:(int)mainID {
    
    GDBL_GetDemoModelList(&ppDemoModelList, &pNumberOfList);
    
	NSMutableArray *context = [[NSMutableArray alloc] init];
    
	switch (mainID)
	{
		case 1000://Section内容
		{
			for (int i=0; i<pNumberOfList; i++)
			{
				NSString *adminName = [NSString chinaFontStringWithCString:ppDemoModelList[i].szAdminName];
				if (0!=[adminName length])
				{
					[context addObject:adminName];
				}
				adminName = nil;
			}
		}
			break;
            
		default:
		{
			for (int i=0; i<ppDemoModelList[mainID].nNumberOfDemoModel; i++)
			{
				NSString *modelName = [NSString chinaFontStringWithCString:ppDemoModelList[mainID].pDemoModel[i].szModelName];
				if (0!=[modelName length])
				{
					[context addObject:modelName];
				}
				modelName = nil;
			}
		}
			break;
	}
	
	return [context autorelease];
}

#pragma mark 开始3D演示模型演示(参数MID为模型的section索引值，SID为row的列索引值)
/**********************************************************************
 * 函数名称: MW_StartModelDemoWithMainID
 * 功能描述: 开始3D演示模型演示(参数MID为模型的section索引值，SID为row的列索引值)
 * 参    数: MID：section索引值 SID:row的列索引值
 * 返 回 值: 成功返回0 失败返回对应出错码
 * 其它说明:
 **********************************************************************/
- (int)MW_StartModelDemoWithMainID:(NSInteger)MID WithSubID:(NSInteger)SID {
	
	GDBL_GoToCCP();
	GSTATUS res = GDBL_StartModelDemo(&(ppDemoModelList[MID].pDemoModel[SID]));
    return res;
}

#pragma mark 获取3D演示模型演示对应城市行政编码(参数section为模型的section索引值，index为row的列索引值)
/**********************************************************************
 * 函数名称: MW_GetModelDemoAdminCodeWithSection
 * 功能描述: 获取3D演示模型演示对应城市行政编码(参数section为模型的section索引值，index为row的列索引值)
 * 参    数: section：城市索引 index:row的列索引值
 * 返 回 值: 行政编码
 * 其它说明:
 **********************************************************************/
- (int)MW_GetModelDemoAdminCodeWithSection:(int)section Index:(int)index
{
    
    GCOORD demoCoord = {0};
    demoCoord = [[ANDataSource sharedInstance] GMD_SPCodeToCoord:ppDemoModelList[section].pDemoModel[index].szSPCode];
    int adminCode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:demoCoord.x Lat:demoCoord.y];
    return adminCode;
}

#pragma mark 暂停或继续3D演示模型演示(参数0为暂停,1为继续)
/**********************************************************************
 * 函数名称: MW_PauseModelDemoORContinueModelDemoWithID
 * 功能描述: 暂停或继续3D演示模型演示(参数0为暂停,1为继续)
 * 参    数: ID：0 暂停 1 继续
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_PauseModelDemoORContinueModelDemoWithID:(NSInteger)ID {
	
	if (0==ID)
	{
		GDBL_PauseModelDemo();
	}
	else
	{
		GDBL_ContinueModelDemo();
	}
}

#pragma mark 停止3D演示模型演示
/**********************************************************************
 * 函数名称: MW_StopModelDemo
 * 功能描述: 停止3D演示模型演示
 * 参    数: 
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_StopModelDemo {
    
	GDBL_StopModelDemo();//停止模型演示
	GDBL_GoToCCP();//回车位，更新图面
}

#pragma mark -
#pragma mark 3D演示路线=============================================================================
#pragma mark -
#pragma mark 获取3D演示路线列表
/**********************************************************************
 * 函数名称: MW_GetDemoJourneyList
 * 功能描述: 获取3D演示路线列表
 * 参    数: 
 * 返 回 值: 路线列表
 * 其它说明:
 **********************************************************************/
- (NSArray *)MW_GetDemoJourneyList {
    
	NSMutableArray *context = [[NSMutableArray alloc] init];
    
	GSTATUS res = GDBL_GetDemoJourneyList(&ppDemoJourneyList);
    
    if (res == GD_ERR_OK)
    {
        for (int i=0; i<ppDemoJourneyList->nNumberOfDemoJourney; i++)
        {
            NSString *journeyName = [NSString chinaFontStringWithCString:ppDemoJourneyList->pDemoJourney[i].szJourneyName];
            if (0!=[journeyName length])
            {
                [context addObject:journeyName];
            }
            journeyName = nil;
        }
    }
    
	return [context autorelease];
}

#pragma mark 开始路线演示(参数为索引值)
/**********************************************************************
 * 函数名称: MW_LoadDemoJourneyWithMainID
 * 功能描述: 开始路线演示(参数为索引值)
 * 参    数: MID：路线索引
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (int)MW_LoadDemoJourneyWithMainID:(NSInteger)MID {
	
	Guint32 index = ppDemoJourneyList->pDemoJourney[MID].nID;
    GSTATUS res = GDBL_LoadDemoJourney(index);
    return res;
}

#pragma mark 获取路线演示行政编码(参数为起点，途径点，终点)
/**********************************************************************
 * 函数名称: MW_GetDemoJourneyAdmincode
 * 功能描述: 获取路线演示行政编码
 * 参    数: index：路线索引 type:起点，途径点，终点
 * 返 回 值: 行政编码
 * 其它说明:
 **********************************************************************/
- (int)MW_GetDemoJourneyAdmincode:(int)index Type:(GJOURNEYPOINTTYPE)type {
	
	GCOORD m_coord = ppDemoJourneyList->pDemoJourney[index].stCoord[type];
    int adminCode = [[ANDataSource sharedInstance] GMD_CoordToAdminCode:m_coord.x Lat:m_coord.y];
    return adminCode;
}

#pragma mark 暂停或继续路线演示
/**********************************************************************
 * 函数名称: MW_PauseDemoORContinueDemoWithID
 * 功能描述: 暂停或继续路线演示
 * 参    数: ID：0 暂停 1 继续
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_PauseDemoORContinueDemoWithID:(NSInteger)ID {
	
	if (0==ID)
	{
		GDBL_PauseDemo();
	}
	else
	{
		GDBL_ContinueDemo();
	}
}

#pragma mark 停止路线演示
/**********************************************************************
 * 函数名称: MW_UnloadDemoJourney
 * 功能描述: 停止路线演示
 * 参    数: 
 * 返 回 值:
 * 其它说明:
 **********************************************************************/
- (void)MW_UnloadDemoJourney {
    
	GDBL_UnloadDemoJourney();
	GDBL_GoToCCP();
	
	[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_STOPGUIDANCE object:nil];
}



@end
