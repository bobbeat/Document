//
//  DefineNotificationParam.m
//  AutoNavi
//
//  Created by liao yu on 12-4-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "DefineNotificationParam.h"

@implementation DefineNotificationParam

@synthesize sender,flag,param;

@end
