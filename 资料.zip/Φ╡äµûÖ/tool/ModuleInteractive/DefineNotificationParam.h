//
//  DefineNotificationParam.h
//  AutoNavi
//
//  Created by liao yu on 12-4-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DefineNotificationParam : NSObject


@property(nonatomic,assign)NSObject* sender;

@property(nonatomic,assign)int flag;

@property(nonatomic,retain)id param;

@end
