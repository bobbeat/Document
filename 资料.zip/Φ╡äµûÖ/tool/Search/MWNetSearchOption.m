//
//  MWNetSearchOption.m
//  AutoNavi
//
//  Created by gaozhimin on 14-2-25.
//
//

#import "MWNetSearchOption.h"
#import "NSString+Category.h"
#import "XMLDictionary.h"
#include <objc/runtime.h>


@interface MWNetSearchOption()

@property (nonatomic,copy) NSString *servcode;  //0005 表示 POI 搜索查询、语音搜 索查询、交叉路口搜索查询 0006 表示周边查询
@property (nonatomic,copy) NSString *syscode;  //业务系统账号             非空,参与鉴权计算
@property (nonatomic,copy) NSString *sign;  //签名串                  接口访问鉴权使用,非空
@property (nonatomic,assign) int model;  //搜索模式                 默认为 0,大陆搜索 1,台湾搜索
@property (nonatomic,copy) NSString *imei;  //机器唯一码              非空
@property (nonatomic,assign) int adcodesrc;          //Adcode 来源
@property (nonatomic,copy) NSString *mapv;          //本地数据版本号

@end

@implementation MWNetSearchOption

@synthesize size,adcode,search,adcodesrc,language,mapv,page,servcode,sign,syscode,model,imei;

- (id)init
{
    if (self = [super init])
    {
        NSString *dataVersion = [Utility GetMapVersion];
        NSArray *array = [dataVersion componentsSeparatedByString:@" "];
        if ([array count] >= 2)
        {
            self.mapv = [array objectAtIndex:1];    //获取地图数据版本号
        }
        self.imei = VendorID;
        self.page = 1;
        self.adcode = @"010";
        self.adcodesrc = 0;
        self.model = 0;
        self.syscode = KNetChannelID;
    }
    return self;
}

- (void)dealloc
{
    self.imei = nil;
    self.servcode = nil;
    self.syscode = nil;
    self.sign = nil;
    self.adcode = nil;
    self.search = nil;
    self.mapv = nil;
    [super dealloc];
}

/*
 获取对象的所有属性和属性内容
 */
- (NSMutableDictionary *)getAllPropertiesAndVaules
{
    NSMutableDictionary *props = [NSMutableDictionary dictionary];
    unsigned int outCount, i;
    objc_property_t *properties =class_copyPropertyList([MWNetSearchOption class], &outCount);
    for (i = 0; i<outCount; i++)
    {
        objc_property_t property = properties[i];
        const char* char_f =property_getName(property);
        NSString *propertyName = [NSString stringWithUTF8String:char_f];
        id propertyValue = [self valueForKey:(NSString *)propertyName];
        if (propertyValue) [props setObject:propertyValue forKey:propertyName];
    }
    free(properties);
    return props;
}

/*
   md5值计算 String sign = MD5(syscode+parameter+"@"+key)
*/
- (NSString *)calculateSignWith:(NSString *)param
{
    NSString *md5 = [NSString stringWithFormat:@"%@%@@%@",self.syscode,param,kNetSignKey];
    md5 = [md5 stringFromMD5];
    return md5;
}

@end

@interface MWNetKeyWordSearchOption()



@end

@implementation MWNetKeyWordSearchOption

- (id)init
{
    self = [super init];
    if (self) {
        self.servcode = @"0005";
    }
    return self;
}

@synthesize searchtype;

- (void)dealloc
{
    [super dealloc];
}

/* 
  获取对象的所有属性和属性内容
 */
- (NSDictionary *)getAllPropertiesAndVaules
{
    
    NSMutableDictionary *props = [super getAllPropertiesAndVaules];
    unsigned int outCount, i;
    objc_property_t *properties =class_copyPropertyList([self class], &outCount);
    for (i = 0; i<outCount; i++)
    {
        objc_property_t property = properties[i];
        const char* char_f =property_getName(property);
        NSString *propertyName = [NSString stringWithUTF8String:char_f];
        id propertyValue = [self valueForKey:(NSString *)propertyName];
        if (propertyValue) [props setObject:propertyValue forKey:propertyName];
    }
    free(properties);
    return props;
}

/*
    搜索条件转换成NSData
 */
- (NSData *)getAllPropertiesAndVaulesData
{
    NSDictionary *props = [self getAllPropertiesAndVaules]; //获取类中所有属性，呈字典显示
    NSString *search = [props objectForKey:@"search"];      //将 search 中的 值置为 NSDATA  <search><![CDATA[天安门]]</search>
    if (search)
    {
        NSString *sign_md5 = [super calculateSignWith:search];   //计算MD5值 param = search
        if (sign_md5)
        {
            [props setValue:sign_md5 forKey:@"sign"];
        }
        
        [props setValue:[search dataUsingEncoding:NSUTF8StringEncoding] forKey:@"search"];
    }
    NSString *str = [GD_NSObjectToXML xmlHeadString];
    str = [str stringByAppendingString:[GD_NSObjectToXML convertDictionaryToXML:props rootName:@"og"]];
    NSLog(@"%@",str);
    return [str dataUsingEncoding:NSUTF8StringEncoding];
}


@end


@implementation MWNetAroundSearchOption

@synthesize category,center,cx,cy,range;

- (id)init
{
    self = [super init];
    if (self) {
        self.servcode = @"0006";
    }
    return self;
}

- (void)dealloc
{
    self.category = nil;
    self.center = nil;
    self.cx = nil;
    self.cy = nil;
    [super dealloc];
}

/*
 获取对象的所有属性和属性内容
 */
- (NSDictionary *)getAllPropertiesAndVaules
{
    
    NSMutableDictionary *props = [super getAllPropertiesAndVaules];
    unsigned int outCount, i;
    objc_property_t *properties =class_copyPropertyList([self class], &outCount);
    for (i = 0; i<outCount; i++)
    {
        objc_property_t property = properties[i];
        const char* char_f =property_getName(property);
        NSString *propertyName = [NSString stringWithUTF8String:char_f];
        id propertyValue = [self valueForKey:(NSString *)propertyName];
        if (propertyValue) [props setObject:propertyValue forKey:propertyName];
    }
    free(properties);
    return props;
}

/*
 搜索条件转换成NSData
 */
- (NSData *)getAllPropertiesAndVaulesData
{
    NSDictionary *props = [self getAllPropertiesAndVaules]; //获取类中所有属性，呈字典显示
    
    NSString *param = @"";
    if ([props objectForKey:@"cx"])
    {
        param = [param stringByAppendingString:[props objectForKey:@"cx"]];
    }
    if ([props objectForKey:@"cy"])
    {
        param = [param stringByAppendingString:[props objectForKey:@"cy"]];
    }
    if ([props objectForKey:@"category"])
    {
        param = [param stringByAppendingString:[props objectForKey:@"category"]];
    }
    else
    {
        [props setValue:@"" forKey:@"category"];
    }
    if ([props objectForKey:@"search"])
    {
        param = [param stringByAppendingString:[props objectForKey:@"search"]];
    }
    else
    {
        [props setValue:@"" forKey:@"search"];
    }
    NSString *sign_md5 = [super calculateSignWith:param];   //计算MD5值 param = cx+cy+category+search
    if (sign_md5)
    {
        [props setValue:sign_md5 forKey:@"sign"];
    }
    
    NSString *data = [props objectForKey:@"search"];      //将 search 中的 值置为 NSDATA  <search><![CDATA[天安门]]</search>
    if (data)
    {
        [props setValue:[data dataUsingEncoding:NSUTF8StringEncoding] forKey:@"search"];
    }
    data = [props objectForKey:@"center"];      //将 center 中的 值置为 NSDATA <center><![CDATA[木香美食]]</center>
    if (data)
    {
        [props setValue:[data dataUsingEncoding:NSUTF8StringEncoding] forKey:@"center"];
    }
   
    NSString *str = [GD_NSObjectToXML xmlHeadString];
    str = [str stringByAppendingString:[GD_NSObjectToXML convertDictionaryToXML:props rootName:@"og"]];
    NSLog(@"%@",str);
    return [str dataUsingEncoding:NSUTF8StringEncoding];
}

@end