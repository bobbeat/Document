//
//  MWPoiOperator.m
//  AutoNavi
//
//  Created by yu.liao on 13-7-29.
//
//

#import "MWPoiOperator.h"
#import "NSString+Category.h"
#import "NameIndex.h"
#import "Account.h"
#import "JSON.h"
#import "GDAlertView.h"
#import "Plugin_OnLineMapUtility.h"

#define CONTACT_FILE_NAME @"Contacts.plist"
#define Collect_Directory [NSHomeDirectory() stringByAppendingString:@"/Documents/address"]             //收藏文件夹路径
#define Favorite_Path [Collect_Directory stringByAppendingString:@"/Favorite.plist"]  //我的收藏夹
#define History_Path [Collect_Directory stringByAppendingString:@"/History.plist"]    //历史目的地
#define SmartEye_Path [Collect_Directory stringByAppendingString:@"/SmartEye.plist"]  //电子眼

#define Syn_Favorite @"favorites/difuploadaddr_v2/?"
#define Syn_History @"favorites/difuploadhistory_v2/?"
#define Syn_SmartEye @"favorites/difuploadeleceye_v2/?"

static RecognizeController *gRecognizeController = nil;
static GSAFECATEGORY	g_smartEyesCategory;     //保存每次获取电子眼的类别，删除时使用
static BOOL bAddToLoacl = YES;                       //添加的收藏点是否要添加到本地

Class object_getClass(id object);

void GcharMemcpy(Gchar *dest,const Gchar *src, int len)
{
    if (dest == NULL || src == NULL)
    {
        return;
    }
    if (strlen(src) < len)
    {
        len = strlen(src);
    }
    dest[len] = '\0';
    memcpy(dest, src, len);
}

@interface MWPoiOperator ()<onlineMapSearchDelegate>
{
    MWSearchOption *_poiOperationOptionLocal;
    MWSearchOption *_poiOperationOptionNet;
    GCOORD _coordForNearest;
    int mResultType;
}

@property (nonatomic,copy) NSString *userName;
@property (nonatomic,assign) Class originalClass;

@end

@implementation MWPoiOperator

@synthesize poiDelegate,userName,originalClass;

- (id)initWithDelegate:(id<MWPoiOperatorDelegate>)delegate
{
    if (self = [super init])
    {
        self.poiDelegate = delegate;
        NSFileManager *fileMgr = [NSFileManager defaultManager];
        if (![fileMgr fileExistsAtPath:Collect_Directory])      //检测document下address文件夹是否存在，不存在则创建
        {
            BOOL sign = [fileMgr createDirectoryAtPath:Collect_Directory withIntermediateDirectories:nil attributes:nil error:nil];
            if (!sign)
            {
                NSLog(@"收藏夹文件夹创建失败");
            }
        }
        self.originalClass = object_getClass(delegate);
        bAddToLoacl = YES;
    }
    return self;
}

- (id)init
{
    return [self initWithDelegate:nil];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    self.userName = nil;
    if (_poiOperationOptionLocal)
    {
        [_poiOperationOptionLocal release];
        _poiOperationOptionLocal = nil;
    }
    if (_poiOperationOptionNet)
    {
        [_poiOperationOptionNet release];
        _poiOperationOptionNet = nil;
    }
    if (gRecognizeController)
    {
        [gRecognizeController release];
        gRecognizeController = nil;
    }
    self.originalClass = nil;
    [super dealloc];
}

#pragma mark - public method

#pragma mark   搜索接口
/*!
 @brief  POI 查询接口函数，即根据 POI 参数选项进行 POI 查询。
 @param operationOption POI 查询选项,具体属性字段请参考 MAPoiSearchOption 类。
 */
-(BOOL)poiLocalSearchWithOption:(MWSearchOption*)operationOption
{
    GSEARCHCONDITION pSearchCondition;
    memset(&pSearchCondition, 0, sizeof(GSEARCHCONDITION));

    pSearchCondition.Coord.x = operationOption.longitude;
    pSearchCondition.Coord.y = operationOption.latitude;
    pSearchCondition.eRoutePoiType = operationOption.routePoiTpe;
    pSearchCondition.eSearchType = operationOption.operatorType;
    pSearchCondition.lAroundRange = operationOption.aroundRange;
    pSearchCondition.lCategoryID = operationOption.categoryID;
    
    const char *string = NSSTRING_TO_CSTRING(operationOption.keyWord) ;
    if(string)
    {
        GcharMemcpy(pSearchCondition.szKeyword, string,GMAX_KEYWORD_LEN);
    }
    GSTATUS ret =  GDBL_StartSearchPOI(&pSearchCondition);
    if(ret != GD_ERR_OK)
	{
		return NO;
	}
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenNotification:) name:NOTIFY_GETPOIDATA object:nil];
    _poiOperationOptionLocal = [operationOption retain];
    [self retain];
	return YES;
    
}

/*!
 @brief  POI 网络查询接口函数，即根据 POI 参数选项进行 POI 查询。
 @param operationOption POI 查询选项,具体属性字段请参考 MWSearchOption 类。
 */
-(BOOL)poiNetSearchWithOption:(MWSearchOption*)operationOption
{
    GSEARCHCONDITION pSearchCondition;
    memset(&pSearchCondition, 0, sizeof(GSEARCHCONDITION));
    
    pSearchCondition.Coord.x = operationOption.longitude;
    pSearchCondition.Coord.y = operationOption.latitude;
    pSearchCondition.eRoutePoiType = operationOption.routePoiTpe;
    pSearchCondition.eSearchType = operationOption.operatorType;
    pSearchCondition.lAroundRange = operationOption.aroundRange;
    pSearchCondition.lCategoryID = operationOption.categoryID;
    
    const char *string = [operationOption.keyWord  cStringUsingEncoding:NSUTF8StringEncoding];
    if(string)
    {
        GcharMemcpy(pSearchCondition.szKeyword, string,GMAX_KEYWORD_LEN);
    }
    GSTATUS ret =  GDBL_StartSearchPOINet(&pSearchCondition);
    if(ret != GD_ERR_OK)
	{
		return NO;
	}
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenNotification:) name:NOTIFY_GETPOIDATA object:nil];
    _poiOperationOptionNet = [operationOption retain];
    [self retain];
    
	return YES;
}

/*!
 @brief  请求获取当前点最近的POI点 只需传入经纬度
 @param operationOption POI 查询选项,具体属性字段请参考 MWSearchOption 类。GDBL_RequestNearestPOI
 */
-(BOOL)poiNearestSearchWithCoord:(GCOORD)coord
{
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        CLLocationCoordinate2D coord2d = [[Plugin_OnLineMapUtility sharedInstance] NET_GetAmapCenter];
        coord.x = coord2d.longitude * 1000000.0;
        coord.y = coord2d.latitude * 1000000.0;
        return [self netPoiSearchWithCoord:coord];
    }
    GSTATUS ret =  GDBL_RequestNearestPOI(coord);
    if(ret != GD_ERR_OK)
	{
		return NO;
	}
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenNotification:) name:NOTIFY_GETPOIDATA object:nil];
    _coordForNearest = coord;
    [self retain];
	return YES;
}

/*!
 @brief  请求获取网络地图中心点信息 
 */
-(BOOL)netPoiSearchWithCoord:(GCOORD)coord
{
    
    if ([Plugin_OnLineMapUtility sharedInstance].isAmapView)
    {
        _coordForNearest = coord;
        [[Plugin_OnLineMapUtility sharedInstance] NET_getPoiInfoWithCoord:coord delegate:self];
        [self retain];
        return YES;
    }
	return NO;
}

/*!
 @brief  获取周边类别列表接口
 @param  lCategoryID, 类别编码 0为获取所有类别列表
 @param  list, 输出 , 周边类别列表
 @return YES:获取成功。
 */

-(BOOL)getAroundListWith:(int)lCategoryID list:(MWPoiCategoryList **)list
{
    GPOICATEGORYLIST *ppCategoryList = NULL;
    GDBL_GetPOICategoryList(lCategoryID, &ppCategoryList);
    if (ppCategoryList == NULL)
    {
        return NO;
    }
    MWPoiCategoryList *temp = [[[MWPoiCategoryList alloc] init] autorelease];
    temp.lNumberOfCategory = ppCategoryList->lNumberOfCategory;
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (int i = 0; i < ppCategoryList->lNumberOfCategory; i++)
    {
        GPOICATEGORY gPoiCategory = ppCategoryList->pCategory[i];
        MWPoiCategory  *poiCategory = [self recursiveForCategory:gPoiCategory];
        [array addObject:poiCategory];
    }
    temp.pCategoryArray = [NSArray arrayWithArray:array];
    [array release];
    
    *list = temp;
    
    return YES;
}

#pragma mark  语音搜索
/*!
 @brief  语音搜索调用
 @param option 语音搜索选项
 @param superView 语音视图的父视图
 @return YES:成功启动搜索。搜索成功将回调 -(void)voiceSearchResult:(MWVoiceResult *)result;
 */

-(BOOL)voiceSearchWith:(MWVoiceOption *)option withSuperView:(UIView*)view

{
    if (view == nil)
    {
        NSLog(@"view is nil");
        return NO;
    }
    if (gRecognizeController == nil)
    {
        gRecognizeController = [[RecognizeController alloc] initWithView:view Lon:option.longitude Lat:option.latitude AdminCode:option.lAdminCode];
    }
    
    [gRecognizeController setDelegate:self];
    [gRecognizeController setResultType:option.resultType];
    [gRecognizeController start];
    [self retain];
    mResultType = option.resultType;
    return YES;
}


/*!
 @brief  设置语音框的中心位置，  注意：该方法为类方法。
 @param center 中心点位置
 */
+(void)setRecognizeViewCenter:(CGPoint)center
{
    if (gRecognizeController)
    {
//        [gRecognizeController setViewCenter:center];
    }
}

/*!
 @brief  开始语音，  注意：该方法为类方法。
 */
+(void)setRecognizeStart
{
    if (gRecognizeController)
    {
        [gRecognizeController start];
    }
}

/*!
 @brief  设置语音识别参数，  注意：该方法为类方法。
 @param gaoLon 高德经度
 @param gaoLat 高德纬度
 @param adminCode 行政编码
 */
+(void)setPosition:(int)gaoLon Lat:(int)gaoLat AdminCode:(int)adminCode
{
    if (gRecognizeController)
    {
        [gRecognizeController setPosition:gaoLon Lat:gaoLat AdminCode:adminCode];
    }
}

/*!
 @brief  停止语音，  注意：该方法为类方法。
 */
+(void)setRecognizeStop
{
    if (gRecognizeController)
    {
        [gRecognizeController stop];
    }
}


#pragma mark  地址簿，历史目的地接口

/*!
 @brief  同步收藏夹兴趣点
 @param   eCategory 兴趣点类别GFAVORITECATEGORY，用于标识要上传的收藏夹类别。
 @param   type     请求类型
 */
+ (BOOL)synFavoritePoiWith:(MWFavoriteOption *)option requestType:(RequestType)type delegate:(id<MWPoiOperatorDelegate>)delegate
{
    MWFavorite *favorite = nil;
    if (option.eCategory == GFAVORITE_CATEGORY_DEFAULT) //我的收藏夹
    {
        favorite = [NSKeyedUnarchiver unarchiveObjectWithFile:Favorite_Path];
    }
    else if (option.eCategory == GFAVORITE_CATEGORY_HISTORY) //历史目的地
    {
        favorite = [NSKeyedUnarchiver unarchiveObjectWithFile:History_Path];
    }
    
    if (favorite == nil)
    {
        NSLog(@"无文件数据");
        favorite = [[[MWFavorite alloc] init] autorelease];
    }
    
    NSArray *poiList = favorite.pFavoritePOIArray;  //上传改动的poi信息
    NSArray *array;
    GDBL_GetAccountInfo(&array);
    int loginType = [[array objectAtIndex:0] intValue];
    NSString *url = nil;
    NSString *userName = nil;
    if (loginType == 0)
    {
        return NO;
    }
    if (option.eCategory == GFAVORITE_CATEGORY_DEFAULT) //我的收藏夹
    {
        if (loginType == 3 || loginType == 5)
        {
            url = [NSString stringWithFormat:@"%@%@out=xml&tpuserid=%@&tptype=1",kNetDomain,Syn_Favorite,[array objectAtIndex:5]];
            userName = [[array objectAtIndex:5] stringByAppendingString:@"1"];  //记录用户名
        }
        else if (loginType == 4 || loginType == 6)
        {
            url = [NSString stringWithFormat:@"%@%@out=xml&tpuserid=%@&tptype=2",kNetDomain,Syn_Favorite,[array objectAtIndex:5]];
            userName = [[array objectAtIndex:5] stringByAppendingString:@"2"];  //记录用户名
        }
        else
        {
            url = [NSString stringWithFormat:@"%@%@out=xml&username=%@&password=%@",kNetDomain,Syn_Favorite,[array objectAtIndex:1],[array objectAtIndex:2]];
            userName = [array objectAtIndex:1];                                         //记录用户名
        }
    }
    else if (option.eCategory == GFAVORITE_CATEGORY_HISTORY) //历史目的地
    {
        if (loginType == 3 || loginType == 5)
        {
            url = [NSString stringWithFormat:@"%@%@out=xml&tpuserid=%@&tptype=1",kNetDomain,Syn_History,[array objectAtIndex:5]];
            userName = [[array objectAtIndex:5] stringByAppendingString:@"1"];  //记录用户名
        }
        else if (loginType == 4 || loginType == 6)
        {
            url = [NSString stringWithFormat:@"%@%@out=xml&tpuserid=%@&tptype=2",kNetDomain,Syn_History,[array objectAtIndex:5]];
            userName = [[array objectAtIndex:5] stringByAppendingString:@"2"];  //记录用户名
        }
        else
        {
            url = [NSString stringWithFormat:@"%@%@out=xml&username=%@&password=%@",kNetDomain,Syn_History,[array objectAtIndex:1],[array objectAtIndex:2]];
            userName = [array objectAtIndex:1]; 
        }
    }
    
    //判断上次同步的 用户与此次是否相同，不同则将时间置为较早时间
    if (![favorite.userName isEqualToString:userName])
    {
        GDATE	Date_tmp = {1975,1,1};
        favorite.Date	= Date_tmp;
        GTIME	Time_tmp = {1,1,1};
        favorite.Time	= Time_tmp;
        MWFavorite *allFavorite;
        [self getPoiListWith:option.eCategory poiList:&allFavorite];
        for (MWFavoritePoi *temp in allFavorite.pFavoritePOIArray)
        {
            temp.actionType = 1;
        }
        poiList = allFavorite.pFavoritePOIArray;
    }
    
	NSString *temp = @"<?xml version=\"1.0\" encoding=\"utf-8\"?><archive>";
    temp = [temp stringByAppendingFormat:@"<lasttime>%d-%02d-%02d %02d:%02d:%02d</lasttime><context>",favorite.Date.year,favorite.Date.month,favorite.Date.day,favorite.Time.hour,favorite.Time.minute,favorite.Time.second];
	for(int i = 0; i < [poiList count]; i++)
    {
		MWFavoritePoi *tmp = [poiList objectAtIndex:i];
        NSString *name =(NSString *)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                            (CFStringRef)tmp.szName,
                                                                            NULL,
                                                                            CFSTR(":/?#[]@!$&’()*+,;="),
                                                                            kCFStringEncodingUTF8);
		temp = [temp stringByAppendingFormat:@"<item><item_id>%d</item_id><longitude>%ld</longitude>",0,tmp.longitude];
		temp = [temp stringByAppendingFormat:@"<latitude>%ld</latitude><longitude_off>0</longitude_off>",tmp.latitude];
		temp = [temp stringByAppendingFormat:@"<latitude_off>0</latitude_off><name>%@</name>",name];
		temp = [temp stringByAppendingFormat:@"<type>0001</type><origen_type>0001</origen_type><admin_code>%d</admin_code>",tmp.lAdminCode];
		temp = [temp stringByAppendingFormat:@"<from_type>%d</from_type><town>%@</town><address>%@</address>",tmp.lCategoryID,tmp.szTown,tmp.szAddr];
		temp = [temp stringByAppendingFormat:@"<telephone>%@</telephone><detail></detail><state>%d</state></item>",tmp.szTel,tmp.actionType];
        [name release];
    }
	
    if ([poiList count] == 0)
    {
        temp = [temp stringByAppendingString:@"<item></item>"];
    }
	temp = [temp stringByAppendingString:@"</context></archive>"];
	
	NSData *requstBody = [temp dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    
    /**
     组转上传数据
     */

    MWPoiOperator *operator = [[MWPoiOperator alloc] initWithDelegate:delegate];    //回调中释放
    operator.userName = userName;
    operator.originalClass = object_getClass(delegate);
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = url;
    net_condition.bodyData = requstBody;
    net_condition.httpMethod = @"POST";
    
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:operator];
    
    return YES;
}

/*!
 @brief  取消同步收藏兴趣点
 @param   type     请求类型
 @return	成功返回YES 否则返回NO
 */
+ (BOOL)cancelSynFavoritePoiWith:(RequestType)type
{
    return [[NetExt sharedInstance] Net_CancelRequestWithType:type];
}

/*!
 @brief  收藏指定条件兴趣点
 @return 收藏成功返回GD_ERR_OK，重复收藏返回GD_ERR_DUPLICATE_DATA。其他错误码请参见 GSTATUS
 */
+(GSTATUS)collectPoiWith:(GFAVORITECATEGORY)eCategory icon:(GFAVORITEICON)eIconID poi:(GPOI)gpoi
{
    MWFavoritePoi *poi = [[[MWFavoritePoi alloc] init] autorelease];
    poi.eCategory = eCategory;
    poi.eIconID = eIconID;
    poi.lAdminCode = gpoi.lAdminCode;
    poi.latitude = gpoi.Coord.y;
    poi.longitude = gpoi.Coord.x;
    poi.lCategoryID = gpoi.lCategoryID;
    poi.lDistance = gpoi.lDistance;
    poi.lHilightFlag = gpoi.lHilightFlag;
    poi.lMatchCode = gpoi.lMatchCode;
    poi.lPoiId = gpoi.lPoiId;
    poi.lPoiIndex = gpoi.lPoiIndex;
    poi.usNodeId = gpoi.usNodeId;
    poi.ucFlag = gpoi.ucFlag;
    poi.Reserved = gpoi.Reserved;
    poi.siELatOff = gpoi.siELatOff;
    poi.siELonOff = gpoi.siELonOff;
    poi.szName = CSTRING_TO_NSSTRING(gpoi.szName);
    poi.szAddr = CSTRING_TO_NSSTRING(gpoi.szAddr);
    poi.szTel = CSTRING_TO_NSSTRING(gpoi.szTel);
    return [self collectPoiWith:poi];
}

/*!
 @brief  收藏指定条件兴趣点
 @param favoritePoi POI 收藏条件
 @return 收藏成功返回GD_ERR_OK，重复收藏返回GD_ERR_DUPLICATE_DATA。其他错误码请参见 GSTATUS
 */
+(GSTATUS)collectPoiWith:(MWFavoritePoi *)favoritePoi
{
    if (favoritePoi == nil)
    {
        return GD_ERR_FAILED;
    }
    GPOI pPOI = {0};
    pPOI.Coord.x = favoritePoi.longitude;
    pPOI.Coord.y = favoritePoi.latitude;
    pPOI.lCategoryID = favoritePoi.lCategoryID;
    pPOI.lDistance = favoritePoi.lDistance;
    pPOI.lMatchCode = favoritePoi.lMatchCode;
    pPOI.lHilightFlag = favoritePoi.lHilightFlag;
    pPOI.lAdminCode = favoritePoi.lAdminCode;
    pPOI.lPoiId = favoritePoi.lPoiId;
    pPOI.siELonOff = favoritePoi.siELonOff;
    pPOI.siELatOff = favoritePoi.siELatOff;
    
    const char *str =  NSSTRING_TO_CSTRING(favoritePoi.szName);
    if(str)
    {
        GcharMemcpy(pPOI.szName,str,GMAX_POI_NAME_LEN);
    }
    str = NSSTRING_TO_CSTRING(favoritePoi.szAddr);
    if(str)
    {
        GcharMemcpy(pPOI.szAddr,str,GMAX_POI_ADDR_LEN);
    }
    str = NSSTRING_TO_CSTRING(favoritePoi.szTel);
    if(str)
    {
        GcharMemcpy(pPOI.szTel,str,GMAX_POI_TEL_LEN);
    }
    
    pPOI.lPoiIndex = favoritePoi.lPoiIndex;
    pPOI.ucFlag = favoritePoi.ucFlag;
    pPOI.Reserved = favoritePoi.Reserved;
    pPOI.usNodeId = favoritePoi.usNodeId;

    
    GSTATUS res = GDBL_AddFavorite(favoritePoi.eCategory,favoritePoi.eIconID,&pPOI);
    if (res == GD_ERR_OK && bAddToLoacl)               //成功，则将点同步至本地文件
    {
        /***将MWFavorite类 保存至本地文件 用于同步收藏夹内容 路径见宏 Favorite_Path History_Path***/
        NSString *file_path = Favorite_Path;
        if (favoritePoi.eCategory == GFAVORITE_CATEGORY_HISTORY)
        {
            file_path = History_Path;
        }
        
        favoritePoi.actionType = 1;     //添加
        MWFavorite *favorite = nil;
        BOOL bExistPoi = NO;            //判断文件中是否存在添加的poi点，如若没有，则添加至文件
        favorite = [NSKeyedUnarchiver unarchiveObjectWithFile:file_path];
        for (int i = 0 ; i < [favorite.pFavoritePOIArray count]; i++)
        {
            MWFavoritePoi *poi = [favorite.pFavoritePOIArray objectAtIndex:i];
            if (poi.longitude == favoritePoi.longitude && poi.latitude == favoritePoi.latitude)
            {
                bExistPoi = YES;
                if (poi.actionType == 2)        //如果已存在删除的点，则删除删除该点
                {
                    [favorite.pFavoritePOIArray removeObject:poi];
                    break;
                }
                [favorite.pFavoritePOIArray replaceObjectAtIndex:i withObject:favoritePoi];
                
                break;
            }
        }
        
        if (!bExistPoi)
        {
            if (favorite == nil)
            {
                favorite = [[[MWFavorite alloc] init] autorelease];
                favorite.pFavoritePOIArray = [NSMutableArray array];
            }
            [favorite.pFavoritePOIArray addObject:favoritePoi];
        }
        favorite.nNumberOfItem = [favorite.pFavoritePOIArray count];
        if (![NSKeyedArchiver archiveRootObject:favorite toFile:file_path])
        {
            NSLog(@"-------------同步至本地文件失败-----------------");
        }
        else
        {
            NSLog(@"-------------同步至本地文件成功-----------------");
        }
        /******/
    }
    else if (res == GD_ERR_NO_SPACE)
    {
        GDAlertView *alert = [[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"POI_FavoriteFull", @"POI")];
        [alert addButtonWithTitle:STR(@"Universal_ok", @"Localizable") type:GDAlertViewButtonTypeDefault handler:nil];
        [alert show];
        [alert release];
    }
    return res;
}

/*!
 @brief  编辑已收藏的兴趣点
 @param  favoritePoi 编辑后的兴趣点
 @return 编辑成功返回GD_ERR_OK。其他错误码请参见 GSTATUS
 */
+(GSTATUS)editeFavoritePoiWith:(MWFavoritePoi *)favoritePoi
{
    if (favoritePoi == nil)
    {
        return GD_ERR_FAILED;
    }
    
    GFAVORITEPOI pFavoritePOI = {0};
    
    NSDate *localDate = [NSDate date];
    NSCalendar  * cal=[NSCalendar  currentCalendar];
    NSUInteger  unitFlags=NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;
    NSDateComponents * conponent= [cal components:unitFlags fromDate:localDate];
    NSInteger year=[conponent year];
    NSInteger month=[conponent month];
    NSInteger day=[conponent day];
    
    NSDateFormatter *timeFormatter = [[[NSDateFormatter alloc]init]autorelease];
    timeFormatter.dateFormat = @"HH:mm:ss";
    NSString *dateString = [timeFormatter stringFromDate:localDate];
    NSInteger hour = [[dateString CutToNSString:@":"] intValue];
    NSInteger min = [[dateString CutFromNSString:@":" Tostring:@":"] intValue];
    NSInteger second = [[dateString CutToNSStringBackWard:@":"] intValue];
    
    pFavoritePOI.Date.year = year;
    pFavoritePOI.Date.month = month;
    pFavoritePOI.Date.day = day;
    pFavoritePOI.Time.hour = hour;
    pFavoritePOI.Time.minute = min;
    pFavoritePOI.Time.second = second;
    
    pFavoritePOI.eCategory = favoritePoi.eCategory;
    pFavoritePOI.nIndex = favoritePoi.nIndex;
    
    pFavoritePOI.Poi.Coord.x = favoritePoi.longitude;
    pFavoritePOI.Poi.Coord.y = favoritePoi.latitude;
    pFavoritePOI.Poi.lCategoryID = favoritePoi.lCategoryID;
    pFavoritePOI.Poi.lDistance = favoritePoi.lDistance;
    pFavoritePOI.Poi.lMatchCode = favoritePoi.lMatchCode;
    pFavoritePOI.Poi.lHilightFlag = favoritePoi.lHilightFlag;
    pFavoritePOI.Poi.lAdminCode = favoritePoi.lAdminCode;
    pFavoritePOI.Poi.lPoiId = favoritePoi.lPoiId;
    pFavoritePOI.Poi.siELonOff = favoritePoi.siELonOff;
    pFavoritePOI.Poi.siELatOff = favoritePoi.siELatOff;
    
    const char *str =  NSSTRING_TO_CSTRING(favoritePoi.szName);
    if(str)
    {
        GcharMemcpy(pFavoritePOI.Poi.szName,str,GMAX_POI_NAME_LEN);
    }
    str = NSSTRING_TO_CSTRING(favoritePoi.szAddr);
    if(str)
    {
        GcharMemcpy(pFavoritePOI.Poi.szAddr,str,GMAX_POI_ADDR_LEN);
    }
    str = NSSTRING_TO_CSTRING(favoritePoi.szTel);
    if(str)
    {
        GcharMemcpy(pFavoritePOI.Poi.szTel,str,GMAX_POI_TEL_LEN);
    }

    pFavoritePOI.eIconID=GFAVORITE_ICON_DEFAULT;
    pFavoritePOI.Poi.lPoiIndex = favoritePoi.lPoiIndex;
    pFavoritePOI.Poi.ucFlag = favoritePoi.ucFlag;
    pFavoritePOI.Poi.Reserved = favoritePoi.Reserved;
    pFavoritePOI.Poi.usNodeId = favoritePoi.usNodeId;
    
    GSTATUS res = GDBL_EditFavorite(&pFavoritePOI);
    if (res == GD_ERR_OK && bAddToLoacl)           //成功，则将点同步至本地文件
    {
        /***将MWFavorite类 保存至本地文件 用于同步收藏夹内容 路径见宏 Favorite_Path History_Path***/
        NSString *file_path = Favorite_Path;
        if (favoritePoi.eCategory == GFAVORITE_CATEGORY_HISTORY)
        {
            file_path = History_Path;
        }
        
        favoritePoi.actionType = 3;     //编辑
        BOOL bExistPoi = NO;            //判断文件中是否存在编辑的poi点，如若没有，则添加至文件
        MWFavorite *favorite = nil;
        favorite = [NSKeyedUnarchiver unarchiveObjectWithFile:file_path];
        for (int i = 0 ; i < [favorite.pFavoritePOIArray count]; i++)
        {
            MWFavoritePoi *poi = [favorite.pFavoritePOIArray objectAtIndex:i];
            if (poi.longitude == favoritePoi.longitude && poi.latitude == favoritePoi.latitude)
            {
                bExistPoi = YES;
                if (poi.actionType == 2)        //如果已存在删除的点，则删除删除该点
                {
                    [favorite.pFavoritePOIArray removeObject:poi];
                    break;
                }
                [favorite.pFavoritePOIArray replaceObjectAtIndex:i withObject:favoritePoi];
                break;
            }
        }
        
        if (!bExistPoi)
        {
            if (favorite == nil)
            {
                favorite = [[[MWFavorite alloc] init] autorelease];
                favorite.pFavoritePOIArray = [NSMutableArray array];
            }
            [favorite.pFavoritePOIArray addObject:favoritePoi];
        }
        favorite.nNumberOfItem = [favorite.pFavoritePOIArray count];
        if (![NSKeyedArchiver archiveRootObject:favorite toFile:file_path])
        {
            NSLog(@"-------------同步至本地文件失败-----------------");
        }
        else
        {
            NSLog(@"-------------同步至本地文件成功-----------------");
        }
        /******/
    }
    return res;
}

+(GSTATUS)getPoiListWith:(GFAVORITECATEGORY)eCategory poiList:(MWFavorite **)resultList
{
    GFAVORITEPOILIST *ppFavoritePOIList = {0};
    GSTATUS res;
	res = GDBL_GetFavoriteList(eCategory, &ppFavoritePOIList);
    if (res != GD_ERR_OK)
    {
        *resultList = nil;
        return res;
    }
        
    MWFavorite *temp = [[[MWFavorite alloc] init] autorelease];
	int cellNumber = ppFavoritePOIList->nNumberOfItem;
    temp.nNumberOfItem = cellNumber;
    
    
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
	for (int i=0; i<cellNumber; i++)
	{
		MWFavoritePoi *node =[[MWFavoritePoi alloc] init];
        
        GFAVORITEPOI favorite_poiResult = ppFavoritePOIList->pFavoritePOI[i];
        node.Date = favorite_poiResult.Date;
        node.Time = favorite_poiResult.Time;
        node.eIconID = favorite_poiResult.eIconID;
        node.eCategory = favorite_poiResult.eCategory;
        node.nIndex = favorite_poiResult.nIndex;
        
        GPOI     poiResult = favorite_poiResult.Poi;
        node.longitude = poiResult.Coord.x;
		node.latitude = poiResult.Coord.y;
		node.lCategoryID = poiResult.lCategoryID;
		node.lDistance = poiResult.lDistance;
		node.lMatchCode = poiResult.lMatchCode;
		node.lHilightFlag = poiResult.lHilightFlag;
		node.lAdminCode = poiResult.lAdminCode;
		node.lPoiId = poiResult.lPoiId;
		node.siELonOff = poiResult.siELonOff;
		node.siELatOff = poiResult.siELatOff;
		node.szName = [NSString chinaFontStringWithCString:poiResult.szName];
		node.szAddr = [NSString chinaFontStringWithCString:poiResult.szAddr];
		node.szTel = [NSString chinaFontStringWithCString:poiResult.szTel];
		node.lPoiIndex = poiResult.lPoiIndex;
		node.ucFlag = poiResult.ucFlag;
		node.Reserved = poiResult.Reserved;
		node.usNodeId = poiResult.usNodeId;
        [array addObject:node];
        [node release];
	}
    temp.pFavoritePOIArray = array;
    [array release];
    
    *resultList = temp;
    
    return  res;
}

/*!
 @brief  删除收藏夹poi(参数为索引值)
 @param   index 收藏的兴趣点的索引 (即 MWFavoritePoi 类中的 nIndex)
 @return 删除成功返回GD_ERR_OK。其他错误码请参见 GSTATUS
 */
+(GSTATUS)deleteFavoriteWith:(GFAVORITECATEGORY)eCategory index:(int)index;
{
    MWFavoritePoi *favoritePoi = nil;
    
    MWFavorite *favorite = nil;
    [self getPoiListWith:eCategory poiList:&favorite];
    
    GSTATUS res = GDBL_DelFavorite(&index, 1);
    if (res == GD_ERR_OK && bAddToLoacl)           //成功，则将点同步至本地文件
    {
        for (MWFavoritePoi *temp in favorite.pFavoritePOIArray)
        {
            if (index == temp.nIndex)
            {
                favoritePoi = temp;
                break;
            }
        }
        if (favoritePoi == nil)
        {
            return res;
        }
        
        /***将MWFavorite类 保存至本地文件 用于同步收藏夹内容 路径见宏 Favorite_Path History_Path***/
        NSString *file_path = Favorite_Path;
        if (favoritePoi.eCategory == GFAVORITE_CATEGORY_HISTORY)
        {
            file_path = History_Path;
        } 
        
        favoritePoi.actionType = 2;     //删除
        BOOL bExistPoi = NO;            //判断文件中是否存在删除的poi点，如若没有，则添加至文件
        favorite = [NSKeyedUnarchiver unarchiveObjectWithFile:file_path];
        for (int i = 0 ; i < [favorite.pFavoritePOIArray count]; i++)
        {
            MWFavoritePoi *poi = [favorite.pFavoritePOIArray objectAtIndex:i];
            if (poi.longitude == favoritePoi.longitude && poi.latitude == favoritePoi.latitude)
            {
                bExistPoi = YES;
                if (poi.actionType != 2)        //如果已存在删除或更新的点，则删除该点
                {
                    [favorite.pFavoritePOIArray removeObject:poi];
                    break;
                }
                [favorite.pFavoritePOIArray replaceObjectAtIndex:i withObject:favoritePoi];
                bExistPoi = YES;
                break;
            }
        }
        
        if (!bExistPoi)
        {
            if (favorite == nil)
            {
                favorite = [[[MWFavorite alloc] init] autorelease];
                favorite.pFavoritePOIArray = [NSMutableArray array];
            }
            [favorite.pFavoritePOIArray addObject:favoritePoi];
        }
        favorite.nNumberOfItem = [favorite.pFavoritePOIArray count];
        if (![NSKeyedArchiver archiveRootObject:favorite toFile:file_path])
        {
            NSLog(@"-------------同步至本地文件失败-----------------");
        }
        else
        {
            NSLog(@"-------------同步至本地文件成功-----------------");
        }
        /******/
    }
    return res;
}

/*!
 @brief  清空收藏夹兴趣点
 @param   eCategory poi的类型
 @return 删除成功返回GD_ERR_OK。其他错误码请参见 GSTATUS
 */
+(GSTATUS)clearFavoriteWith:(GFAVORITECATEGORY)eCategory
{
    MWFavorite *temp_favorite = nil;
    [self getPoiListWith:eCategory poiList:&temp_favorite];

    GSTATUS res = GDBL_ClearFavorite(eCategory);
    if (res == GD_ERR_OK && bAddToLoacl)
    {
        /***将MWFavorite类 保存至本地文件 用于同步收藏夹内容 路径见宏 Favorite_Path History_Path***/
        NSString *file_path = Favorite_Path;
        if (eCategory == GFAVORITE_CATEGORY_HISTORY)
        {
            file_path = History_Path;
        }
        
        MWFavorite *favorite = [NSKeyedUnarchiver unarchiveObjectWithFile:file_path];
        if (favorite == nil)
        {
            favorite = [[[MWFavorite alloc] init] autorelease];
        }
        
        for (int i = 0 ; i < [temp_favorite.pFavoritePOIArray count]; i++)
        {
            MWFavoritePoi *poi = [temp_favorite.pFavoritePOIArray objectAtIndex:i];
            poi.actionType = 2;
            BOOL bAdd = YES;
            for (int j = 0; j < [favorite.pFavoritePOIArray count]; j++)
            {
                MWFavoritePoi *temp = [favorite.pFavoritePOIArray objectAtIndex:j];
                if (temp.latitude == poi.latitude && temp.longitude == poi.longitude)
                {
                    bAdd = NO;
                    if (poi.actionType != 2)        //如果已存在删除或更新的点，则删除该点
                    {
                        [favorite.pFavoritePOIArray removeObject:poi];
                        break;
                    }
                }
            }
            if (bAdd)
            {
                [favorite.pFavoritePOIArray addObject:poi];
            }
        }
        favorite.nNumberOfItem = [favorite.pFavoritePOIArray count];
        if (![NSKeyedArchiver archiveRootObject:favorite toFile:file_path])
        {
            NSLog(@"-------------同步至本地文件失败-----------------");
        }
        else
        {
            NSLog(@"-------------同步至本地文件成功-----------------");
        }
        /******/

    }
	return res;
}

/**
 *	判断该点是否收藏
 *
 *	@param	favoritePoi	要判断的点
 *
 *	@return	已收藏返回YES，未收藏返回NO
 */
+ (BOOL)isCollect:(MWPoi *)favoritePoi
{
    if (favoritePoi == nil)
    {
        return NO;
    }
    GPOI pPOI = {0};
    pPOI.Coord.x = favoritePoi.longitude;
    pPOI.Coord.y = favoritePoi.latitude;
    pPOI.lCategoryID = favoritePoi.lCategoryID;
    pPOI.lDistance = favoritePoi.lDistance;
    pPOI.lMatchCode = favoritePoi.lMatchCode;
    pPOI.lHilightFlag = favoritePoi.lHilightFlag;
    pPOI.lAdminCode = favoritePoi.lAdminCode;
    pPOI.lPoiId = favoritePoi.lPoiId;
    pPOI.siELonOff = favoritePoi.siELonOff;
    pPOI.siELatOff = favoritePoi.siELatOff;
    
    const char *str =  NSSTRING_TO_CSTRING(favoritePoi.szName);
    if(str)
    {
        GcharMemcpy(pPOI.szName,str,GMAX_POI_NAME_LEN);
    }
    str = NSSTRING_TO_CSTRING(favoritePoi.szAddr);
    if(str)
    {
        GcharMemcpy(pPOI.szAddr,str,GMAX_POI_ADDR_LEN);
    }
    str = NSSTRING_TO_CSTRING(favoritePoi.szTel);
    if(str)
    {
        GcharMemcpy(pPOI.szTel,str,GMAX_POI_TEL_LEN);
    }
    
    pPOI.lPoiIndex = favoritePoi.lPoiIndex;
    pPOI.ucFlag = favoritePoi.ucFlag;
    pPOI.Reserved = favoritePoi.Reserved;
    pPOI.usNodeId = favoritePoi.usNodeId;
    
    Gbool pbFavorited;
    if (GD_ERR_OK == GDBL_IsFavorited(GFAVORITE_CATEGORY_DEFAULT, &pPOI, &pbFavorited))
    {
        return pbFavorited;
    }
    return NO;
}

/**
 *	若该点已收藏，则取消收藏该点，若未收藏则收藏该点
 *
 *	@param	favoritePoi	要收藏的点
 *
 *	@return	收藏，取消收藏成功返回YES 否则返回NO
 */
+ (BOOL)reverseCollectPoi:(MWPoi *)favoritePoi
{
    if (favoritePoi == nil)
    {
        return NO;
    }
    GPOI pPOI = {0};
    pPOI.Coord.x = favoritePoi.longitude;
    pPOI.Coord.y = favoritePoi.latitude;
    pPOI.lCategoryID = favoritePoi.lCategoryID;
    pPOI.lDistance = favoritePoi.lDistance;
    pPOI.lMatchCode = favoritePoi.lMatchCode;
    pPOI.lHilightFlag = favoritePoi.lHilightFlag;
    pPOI.lAdminCode = favoritePoi.lAdminCode;
    pPOI.lPoiId = favoritePoi.lPoiId;
    pPOI.siELonOff = favoritePoi.siELonOff;
    pPOI.siELatOff = favoritePoi.siELatOff;
    
    const char *str =  NSSTRING_TO_CSTRING(favoritePoi.szName);
    if(str)
    {
        GcharMemcpy(pPOI.szName,str,GMAX_POI_NAME_LEN);
    }
    str = NSSTRING_TO_CSTRING(favoritePoi.szAddr);
    if(str)
    {
        GcharMemcpy(pPOI.szAddr,str,GMAX_POI_ADDR_LEN);
    }
    str = NSSTRING_TO_CSTRING(favoritePoi.szTel);
    if(str)
    {
        GcharMemcpy(pPOI.szTel,str,GMAX_POI_TEL_LEN);
    }
    
    pPOI.lPoiIndex = favoritePoi.lPoiIndex;
    pPOI.ucFlag = favoritePoi.ucFlag;
    pPOI.Reserved = favoritePoi.Reserved;
    pPOI.usNodeId = favoritePoi.usNodeId;
    
    Gbool pbFavorited;
    if (GD_ERR_OK == GDBL_IsFavorited(GFAVORITE_CATEGORY_DEFAULT, &pPOI, &pbFavorited))
    {
        if (pbFavorited)
        {
            GFAVORITEPOILIST *ppFavoritePOIList;
            GSTATUS res;
            res = GDBL_GetFavoriteList(GFAVORITE_CATEGORY_DEFAULT, &ppFavoritePOIList);      //获取引擎中的电子眼信息
            if( GD_ERR_OK == res)
            {
                for (int i = 0; i < ppFavoritePOIList->nNumberOfItem; i++)
                {
                    GFAVORITEPOI pFavoritePOI = ppFavoritePOIList->pFavoritePOI[i];
                    if (pFavoritePOI.Poi.Coord.x == pPOI.Coord.x && pFavoritePOI.Poi.Coord.y == pPOI.Coord.y)
                    {
                        GSTATUS res = [self deleteFavoriteWith:GFAVORITE_CATEGORY_DEFAULT index:pFavoritePOI.nIndex];
                        if (res == GD_ERR_OK)
                        {
                            return YES;
                        }
                    }
                }
            }
        }
        else
        {
            MWFavoritePoi *favorite_temp = [[[MWFavoritePoi alloc] init] autorelease];
            favorite_temp.eCategory = GFAVORITE_CATEGORY_DEFAULT;
            favorite_temp.eIconID = GFAVORITE_ICON_DEFAULT;
            favorite_temp.longitude = favoritePoi.longitude;
            favorite_temp.latitude = favoritePoi.latitude;
            favorite_temp.lCategoryID = favoritePoi.lCategoryID;
            favorite_temp.lDistance = favoritePoi.lDistance;
            favorite_temp.lMatchCode = favoritePoi.lMatchCode;
            favorite_temp.lHilightFlag = favoritePoi.lHilightFlag;
            favorite_temp.lAdminCode = favoritePoi.lAdminCode;
            favorite_temp.lPoiId = favoritePoi.lPoiId;
            favorite_temp.siELonOff = favoritePoi.siELonOff;
            favorite_temp.siELatOff = favoritePoi.siELatOff;
            favorite_temp.lPoiIndex = favoritePoi.lPoiIndex;
            favorite_temp.ucFlag = favoritePoi.ucFlag;
            favorite_temp.Reserved = favoritePoi.Reserved;
            favorite_temp.usNodeId = favoritePoi.usNodeId;
            favorite_temp.szAddr = favoritePoi.szAddr;
            favorite_temp.szName = favoritePoi.szName;
            favorite_temp.szTel = favoritePoi.szTel;
            favorite_temp.szTown = favoritePoi.szTown;
            GSTATUS res = [self collectPoiWith:favorite_temp];
            if (res == GD_ERR_OK)
            {
                return YES;
            }
        }
    }
    return NO;
}

/**
 *	MWPoi 结构转 GPoi结构
 *
 *	@param	mwPoi 传入的值 gPoi 转化后的值
 *
 *	@return	转化成功返回YES 否则返回NO
 */
+ (BOOL)MWPoiToGPoi:(MWPoi *)mwPoi GPoi:(GPOI *)gPoi
{
    if (mwPoi == nil)
    {
        return NO;
    }
    
    gPoi->Coord.x = mwPoi.longitude;
    gPoi->Coord.y = mwPoi.latitude;
    gPoi->lCategoryID = mwPoi.lCategoryID;
    gPoi->lDistance = mwPoi.lDistance;
    gPoi->lMatchCode = mwPoi.lMatchCode;
    gPoi->lHilightFlag = mwPoi.lHilightFlag;
    gPoi->lAdminCode = mwPoi.lAdminCode;
    gPoi->lPoiId = mwPoi.lPoiId;
    gPoi->siELonOff = mwPoi.siELonOff;
    gPoi->siELatOff = mwPoi.siELatOff;
    
    Gchar *str =  NSSTRING_TO_CSTRING(mwPoi.szName);
    if(str)
    {
        GcharMemcpy(gPoi->szName, str, GMAX_POI_NAME_LEN+1);
    }
    str = NSSTRING_TO_CSTRING(mwPoi.szAddr);
    if(str)
    {
        GcharMemcpy(gPoi->szAddr, str, GMAX_POI_NAME_LEN+1);
    }
    str = NSSTRING_TO_CSTRING(mwPoi.szTel);
    if(str)
    {
        GcharMemcpy(gPoi->szTel, str, GMAX_POI_NAME_LEN+1);
    }
    
    gPoi->lPoiIndex = mwPoi.lPoiIndex;
    gPoi->ucFlag = mwPoi.ucFlag;
    gPoi->Reserved = mwPoi.Reserved;
    return YES;
}

#pragma mark 电子眼接口

/*!
 @brief  同步电子眼
 @param   option 电子眼同步条件
 @param   type     请求类型
 @param   delegate     委托，同步结果的返回
 */
+ (BOOL)synSmartEyesWith:(MWSmartEyesOption *)option requestType:(RequestType)type delegate:(id<MWPoiOperatorDelegate>)delegate
{
    MWSmartEyes *smartEyes = nil;
    smartEyes = [NSKeyedUnarchiver unarchiveObjectWithFile:SmartEye_Path];
    if (smartEyes == nil)
    {
        NSLog(@"无文件数据");
        smartEyes = [[[MWSmartEyes alloc] init ]autorelease];
    }
    /**
     组转上传数据
     */
    NSArray *poiList = smartEyes.smartEyesArray;  //上传改动的poi信息
    NSArray *array;
    GDBL_GetAccountInfo(&array);
    int loginType = [[array objectAtIndex:0] intValue];
    NSString *url = nil;
    NSString *userName = nil;
    if (loginType == 0)
    {
        return NO;
    }
    else if (loginType == 3 || loginType == 5)
    {
        url = [NSString stringWithFormat:@"%@%@out=xml&tpuserid=%@&tptype=1",kNetDomain,Syn_SmartEye,[array objectAtIndex:5]];
        userName = [[array objectAtIndex:5] stringByAppendingString:@"1"];  //记录用户名
    }
    else if (loginType == 4 || loginType == 6)
    {
        url = [NSString stringWithFormat:@"%@%@out=xml&tpuserid=%@&tptype=2",kNetDomain,Syn_SmartEye,[array objectAtIndex:5]];
        userName = [[array objectAtIndex:5] stringByAppendingString:@"2"];  //记录用户名
    }
    else
    {
        url = [NSString stringWithFormat:@"%@%@out=xml&username=%@&password=%@",kNetDomain,Syn_SmartEye,[array objectAtIndex:1],[array objectAtIndex:2]];
        userName = [array objectAtIndex:1];  //记录用户名
    }
    
    //判断上次同步的 用户与此次是否相同，不同则将时间置为较早时间
    if (![smartEyes.userName isEqualToString:userName])
    {
        GDATE	Date_tmp = {1975,1,1};
        smartEyes.Date	= Date_tmp;
        GTIME	Time_tmp = {1,1,1};
        smartEyes.Time	= Time_tmp;
        MWSmartEyes *allSmartEyes;
        [self getSmartEyesListWith:GSAFE_CATEGORY_ALL poiList:&allSmartEyes];
        for (MWSmartEyesItem *temp in allSmartEyes.smartEyesArray)
        {
            temp.actionType = 1;
        }
        poiList = allSmartEyes.smartEyesArray;
    }
    
    NSString *temp = @"<?xml version=\"1.0\" encoding=\"utf-8\"?><archive>";
    temp = [temp stringByAppendingFormat:@"<lasttime>%d-%02d-%02d %02d:%02d:%02d</lasttime><context>",smartEyes.Date.year,smartEyes.Date.month,smartEyes.Date.day,smartEyes.Time.hour,smartEyes.Time.minute,smartEyes.Time.second];
	for(int i = 0; i < [poiList count]; i++)
    {
		MWSmartEyesItem *tmp = [poiList objectAtIndex:i];
		temp = [temp stringByAppendingFormat:@"<item><item_id>%d</item_id><longitude>%ld</longitude>",0,tmp.longitude];
		temp = [temp stringByAppendingFormat:@"<latitude>%ld</latitude>",tmp.latitude];
		temp = [temp stringByAppendingFormat:@"<name>%@</name>",tmp.szName];
		temp = [temp stringByAppendingFormat:@"<type>0001</type>"];
		temp = [temp stringByAppendingFormat:@"<flag>%d</flag><town>%@</town><angle>%d</angle>",tmp.eCategory,@"",tmp.nAngle];
		temp = [temp stringByAppendingFormat:@"<speed>%d</speed><detail></detail><state>%d</state></item>",tmp.nSpeed,tmp.actionType];
    }
	if ([poiList count] == 0)
    {
        temp = [temp stringByAppendingString:@"<item></item>"];
    }
	temp = [temp stringByAppendingString:@"</context></archive>"];
	NSData *requstBody = [temp dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    
    MWPoiOperator *operator = [[MWPoiOperator alloc] initWithDelegate:delegate];    //回调中释放
    operator.userName = userName;
    operator.originalClass = object_getClass(delegate);
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = url;
    net_condition.bodyData = requstBody;
    net_condition.httpMethod = @"POST";
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:operator];
    
    return YES;
}

/*!
 @brief  取消同步收藏电子眼
 @param   type     请求类型
 @return	成功返回YES 否则返回NO
 */
+ (BOOL)cancelSynSmartEyesWith:(RequestType)type
{
    return [[NetExt sharedInstance] Net_CancelRequestWithType:type];
}

/*!
 @brief  收藏电子眼
 @param smartEyesItem 收藏条件   注：（无需设置Date，Time两个参数）
 @return 收藏成功返回GD_ERR_OK，重复收藏返回GD_ERR_DUPLICATE_DATA。其他错误码请参见 GSTATUS
 */
+(GSTATUS)collectSmartEyesWith:(MWSmartEyesItem *)smartEyesItem
{
    GUSERSAFEINFO pSafeInfo = {0};
    pSafeInfo.nIndex = smartEyesItem.nIndex;
    pSafeInfo.lAdminCode = smartEyesItem.lAdminCode;
    pSafeInfo.eCategory = smartEyesItem.eCategory;
    pSafeInfo.coord.x = smartEyesItem.longitude;
    pSafeInfo.coord.y = smartEyesItem.latitude;
    pSafeInfo.nSpeed = smartEyesItem.nSpeed;
    pSafeInfo.nAngle = smartEyesItem.nAngle;
    
    const char *str = NSSTRING_TO_CSTRING(smartEyesItem.szName) ;
    if(str)
    {
        GcharMemcpy(pSafeInfo.szName,str,GMAX_CLASS_NAME_LEN);
    }
    
    NSDate *localDate = [NSDate date];
    NSCalendar  * cal=[NSCalendar  currentCalendar];
    NSUInteger  unitFlags=NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;
    NSDateComponents * conponent= [cal components:unitFlags fromDate:localDate];
    NSInteger year=[conponent year];
    NSInteger month=[conponent month];
    NSInteger day=[conponent day];
    
    NSDateFormatter *timeFormatter = [[[NSDateFormatter alloc]init]autorelease];
    timeFormatter.dateFormat = @"HH:mm:ss";
    NSString *dateString = [timeFormatter stringFromDate:localDate];
    NSInteger hour = [[dateString CutToNSString:@":"] intValue];
    NSInteger min = [[dateString CutFromNSString:@":" Tostring:@":"] intValue];
    NSInteger second = [[dateString CutToNSStringBackWard:@":"] intValue];
    
    pSafeInfo.Date.year = year;
    pSafeInfo.Date.month = month;
    pSafeInfo.Date.day = day;
    pSafeInfo.Time.hour = hour;
    pSafeInfo.Time.minute = min;
    pSafeInfo.Time.second = second;
    
    
    GSTATUS res = GDBL_AddUserSafeInfo(&pSafeInfo);
    if (res == GD_ERR_OK && bAddToLoacl)
    {
        /***将MWFavorite类 保存至本地文件 用于同步收藏夹内容 路径见宏 Favorite_Path History_Path***/
        NSString *file_path = SmartEye_Path;
        
        smartEyesItem.actionType = 1;     //添加
        MWSmartEyes *smartEyes = nil;
        BOOL bExistPoi = NO;            //判断文件中是否存在添加的poi点，如若没有，则添加至文件
        smartEyes = [NSKeyedUnarchiver unarchiveObjectWithFile:file_path];
        for (int i = 0 ; i < [smartEyes.smartEyesArray count]; i++)
        {
            MWSmartEyesItem *poi = [smartEyes.smartEyesArray objectAtIndex:i];
            if (poi.longitude == smartEyesItem.longitude && poi.latitude == smartEyesItem.latitude)
            {
                bExistPoi = YES;
                if (poi.actionType == 2)        //如果已存在删除的点，则删除该点
                {
                    [smartEyes.smartEyesArray removeObject:poi];
                    break;
                }
                [smartEyes.smartEyesArray replaceObjectAtIndex:i withObject:smartEyesItem];
                break;
            }
        }
        
        if (!bExistPoi)
        {
            if (smartEyes == nil)
            {
                smartEyes = [[[MWSmartEyes alloc] init] autorelease];
                smartEyes.smartEyesArray = [NSMutableArray array];
            }
            
            [smartEyes.smartEyesArray addObject:smartEyesItem];
        }
        smartEyes.nNumberOfItem = [smartEyes.smartEyesArray count];
        if (![NSKeyedArchiver archiveRootObject:smartEyes toFile:file_path])
        {
            NSLog(@"-------------同步至本地文件失败-----------------");
        }
        else
        {
            NSLog(@"-------------同步至本地文件成功-----------------");
        }
        /******/
    }
	
	return res;
}


/*!
 @brief  编辑已收藏的电子眼
 @param  favoritePoi 编辑后的电子眼  注：（无需设置Date，Time两个参数）
 @return 编辑成功返回GD_ERR_OK。其他错误码请参见 GSTATUS
 */
+(GSTATUS)editeSmartEyesWith:(MWSmartEyesItem *)smartEyesItem
{
    GUSERSAFEINFO pSafeInfo = {0};
    pSafeInfo.nIndex = smartEyesItem.nIndex;
    pSafeInfo.lAdminCode = smartEyesItem.lAdminCode;
    pSafeInfo.eCategory = smartEyesItem.eCategory;
    pSafeInfo.coord.x = smartEyesItem.longitude;
    pSafeInfo.coord.y = smartEyesItem.latitude;
    pSafeInfo.nSpeed = smartEyesItem.nSpeed;
    pSafeInfo.nAngle = smartEyesItem.nAngle;
    
    const char *str =NSSTRING_TO_CSTRING(smartEyesItem.szName)  ;
    if(str)
    {
        GcharMemcpy(pSafeInfo.szName,str,GMAX_CLASS_NAME_LEN);
    }
    
    NSDate *localDate = [NSDate date];
    NSCalendar  * cal=[NSCalendar  currentCalendar];
    NSUInteger  unitFlags=NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;
    NSDateComponents * conponent= [cal components:unitFlags fromDate:localDate];
    NSInteger year=[conponent year];
    NSInteger month=[conponent month];
    NSInteger day=[conponent day];
    
    NSDateFormatter *timeFormatter = [[[NSDateFormatter alloc]init]autorelease];
    timeFormatter.dateFormat = @"HH:mm:ss";
    NSString *dateString = [timeFormatter stringFromDate:localDate];
    NSInteger hour = [[dateString CutToNSString:@":"] intValue];
    NSInteger min = [[dateString CutFromNSString:@":" Tostring:@":"] intValue];
    NSInteger second = [[dateString CutToNSStringBackWard:@":"] intValue];
    
    pSafeInfo.Date.year = year;
    pSafeInfo.Date.month = month;
    pSafeInfo.Date.day = day;
    pSafeInfo.Time.hour = hour;
    pSafeInfo.Time.minute = min;
    pSafeInfo.Time.second = second;
    
//    GUSERSAFEINFOLIST  *ppSafeInfoList;
//	GSTATUS res = GDBL_GetUserSafeInfoList(smartEyesItem.eCategory,&ppSafeInfoList);   //在编辑电子眼前需要获取电子眼列表
    
    GSTATUS res = GDBL_EditUserSafeInfo(&pSafeInfo);
    if (res == GD_ERR_OK && bAddToLoacl)
    {
        /***将MWFavorite类 保存至本地文件 用于同步收藏夹内容 路径见宏 Favorite_Path History_Path***/
        NSString *file_path = SmartEye_Path;
        
        smartEyesItem.actionType = 3;     //编辑
        MWSmartEyes *smartEyes = nil;
        BOOL bExistPoi = NO;            //判断文件中是否存在编辑的poi点，如若没有，则添加至文件
        smartEyes = [NSKeyedUnarchiver unarchiveObjectWithFile:file_path];
        for (int i = 0 ; i < [smartEyes.smartEyesArray count]; i++)
        {
            MWSmartEyesItem *poi = [smartEyes.smartEyesArray objectAtIndex:i];
            if (poi.longitude == smartEyesItem.longitude && poi.latitude == smartEyesItem.latitude)
            {
                bExistPoi = YES;
                if (poi.actionType == 2)        //如果已存在删除的点，则删除该点
                {
                    [smartEyes.smartEyesArray removeObject:poi];
                    break;
                }
                [smartEyes.smartEyesArray replaceObjectAtIndex:i withObject:smartEyesItem];
                break;
            }
        }
        
        if (!bExistPoi)
        {
            if (smartEyes == nil)
            {
                smartEyes = [[[MWSmartEyes alloc] init] autorelease];
                smartEyes.smartEyesArray = [NSMutableArray array];
            }
            [smartEyes.smartEyesArray addObject:smartEyesItem];
        }
        smartEyes.nNumberOfItem = [smartEyes.smartEyesArray count];
        if (![NSKeyedArchiver archiveRootObject:smartEyes toFile:file_path])
        {
            NSLog(@"-------------同步至本地文件失败-----------------");
        }
        else
        {
            NSLog(@"-------------同步至本地文件成功-----------------");
        }
        /******/
    }
	return res;
}

/*!
 @brief  获取已收藏的电子眼列表
 @param   eCategory 收藏的电子眼类别GSAFECATEGORY，用于标识要获取的收藏夹类别。
 @param   resultList 输出，用于返回收藏夹兴趣点列表。
 @return 收藏获取列表返回GD_ERR_OK。其他错误码请参见 GSTATUS
 */
+(GSTATUS)getSmartEyesListWith:(GSAFECATEGORY)eCategory poiList:(MWSmartEyes **)resultList
{
    GUSERSAFEINFOLIST  *ppSafeInfoList;
	GSTATUS res = GDBL_GetUserSafeInfoList(eCategory,&ppSafeInfoList);
	if( GD_ERR_OK != res)
	{
        *resultList = nil;
        return res;
	}
    
    g_smartEyesCategory = eCategory;
    
    MWSmartEyes  *smartEyes = [[[MWSmartEyes alloc] init] autorelease];
    
    int count = ppSafeInfoList->nNumberOfItem;
    smartEyes.nNumberOfItem = count;
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (int i = 0; i < count; i++)
    {
        MWSmartEyesItem *smartEyesItem = [[MWSmartEyesItem alloc] init];
        smartEyesItem.nIndex = ppSafeInfoList->pSafeInfo[i].nIndex;
        smartEyesItem.lAdminCode = ppSafeInfoList->pSafeInfo[i].lAdminCode;
        smartEyesItem.eCategory = ppSafeInfoList->pSafeInfo[i].eCategory;
        smartEyesItem.longitude = ppSafeInfoList->pSafeInfo[i].coord.x;
        smartEyesItem.latitude = ppSafeInfoList->pSafeInfo[i].coord.y;
        smartEyesItem.nSpeed = ppSafeInfoList->pSafeInfo[i].nSpeed;
        smartEyesItem.nAngle = ppSafeInfoList->pSafeInfo[i].nAngle;
        smartEyesItem.szName = [NSString chinaFontStringWithCString:ppSafeInfoList->pSafeInfo[i].szName];
        [array addObject:smartEyesItem];
        [smartEyesItem release];
        smartEyesItem = nil;
    }
    smartEyes.smartEyesArray = array;
    [array release];
    
    *resultList = smartEyes;
    
    return res;
}

/*!
 @brief  删除收藏夹poi(参数为索引值)
 @param   index 收藏的电子眼的索引 (即 MWSmartEyesItem 类中的 nIndex)
 @return 删除成功返回GD_ERR_OK。其他错误码请参见 GSTATUS
 */
+(GSTATUS)deleteSmartEyesWithIndex:(int)index
{
    MWSmartEyesItem *smartEyesItem = nil;
    MWSmartEyes *smartEyes = nil;
    [self getSmartEyesListWith:g_smartEyesCategory poiList:&smartEyes];
    
    GSTATUS res = GDBL_DelUserSafeInfo(&index, 1);
    if (res == GD_ERR_OK && bAddToLoacl)
    {
        NSArray *poiList = smartEyes.smartEyesArray;
        
        for (MWSmartEyesItem *temp in poiList)
        {
            if (index == temp.nIndex)
            {
                smartEyesItem = temp;
                break;
            }
        }
        if (smartEyesItem == nil)
        {
            return res;
        }
        /***将MWFavorite类 保存至本地文件 用于同步收藏夹内容 路径见宏 Favorite_Path History_Path***/
        NSString *file_path = SmartEye_Path;
        
        smartEyesItem.actionType = 2;     //删除
        MWSmartEyes *smartEyes = nil;
        BOOL bExistPoi = NO;            //判断文件中是否存在删除的电子眼，如若没有，则添加至文件
        smartEyes = [NSKeyedUnarchiver unarchiveObjectWithFile:file_path];
        for (int i = 0 ; i < [smartEyes.smartEyesArray count]; i++)
        {
            MWSmartEyesItem *poi = [smartEyes.smartEyesArray objectAtIndex:i];
            if (poi.longitude == smartEyesItem.longitude && poi.latitude == smartEyesItem.latitude)
            {
                bExistPoi = YES;
                if (poi.actionType != 2)        //如果已存在添加或修改的点，则删除该点
                {
                    [smartEyes.smartEyesArray removeObject:poi];
                    break;
                }
                [smartEyes.smartEyesArray replaceObjectAtIndex:i withObject:smartEyesItem];
                break;
            }
        }
        
        if (!bExistPoi)
        {
            if (smartEyes == nil)
            {
                smartEyes = [[[MWSmartEyes alloc] init] autorelease];
                smartEyes.smartEyesArray = [NSMutableArray array];
            }
            [smartEyes.smartEyesArray addObject:smartEyesItem];
        }
        smartEyes.nNumberOfItem = [smartEyes.smartEyesArray count];
        if (![NSKeyedArchiver archiveRootObject:smartEyes toFile:file_path])
        {
            NSLog(@"-------------同步至本地文件失败-----------------");
        }
        else
        {
            NSLog(@"-------------同步至本地文件成功-----------------");
        }
        /******/
    }
    
    return res;
}

/*!
 @brief  清空收藏夹兴趣点
 @param   eCategory 电子眼的类型
 @return 删除成功返回GD_ERR_OK。其他错误码请参见 GSTATUS
 */
+(GSTATUS)clearSmartEyesWith:(GSAFECATEGORY)eCategory
{
    MWSmartEyes *smartEyes_temp = nil;
    [self getSmartEyesListWith:eCategory poiList:&smartEyes_temp];
    
    GSTATUS res = GDBL_ClearUserSafeInfo(eCategory);
    if (res == GD_ERR_OK && bAddToLoacl)
    {
        /***将MWFavorite类 保存至本地文件 用于同步收藏夹内容 路径见宏 Favorite_Path History_Path***/
        NSString *file_path = SmartEye_Path;
        
        MWSmartEyes *smartEyes = [NSKeyedUnarchiver unarchiveObjectWithFile:file_path];
        if (smartEyes == nil)
        {
            smartEyes = [[[MWSmartEyes alloc] init] autorelease];
            smartEyes.smartEyesArray = [NSMutableArray array];
        }
        
        for (int i = 0 ; i < [smartEyes_temp.smartEyesArray count]; i++)
        {
            MWSmartEyesItem *poi = [smartEyes_temp.smartEyesArray objectAtIndex:i];
            poi.actionType = 2;
            BOOL bAdd = YES;
            for (int j = 0; j < [smartEyes.smartEyesArray count]; j++)
            {
                MWSmartEyesItem *temp = [smartEyes.smartEyesArray objectAtIndex:j];
                if (temp.latitude == poi.latitude && temp.longitude == poi.longitude)
                {
                    bAdd = NO;
                    if (poi.actionType != 2)        //如果已存在添加或修改的点，则删除该点
                    {
                        [smartEyes.smartEyesArray removeObject:poi];
                        break;
                    }
                }
            }
            if (bAdd)
            {
                [smartEyes.smartEyesArray addObject:poi];
            }
        }
        smartEyes.nNumberOfItem = [smartEyes.smartEyesArray count];
        if (![NSKeyedArchiver archiveRootObject:smartEyes toFile:file_path])
        {
            NSLog(@"-------------同步至本地文件失败-----------------");
        }
        else
        {
            NSLog(@"-------------同步至本地文件成功-----------------");
        }
        /******/
        
    }
    return res;
}

#pragma mark  联系人 接口

/*!
 @brief  上传联系人   回调：
 成功 -(void)uploadSuccessWith:(RequestType)type result:(id)result;
 失败 -(void)uploadFailWith:(RequestType)type error:(NSError *)error;
 @param   option 上传联系人时的条件
 @param   type 请求类型
 */
+(void)uploadContactWith:(MWContactOption *)option requestType:(RequestType)type delegate:(id<MWPoiOperatorDelegate>)delegate
{
    MWContact *contact = nil;
    [self getContactList:&contact];
    
	NSArray *poiList = contact.contactArray;
    
    NSArray *array = [[Account AccountInstance] getAccountInfo];
    int loginType = [[array objectAtIndex:0] intValue];
    
    NSString *url;
    
    if (loginType == 3 || loginType == 5)
    {
        url = [NSString stringWithFormat:@"%@favorites/uploadphonebook_v2/?out=xml&tpuserid=%@&tptype=1",kNetDomain,[array objectAtIndex:5]];
    }
    else if (loginType == 4 || loginType == 6)
    {
        url = [NSString stringWithFormat:@"%@favorites/uploadphonebook_v2/?out=xml&tpuserid=%@&tptype=2",kNetDomain,[array objectAtIndex:5]];
    }
    else
    {
        url = [NSString stringWithFormat:@"%@favorites/uploadphonebook_v2/?out=xml&username=%@&password=%@",kNetDomain,option.userName,option.password];
    }
    
	NSString *temp = @"<?xml version=\"1.0\" encoding=\"utf-8\"?><archive><context>";
	
	for(int i = 0; i < [poiList count]; i++)
    {
        NameIndex *tmp = [poiList objectAtIndex:i];
        if (tmp._fullName == nil) {
			tmp._fullName = @"";
		}
		temp = [temp stringByAppendingFormat:@"<item><item_id>%d</item_id><name>%@</name>",i+1,tmp._fullName];
        
		
        
        temp = [temp stringByAppendingString:@"<phonenum>"];
        for (int j = 0; j < [tmp.phoneArray count]; j++) {
            temp = [temp stringByAppendingFormat:@"<phoneitem><phonetype>%@</phonetype><phonestring>%@</phonestring></phoneitem>",[tmp.phoneTypeArray objectAtIndex:j],[tmp.phoneArray objectAtIndex:j]];
        }
        temp = [temp stringByAppendingString:@"</phonenum>"];
        
        temp = [temp stringByAppendingString:@"<address>"];
		for (int j = 0; j < [tmp.addressArray count]; j++) {
            AddressItem *addressItem = [tmp.addressArray objectAtIndex:j];
			if (addressItem.type == nil) {
				addressItem.type = @"";
			}
			if (addressItem.city == nil) {
				addressItem.city = @"";
			}
			if (addressItem.country == nil) {
				addressItem.country = @"";
			}
			if (addressItem.countryCode == nil) {
				addressItem.countryCode = @"";
			}
			if (addressItem.state == nil) {
				addressItem.state = @"";
			}
			if (addressItem.street == nil) {
				addressItem.street = @"";
			}
			if (addressItem.zip == nil) {
				addressItem.zip = @"";
			}
            temp = [temp stringByAppendingFormat:@"<addressitem><addresstype>%@</addresstype><city>%@</city><country>%@</country><countrycode>%@</countrycode><state>%@</state><street>%@</street><zip>%@</zip></addressitem>",addressItem.type ,addressItem.city,addressItem.country,addressItem.countryCode,addressItem.state,addressItem.street,addressItem.zip];
        }
        temp = [temp stringByAppendingString:@"</address>"];
        
        temp = [temp stringByAppendingString:@"<email>"];
		for (int j = 0; j < [tmp.emailArray count]; j++) {
            temp = [temp stringByAppendingFormat:@"<emailitem><emailtype>%@</emailtype><emailstring>%@</emailstring></emailitem>",[tmp.emailTypeArray objectAtIndex:j],[tmp.emailArray objectAtIndex:j]];
        }
        temp = [temp stringByAppendingString:@"</email>"];
        
        temp = [temp stringByAppendingString:@"<url>"];
		for (int j = 0; j < [tmp.URLArray count]; j++) {
            temp = [temp stringByAppendingFormat:@"<urlitem><urltype>%@</urltype><urlstring>%@</urlstring><lastedittime>%@</lastedittime></urlitem>",[tmp.URLTypeArray objectAtIndex:j],[tmp.URLArray objectAtIndex:j],tmp.lastEditTime];
        }
        temp = [temp stringByAppendingString:@"</url></item>"];
		
    }
	if ([poiList count] == 0)
    {
        temp = [temp stringByAppendingString:@"<item></item>"];
    }
	temp = [temp stringByAppendingString:@"</context></archive>"];
	//NSLog(@"temp===%@",temp);
    
	NSData *requstBody = [temp dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    
    MWPoiOperator *operator = [[MWPoiOperator alloc] initWithDelegate:delegate];
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = url;
    net_condition.bodyData = requstBody;
    net_condition.httpMethod = @"POST";
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:operator];
}

/*!
 @brief  下载联系人
 回调：
 成功 -(void)downloadSuccessWith:(RequestType)type result:(id)result;
 失败 -(void)downloadFailWith:(RequestType)type error:(NSError *)error;
 @param   option 下载联系人时的条件
 @param   type 请求类型
 */
+(void)downloadContactWith:(MWContactOption *)option requestType:(RequestType)type delegate:(id<MWPoiOperatorDelegate>)delegate
{
    NSArray *array = [[Account AccountInstance] getAccountInfo];
    int loginType = [[array objectAtIndex:0] intValue];
    
    NSString *url;
    
    if (loginType == 3 || loginType == 5)
    {
        url = [NSString stringWithFormat:@"%@favorites/downloadphonebook_v2/?out=xml&tpuserid=%@&tptype=1",kNetDomain,[array objectAtIndex:5]];
    }
    else if (loginType == 4 || loginType == 6)
    {
        url = [NSString stringWithFormat:@"%@favorites/downloadphonebook_v2/?out=xml&tpuserid=%@&tptype=2",kNetDomain,[array objectAtIndex:5]];
    }
    else
    {
        url = [NSString stringWithFormat:@"%@favorites/downloadphonebook_v2/?out=xml&username=%@&password=%@",kNetDomain,option.userName,option.password];
    }
    
    MWPoiOperator *operator = [[MWPoiOperator alloc] initWithDelegate:delegate];
    
    NetBaseRequestCondition *net_condition = [NetBaseRequestCondition requestCondition];
    net_condition.requestType = type;
    net_condition.baceURL = url;
    
    [[NetExt sharedInstance] requestWithCondition:net_condition delegate:operator];
    
}

/*!
 @brief  收藏联系人。
 @param operationOption POI 查询选项
 @return YES:成功启动搜索。搜索成功将回调 -(void)poiLocalSearch:(MWSearchOption*)poiSearchOption Result:(MWSearchResult *)result;
 */
+(BOOL)collectContactWith:(ABRecordRef)record
{
    NSMutableArray *poiList = [[NSMutableArray alloc] init];
    
    NameIndex *item = [[NameIndex alloc] init];//NameIndex是一个用于给UILocalizedIndexedCollation类对象做索引的类，代码见下个代码块
    
    item._fullName = (NSString*)ABRecordCopyCompositeName(record);
    item.lastEditTime = (NSDate*)ABRecordCopyValue(record, kABPersonModificationDateProperty);
	
    ABMultiValueRef phones = (ABMultiValueRef) ABRecordCopyValue(record, kABPersonPhoneProperty);
    for(int i = 0 ;i < ABMultiValueGetCount(phones); i++)
    {
        NSString *phone = (NSString *)ABMultiValueCopyValueAtIndex(phones, i);
        NSString *labelName = (NSString *)ABMultiValueCopyLabelAtIndex(phones,i);
        NSString *phoneType;
        if ([labelName rangeOfString:@"Mobile"].length > 0) {
            phoneType = [NSString stringWithFormat:@"移动"];
        }
        else if([labelName rangeOfString:@"iPhone"].length > 0) {
            phoneType = [NSString stringWithFormat:@"iPhone"];
        }
        else if([labelName rangeOfString:@"Home"].length > 0) {
            phoneType = [NSString stringWithFormat:@"住宅"];
        }
        else if([labelName rangeOfString:@"Work"].length > 0) {
            phoneType = [NSString stringWithFormat:@"工作"];
        }
        else if([labelName rangeOfString:@"Main"].length > 0) {
            phoneType = [NSString stringWithFormat:@"主要"];
        }
        else if([labelName rangeOfString:@"HomeFAX"].length > 0) {
            phoneType = [NSString stringWithFormat:@"住宅传真"];
        }
        else if([labelName rangeOfString:@"WorkFAX"].length > 0) {
            phoneType = [NSString stringWithFormat:@"工作传真"];
        }
        else if([labelName rangeOfString:@"Pager"].length > 0) {
            phoneType = [NSString stringWithFormat:@"传呼"];
        }
        else if([labelName rangeOfString:@"Other"].length > 0) {
            phoneType = [NSString stringWithFormat:@"其他"];
        }
        else {
            phoneType = [NSString stringWithFormat:@"%@",labelName];
        }
        
        //NSLog(@"电话=%@,%d,%@",labelName,i,item._fullName);
        [item.phoneTypeArray addObject:phoneType];
        [item.phoneArray addObject:phone];
        
        
    }
    
    ABMultiValueRef mails = (ABMultiValueRef) ABRecordCopyValue(record, kABPersonEmailProperty);
    for(int i = 0 ;i < ABMultiValueGetCount(mails); i++)
    {
        NSString *mail = (NSString *)ABMultiValueCopyValueAtIndex(mails, i);
        NSString *labelName = (NSString *)ABMultiValueCopyLabelAtIndex(mails,i);
        NSString *mailType;
        
        if([labelName rangeOfString:@"Home"].length > 0) {
            mailType = [NSString stringWithFormat:@"住宅"];
        }
        else if([labelName rangeOfString:@"Work"].length > 0) {
            mailType = [NSString stringWithFormat:@"工作"];
        }
        else if([labelName rangeOfString:@"Other"].length > 0) {
            mailType = [NSString stringWithFormat:@"其他"];
        }
        else {
            mailType = [NSString stringWithFormat:@"%@",labelName];
        }
        
        // NSLog(@"邮件=%@,%d,%@",labelName,i,item._fullName);
        [item.emailTypeArray addObject:mailType];
        [item.emailArray addObject:mail];
    }
    
    ABMultiValueRef url = (ABMultiValueRef) ABRecordCopyValue(record, kABPersonURLProperty);
    for(int i = 0 ;i < ABMultiValueGetCount(url); i++)
    {
        NSString *myurl = (NSString *)ABMultiValueCopyValueAtIndex(url, i);
        NSString *labelName = (NSString *)ABMultiValueCopyLabelAtIndex(url,i);
        
        NSString *urlType;
        
        if([labelName rangeOfString:@"HomePage"].length > 0) {
            urlType = [NSString stringWithFormat:@"首页"];
        }
        else if([labelName rangeOfString:@"Home"].length > 0) {
            urlType = [NSString stringWithFormat:@"住宅"];
        }
        else if([labelName rangeOfString:@"Work"].length > 0) {
            urlType = [NSString stringWithFormat:@"工作"];
        }
        else if([labelName rangeOfString:@"Other"].length > 0) {
            urlType = [NSString stringWithFormat:@"其他"];
        }
        else
        {
            urlType = [NSString stringWithFormat:@"%@",labelName];
        }
        //NSLog(@"url=%@,%d,%@",labelName,i,item._fullName);
        [item.URLTypeArray addObject:urlType];
        [item.URLArray addObject:myurl];
    }
    
    ABMultiValueRef address = (ABMultiValueRef) ABRecordCopyValue(record, kABPersonAddressProperty);
    for(int i = 0 ;i < ABMultiValueGetCount(address); i++)
    {
        // NSString *addres = (NSString *)ABMultiValueCopyValueAtIndex(address, i);
        NSString *labelName = (NSString *)ABMultiValueCopyLabelAtIndex(address,i);
        AddressItem *addressItem = [[AddressItem alloc] init];
        NSString *addressType;
        
        if([labelName rangeOfString:@"Home"].length > 0) {
            addressType = [NSString stringWithFormat:@"住宅"];
        }
        else if([labelName rangeOfString:@"Work"].length > 0) {
            addressType = [NSString stringWithFormat:@"工作"];
        }
        else if([labelName rangeOfString:@"Other"].length > 0) {
            addressType = [NSString stringWithFormat:@"其他"];
        }
        else {
            addressType = [NSString stringWithFormat:@"%@",labelName];
        }
        //NSLog(@"地址=%@,%d,%@",labelname,i,item._fullName);
        addressItem.type = addressType;
        
        //获取地址的spcode属性
        NSDictionary* personaddress =(NSDictionary*) ABMultiValueCopyValueAtIndex(address, i);
        
        
        addressItem.zip = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressZIPKey];
        addressItem.city = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressCityKey];
        addressItem.street = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressStreetKey];
        addressItem.country =  (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressCountryKey];
        addressItem.countryCode = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressCountryCodeKey];
        addressItem.state = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressStateKey];
        [item.addressArray addObject:addressItem];
        [addressItem release];
        [personaddress release];
    }
    
    [poiList addObject:item];
    
    [item release];
    
    BOOL sign = [MWPoiOperator saveFile:poiList];
    
    [poiList release];
    
    return sign;
}

/*!
 @brief  编辑联系人
 @param  record 编辑后的联系人信息
 @param  index  编辑的联系人在数组中所处的位置
 @return YES:成功编辑联系。
 */
+ (BOOL)editContactWith:(ABRecordRef)record index:(int)index
{
    if (index < 0)
    {
        return NO;
    }
    
    NSMutableArray *poiList = [[NSMutableArray alloc] init];
    NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:CONTACT_FILE_NAME];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	[poiList addObjectsFromArray:array];
    
    if (index >= [poiList count])
    {
        return NO;
    }
    
    
    NameIndex *item = [[NameIndex alloc] init];//NameIndex是一个用于给UILocalizedIndexedCollation类对象做索引的类，代码见下个代码块
	
	item._fullName = (NSString*)ABRecordCopyCompositeName(record);
	item.lastEditTime = (NSDate*)ABRecordCopyValue(record, kABPersonModificationDateProperty);
	
	ABMultiValueRef phones = (ABMultiValueRef) ABRecordCopyValue(record, kABPersonPhoneProperty);
	for(int i = 0 ;i < ABMultiValueGetCount(phones); i++)
	{
		NSString *phone = (NSString *)ABMultiValueCopyValueAtIndex(phones, i);
		NSString *labelName = (NSString *)ABMultiValueCopyLabelAtIndex(phones,i);
		NSString *phoneType;
		if ([labelName rangeOfString:@"Mobile"].length > 0) {
			phoneType = [NSString stringWithFormat:@"移动"];
		}
		else if([labelName rangeOfString:@"iPhone"].length > 0) {
			phoneType = [NSString stringWithFormat:@"iPhone"];
		}
		else if([labelName rangeOfString:@"Home"].length > 0) {
			phoneType = [NSString stringWithFormat:@"住宅"];
		}
		else if([labelName rangeOfString:@"Work"].length > 0) {
			phoneType = [NSString stringWithFormat:@"工作"];
		}
		else if([labelName rangeOfString:@"Main"].length > 0) {
			phoneType = [NSString stringWithFormat:@"主要"];
		}
		else if([labelName rangeOfString:@"HomeFAX"].length > 0) {
			phoneType = [NSString stringWithFormat:@"住宅传真"];
		}
		else if([labelName rangeOfString:@"WorkFAX"].length > 0) {
			phoneType = [NSString stringWithFormat:@"工作传真"];
		}
		else if([labelName rangeOfString:@"Pager"].length > 0) {
			phoneType = [NSString stringWithFormat:@"传呼"];
		}
		else if([labelName rangeOfString:@"Other"].length > 0) {
			phoneType = [NSString stringWithFormat:@"其他"];
		}
	    else
		{
			phoneType = [NSString stringWithFormat:@"%@",labelName];
		}
		//NSLog(@"电话=%@,%d,%@",labelName,i,item._fullName);
		[item.phoneTypeArray addObject:phoneType];
		[item.phoneArray addObject:phone];
		
		
	}
	
	ABMultiValueRef mails = (ABMultiValueRef) ABRecordCopyValue(record, kABPersonEmailProperty);
	for(int i = 0 ;i < ABMultiValueGetCount(mails); i++)
	{
		NSString *mail = (NSString *)ABMultiValueCopyValueAtIndex(mails, i);
		NSString *labelName = (NSString *)ABMultiValueCopyLabelAtIndex(mails,i);
		NSString *mailType;
		
		if([labelName rangeOfString:@"Home"].length > 0) {
			mailType = [NSString stringWithFormat:@"住宅"];
		}
		else if([labelName rangeOfString:@"Work"].length > 0) {
			mailType = [NSString stringWithFormat:@"工作"];
		}
		else if([labelName rangeOfString:@"Other"].length > 0) {
			mailType = [NSString stringWithFormat:@"其他"];
		}
		else {
			mailType = [NSString stringWithFormat:@"%@",labelName];
		}
        
		// NSLog(@"邮件=%@,%d,%@",labelName,i,item._fullName);
		[item.emailTypeArray addObject:mailType];
		[item.emailArray addObject:mail];
	}
	
	ABMultiValueRef url = (ABMultiValueRef) ABRecordCopyValue(record, kABPersonURLProperty);
	for(int i = 0 ;i < ABMultiValueGetCount(url); i++)
	{
		NSString *myurl = (NSString *)ABMultiValueCopyValueAtIndex(url, i);
		NSString *labelName = (NSString *)ABMultiValueCopyLabelAtIndex(url,i);
		
		NSString *urlType;
		
		if([labelName rangeOfString:@"HomePage"].length > 0) {
			urlType = [NSString stringWithFormat:@"首页"];
		}
		else if([labelName rangeOfString:@"Home"].length > 0) {
			urlType = [NSString stringWithFormat:@"住宅"];
		}
		else if([labelName rangeOfString:@"Work"].length > 0) {
			urlType = [NSString stringWithFormat:@"工作"];
		}
		else if([labelName rangeOfString:@"Other"].length > 0) {
			urlType = [NSString stringWithFormat:@"其他"];
		}
		else
		{
			urlType = [NSString stringWithFormat:@"%@",labelName];
		}
		//NSLog(@"url=%@,%d,%@",labelName,i,item._fullName);
		[item.URLTypeArray addObject:urlType];
		[item.URLArray addObject:myurl];
	}
	
	ABMultiValueRef address = (ABMultiValueRef) ABRecordCopyValue(record, kABPersonAddressProperty);
	for(int i = 0 ;i < ABMultiValueGetCount(address); i++)
	{
		// NSString *addres = (NSString *)ABMultiValueCopyValueAtIndex(address, i);
		NSString *labelName = (NSString *)ABMultiValueCopyLabelAtIndex(address,i);
		AddressItem *addressItem = [[AddressItem alloc] init];
		NSString *addressType;
		
		if([labelName rangeOfString:@"Home"].length > 0) {
			addressType = [NSString stringWithFormat:@"住宅"];
		}
		else if([labelName rangeOfString:@"Work"].length > 0) {
			addressType = [NSString stringWithFormat:@"工作"];
		}
		else if([labelName rangeOfString:@"Other"].length > 0) {
			addressType = [NSString stringWithFormat:@"其他"];
		}
		else {
			addressType = [NSString stringWithFormat:@"%@",labelName];
		}
		//NSLog(@"地址=%@,%d,%@",labelname,i,item._fullName);
		addressItem.type = addressType;
		
		//获取地址的spcode属性
		NSDictionary* personaddress =(NSDictionary*) ABMultiValueCopyValueAtIndex(address, i);
		
		
		addressItem.zip = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressZIPKey];
		addressItem.city = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressCityKey];
		addressItem.street = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressStreetKey];
		addressItem.country =  (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressCountryKey];
		addressItem.countryCode = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressCountryCodeKey];
		addressItem.state = (NSString *)[personaddress valueForKey:(NSString *)kABPersonAddressStateKey];
		[item.addressArray addObject:addressItem];
		[addressItem release];
		
	}
	
	[poiList replaceObjectAtIndex:index withObject:item];
	
	[item release];
	
    int sign = [self saveFile:poiList];
    
    [poiList release];
    
	return sign;
}

/*!
 @brief  获取已收藏的联系人列表
 @param   resultList 输出，用于返回联系人列表。
 @return  YES:成功获取联系人列表。
 */
+(BOOL)getContactList:(MWContact **)resultList
{
    MWContact *temp = [[[MWContact alloc] init] autorelease];
    
    NSMutableArray *poiList = [[NSMutableArray alloc] init];
    NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:CONTACT_FILE_NAME];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
    [poiList addObjectsFromArray:array];
    
    if ([poiList count] == 0)
    {
        [poiList release];
        return NO;
    }
    
    temp.nNumberOfItem = [poiList count];
    temp.contactArray = poiList;
    [poiList release];
    
    *resultList = temp;
    return YES;
}

/*!
 @brief  删除联系人(参数为索引值)
 @param   index 收藏的联系人的索引 (即 NameIndex 在数组中的索引)
 @return 删除成功返回YES。
 */
+(BOOL)deleteContactWithIndex:(int)index
{
    if (index < 0)
    {
        return NO;
    }
    NSMutableArray *poiList = [[NSMutableArray alloc] init];
    NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:CONTACT_FILE_NAME];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
    [poiList addObjectsFromArray:array];
    
    if ([poiList count] == 0)
    {
        [poiList release];
        return NO;
    }
    
    if (index < [poiList count])
    {
		[poiList removeObjectAtIndex:index];
		int sign = [self saveFile:poiList];
        [poiList release];
		return sign;
	}
	
	return NO;
}

/*!
 @brief  清空联系人列表
 @return 删除成功返回YES。
 */
+ (BOOL)clearContact
{
    NSMutableArray *poiList = [[[NSMutableArray alloc] init] autorelease];
	return [self saveFile:poiList];
}

/*!
 @brief  检测联系人是否在本地文件中
 @param   name 联系人的姓名
 @return 存在返回YES。
 */
+ (BOOL)bCheckContactInListWithName:(NSString *)name
{
    NSMutableArray *poiList = [[NSMutableArray alloc] init];
    NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:CONTACT_FILE_NAME];
	NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filename];
	[poiList addObjectsFromArray:array];
    
    
    for (int i=0; i<[poiList count]; i++)
    {
		NameIndex *tmp = [poiList objectAtIndex:i];
		if ([name isEqualToString:tmp._fullName])
        {
			return YES;
		}
	}
    return NO;
}

#pragma mark - private method
#pragma mark search method

/*!
 @brief  递归将GPOICATEGORY转化成MWPoiCategory
 @param  gPoiCategory, 将要转化的GPOICATEGORY
 @return 转化后的 MWPoiCategory。
 */
-(MWPoiCategory *)recursiveForCategory:(GPOICATEGORY)gPoiCategory
{
    if (&gPoiCategory == NULL)
    {
        return nil;
    }
    MWPoiCategory  *poiCategory = [[MWPoiCategory alloc] init];
    poiCategory.Reserved = gPoiCategory.Reserved;
    poiCategory.lCategoryID = gPoiCategory.lCategoryID;
    poiCategory.nNumberOfSubCategory = gPoiCategory.nNumberOfSubCategory;
    poiCategory.szName = CSTRING_TO_NSSTRING(gPoiCategory.szName);
    
    if (gPoiCategory.nNumberOfSubCategory == 0 || gPoiCategory.pSubCategory == NULL)
    {
        return [poiCategory autorelease];
    }
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (int i = 0; i < gPoiCategory.nNumberOfSubCategory; i++)
    {
        MWPoiCategory *recursive = [self recursiveForCategory:gPoiCategory.pSubCategory[i]];
        [array addObject:recursive];
    }
    poiCategory.pSubCategoryArray = array;
    [array release];
    return [poiCategory autorelease];
}

/*!
 @brief  递归将GADAREA转化成MWArea
 @param  area, 将要转化的GADAREA
 @return 转化后的 MWArea。
 */
-(MWArea *)recursiveForArea:(GADAREA)area
{
    if (&area == NULL)
    {
        return nil;
    }
    MWArea  *mwarea = [[MWArea alloc] init];
    mwarea.lAdminCode = area.lAdminCode;
    mwarea.szAdminName = [NSString stringWithCString:area.szAdminName encoding:NSUTF8StringEncoding];
    mwarea.szAdminSpell = [NSString stringWithCString:area.szAdminSpell encoding:NSUTF8StringEncoding];
    mwarea.lNumberOfSubAdarea = area.lNumberOfSubAdarea;
    
    if (area.lNumberOfSubAdarea == 0 || area.pSubAdarea == NULL)
    {
        return [mwarea autorelease];
    }
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (int i = 0; i < area.lNumberOfSubAdarea; i++)
    {
        MWArea *recursive = [self recursiveForArea:area.pSubAdarea[i]];
        [array addObject:recursive];
    }
    mwarea.pSubAdareaArray = array;
    [array release];
    return [mwarea autorelease];
}


/*!
 @brief  按距离排序 冒泡排序。
 @param  pResult:需要排序的GPOIRESULT结构体，由引擎给出。
 */
- (void)sortDistanceWith:(GPOIRESULT *)pResult
{
    GPOI temp;
    int kk = pResult->sNumberOfItemGet;
    for (int j = 0; j < kk-1;j++)
    {
        for (int k = 0; k < kk - j - 1;k++)
        {
            if (pResult->pPOI[k].lDistance > pResult->pPOI[k+1].lDistance)
            {
                temp = pResult->pPOI[k];
                pResult->pPOI[k] = pResult->pPOI[k + 1];
                pResult->pPOI[k + 1] = temp;
            }
        }
    }
}

/*!
 @brief  计算距离。
 @param  pResult:需要排序的GPOIRESULT结构体，由引擎给出。
 */
- (void)setDistanceWith:(GPOIRESULT *)pResult
{
    GCOORD coord = {0};
    if (_poiOperationOptionNet)
    {
        if (_poiOperationOptionNet.operatorType == GSEARCH_TYPE_AROUND)
        {
            coord.x = _poiOperationOptionNet.longitude;
            coord.y = _poiOperationOptionNet.latitude;
        }
        else
        {
            GCARINFO pCarInfo = {};
            GDBL_GetCarInfo(&pCarInfo);
            coord.x = pCarInfo.Coord.x;
            coord.y = pCarInfo.Coord.y;
        }
    }
    
    int kk = pResult->sNumberOfItemGet;
    for (int j = 0; j < kk;j++)
    {
        pResult->pPOI[j].lDistance = [[ANDataSource sharedInstance] GMD_CalculateDistanceWithStart:coord Des:pResult->pPOI[j].Coord];
        pResult->pPOI[j].lHilightFlag = 0;
    }
}

/*!
 @brief  获取MWPoi对象。
 @param  gpoi : gpoi结构体 
 @param  enc : 传入数据的编码方式
 @return 返回自动释放的MWPoi对象。
 */
- (MWPoi *)getMWPoiWith:(GPOI)gpoi encoding:(NSStringEncoding)enc
{
    MWPoi *poi = [[MWPoi alloc] init];
    poi.lAdminCode = gpoi.lAdminCode;
    poi.latitude = gpoi.Coord.y;
    poi.longitude = gpoi.Coord.x;
    poi.lCategoryID = gpoi.lCategoryID;
    poi.lDistance = gpoi.lDistance;
    poi.lHilightFlag = gpoi.lHilightFlag;
    poi.lMatchCode = gpoi.lMatchCode;
    poi.lPoiId = gpoi.lPoiId;
    poi.lPoiIndex = gpoi.lPoiIndex;
    poi.usNodeId = gpoi.usNodeId;
    poi.ucFlag = gpoi.ucFlag;
    poi.Reserved = gpoi.Reserved;
    poi.siELatOff = gpoi.siELatOff;
    poi.siELonOff = gpoi.siELonOff;
    poi.szName = [NSString stringWithCString:gpoi.szName encoding:enc];
    poi.szAddr = [NSString stringWithCString:gpoi.szAddr encoding:enc];
    poi.szTel = [NSString stringWithCString:gpoi.szTel encoding:enc];
    return [poi autorelease];
}
/*!
 @brief  获取MWSearchResult对象。
 @param  pResult:GPOIRESULT结构体，由引擎给出。
 @param  enc:传入数据的编码方式
 @return 返回自动释放的MWSearchResult对象。
 */
- (MWSearchResult *)getSearchResultWith:(GPOIRESULT *)pResult encoding:(NSStringEncoding)enc
{
    MWSearchResult *operatorResult = [[MWSearchResult alloc] init];
    operatorResult.index = pResult->sIndex;
    operatorResult.numberOfItemGet = pResult->sNumberOfItemGet;
    operatorResult.numberOfTotalItem = pResult->sNumberOfTotalItem;
    operatorResult.reserved = pResult->Reserved;
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (int i = 0; i < pResult->sNumberOfItemGet; i++)
    {
        MWPoi *poi = [self getMWPoiWith:pResult->pPOI[i] encoding:enc];
        [array addObject:poi];
    }
    operatorResult.pois = [NSArray arrayWithArray:array];
    [array release];
    
    return [operatorResult autorelease];
}

/*!
 @brief  搜索失败，处理函数
 @param  errcode 错误码。
 */
- (void)searchLocalPoifail:(NSError *)errcode
{
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(search:Error:)])
        {
            [self.poiDelegate search:_poiOperationOptionLocal Error:errcode];
        }
    }
    else
    {
        NSLog(@"delegate dealloc");
    }
    if (_poiOperationOptionLocal)
    {
        [_poiOperationOptionLocal release];
        _poiOperationOptionLocal = nil;
    }
    [self release];
}

/*!
 @brief  搜索失败，处理函数
 @param  errcode 错误码。
 */
- (void)searchNetPoifail:(NSError *)errcode
{
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(search:Error:)])
        {
            [self.poiDelegate search:_poiOperationOptionNet Error:errcode];
        }
    }
    else
    {
        NSLog(@"delegate dealloc");
    }
    if (_poiOperationOptionNet)
    {
        [_poiOperationOptionNet release];
        _poiOperationOptionNet = nil;
    }
    [self release];
}

/*!
 @brief  搜索失败，处理函数
 @param  errcode 错误码。
 */
- (void)searchNearestPoifail:(NSError *)errcode
{
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(search:Error:)])
        {
            MWSearchOption *temp = [[[MWSearchOption alloc] init] autorelease];
            temp.longitude = _coordForNearest.x;
            temp.latitude = _coordForNearest.y;
            [self.poiDelegate search:temp Error:errcode];
        }
    }
    else
    {
        NSLog(@"delegate dealloc");
    }
    [self release];
}

/*!
 @brief  本地搜索成功，处理函数
 @param  result 搜索成功后，获取的poi结构对象。
 */
- (void)searchPoiItemSuccess:(MWSearchResult *)result
{
    
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(poiLocalSearch:Result:)])
        {
            [self.poiDelegate poiLocalSearch:_poiOperationOptionLocal Result:result];
        }
    }
    else
    {
        NSLog(@"delegate dealloc");
    }
    if (_poiOperationOptionLocal)
    {
        [_poiOperationOptionLocal release];
        _poiOperationOptionLocal = nil;
    }
    [self release];
}

/*!
 @brief  网络搜索成功，处理函数 （当前城市搜索成功）
 @param  result 搜索成功后，获取的poi结构对象。
 */
- (void)searchNetPoiItemSuccess:(MWSearchResult *)result
{
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(poiNetSearch:Result:)])
        {
            [self.poiDelegate poiNetSearch:_poiOperationOptionNet Result:result];
        }
    }
    else
    {
        NSLog(@"delegate dealloc");
    }
    
    [self release];
    if (_poiOperationOptionNet)
    {
        [_poiOperationOptionNet release];
        _poiOperationOptionNet = nil;
    }
}

/*!
 @brief  网络搜索成功，处理函数  （转其他城市搜索）
 */
- (void)searchNetPoiItemToOtherCitySuccess
{
    MWAreaList *list = [[[MWAreaList alloc] init] autorelease];
    GADAREALIST *ppAdareaList;
    GSTATUS res;
    res = GDMID_GetNetCandidateAdareaList (&ppAdareaList);
    list.lNumberOfAdarea = ppAdareaList->lNumberOfAdarea;
    if (res == GD_ERR_OK)
    {
        NSMutableArray *array = [[NSMutableArray alloc] init];
        for (int i = 0; i< ppAdareaList->lNumberOfAdarea; i++)
        {
            GADAREA area = ppAdareaList->pAdarea[i];
            MWArea *mwArea = [self recursiveForArea:area];
            [array addObject:mwArea];
        }
        list.pAdareaArray = [NSArray arrayWithArray:array];
        [array release];
    }
    else
    {//获取失败
        [self searchNetPoifail:[self searchErrorWithCode:0 userInfo:nil]];
        return;
    }
    
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(poiNetToOtherCitySearch:Result:)])
        {
            [self.poiDelegate poiNetToOtherCitySearch:_poiOperationOptionNet Result:list];
        }
    }
    else
    {
        NSLog(@"delegate dealloc");
    }
    
    [self release];
    if (_poiOperationOptionNet)
    {
        [_poiOperationOptionNet release];
        _poiOperationOptionNet = nil;
    }
}

/*!
 @brief  当前点最近的POI点搜索成功，处理函数
 @param  result 搜索成功后，获取的poi结构对象。
 */
- (void)searchNearestPoiItemSuccess:(MWPoi *)poi
{
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(poiNearestSearch:Poi:)])
        {
            [self.poiDelegate poiNearestSearch:_coordForNearest Poi:poi];
        }
    }
    [self release];
}

- (void)onlineMapSearchCenterWith:(MWPoi *)poi
{
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(poiNearestSearch:Poi:)])
        {
            [self.poiDelegate poiNearestSearch:_coordForNearest Poi:poi];
        }
    }
    [self release];
}

- (void)listenNotification:(NSNotification *)notification
{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if ([notification.name isEqual:NOTIFY_GETPOIDATA])
	{
		NSLog(@"ddd--%@",[notification.object objectAtIndex:0]);
        
		NSArray *result = [notification object];
        if ([[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_GENERAL_0)
        { 
            if ([[result objectAtIndex:1] intValue] == _GD_SEARCH_RESULT_SUCCESS_0)  //成功
            {
                GETPOIINPUT input;
                input.sIndex = 0;//首次默认从第0条开始获取
                input.sNumberOfItemToGet= 500; //从开始条数序号起，要获取的条数
                
                GPOIRESULT *pResult;
			    GSTATUS res;
                res = GDBL_GetPOIResult(&input, &pResult);
                if (res == GD_ERR_OK)
                {
                    MWSearchResult *operatorResult = [self getSearchResultWith:pResult encoding:0x80000632]; //0x80000632 GBK编码
                    [self performSelectorOnMainThread:@selector(searchPoiItemSuccess:) withObject:operatorResult waitUntilDone:NO];
                }
                else
                {
                    [self performSelectorOnMainThread:@selector(searchLocalPoifail:) withObject:[self searchErrorWithCode:0 userInfo:nil] waitUntilDone:NO];
                }
                
            }
            else
            {
                [self performSelectorOnMainThread:@selector(searchLocalPoifail:) withObject:[self searchErrorWithCode:0 userInfo:nil] waitUntilDone:NO];
            }
        }
        else  if ([[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_ONLINE_3)
        {
            if ([[result objectAtIndex:1] intValue] == _GD_SEARCH_RESULT_SUCCESS_0)  //成功
            {
                GETPOIINPUT input;
                input.sIndex = 0;//首次默认从第0条开始获取
                input.sNumberOfItemToGet= 500; //从开始条数序号起，要获取的条数
                
                GPOIRESULT *pResult;
			    GSTATUS res;
                res = GDBL_GetPOIResult(&input, &pResult);

                
                if (res == GD_ERR_OK)
                {
                    [self setDistanceWith:pResult];
                    if (_poiOperationOptionNet.sortType == 1) //按距离排序
                    {
                        [self sortDistanceWith:pResult];
                    }
                    MWSearchResult *operatorResult = [self getSearchResultWith:pResult encoding:NSUTF8StringEncoding];
                    [self performSelectorOnMainThread:@selector(searchNetPoiItemSuccess:) withObject:operatorResult waitUntilDone:NO];
                }
                else
                {
                    [self performSelectorOnMainThread:@selector(searchNetPoifail:) withObject:[self searchErrorWithCode:0 userInfo:nil] waitUntilDone:NO];
                }
                
            }
            else
            {
                [self performSelectorOnMainThread:@selector(searchNetPoifail:) withObject:[self searchErrorWithCode:0 userInfo:nil] waitUntilDone:NO];
            }
        }
        else  if ([[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_NEAREST_POI_1)
        {
            if ([[result objectAtIndex:1] intValue] == _GD_SEARCH_RESULT_SUCCESS_0)  //成功
            {
                GPOI pNearestPOI = {0};
                GDBL_GetNearestPOI(&pNearestPOI);
                
                MWPoi *poi = [self getMWPoiWith:pNearestPOI encoding:0x80000632];
                [self performSelectorOnMainThread:@selector(searchNearestPoiItemSuccess:) withObject:poi waitUntilDone:NO];
            }
            else
            {
                [self performSelectorOnMainThread:@selector(searchNearestPoifail:) withObject:[self searchErrorWithCode:0 userInfo:nil] waitUntilDone:NO];
            }
        }
        else if ([[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_OTHER_CITY_INOF_4 )//获取城市列表
        {
            if ([[result objectAtIndex:1] intValue] == _GD_SEARCH_RESULT_SUCCESS_0)  //成功
            {
                [self performSelectorOnMainThread:@selector(searchNetPoiItemToOtherCitySuccess) withObject:nil waitUntilDone:NO];
            }
            else
            {
                [self performSelectorOnMainThread:@selector(searchNetPoifail:) withObject:[self searchErrorWithCode:0 userInfo:nil] waitUntilDone:NO];
            }
        }
	}
}

- (id)searchErrorWithCode:(NSInteger)code userInfo:(NSDictionary *)userInfo
{
  
    return [NSError errorWithDomain:MWPOISearchErrorDomain code:code userInfo:userInfo];
}

#pragma mark  contact private method

//序列化联系人列表
+ (BOOL)saveFile:(NSMutableArray *)array
{
	NSString *Path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *filename = [Path stringByAppendingPathComponent:CONTACT_FILE_NAME];
	if (![NSKeyedArchiver archiveRootObject:array toFile:filename])
    {
		return NO;
	}
	else {
		return YES;
	}
    
}

//添加邮件字段
+ (BOOL)addEmail:(ABRecordRef)person email:(NSString*)email type:(NSString *)emailtype
{
	ABMultiValueRef immutableMultiAddress = (ABMultiValueRef) ABRecordCopyValue(person, kABPersonEmailProperty);
	ABMutableMultiValueRef multi;
	if (immutableMultiAddress)
    {
		
        multi = ABMultiValueCreateMutableCopy(immutableMultiAddress);
		
    }
    else
    {
		
        multi = ABMultiValueCreateMutable(kABMultiStringPropertyType);
    }
    
    CFErrorRef anError = NULL;
	
    ABMultiValueIdentifier multivalueIdentifier;
    
    if (!ABMultiValueAddValueAndLabel(multi, (CFStringRef)email, (CFStringRef)emailtype, &multivalueIdentifier)){
        if(multi)CFRelease(multi);
        return NO;
    }
	
    if (!ABRecordSetValue(person, kABPersonEmailProperty, multi, &anError)){
        if(multi)CFRelease(multi);
        return NO;
    }
	
    if(multi)CFRelease(multi);
    return YES;
}
//添加电话字段
+ (BOOL)addPhone:(ABRecordRef)person phone:(NSString*)phone type:(NSString *)phonetype
{
	ABMultiValueRef immutableMultiAddress = (ABMultiValueRef) ABRecordCopyValue(person, kABPersonPhoneProperty);
	ABMutableMultiValueRef multi;
	if (immutableMultiAddress)
    {
		
        multi = ABMultiValueCreateMutableCopy(immutableMultiAddress);
		
    }
    else
    {
		
        multi = ABMultiValueCreateMutable(kABMultiStringPropertyType);
    }
    
    CFErrorRef anError = NULL;
    
    ABMultiValueIdentifier multivalueIdentifier;
    
    if (!ABMultiValueAddValueAndLabel(multi, (CFStringRef)phone, (CFStringRef)phonetype, &multivalueIdentifier)){
        if(multi)CFRelease(multi);
        return NO;
    }
	
    if (!ABRecordSetValue(person, kABPersonPhoneProperty, multi, &anError)){
        if(multi)CFRelease(multi);
        return NO;
    }
	
    if(multi)CFRelease(multi);
    return YES;
}
//通讯录添加地址字段
+ (BOOL)addAddress:(ABRecordRef)person address:(AddressItem*)addr
{
	
    ABMultiValueRef immutableMultiAddress = (ABMultiValueRef) ABRecordCopyValue(person, kABPersonAddressProperty);
	ABMutableMultiValueRef addres;
	if (immutableMultiAddress)
		
    {
		
        addres= ABMultiValueCreateMutableCopy(immutableMultiAddress);
		
    }
    else
		
    {
		
        addres = ABMultiValueCreateMutable(kABDictionaryPropertyType);
    }
	
    
    static int  homeLableValueCount = 6;
    
    // 设置字典的keys和value
    CFStringRef keys[homeLableValueCount];
    CFStringRef values[homeLableValueCount];
    keys[0]      = kABPersonAddressStreetKey;
    keys[1]      = kABPersonAddressCityKey;
    keys[2]      = kABPersonAddressStateKey;
    keys[3]      = kABPersonAddressZIPKey;
    keys[4]      = kABPersonAddressCountryKey;
    keys[5]      = kABPersonAddressCountryCodeKey;
    
    values[0]    = (CFStringRef)addr.street;
    values[1]    = (CFStringRef)addr.city;
    values[2]    = (CFStringRef)addr.state;
    values[3]    = (CFStringRef)addr.zip;
    values[4]    = (CFStringRef)addr.country;
    values[5]    = (CFStringRef)addr.countryCode;
    
    CFDictionaryRef aDict = CFDictionaryCreate(
                                               kCFAllocatorDefault,
                                               (void *)keys,
                                               (void *)values,
                                               homeLableValueCount,
                                               &kCFCopyStringDictionaryKeyCallBacks,
                                               &kCFTypeDictionaryValueCallBacks
                                               );
    
    // 添加地址到 person 纪录.
    ABMultiValueIdentifier identifier;
    
    BOOL result = ABMultiValueAddValueAndLabel(addres, aDict, (CFStringRef)addr.type, &identifier);
	
    CFErrorRef error = NULL;
    result = ABRecordSetValue(person, kABPersonAddressProperty, addres, &error);
    
    if(aDict)CFRelease(aDict);
    if(addres)CFRelease(addres);
    
    return result;
}
//添加url字段
+ (BOOL)addURL:(ABRecordRef)person url:(NSString*)url type:(NSString*)urltype
{
    
	ABMultiValueRef immutableMultiURL = (ABMultiValueRef) ABRecordCopyValue(person, kABPersonURLProperty);
	ABMutableMultiValueRef multi;
	CFErrorRef anError = NULL;
    ABMultiValueIdentifier multivalueIdentifier;
	if (immutableMultiURL)
    {
		
        multi= ABMultiValueCreateMutableCopy(immutableMultiURL);
		
    }
    else
    {
		
        multi = ABMultiValueCreateMutable(kABMultiStringPropertyType);
    }
    //添加url属性值
    if (!ABMultiValueAddValueAndLabel(multi, (CFStringRef)url, (CFStringRef)urltype,
									  &multivalueIdentifier)){
        if(multi)CFRelease(multi);
        return NO;
    }
	//设置url属性值
    if (!ABRecordSetValue(person, kABPersonURLProperty, multi, &anError)){
        if(multi)CFRelease(multi);
        return NO;
    }
	
    if(multi)CFRelease(multi);
    return YES;
}

//添加到系统联系人
+(BOOL)addtoSystemContact:(NSArray *)contextArray
{
    //ios6.0-bug
    
    ABRecordRef person = ABPersonCreate();
    if(person) CFRelease(person);
    
    //添加到系统中
    for (int t = 0; t<[contextArray count]; t++) {
		NameIndex *tmpnode = [contextArray objectAtIndex:t];
        
		ABAddressBookRef addressBook = nil;
        
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 6.0)
        {
            
            addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
            
            //等待同意后向下执行
            dispatch_semaphore_t sema = dispatch_semaphore_create(0);
            ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error)
                                                     {
                                                         dispatch_semaphore_signal(sema);
                                                     });
            
            dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
            dispatch_release(sema);
            
        }
        else
        {
            addressBook = ABAddressBookCreate();
        }
        CFArrayRef friendList = ABAddressBookCopyArrayOfAllPeople(addressBook);
        BOOL isSame = NO;
        
        for (id record in (NSArray *)friendList) {
            BOOL addFlag = NO;
            BOOL URLFlag = NO;
            BOOL emailFlag = NO;
            BOOL PhoneFlag = NO;
            NSString *temp = [NSString stringWithFormat:@"%@",(NSString*)ABRecordCopyCompositeName(record)];
            if ([tmpnode._fullName isEqualToString:temp]) {//对比名字
                
                //对比地址字段
                ABMultiValueRef address = (ABMultiValueRef)ABRecordCopyValue(record, kABPersonAddressProperty);
                int addressCount = ABMultiValueGetCount(address);
                if (addressCount != [tmpnode.addressArray count]) {//地址个数不一样则对比下一个记录
                    continue;
                }
                else {
                    for (int i = 0; i<[tmpnode.addressArray count]; i++) {
                        AddressItem *item = [tmpnode.addressArray objectAtIndex:i];
                        NSString *addressTmp = [NSString stringWithFormat:@"%@%@%@%@%@%@",item.country,item.city,item.state,item.street,item.zip,item.countryCode];
                        NSDictionary *personaddress = (NSDictionary*)ABMultiValueCopyValueAtIndex(address, i);
                        NSString* country = [personaddress valueForKey:(NSString *)kABPersonAddressCountryKey];
                        NSString* city = [personaddress valueForKey:(NSString *)kABPersonAddressCityKey];
                        NSString* state = [personaddress valueForKey:(NSString *)kABPersonAddressStateKey];
                        NSString* street = [personaddress valueForKey:(NSString *)kABPersonAddressStreetKey];
                        NSString* zip = [personaddress valueForKey:(NSString *)kABPersonAddressZIPKey];
                        NSString* coutntrycode = [personaddress valueForKey:(NSString *)kABPersonAddressCountryCodeKey];
                        NSString* addressAll = [NSString stringWithFormat:@"%@%@%@%@%@%@",country,city,state,street,zip,coutntrycode];
                        if (![addressTmp isEqualToString:addressAll]) {
                            addFlag = YES;
                            break;
                        }
                        
                    }
                    if (addFlag == YES) {//地址字段不一样则对比下一个记录
                        if(address) CFRelease(address);
                        
                        continue;
                    }
                }
                if(address) CFRelease(address);
                //对比邮件字段
                ABMultiValueRef email = (ABMultiValueRef)ABRecordCopyValue(record, kABPersonEmailProperty);
                int emailcount = ABMultiValueGetCount(email);
                if (emailcount != [tmpnode.emailArray count]) {
                    continue;
                }
                else {
                    for (int j = 0; j<[tmpnode.emailArray count]; j++) {
                        NSString *emailString = [tmpnode.emailArray objectAtIndex:j];
                        NSString* emailContent = (NSString*)ABMultiValueCopyValueAtIndex(email, j);
                        if (![emailString isEqualToString:emailContent]) {
                            emailFlag = YES;
                            break;
                        }
                        
                    }
                    if (emailFlag == YES) {
                        if(email) CFRelease(email);
                        continue;
                    }
                }
                if(email) CFRelease(email);
                //对比url字段
                ABMultiValueRef URL = (ABMultiValueRef)ABRecordCopyValue(record, kABPersonURLProperty);
                int URLcount = ABMultiValueGetCount(URL);
                if (URLcount != [tmpnode.URLArray count]) {
                    continue;
                }
                else {
                    for (int k = 0; k<[tmpnode.URLArray count]; k++) {
                        NSString *URLString = [tmpnode.URLArray objectAtIndex:k];
                        NSString* URLContent = (NSString*)ABMultiValueCopyValueAtIndex(URL, k);
                        if (![URLString isEqualToString:URLContent]) {
                            URLFlag = YES;
                            break;
                        }
                        
                    }
                    if (URLFlag == YES) {
                        if(URL) CFRelease(URL);
                        continue;
                    }
                }
                if(URL) CFRelease(URL);
                //对比电话字段
                ABMultiValueRef phone = (ABMultiValueRef)ABRecordCopyValue(record, kABPersonPhoneProperty);
                int phonecount = ABMultiValueGetCount(phone);
                if (phonecount != [tmpnode.phoneArray count]) {
                    continue;
                }
                else {
                    for (int r = 0; r<[tmpnode.phoneArray count]; r++) {
                        NSString *phoneString = [tmpnode.phoneArray objectAtIndex:r];
                        NSString* phoneContent = (NSString*)ABMultiValueCopyValueAtIndex(phone, r);
                        if (![phoneString isEqualToString:phoneContent]) {
                            PhoneFlag = YES;
                            break;
                        }
                        
                    }
                    if (PhoneFlag == YES) {
                        if(phone) CFRelease(phone);
                        continue;
                    }
                }
                if(phone) CFRelease(phone);
                isSame = YES;
                break;
            }
            
        }
        //通讯录中无相同记录则添加
        if (isSame == NO) {
            CFErrorRef error = NULL;
            bool result; 
            //创建一个空记 录    
            ABRecordRef person = ABPersonCreate();
            result = ABRecordSetValue(person, kABPersonFirstNameProperty, tmpnode._fullName, &error) ;
            
            for (int q = 0; q < [tmpnode.phoneArray count]; q++) {
                [MWPoiOperator addPhone:person phone:[tmpnode.phoneArray objectAtIndex:q] type:[tmpnode.phoneTypeArray objectAtIndex:q]];
            }
            for (int w = 0; w < [tmpnode.emailArray count]; w++) {
                [MWPoiOperator addEmail:person email:[tmpnode.emailArray objectAtIndex:w] type:[tmpnode.emailTypeArray objectAtIndex:w]];
            }
            for (int e = 0; e < [tmpnode.addressArray count]; e++) {
                [MWPoiOperator addAddress:person address:[tmpnode.addressArray objectAtIndex:e]];
            }
            for (int y = 0; y < [tmpnode.URLArray count]; y++) {
                [MWPoiOperator addURL:person url:[tmpnode.URLArray objectAtIndex:y] type:[tmpnode.URLTypeArray objectAtIndex:y]];
            }
            //增加记录
            result = ABAddressBookAddRecord(addressBook, person, &error);
            // 保存到地址本
            result = ABAddressBookSave(addressBook, &error);
            if (!result) {
                return NO;
            }
        }
        if(friendList) CFRelease(friendList);
        //释放内存
        if (addressBook) CFRelease(addressBook);
        
	}
	return YES;
	
}

#pragma mark -
#pragma mark 语音委托

//获取命令ID和关键字，返回值为cmderr字段，为0表示匹配到，为1表示没有匹配到,-1表示字符串中没有cmderr字段
-(int)getCmd:(NSString *)resultText outputStringCmdID:(NSString**)outputStringCmdID outputCmdText:(NSString **)outputCmdText
{
	/**outputStringCmdID = [[NSString stringWithFormat:@"%@",@"101"] retain];
     *outputCmdText = [[NSString stringWithFormat:@"%@",@""] retain];*/
	SBJsonParser * parser = [[SBJsonParser alloc] init];
	NSString *resource = [resultText stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSDictionary * dicJson = [parser objectWithString:resource];
	NSArray * resArray = [dicJson objectForKey:@"ws"];
	//NSMutableString * newText = [[NSMutableString alloc] init];
	NSMutableArray * resKeyArray = [[[NSMutableArray alloc] init] autorelease];
	NSMutableArray * resContentArray = nil;
	for (int i = 0; i < [resArray count]; i++)
	{
		NSArray *tmpArray = [[resArray objectAtIndex:i] objectForKey:@"cw"];
		for (int j = 0; j < [tmpArray count]; j++)
		{
			NSString *keyWord = [[tmpArray objectAtIndex:j] objectForKey:@"w"];
			[resKeyArray addObject:keyWord];
		}
	}
	resContentArray = [[[NSMutableArray alloc] init] autorelease];
	resArray = [dicJson objectForKey:@"sr"];
    if([resArray count] == 0)
    {
        return -1;
    }
	NSDictionary * tmpDic = [resArray objectAtIndex:0];
	*outputStringCmdID = [tmpDic objectForKey:@"cmdid"];
	*outputCmdText = [tmpDic objectForKey:@"cmdtxt"];
	NSString * cmderrStr = [tmpDic objectForKey:@"cmderr"];
	[parser release];
	if(cmderrStr != nil && [cmderrStr intValue] == 0)
	{
		int cmderr = [cmderrStr intValue];
		return cmderr;
	}
    else if(cmderrStr != nil && [cmderrStr intValue] == 1)
    {
        return 1;
    }
	else
	{
		return -1;
	}
}
-(void)getSearchResult:(NSString *)resultText keyArray:(NSArray **)outKeyArray contentArray:(NSArray **)outContentArray
{
	SBJsonParser * parser = [[SBJsonParser alloc] init];
	NSString *resource = [resultText stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSDictionary * dicJson = [parser objectWithString:resource];
	NSArray * resArray = [dicJson objectForKey:@"ws"];
	//NSMutableString * newText = [[NSMutableString alloc] init];
	NSMutableArray * resKeyArray = [[[NSMutableArray alloc] init] autorelease];
	NSMutableArray * resContentArray = nil;
	for (int i = 0; i < [resArray count]; i++)
	{
		NSArray *tmpArray = [[resArray objectAtIndex:i] objectForKey:@"cw"];
		for (int j = 0; j < [tmpArray count]; j++)
		{
			NSString *keyWord = [[tmpArray objectAtIndex:j] objectForKey:@"w"];
			[resKeyArray addObject:keyWord];
		}
		//		NSString *keyWord = [[resArray objectAtIndex:i] objectForKey:@"w"];
		//		[resKeyArray addObject:keyWord];
	}
	if(mResultType == RESULT_TYPE_KEYWORD_CONTENT)
	{
        
        GCARINFO pCarInfo = {};
        GDBL_GetCarInfo(&pCarInfo);
        
        
		resContentArray = [[[NSMutableArray alloc] init] autorelease];
		resArray = [dicJson objectForKey:@"sr"];
		for (int i = 0; i < [resArray count]; i++)
		{
			NSDictionary * tmpDic = [resArray objectAtIndex:i];
			MWPoi * tmpContent = [[MWPoi alloc] init];
			tmpContent.szName = [tmpDic objectForKey:@"name"];
			tmpContent.szAddr = nil;//[tmpDic objectForKey:@"addr"];
			tmpContent.szTown = [tmpDic objectForKey:@"town"];
			tmpContent.szTel = [tmpDic objectForKey:@"tel"];
			tmpContent.longitude = (int)([[tmpDic objectForKey:@"lon"] doubleValue]*1000000);
			tmpContent.latitude = (int)([[tmpDic objectForKey:@"lat"] doubleValue]*1000000);
            GCOORD coord = {0};
            coord.x = tmpContent.longitude;
            coord.y = tmpContent.latitude;
			//NSString *keyWord = [tmpDic objectForKey:@"w"];
            if(![self checkPOIContent:tmpContent])
            {
                [tmpContent release];
                continue;
            }
            tmpContent.lDistance = [[ANDataSource sharedInstance] GMD_CalculateDistanceWithStart:pCarInfo.Coord Des:coord];
			[resContentArray addObject:tmpContent];
			[tmpContent release];
		}
	}
	*outKeyArray = resKeyArray;
	*outContentArray = resContentArray;
	[parser release];
}

-(BOOL)checkPOIContent:(MWPoi *)content
{
    if(content.longitude == 0 || content.latitude == 0)
    {
        return NO;
    }
    return YES;
}
- (void)speechResultText:(NSString *)resultText
{
    NSLog(@"resultText = %@",resultText);
	NSMutableArray * resKeyArray;
	NSMutableArray * resContentArray;
	NSString *cmdID,*cmdText;
    int returnFlag = [self getCmd:resultText outputStringCmdID:&cmdID outputCmdText:&cmdText];
	if(returnFlag == 0)
	{
		[self cmdRouter:cmdID cmdText:cmdText];
	}
	else if(returnFlag == -1)
	{
		[self getSearchResult:resultText keyArray:&resKeyArray contentArray:&resContentArray];
		[self result:resKeyArray content:resContentArray];
	}
    else
    {
        [self errorOccur:ERROR_CODE_RECOGNIZE];
    }
}

-(void)errorOccur:(int)errorCode
{
    if (gRecognizeController)
    {
        [gRecognizeController release];
        gRecognizeController = nil;
    }
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
//        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(voiceSearchFail:)])
//        {
//            [self.poiDelegate voiceSearchFail:errorCode];
//        }
    }
    else
    {
        NSLog(@"delegate dealloc");
    }
    [self release];
}

-(void)result:(NSArray*)keyword content:(NSArray*)content
{
    if ([keyword count] == 0)
    {
        return;
    }
    MWVoiceResult *result = [[MWVoiceResult alloc] init];
    result.voiceDataType = MWVOICE_DATA_CMDERR;
    result.keyArray = keyword;
    result.contentArray = content;
    
    Class currentClass = object_getClass(self.poiDelegate);
    if (currentClass == self.originalClass)
    {
        if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(voiceSearchResult:)])
        {
            [self.poiDelegate voiceSearchResult:result];
        }
    }
    else
    {
        NSLog(@"delegate dealloc");
    }
    
    [result release];
}


-(void)cmdRouter:(NSString *)cmdID cmdText:(NSString *)cmdText
{
    NSLog(@"cmdID = %@,cmdText = %@",cmdID,cmdText);
	int classType = [cmdID intValue];
    
    MWVoiceResult *result = [[MWVoiceResult alloc] init];
    result.voiceDataType = MWVOICE_DATA_CMDID;
    result.cmdid = classType;
    result.cmdtxt = cmdText;
    
    if ([cmdID length] > 0)
    {
        if ([[cmdID substringToIndex:1] isEqualToString:@"A"])
        {
            GDAlertView *alert = [[GDAlertView alloc] initWithTitle:nil andMessage:STR(@"Universal_noSupportOperator", @"Localizable")];
            [alert show];
            [alert release];
        }
        else
        {
            Class currentClass = object_getClass(self.poiDelegate);
            if (currentClass == self.originalClass)
            {
                if (self.poiDelegate && [self.poiDelegate respondsToSelector:@selector(voiceSearchResult:)])
                {
                    [self.poiDelegate voiceSearchResult:result];
                }
            }
            else
            {
                NSLog(@"delegate dealloc");
            }
        }
    }
    
    [result release];
}

#pragma mark  NetRequestExtDelegate callback


- (void)request:(NetRequestExt *)request didFailWithError:(NSError *)error
{
    [self failedWithError:error withRequestType:request.requestCondition.requestType];
    [self release];
}
- (void)request:(NetRequestExt *)request didFinishLoadingWithData:(NSData *)data{
    
    [self handleResponseData:data withRequestType:request.requestCondition.requestType];
    [self release];
}

#pragma mark  request data handle

- (void)handleResponseData:(NSData *)data withRequestType:(RequestType) type
{
    if (type == REQ_SYN_DES || type == REQ_SYN_FAV)
    {
        NSString *string = [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
        if ([string rangeOfString:@"<Authenticate>False</Authenticate>"].length > 0)
        {
            GDBL_clearAccountInfo();
            [self failedWithError:[self errorWithCode:1 userInfo:nil] withRequestType:type];
            return;
        }
        NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
        MWFavXMLParser *myparser = [[MWFavXMLParser alloc] init];
        BOOL result = [myparser parser:data];
        NSRange result_range = [string rangeOfString:@"<Result>SUCCESS</Result>"];
        if (result && result_range.length)
        {
            bAddToLoacl = NO;       //关闭保存至本地文件
            
            MWFavorite *parserFavorite = myparser.favorite;
           
            /*根据唯一标识，删除引擎中服务器上没有的点*/
            GFAVORITECATEGORY tempCategory;
            GFAVORITEICON tempIconID;
            NSString *strPath = nil;
            if (type == REQ_SYN_FAV)
            {
                tempCategory = GFAVORITE_CATEGORY_DEFAULT;
                tempIconID= GFAVORITE_ICON_DEFAULT;
                strPath = Favorite_Path;
            }
            else
            {
                tempCategory = GFAVORITE_CATEGORY_HISTORY;
                tempIconID= GFAVORITE_ICON_HISTORY;
                strPath = History_Path;
            }
            
            GFAVORITEPOILIST *ppFavoritePOIList;
            GSTATUS res;
            res = GDBL_GetFavoriteList(tempCategory, &ppFavoritePOIList);      //获取引擎中的收藏夹信息
            if( GD_ERR_OK == res )
            {
                NSArray *allIdentifyArray = nil;
                if ([myparser.favorite.allIdentify length] > 0)
                {
                    NSString *all_temp = [myparser.favorite.allIdentify substringToIndex:[myparser.favorite.allIdentify length] - 1];
                    allIdentifyArray = [all_temp componentsSeparatedByString:@","];
                }
                
                
                int *deleteIndex = malloc(sizeof(int) * ppFavoritePOIList->nNumberOfItem);
                int deleteCount = 0;
                for (int i = 0; i < ppFavoritePOIList->nNumberOfItem; i++)
                {
                    GFAVORITEPOI pFavoritePOI = ppFavoritePOIList->pFavoritePOI[i];
                    BOOL bExist = NO;
                    for (int j = 0; j < [allIdentifyArray count];j += 2 )
                    {
                        int x = [[allIdentifyArray objectAtIndex:j] intValue];
                        int y = [[allIdentifyArray objectAtIndex:j+1] intValue];
                        if (pFavoritePOI.Poi.Coord.x == x && pFavoritePOI.Poi.Coord.y == y)   //引擎中的点，在服务器中存在
                        {
                            bExist = YES;
                        }
                    }
                    if (!bExist)        //如果引擎中的点，在服务器中不存在，则删除该点
                    {
                        deleteIndex[deleteCount] = pFavoritePOI.nIndex;
                        NSLog(@"deleteIndex %d",deleteIndex[deleteCount]);
                        deleteCount++;
                    }
                    
                }
                GSTATUS res = GDBL_DelFavorite(deleteIndex, deleteCount);
                free(deleteIndex);
                NSLog(@"GDBL_DelFavorite : %d",res);
            }

            
            /*根据唯一标识，删除引擎中服务器上没有的点*/
            
            for (int i =0; i < [parserFavorite.pFavoritePOIArray count]; i++)     //操作服务器下发数据
            {
                MWFavoritePoi *tmp = [parserFavorite.pFavoritePOIArray objectAtIndex:i];
                tmp.eCategory = tempCategory;
                tmp.eIconID = tempIconID;
                GSTATUS sign = [MWPoiOperator editeFavoritePoiWith:tmp]; //修改接口调用不成功，则调用添加接口
                NSLog(@"editeFavoritePoiWith %d",sign);
                if (sign != GD_ERR_OK)
                {
                    sign = [MWPoiOperator collectPoiWith:tmp];
                    if (sign == GD_ERR_NO_SPACE)
                    {
                        break;
                    }
                    NSLog(@"collectPoiWith %d",sign);
                }
                
            }
            bAddToLoacl = YES;                               //打开保存至本地文件
            MWFavorite *favorite = nil;
            [MWPoiOperator getPoiListWith:tempCategory poiList:&favorite];
            
            [parserFavorite.pFavoritePOIArray removeAllObjects];
            
            parserFavorite.userName = self.userName;        //记录此次与服务器同步的用户名，用于下次同步判断
            
            if (![NSKeyedArchiver archiveRootObject:parserFavorite toFile:strPath])
            {
                NSLog(@"-------------清除本地文件失败-----------------");
            }
            else
            {
                NSLog(@"-------------清除本地文件成功-----------------");
            }
            
            Class currentClass = object_getClass(self.poiDelegate);
            if (currentClass == self.originalClass)
            {
                if ([self.poiDelegate respondsToSelector:@selector(synSuccessWith:result:)])
                {
                    [self.poiDelegate synSuccessWith:type result:favorite];
                }
            }
            else
            {
                NSLog(@"delegate dealloc");
            }
        }
        else
        {
            NSString *str = [string CutFromNSString:@"<Message>" Tostring:@"</Message>"];
            NSDictionary *dic = [NSDictionary dictionaryWithObject:str forKey:@"message"];
            [self failedWithError:[self errorWithCode:0 userInfo:dic] withRequestType:type];
        }
        
        [myparser release];
        [string release];
        string = nil;
    }
    else if (type == REQ_SYN_DSP)
    {
        NSString *string = [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
        if ([string rangeOfString:@"<Authenticate>False</Authenticate>"].length > 0)
        {
            GDBL_clearAccountInfo();
            [self failedWithError:[self errorWithCode:1 userInfo:nil] withRequestType:type];
            return;
        }
        NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
        NSMutableArray *contextArray = [[NSMutableArray alloc] init];
        MWSmartEyesXMLParser *myparser = [[MWSmartEyesXMLParser alloc] init];
        BOOL result = [myparser parser:data];
        NSRange result_range = [string rangeOfString:@"<Result>SUCCESS</Result>"];
        if (result && result_range.length)
        {
            bAddToLoacl = NO;
            MWSmartEyes *parserSmartEyes = myparser.smartEyes;
            
            /*根据唯一标识，删除引擎中服务器上没有的点*/
            GUSERSAFEINFOLIST  *ppSafeInfoList;
            GSTATUS res = GDBL_GetUserSafeInfoList(GSAFE_CATEGORY_ALL,&ppSafeInfoList);  //获取引擎中的电子眼信息
            if( GD_ERR_OK == res)
            {
                NSArray *allIdentifyArray = nil;
                if ([parserSmartEyes.allIdentify length] > 0)
                {
                    NSString *all_temp = [parserSmartEyes.allIdentify substringToIndex:[parserSmartEyes.allIdentify length] - 1];
                    allIdentifyArray = [all_temp componentsSeparatedByString:@","];
                }
                
                int *deleteIndex = malloc(sizeof(int) * ppSafeInfoList->nNumberOfItem);
                int deleteCount = 0;
                for (int i = 0; i < ppSafeInfoList->nNumberOfItem; i++)
                {
                    GUSERSAFEINFO pSafeInfo = ppSafeInfoList->pSafeInfo[i];
                    BOOL bExist = NO;
                    for (int j = 0; j < [allIdentifyArray count];j += 2)
                    {
                        int x = [[allIdentifyArray objectAtIndex:j] intValue];
                        int y = [[allIdentifyArray objectAtIndex:j+1] intValue];
                        if (pSafeInfo.coord.x == x && pSafeInfo.coord.y == y)   //引擎中的点，在服务器中存在
                        {
                            bExist = YES;
                        }
                    }
                    if (!bExist)        //如果引擎中的点，在服务器中不存在，则删除该点
                    {
                        deleteIndex[deleteCount] = pSafeInfo.nIndex;
                        NSLog(@"deleteIndex %d",deleteIndex[deleteCount]);
                        deleteCount++;
                    }
                
                }
                GSTATUS res = GDBL_DelUserSafeInfo(deleteIndex, deleteCount);
                NSLog(@"GDBL_DelFavorite : %d",res);
                free(deleteIndex);
            }
            /*根据唯一标识，删除引擎中服务器上没有的点*/
            
            for (int i =0; i<[parserSmartEyes.smartEyesArray count]; i++) //重新添加服务器下发的电子眼数据
            {
                MWSmartEyesItem *tmp = [parserSmartEyes.smartEyesArray objectAtIndex:i];
                GSTATUS res = [MWPoiOperator editeSmartEyesWith:tmp];        //调用修改接口，不成功则调用添加接口
                if (res != GD_ERR_OK)
                {
                    GSTATUS res = [MWPoiOperator collectSmartEyesWith:tmp];
                    if (res == GD_ERR_NO_SPACE)
                    {
                        break;
                    }
                    NSLog(@"collectSmartEyesWith : %d",res);
                }                                 
 
            }
            bAddToLoacl = YES;                               //打开保存至本地文件
            
            [parserSmartEyes.smartEyesArray removeAllObjects];      //同步后，收到服务器下发数据时，需删除本地同步文件,
            parserSmartEyes.userName = self.userName;        //记录此次与服务器同步的用户名，用于下次同步判断
            if (![NSKeyedArchiver archiveRootObject:parserSmartEyes toFile:SmartEye_Path])
            {
                NSLog(@"-------------清除本地文件失败-----------------");
            }
            else
            {
                NSLog(@"-------------清除本地文件成功-----------------");
            }
            
            MWSmartEyes *smartEyes;
            [MWPoiOperator getSmartEyesListWith:GSAFE_CATEGORY_ALL poiList:&smartEyes];
            
            Class currentClass = object_getClass(self.poiDelegate);
            if (currentClass == self.originalClass)
            {
                if ([self.poiDelegate respondsToSelector:@selector(synSuccessWith:result:)])
                {
                    [self.poiDelegate synSuccessWith:type result:smartEyes];
                }
            }
            else
            {
                NSLog(@"delegate dealloc");
            }
            
        }
        else
        {
            NSString *str = [string CutFromNSString:@"<Message>" Tostring:@"</Message>"];
            NSDictionary *dic = [NSDictionary dictionaryWithObject:str forKey:@"message"];
            [self failedWithError:[self errorWithCode:0 userInfo:dic] withRequestType:type];
        }
        
        [myparser release];
        [contextArray release];
        
        [string release];
        string = nil;
    }
}

- (id)errorWithCode:(NSInteger)code userInfo:(NSDictionary *)userInfo
{
    return [NSError errorWithDomain:MWFavoritemErrorDomain code:code userInfo:userInfo];
}
- (void)failedWithError:(NSError *)error withRequestType:(RequestType) type
{
    if (type == REQ_SYN_DES || type == REQ_SYN_FAV ||type == REQ_SYN_DSP)
    {
        if ([self.poiDelegate respondsToSelector:@selector(synFailWith:error:)])
        {
            [self.poiDelegate synFailWith:type error:error];
        }
    }
}


@end
