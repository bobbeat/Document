//
//  MWSearchOption.m
//  AutoNavi
//
//  Created by gaozhimin on 13-7-29.
//
//

#import "MWSearchOption.h"

@implementation MWSearchOption

@synthesize aroundRange,categoryID,keyWord,latitude,longitude,operatorType,routePoiTpe,sortType;

- (id)init
{
    self = [super init];
    if (self)
    {
        
    }
    return self;
}

- (void)dealloc
{
    self.keyWord = nil;
    [super dealloc];
}

@end
