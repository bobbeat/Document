//
//  plugin_SearchPoiOperate.m
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import "NSString+Category.h"
#import "plugin_SearchPoiOperate.h"
#import "plugin_PoiNode.h"
#import "ANDataSource.h"
#import "ANOperateMethod.h"
#import "DefineNotificationParam.h"
#import "Global.h"
#import "plugin_PoiNode.h"
#import "NSString+Category.h"
#import "ANParamValue.h"
#import "GDNet_ProtocolDefine.h"
#import "GDNet_ProtocolParse.h"
#import "plugin_SearchPoi_Connection.h"
#import "POI.h"
#import "Plugin_OnLineMapUtility.h"
#import "MWMapOperator.h"

static plugin_SearchPoiOperate *sharedPoiOperateManager = nil;
@implementation plugin_SearchPoiOperate

@synthesize psbLocalAddOnlineData = m_bLocalAddOnlineData;
+(plugin_SearchPoiOperate *)sharedInstance
{
	if (sharedPoiOperateManager == nil) 
	{
		sharedPoiOperateManager = [[plugin_SearchPoiOperate alloc] init];
	}
	
	return sharedPoiOperateManager;
}

- (id)init
{
    self = [super init];
    if(self!=nil)
    {
		poiCategoryID = 0;
        m_nAroundRange = 100000;
        m_arrayAroundSearchPOIArray = [[NSMutableArray alloc] init];
		NearPoiArray =[[NSMutableArray alloc] init];
        CityItemArray = [[NSMutableArray alloc] init];
		pNumberOfSchemes = 0;
        m_nAroundSearchType = 0;
        m_bLocalAddOnlineData = 0;
//		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenNotification:) name:NOTIFY_GETPOIDATA object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenBusNotification:) name:NOTIFY_BUS object:nil];
    }
	
    return self;
}
-(void)dealloc
{
    if (m_arrayAroundSearchPOIArray) {
        [m_arrayAroundSearchPOIArray release];
        m_arrayAroundSearchPOIArray = nil;
    }
    if (NearPoiArray) {
        [NearPoiArray release];
        NearPoiArray = nil;
    }
    if (GoWherePOIArray) {
        [GoWherePOIArray release];
        GoWherePOIArray = nil;
    }
    if (FavArray) {
        [FavArray release];
        FavArray = nil;
    }
    if (CityItemArray) {
        [CityItemArray release];
        CityItemArray = nil;
    }
    [super dealloc];
}


/**********************************************************************
 * 函数名称: searchPOI
 * 功能描述: 获取poi列表
 * 输入参数: (NSString *)Keyword（搜索关键字） (int)type（搜索类型）:0-智能 1－门址 2－交叉路口 3-周边 (int)sortType（排序类型）：0－正常 1－按距离排序
 * 输出参数: 
 * 返 回 值: NO：失败 YES:成功
 * 注意事项: 如果是周边关键字搜索，请调用GMD_SetPOICategoryIDWithMainID来设置搜索poi的类别
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
//SEARCHPOITYPE_BY_INTELGENT_0   = 0,//智能搜索
//SEARCHPOITYPE_BY_ADDRESS_1     = 1,//门址搜索
//SEARCHPOITYPE_BY_CROSS_2       = 2,//交叉路口
//SEARCHPOITYPE_BY_NEARBY_3      = 3,//周边
//SEARCHPOITYPE_BY_CATEGARY_4    = 4,//周边类别
//SEARCHPOITYPE_BY_NET_KEYWORD_10 = 10,//关键字网络搜索
//SEARCHPOITYPE_BY_NET_ADDRESS_11 = 11,//道路名网络搜索
//SEARCHPOITYPE_BY_NET_CROSS_12  = 12,//十字路口网络搜索
//SEARCHPOITYPE_BY_NET_NEARBY_13  = 13,//周边网络搜索
-(BOOL)searchPOI:(NSString *)Keyword SearchType:(SEARCHPOITYPE)type SortType:(int)sortType
{
    /*
     Step 1: distingusish keyword search and around search
     */
	if (type == 0 || type == 1 || type == 2 || type == 10|| type == 11|| type == 12) {
		searchType = 0;
	}
	else {
		searchType = 1;
	}
    /*
     Step 2: setting the param for search
     */
	searchSortType = sortType;
	
	GSEARCHCONDITION pSearchCondition;
    memset(&pSearchCondition, 0, sizeof(GSEARCHCONDITION));
	
	switch (type) 
	{
		case SEARCHPOITYPE_BY_INTELGENT_0://智能
		{
			pSearchCondition.eSearchType = GSEARCH_TYPE_NAME;
			
		}
			break;
			
		case SEARCHPOITYPE_BY_ADDRESS_1://门址
		{
			pSearchCondition.eSearchType = GSEARCH_TYPE_ADDRESS;
		}
			break;
			
		case SEARCHPOITYPE_BY_CROSS_2://交叉路口
		{
			pSearchCondition.eSearchType = GSEARCH_TYPE_CROSS;
		}
			break;
			
		case SEARCHPOITYPE_BY_NEARBY_3://周边(关键字检索)
		{
			pSearchCondition.eSearchType = GSEARCH_TYPE_AROUND;
			pSearchCondition.lCategoryID = poiCategoryID;
			pSearchCondition.lAroundRange = m_nAroundRange;
            m_nAroundRange = 100000;
			pSearchCondition.Coord = [ANParamValue sharedInstance].searchMapInfo;
		}
			break;
			
		case SEARCHPOITYPE_BY_CATEGARY_4://POI类别
		{
		    m_bNetOrLocalSearch = 0;
            if (m_nAroundSearchType) {
                pSearchCondition.eSearchType = GSEARCH_TYPE_ROUTEPOI;
                pSearchCondition.eRoutePoiType = GROUTEPOI_TYPE_ALL;
            } else {
                pSearchCondition.eSearchType = GSEARCH_TYPE_AROUND;
            }
            pSearchCondition.lCategoryID = poiCategoryID;		
			pSearchCondition.lAroundRange = 100000;
			pSearchCondition.Coord = [ANParamValue sharedInstance].searchMapInfo;
		}
			break;
            
		case SEARCHPOITYPE_BY_NET_KEYWORD_10://关键字网络搜索
		{
            m_bNetOrLocalSearch = 1;
            
			pSearchCondition.eSearchType = GSEARCH_TYPE_NAME;
            }
            break;
        case SEARCHPOITYPE_BY_NET_ADDRESS_11://道路网络搜索
            {
            m_bNetOrLocalSearch = 1;
            
			pSearchCondition.eSearchType = GSEARCH_TYPE_ADDRESS;
//            pSearchCondition.eSearchType = GSEARCH_TYPE_NAME;
		}
			break;
        case SEARCHPOITYPE_BY_NET_CROSS_12://路口网络搜索
		{
            m_bNetOrLocalSearch = 1;
           
			pSearchCondition.eSearchType = GSEARCH_TYPE_CROSS;
//			pSearchCondition.eSearchType = GSEARCH_TYPE_NAME;
        }
            break;
		case SEARCHPOITYPE_BY_NET_NEARBY_13://周边网络搜索
		{
            m_bNetOrLocalSearch = 1;
            
			pSearchCondition.eSearchType = GSEARCH_TYPE_AROUND;
			pSearchCondition.lCategoryID = poiCategoryID;
			pSearchCondition.lAroundRange =50000;
			pSearchCondition.Coord = [ANParamValue sharedInstance].searchMapInfo;
            }
			break;
	}
    /*
     Step 3:Start search process
     */
    GSTATUS ret;
	switch (type)
	{
		case SEARCHPOITYPE_BY_INTELGENT_0:  //智能	
		case SEARCHPOITYPE_BY_ADDRESS_1:    //门址
		case SEARCHPOITYPE_BY_CROSS_2:      //交叉路口
		case SEARCHPOITYPE_BY_NEARBY_3:     //周边
		case SEARCHPOITYPE_BY_CATEGARY_4:   //POI类别
		{
            m_bNetOrLocalSearch = 0;
            if (Keyword) {
                const char *string = NSSTRING_TO_CSTRING(Keyword) ;
                if(string)
                {
                    strcpy(pSearchCondition.szKeyword,string );
                }
            }
            ret =  GDBL_StartSearchPOI(&pSearchCondition);

		}
			break;
			
		case SEARCHPOITYPE_BY_NET_KEYWORD_10:   //关键字网络搜索
        case SEARCHPOITYPE_BY_NET_ADDRESS_11:   //关键字网络搜索
        case SEARCHPOITYPE_BY_NET_CROSS_12:     //关键字网络搜索
		case SEARCHPOITYPE_BY_NET_NEARBY_13:    //周边网络搜索
		{
            m_bNetOrLocalSearch = 1;
            if (Keyword) {
                const char *string = [Keyword cStringUsingEncoding:NSUTF8StringEncoding];
                if(string)
                {
                    strcpy(pSearchCondition.szKeyword, string);
                }
            }
            ret = GDBL_StartSearchPOINet(&pSearchCondition);
        }
			break;
	}
	if(ret != GD_ERR_OK)
	{
		return NO;
	}
	return YES;
    

}
//指定点周边搜索
-(BOOL)AroundsearchPOI:(NSString *)Keyword SearchType:(int)type SearchCoord:(GCOORD)poiCoord SortType:(int)sortType
{
	
    searchType = 1;
	searchSortType = sortType;
	
	GSEARCHCONDITION pSearchCondition;
    memset(&pSearchCondition, 0, sizeof(GSEARCHCONDITION));
	
	switch (type)
	{
			
		case 0://周边
		{
			pSearchCondition.eSearchType = GSEARCH_TYPE_AROUND;
			pSearchCondition.lCategoryID = poiCategoryID;
			pSearchCondition.lAroundRange = 100000;
			pSearchCondition.Coord = poiCoord;
		}
			break;
			
		case 1://周边网络搜索
		{
            
			pSearchCondition.eSearchType = GSEARCH_TYPE_AROUND;
			pSearchCondition.lCategoryID = poiCategoryID;
            
			pSearchCondition.lAroundRange =50000;
			pSearchCondition.Coord = poiCoord;
            
            GSTATUS res;
            
                res = GDBL_StartSearchPOINet(&pSearchCondition);
        
			if (res != GD_ERR_OK) {
				return NO;
			}
			return YES;
		}
			break;
		default:
			break;
	}
    const char *string = NSSTRING_TO_CSTRING(Keyword) ;
    if(string)
    {
        strcpy(pSearchCondition.szKeyword,string);
    }
	GSTATUS ret =  GDBL_StartSearchPOI(&pSearchCondition);
	if(ret != GD_ERR_OK)
	{
		return NO;
	}
	return YES;
}
//语音命令字搜索
-(BOOL)voicePOISearch:(int)MID
{
    int searchID;
    switch (MID) {
        case 101:
            searchID = 10000;
            break;
        case 104:
            searchID = 20000;
            break;
        case 200:
            searchID = 40000;
            break;
        case 201:
            searchID = 40100;
            break;
        case 202:
            searchID = 40200;
            break;
        case 300:
            searchID = 50000;
            break;
        case 301:
            searchID = 50300;
            break;
        case 302:
            searchID = 50600;
            break;
        case 401:
            searchID = 90400;
            break;
        case 40:
            searchID = 130000;
            break;
        case 404:
            searchID = 130100;
            break;
        case 405:
            searchID = 130200;
            break;
        case 406:
            searchID = 160100;
            break;
        case 407:
            searchID = 90100;
            break;
        case 408:
            searchID = 70000;
            break;
        case 500:
            searchID = 60000;
            break;
        case 501:
            searchID = 60900;
            break;
        case 502:
            searchID = 60600;
            break;
        case 503:
            searchID = 60300;
            break;
        case 504:
            searchID = 60400;
            break;
        case 505:
            searchID = 60200;
            break;
        case 599:
            searchID = 62900;
            break;
        case 600:
            searchID = 80000;
            break;
        case 700:
            searchID = 200000;
            break;
        case 800:
            searchID = 140800;
            break;
        case 900:
            searchID = 100000;
            break;
        case 901:
            searchID = 100100;
            break;
        case 902:
            searchID = 100200;
            break;
        case 903:
            searchID = 150300;
            break;
        case 1000:
            searchID = 110000;
            break;
        case 1100:
            searchID = 170000;
            break;
        case 1101:
            searchID = 170100;
            break;
        case 1102:
            searchID = 170300;
            break;
        case 1200:
            searchID = 120000;
            break;
        case 1300:
            searchID = 150200;
            break;
        case 1301:
            searchID = 160400;
            break;
        case 1302:
            searchID = 180000;
            break;
        case 1400:
            searchID = 190000;
            break;
        case 1403:
            searchID = 190300;
            break;
        case 1500:
            searchID = 140000;
            break;
        case 1501:
            searchID = 140100;
            break;
        case 1502:
            searchID = 140200;
            break;
        case 1503:
            searchID = 140400;
            break;
        case 1504:
            searchID = 140400;
            break;
        case 1505:
            searchID = 140400;
            break;
        case 1506:
            searchID = 140300;
            break;
        case 1600:
            searchID = 150400;
            break;

        default:
            break;
    }
    poiCategoryID = searchID;
    // 周边检索
//    BOOL bStatus = [self searchPOI:nil SearchType:SEARCHPOITYPE_BY_NEARBY_3 SortType:1];
		return YES;
	}
#pragma mark 消息接收处理
- (void)listenNotification:(NSNotification *)notification {
	
	if ([notification.name isEqual:NOTIFY_GETPOIDATA])
	{
		NSLog(@"ddd--%@",[notification.object objectAtIndex:0]);
        
		NSArray *result = [notification object];
        if ([[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_NEAREST_POI_1) { //获取附近点信息
            if ([[result objectAtIndex:1] intValue] == _GD_SEARCH_RESULT_SUCCESS_0)  //成功
            {
                
                GDBL_GetNearestPOI(&pNearestPOI);
                [self arrayForNearPOISearch];
                
            }
            else  //失败
            {
                DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
                msg.flag = _GD_SEARCH_RESULT_FAILED_1;
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
                [msg release];
                
            }
            
        }
        else if ([[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_GENERAL_0 || [[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_ONLINE_3) //搜索，周边，网络
        {
            if ([[result objectAtIndex:1] intValue] == _GD_SEARCH_RESULT_SUCCESS_0) //成功
            {
                GETPOIINPUT input;
                input.sIndex = 0;//首次默认从第0条开始获取
                input.sNumberOfItemToGet= 500; //从开始条数序号起，要获取的条数
                
                GPOIRESULT *pResult;
			    GSTATUS res;
                res = GDBL_GetPOIResult(&input, &pResult);
                if (res!=0) //无结果
                {
					
					DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
					msg.flag = _GD_SEARCH_RESULT_FAILED_1;
					[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
					[msg release];
                    return;
                }
                
                for (int i=0; i<pResult->sNumberOfItemGet; i++)
                {
                    poiResult[i] = pResult->pPOI[i];
                }
                
                cellNumber = pResult->sNumberOfItemGet;
				
                if (cellNumber == pResult->sNumberOfTotalItem) {
					if (searchType == 0) {
                        // 引擎传递过来的数据编码格式不同
                        if (m_bNetOrLocalSearch == 0) {
                            [self arrayForGoWhereSearch];
                        } else {
                            [self arrayForNetPOISearch];
                        }
					}
					else if(searchType == 1){
                        // 引擎传递过来的数据编码格式不同
                        if (m_bNetOrLocalSearch == 0) {
                            [self arrayForAroundSearch];
                        } else {
                            [self arrayForNetPOISearch];
                        }
					}
                    
                    
                }
            }
            else//失败
            {
                
                if ([[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_ONLINE_3) { //网络搜索失败
					DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
                    if ([[result objectAtIndex:1] intValue] == _GD_SEARCH_RESULT_ONLINE_FAILED_2) {
                        msg.flag = _GD_SEARCH_RESULT_ONLINE_FAILED_2;
                    }
                    else
                    {
                        msg.flag = _GD_SEARCH_RESULT_FAILED_1;
                    }
					
					[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
					[msg release];
				}
				else {
					DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
					msg.flag = _GD_SEARCH_RESULT_FAILED_1;
					[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
					[msg release];
				}
                
                
                
            }
            
        }
        else if ([[result objectAtIndex:0] intValue] == _GD_SEARCH_TYPE_OTHER_CITY_INOF_4 )//获取城市列表
        {
            if (m_bLocalAddOnlineData) {
                DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
                msg.flag = _GD_SEARCH_RESULT_FAILED_1;
                [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
                [msg release];
            } else {
            [self arrayForCityItem];
        }
	}
	}
    
}
#pragma mark 设置poi搜索类型(参数mainID为类别级数)
- (void)GMD_SetPOICategoryIDWithMainID:(NSInteger)mainID subCategory:(NSInteger)nIndex{
	
	switch (mainID)
	{
		case 0:
		{
			poiCategoryID = ppCategoryList->pCategory[CategoryListID-1].lCategoryID;
		}
			break;
            
		case 1:
		{
            poiCategoryID = ppCategoryList->pCategory[CategoryListID-1].pSubCategory[nIndex].lCategoryID;
		}
			break;
			
		case 2:
		{
            poiCategoryID = 0;
            
		}
			break;
	}
}
/**********************************************************************
 * 函数名称: searchAroundPOIList
 * 功能描述: 获取周边对应关键字搜索结果
 * 输入参数: (int)index列表索引
 * 输出参数:
 * 返 回 值: NO：失败 YES:成功
 * 其它说明:
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(BOOL)searchAroundPOIList:(int)index
{
	
	BOOL res;
	res = [self searchPOI:[NSString stringWithFormat:@"%d",index] SearchType:4 SortType:0];
	if (res) {
		return YES;
	}
	
	return NO;
}
// 周边检索 10-29lyh //0:按照传入的点检索 1：按照路径检索
-(void) setAroundSearchType:(int)nAroundSearchType
{
    m_nAroundSearchType = nAroundSearchType;
}
// 周边检索 10-29lyh //0:按照传入的点检索 1：按照路径检索
-(int) getAroundSearchType
{
    return m_nAroundSearchType;
}

/**********************************************************************
 * 函数名称: getBackCategoryList
 * 功能描述: 返回上一级，重新获取列表
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明:
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
- (void)getBackCategoryList
{
	[self searchAroundPOIType:CategoryListID];
}

/**********************************************************************
 * 函数名称: searchAroundPOIType
 * 功能描述: 获取周边对应关键字搜索子列表
 * 输入参数: (int)index列表索引
 * 输出参数:
 * 返 回 值: NO：无子类别 YES:有子类别
 * 其它说明:
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(BOOL)searchAroundPOIType:(int)index
{
	if (m_arrayAroundSearchPOIArray)
	{
		[m_arrayAroundSearchPOIArray release];
	}
	m_arrayAroundSearchPOIArray = [[NSMutableArray alloc] init];
	
	CategoryListID = index;
	
	if (index==0)
	{
		GDBL_GetPOICategoryList(0, &ppCategoryList);
		for (int i=0; i<ppCategoryList->lNumberOfCategory; i++)
		{
			[m_arrayAroundSearchPOIArray addObject:[NSString chinaFontStringWithCString:ppCategoryList->pCategory[i].szName]];
		}
	}
	else
	{
		if (0==ppCategoryList->pCategory[index-1].nNumberOfSubCategory)
		{
			return NO;
		}
		for (int i=0; i<ppCategoryList->pCategory[index-1].nNumberOfSubCategory; i++)
		{
			[m_arrayAroundSearchPOIArray addObject:[NSString chinaFontStringWithCString:ppCategoryList->pCategory[index-1].pSubCategory[i].szName]];
		}
	}
	return YES;
}
#pragma mark 填充结果
- (void)arrayForNearPOISearch 
{
    if (NearPoiArray) 
	{
		[NearPoiArray release];
		NearPoiArray = nil;
	}
	NearPoiArray = [[NSMutableArray alloc] init];
    plugin_PoiNode *node = [[plugin_PoiNode alloc] init];
    node.lLon = pNearestPOI.Coord.x;
    node.lLat = pNearestPOI.Coord.y;
    node.lCategoryID = pNearestPOI.lCategoryID;
    node.lDistance = pNearestPOI.lDistance;
    node.lMatchCode = pNearestPOI.lMatchCode;
    node.lHilightFlag = pNearestPOI.lHilightFlag;
    node.lAdminCode = pNearestPOI.lAdminCode;
    node.lPoiId = pNearestPOI.lPoiId;
    node.siELonOff = pNearestPOI.siELonOff;
    node.siELatOff = pNearestPOI.siELatOff;
    node.szName = [NSString chinaFontStringWithCString:pNearestPOI.szName];
    node.szAddr = [NSString chinaFontStringWithCString:pNearestPOI.szAddr];
    node.szTel = [NSString chinaFontStringWithCString:pNearestPOI.szTel];
    node.lPoiIndex = pNearestPOI.lPoiIndex;
    node.ucFlag = pNearestPOI.ucFlag;
    node.ucNodeType = pNearestPOI.Reserved;
    node.usNodeId = pNearestPOI.usNodeId;
    // NSLog(@"qqq=%@ %@ %@",node.szTel,node.szName,node.szAddr);
    [NearPoiArray addObject:node];[node release];
    
    DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
    msg.flag = _GD_SEARCH_RESULT_SUCCESS_0;
	[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
    [msg release];
}
- (void)arrayForFav 
{
	if (FavArray) 
	{
		[FavArray release];
        FavArray = nil;
	}
	FavArray = [[NSMutableArray alloc] init];
	
	for (int i=0; i<cellNumber; i++) 
	{
		plugin_PoiNode *node = [[plugin_PoiNode alloc] init];
		node.lLon = poiResult[i].Coord.x;
		node.lLat = poiResult[i].Coord.y;
		node.lCategoryID = poiResult[i].lCategoryID;
		node.lDistance = poiResult[i].lDistance;
		node.lMatchCode = poiResult[i].lMatchCode;
		node.lHilightFlag = poiResult[i].lHilightFlag;
		node.lAdminCode = poiResult[i].lAdminCode;
		node.lPoiId = poiResult[i].lPoiId;
		node.siELonOff = poiResult[i].siELonOff;
		node.siELatOff = poiResult[i].siELatOff;
		node.szName = [NSString chinaFontStringWithCString:poiResult[i].szName];
		node.szAddr = [NSString chinaFontStringWithCString:poiResult[i].szAddr];
		node.szTel = [NSString chinaFontStringWithCString:poiResult[i].szTel];
		node.lPoiIndex = poiResult[i].lPoiIndex;
		node.ucFlag = poiResult[i].ucFlag;
		node.ucNodeType = poiResult[i].Reserved;
		node.usNodeId = poiResult[i].usNodeId;
		[FavArray addObject:node];[node release];
	}
	cellNumber = 0;
    
}

-(void)arrayForNetPOISearch
{
    //
    NSMutableArray *mArrayForKeyOrAround;
    // 去哪里
	if (searchType == 0) {
        if (m_bLocalAddOnlineData) {
            // 添加数据
            mArrayForKeyOrAround = GoWherePOIArray;
        } else {
            // 重新填充数据
            if (GoWherePOIArray)
	{
                [GoWherePOIArray release];
                GoWherePOIArray = nil;
            }
            GoWherePOIArray = [[NSMutableArray alloc] init];
            mArrayForKeyOrAround = GoWherePOIArray;
	}
    }
    // 周边检索
    else if(searchType == 1) {
        if (m_arrayAroundSearchPOIArray)
        {
            [m_arrayAroundSearchPOIArray release];
            m_arrayAroundSearchPOIArray = nil;
        }
        m_arrayAroundSearchPOIArray = [[NSMutableArray alloc] init];
        mArrayForKeyOrAround = m_arrayAroundSearchPOIArray;
    }
    // 计算距离
    GCARINFO carInfo = {0};
    GDBL_GetCarInfo(&carInfo);
    for (int i = 0; i<cellNumber; i++) {
        Gint32 nDistance;
        GDBL_CalcDistance(&carInfo.Coord, &poiResult[i].Coord, &nDistance);
        poiResult[i].lDistance = nDistance;
    }
//	switch (searchSortType)
//	{
//		case 0:
//		{
//			
//		}
//			break;
//			
//		case 1:
//		{
//			GPOI *temp = (GPOI*)malloc(sizeof(GPOI));
//			int kk = cellNumber;
//			for (int j=0; j<kk-1;j++)
//			{
//				for (int k=0; k<cellNumber-j-1;k++)
//				{
//					if (poiResult[k].lDistance > poiResult[k+1].lDistance)
//					{
//						*temp = poiResult[k];
//						poiResult[k] = poiResult[k + 1];
//						poiResult[k + 1] = *temp;
//					}
//				}
//			}
//			free(temp);
//			temp = NULL;
//		}
//			break;
//			
//		default:
//			break;
//	}
	
	for (int i=0; i<cellNumber; i++)
	{
		plugin_PoiNode *node = [[plugin_PoiNode alloc] init];
		node.lLon = poiResult[i].Coord.x;
		node.lLat = poiResult[i].Coord.y;
		node.lCategoryID = poiResult[i].lCategoryID;
		node.lDistance = poiResult[i].lDistance;
		node.lMatchCode = poiResult[i].lMatchCode;
		node.lHilightFlag = 0/*poiResult[i].lHilightFlag*/;
		node.lAdminCode = poiResult[i].lAdminCode;
		node.lPoiId = poiResult[i].lPoiId;
		node.siELonOff = poiResult[i].siELonOff;
		node.siELatOff = poiResult[i].siELatOff;
        node.szName = [NSString stringWithCString:poiResult[i].szName encoding:NSUTF8StringEncoding];
		node.szAddr = [NSString stringWithCString:poiResult[i].szAddr encoding:NSUTF8StringEncoding];
		node.szTel = [NSString stringWithCString:poiResult[i].szTel encoding:NSUTF8StringEncoding];
		node.lPoiIndex = poiResult[i].lPoiIndex;
		node.ucFlag = poiResult[i].ucFlag;
		node.ucNodeType = poiResult[i].Reserved;
		node.usNodeId = poiResult[i].usNodeId;
		[mArrayForKeyOrAround addObject:node];[node release];
	}
	cellNumber = 0;
    // 距离排序
    if (searchSortType) {
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"lDistance" ascending:YES];
        NSArray *tempArray = [mArrayForKeyOrAround sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
        [mArrayForKeyOrAround release];
        if (searchType == 0) {
            GoWherePOIArray = [[NSMutableArray arrayWithArray:tempArray] retain];
        }
        else if(searchType == 1) {
            m_arrayAroundSearchPOIArray = [[NSMutableArray arrayWithArray:tempArray] retain];
        }
    }
	DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
    msg.flag = _GD_SEARCH_RESULT_SUCCESS_0;
	[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
    [msg release];
}

-(void)arrayForGoWhereSearch
{
	if (GoWherePOIArray)
	{
		[GoWherePOIArray release];
        GoWherePOIArray = nil;
	}
	GoWherePOIArray = [[NSMutableArray alloc] init];
	
	switch (searchSortType) 
	{
		case 0:
		{
			
		}
			break;
			
		case 1:
		{
			GPOI *temp = (GPOI*)malloc(sizeof(GPOI));
			int kk = cellNumber;
			for (int j=0; j<kk-1;j++) 
			{
				for (int k=0; k<cellNumber-j-1;k++) 
				{
					if (poiResult[k].lDistance > poiResult[k+1].lDistance) 
					{
						*temp = poiResult[k];
						poiResult[k] = poiResult[k + 1];
						poiResult[k + 1] = *temp;
					}
				}
			}
			free(temp);
			temp = NULL;
		}
			break;
			
		default:
			break;
	}
	
	for (int i=0; i<cellNumber; i++) 
	{
		plugin_PoiNode *node = [[plugin_PoiNode alloc] init];
		node.lLon = poiResult[i].Coord.x;
		node.lLat = poiResult[i].Coord.y;
		node.lCategoryID = poiResult[i].lCategoryID;
		node.lDistance = poiResult[i].lDistance;
		node.lMatchCode = poiResult[i].lMatchCode;
		node.lHilightFlag = poiResult[i].lHilightFlag;
		node.lAdminCode = poiResult[i].lAdminCode;
		node.lPoiId = poiResult[i].lPoiId;
		node.siELonOff = poiResult[i].siELonOff;
		node.siELatOff = poiResult[i].siELatOff;
		node.szName = [NSString chinaFontStringWithCString:poiResult[i].szName];
		node.szAddr = [NSString chinaFontStringWithCString:poiResult[i].szAddr];
		node.szTel = [NSString chinaFontStringWithCString:poiResult[i].szTel];
		node.lPoiIndex = poiResult[i].lPoiIndex;
		node.ucFlag = poiResult[i].ucFlag;
		node.ucNodeType = poiResult[i].Reserved;
		node.usNodeId = poiResult[i].usNodeId;
		[GoWherePOIArray addObject:node];[node release];
	}
	cellNumber = 0;
    
	DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
    msg.flag = _GD_SEARCH_RESULT_SUCCESS_0;
	[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
    [msg release];
}
- (void)arrayForAroundSearch
{
	if (m_arrayAroundSearchPOIArray)
	{
		[m_arrayAroundSearchPOIArray release];
        m_arrayAroundSearchPOIArray = nil;
	}
	m_arrayAroundSearchPOIArray = [[NSMutableArray alloc] init];
	
	switch (searchSortType) 
	{
		case 0:
		{
			
		}
			break;
			
		case 1:
		{
			GPOI *temp = (GPOI*)malloc(sizeof(GPOI));
			int kk = cellNumber;
			for (int j=0; j<kk-1;j++) 
			{
				for (int k=0; k<cellNumber-j-1;k++) 
				{
					if (poiResult[k].lDistance > poiResult[k+1].lDistance) 
					{
						*temp = poiResult[k];
						poiResult[k] = poiResult[k + 1];
						poiResult[k + 1] = *temp;
					}
				}
			}
			free(temp);
			temp = NULL;
		}
			break;
			
		default:
			break;
	}
	
	for (int i=0; i<cellNumber; i++) 
	{
		plugin_PoiNode *node = [[plugin_PoiNode alloc] init];
		node.lLon = poiResult[i].Coord.x;
		node.lLat = poiResult[i].Coord.y;
		node.lCategoryID = poiResult[i].lCategoryID;
		node.lDistance = poiResult[i].lDistance;
		node.lMatchCode = poiResult[i].lMatchCode;
		node.lHilightFlag = poiResult[i].lHilightFlag;
		node.lAdminCode = poiResult[i].lAdminCode;
		node.lPoiId = poiResult[i].lPoiId;
		node.siELonOff = poiResult[i].siELonOff;
		node.siELatOff = poiResult[i].siELatOff;
		node.szName = [NSString chinaFontStringWithCString:poiResult[i].szName];
		node.szAddr = [NSString chinaFontStringWithCString:poiResult[i].szAddr];
		node.szTel = [NSString chinaFontStringWithCString:poiResult[i].szTel];
		node.lPoiIndex = poiResult[i].lPoiIndex;
		node.ucFlag = poiResult[i].ucFlag;
		node.ucNodeType = poiResult[i].Reserved;
		node.usNodeId = poiResult[i].usNodeId;

		[m_arrayAroundSearchPOIArray addObject:node];[node release];
	}
	cellNumber = 0;
    
	DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
    msg.flag = _GD_SEARCH_RESULT_SUCCESS_0;
	[[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
    [msg release];
    
}

-(GPOI)plugin_poiNodeToGPOI:(plugin_PoiNode *)node
{
    GPOI poiResul = {0};
    poiResul.Coord.x = node.lLon;
    poiResul.Coord.y = node.lLat;
    poiResul.lCategoryID = node.lCategoryID;
    poiResul.lDistance = node.lDistance;
    poiResul.lMatchCode = node.lMatchCode;
    poiResul.lHilightFlag = node.lHilightFlag;
    poiResul.lAdminCode = node.lAdminCode;
    poiResul.lPoiId = node.lPoiId;
    poiResul.siELonOff = node.siELonOff;
    poiResul.siELatOff = node.siELatOff;
    if([node.szName length] != 0)
    {
        memcpy(poiResul.szName,NSSTRING_TO_CSTRING(node.szName) ,strlen(NSSTRING_TO_CSTRING(node.szName)));
    }
    if([node.szAddr length] != 0)
    {
        memcpy(poiResul.szAddr,NSSTRING_TO_CSTRING(node.szAddr),strlen(NSSTRING_TO_CSTRING(node.szAddr)));
    }
    if([node.szTel length] != 0)
    {
        memcpy(poiResul.szTel,NSSTRING_TO_CSTRING(node.szTel),strlen(NSSTRING_TO_CSTRING(node.szTel)));
    }
    poiResul.lPoiIndex = node.lPoiIndex;
    poiResul.ucFlag = node.ucFlag;
    poiResul.Reserved = node.ucNodeType;
    poiResul.usNodeId = node.usNodeId;
    return poiResul;
    
}
- (void)arrayForCityItem
{
    if (CityItemArray)
	{
		[CityItemArray release];
		CityItemArray = nil;
	}
	CityItemArray = [[NSMutableArray alloc] init];
    GADAREALIST *ppAdareaList;
    GSTATUS res;
    res = GDMID_GetNetCandidateAdareaList (&ppAdareaList);
    if (res == GD_ERR_OK) {
        for (int i = 0; i< ppAdareaList->lNumberOfAdarea; i++) {
            SubCityItem *node = [[SubCityItem alloc] init];
                        
            node.lAdminCode = ppAdareaList->pAdarea[i].lAdminCode;
            node.szAdminName = [NSString stringWithCString:ppAdareaList->pAdarea[i].szAdminName encoding:NSUTF8StringEncoding];
            node.szAdminSpell = [NSString stringWithCString:ppAdareaList->pAdarea[i].szAdminSpell encoding:NSUTF8StringEncoding];
            node.lNumberOfSubAdarea = ppAdareaList->pAdarea[i].lNumberOfSubAdarea;
            [CityItemArray addObject:node];[node release];
        }
        DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
        msg.flag = _GD_SEARCH_RESULT_TO_OTHER_CITY_INFO_3;
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
        [msg release];
    }
    else{//获取失败
        DefineNotificationParam *msg = [[DefineNotificationParam alloc] init];
        msg.flag = _GD_SEARCH_RESULT_FAILED_1;
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFY_POISEARCH object:msg];
        [msg release];
    }
    
}
#pragma mark 获取结果
/**********************************************************************
 * 函数名称: localPOIList
 * 功能描述: 返回周边poi列表
 * 输入参数:
 * 输出参数:
 * 返 回 值: 周边poi列表
 * 其它说明:
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(NSMutableArray *)ReturnAroundSearchPOIList
{
	return [NSMutableArray arrayWithArray:m_arrayAroundSearchPOIArray];
}
//搜索结果
-(NSMutableArray *)ReturnGoWhereSearchPOIList
{
	return [NSMutableArray arrayWithArray:GoWherePOIArray];
}
//返回附近点poi列表
-(NSMutableArray *)NearPOIList
{
	return [NSMutableArray arrayWithArray:NearPoiArray];
}
//返回我的收藏poi列表
-(NSMutableArray *)FavPOIList
{
	return [NSMutableArray arrayWithArray:FavArray];
}
//返回城市列表
-(NSMutableArray *)GetCityList
{
	return [NSMutableArray arrayWithArray:CityItemArray];
}
#pragma mark 清空搜索结果
//搜索结果
-(void)clearGoWhereSearchPOIList
{
	if (GoWherePOIArray) {
        [GoWherePOIArray removeAllObjects];
        [GoWherePOIArray release];
        GoWherePOIArray = nil;
    }
}
#pragma mark 我的收藏 --------------------------------------
#pragma mark 获取搜藏夹列表(参数为poi的类型)
- (BOOL)GMD_GetFavoriteListWithMainID:(NSInteger)mainID {

    GSTATUS res;
	res = GDBL_GetFavoriteList(mainID, &ppFavoritePOIList);
    if (res == 3) {
		[FavArray removeAllObjects];
        return NO;
    }
   
	cellNumber = ppFavoritePOIList->nNumberOfItem;
	for (int i=0; i<cellNumber; i++) 
	{
		poiResult[i] = ppFavoritePOIList->pFavoritePOI[i].Poi;
	}
	
	[self arrayForFav];
	return YES;
}

#pragma mark 添加收藏夹兴趣点(参数mainID为收藏类型,index为poi的索引值，要是收藏当前点传1000)
- (int)GMD_AddFavoriteWithMainID:(GFAVORITECATEGORY)eCategory iconType:(GFAVORITEICON)icon index:(NSInteger)index WithPOI:(plugin_PoiNode *)node
{
    GPOI pPOI = {0};
    
    if (1000==index)
    {
        //获取地图中心信息
        GMAPCENTERINFO mapinfo = {0};
        [[MWMapOperator sharedInstance] MW_GetMapViewCenterInfo:GMAP_VIEW_TYPE_MAIN mapCenterInfo:&mapinfo];
        pPOI.Coord = mapinfo.CenterCoord;//坐标
        strcpy(pPOI.szName, mapinfo.szRoadName);//道路名
    }
    else
    {
        pPOI.Coord.x = node.lLon;
        pPOI.Coord.y = node.lLat;
        pPOI.lCategoryID = node.lCategoryID;
        pPOI.lDistance = node.lDistance;
        pPOI.lMatchCode = node.lMatchCode;
        pPOI.lHilightFlag = node.lHilightFlag;
        pPOI.lAdminCode = node.lAdminCode;
        pPOI.lPoiId = node.lPoiId;
        pPOI.siELonOff = node.siELonOff;
        pPOI.siELatOff = node.siELatOff;
        if([node.szName length] != 0)
        {
            
            memcpy(pPOI.szName,NSSTRING_TO_CSTRING(node.szName) ,strlen(NSSTRING_TO_CSTRING(node.szName)));
        }
        if([node.szAddr length] != 0)
        {

            memcpy(pPOI.szAddr,NSSTRING_TO_CSTRING(node.szAddr),strlen(NSSTRING_TO_CSTRING(node.szAddr)));

        }
        if([node.szTel length] != 0)
        {
            memcpy(pPOI.szTel,NSSTRING_TO_CSTRING(node.szTel),strlen(NSSTRING_TO_CSTRING(node.szTel)));
        }
        pPOI.lPoiIndex = node.lPoiIndex;
        pPOI.ucFlag = node.ucFlag;
        pPOI.Reserved = node.ucNodeType;
        pPOI.usNodeId = node.usNodeId;
    }
    
    return GDBL_AddFavorite(eCategory,icon,&pPOI);
}

#pragma mark 删除收藏夹poi(参数为索引值)
- (int)GMD_DelFavoriteWithIndex:(NSInteger)index {
	
	Gint32 pIndex = (Gint32)ppFavoritePOIList->pFavoritePOI[index].nIndex;
	return GDBL_DelFavorite(&pIndex, 1);
    
}

#pragma mark 清空收藏夹兴趣点(参数为poi的类型)
- (int)GMD_ClearFavoriteWithMainID:(NSInteger)mainID {
	
	GFAVORITECATEGORY eCategory = (GFAVORITECATEGORY)mainID;
	return GDBL_ClearFavorite(eCategory);
    
}
#pragma mark 编辑收藏夹兴趣点
-(int)GMD_EditFavoriteWithPOI:(plugin_PoiNode *)node WithIndex:(int)index Type:(int)type
{
    
    GFAVORITEPOI pFavoritePOI = {0};
    
    NSDate *localDate = [NSDate date];
    NSCalendar  * cal=[NSCalendar  currentCalendar];  
    NSUInteger  unitFlags=NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit;  
    NSDateComponents * conponent= [cal components:unitFlags fromDate:localDate];  
    NSInteger year=[conponent year];  
    NSInteger month=[conponent month];  
    NSInteger day=[conponent day];
    
    NSDateFormatter *timeFormatter = [[[NSDateFormatter alloc]init]autorelease];
    timeFormatter.dateFormat = @"HH:mm:ss";
    NSString *dateString = [timeFormatter stringFromDate:localDate];
    NSInteger hour = [[dateString CutToNSString:@":"] intValue];
    NSInteger min = [[dateString CutFromNSString:@":" Tostring:@":"] intValue];
    NSInteger second = [[dateString CutToNSStringBackWard:@":"] intValue];
    
    pFavoritePOI.Date.year = year;
    pFavoritePOI.Date.month = month;
    pFavoritePOI.Date.day = day;
    pFavoritePOI.Time.hour = hour;
    pFavoritePOI.Time.minute = min;
    pFavoritePOI.Time.second = second;
    
    pFavoritePOI.eCategory = (GFAVORITECATEGORY)type;
    pFavoritePOI.nIndex = index;
    
    pFavoritePOI.Poi.Coord.x = node.lLon;
    pFavoritePOI.Poi.Coord.y = node.lLat;
    pFavoritePOI.Poi.lCategoryID = node.lCategoryID;
    pFavoritePOI.Poi.lDistance = node.lDistance;
    pFavoritePOI.Poi.lMatchCode = node.lMatchCode;
    pFavoritePOI.Poi.lHilightFlag = node.lHilightFlag;
    pFavoritePOI.Poi.lAdminCode = node.lAdminCode;
    pFavoritePOI.Poi.lPoiId = node.lPoiId;
    pFavoritePOI.Poi.siELonOff = node.siELonOff;
    pFavoritePOI.Poi.siELatOff = node.siELatOff;
    if([node.szName length] != 0)
    {
        memcpy(pFavoritePOI.Poi.szName,NSSTRING_TO_CSTRING(node.szName) ,strlen(NSSTRING_TO_CSTRING(node.szName)));
    }
    if([node.szAddr length] != 0)
    {
        memcpy(pFavoritePOI.Poi.szAddr,NSSTRING_TO_CSTRING(node.szAddr),strlen(NSSTRING_TO_CSTRING(node.szAddr)));
    }
    if([node.szTel length] != 0)
    {
        memcpy(pFavoritePOI.Poi.szTel,NSSTRING_TO_CSTRING(node.szTel),strlen(NSSTRING_TO_CSTRING(node.szTel)));
    }
    
    pFavoritePOI.Poi.lPoiIndex = node.lPoiIndex;
    pFavoritePOI.Poi.ucFlag = node.ucFlag;
    pFavoritePOI.Poi.Reserved = node.ucNodeType;
    pFavoritePOI.Poi.usNodeId = node.usNodeId;	
    GSTATUS res;
    res = GDBL_EditFavorite(&pFavoritePOI);
    return res;
}


	
- (void)GMD_ViewPOIWithIndex:(NSInteger)index {
	
	GDBL_ViewPOI(&poiResult[index], Gtrue);
}

-(void)GMD_SetAroundRangeForNextSearch:(int)nMeter
{
    m_nAroundRange = nMeter;
}
@end
