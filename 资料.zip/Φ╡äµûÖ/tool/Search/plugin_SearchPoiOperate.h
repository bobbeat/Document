//
//  plugin_SearchPOIOperate.h
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin_SearchPoi.h"
#import "GDBL_typedef.h"
#import "plugin_PoiNode.h"
#import "plugin_SearchPoi_Connection.h"

@interface plugin_SearchPoiOperate : plugin_SearchPoi {
    NSMutableArray *contextArray;
	NSMutableArray *NearPoiArray;
	NSMutableArray *FavArray;
	NSMutableArray *GoWherePOIArray;
    NSMutableArray *m_arrayAroundSearchPOIArray;
    NSMutableArray *CityItemArray;
	GPOI poiResult[500];//POI搜索结果
	NSInteger cellNumber;
	NSInteger searchSortType;
	GPOICATEGORYLIST *ppCategoryList;//类别表
	NSInteger CategoryListID;
	
	int poiCategoryID;//POI搜索ID
	
	GFAVORITEPOILIST *ppFavoritePOIList;//收藏poi列表
    GPOI pNearestPOI;
	GBYBUSSCHEME *ppScheme;//公交
	Guint32 pNumberOfSchemes;//公交换成
	int searchType;//0:去哪里搜索 1：周边搜索
    // 周边检索 10-29lyh
    int m_nAroundSearchType;//0:按照传入的点检索 1：按照路径检索
    //
    int m_bNetOrLocalSearch;//0:本地检索 1：网络检索
    //
    BOOL m_bLocalAddOnlineData;     //0: 1:有网络和本地数据融合
    GHGUIDEROUTE guideRouteHandle;
    int                 m_nAroundRange;
    
}
@property (nonatomic, assign) BOOL psbLocalAddOnlineData;
+(plugin_SearchPoiOperate *)sharedInstance;
/**********************************************************************
 * 函数名称: searchAroundPOIType
 * 功能描述: 获取周边对应关键字搜索子列表
 * 输入参数: (int)index列表索引
 * 输出参数: 
 * 返 回 值: NO：失败 YES:成功
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(BOOL)searchAroundPOIType:(int)index;

/**********************************************************************
 * 函数名称: searchAroundPOIList
 * 功能描述: 获取周边对应关键字搜索结果
 * 输入参数: (int)index列表索引
 * 输出参数: 
 * 返 回 值: NO：失败 YES:成功
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(BOOL)searchAroundPOIList:(int)index;

// 周边检索 10-29lyh
-(void) setAroundSearchType:(int)nAroundSearchType;//0:按照传入的点检索 1：按照路径检索
-(int) getAroundSearchType;

#pragma mark 获取搜藏夹列表(参数为poi的类型)
- (BOOL)GMD_GetFavoriteListWithMainID:(NSInteger)mainID;
#pragma mark 添加收藏夹兴趣点(参数mainID为收藏类型,index为poi的索引值，要是收藏当前点传1000)
- (int)GMD_AddFavoriteWithMainID:(GFAVORITECATEGORY)eCategory iconType:(GFAVORITEICON)icon index:(NSInteger)index WithPOI:(plugin_PoiNode *)POI;
#pragma mark 删除收藏夹poi(参数为索引值)
- (int)GMD_DelFavoriteWithIndex:(NSInteger)index;
#pragma mark 清空收藏夹兴趣点(参数为poi的类型)
- (int)GMD_ClearFavoriteWithMainID:(NSInteger)mainID;
#pragma mark 编辑收藏夹兴趣点
-(int)GMD_EditFavoriteWithPOI:(plugin_PoiNode *)POI WithIndex:(int)index Type:(int)type;
#pragma mark 设置poi搜索类型(参数mainID为类别级数)
- (void)GMD_SetPOICategoryIDWithMainID:(NSInteger)mainID subCategory:(NSInteger)nIndex;


#pragma mark 语音命令字搜索
-(BOOL)voicePOISearch:(int)MID;

-(NSMutableArray *)NearPOIList;
//返回我的收藏poi列表
-(NSMutableArray *)FavPOIList;
//返回城市列表
-(NSMutableArray *)GetCityList;

//搜索结果
-(void)clearGoWhereSearchPOIList;
//搜索结果
-(NSMutableArray *)ReturnGoWhereSearchPOIList;
//
-(NSMutableArray *)ReturnAroundSearchPOIList;
// 在下一次检索时，设置检索范围
-(void)GMD_SetAroundRangeForNextSearch:(int)nMeter;
@end
