//
//  MWNetSearchOperator.m
//  AutoNavi
//
//  Created by gaozhimin on 14-2-25.
//
//

#import "MWNetSearchOperator.h"
#import "MWNetSearchListener.h"

#define NetSearchURL @"http://mlbs.autonavi.com/servicesearch" //正式接口地址
//#define NetSearchURL @"http://ctest.mapabc.com:8080/giswireless/servicesearch" //测试接口地址

@implementation MWNetSearchOperator

/**
 *	POI搜索、交叉路口搜索请求接口
 *
 *	@param	type	请求类型
 *	@param	option	POI搜索、交叉路口搜索条件
 *	@param	delegate	回调委托
 *
 *	@return 成功返回GD_ERR_OK, 失败返回对应出错码 
 */

+ (GSTATUS)MWNetKeywordSearchWith:(RequestType)type  option:(MWNetKeyWordSearchOption *)option delegate:(id<NetReqToViewCtrDelegate>)delegate
{
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = NetSearchURL;
    condition.requestType = type;
    condition.httpMethod = @"POST";
    condition.bodyData = [option getAllPropertiesAndVaulesData];
    
    MWNetSearchListener *deal = [MWNetSearchListener  createListenerWith:type delegate:delegate];   //创建请求监听对象
    NetRequestExt* request = [[NetExt sharedInstance] requestWithCondition:condition delegate:deal]; //开始请求
    if (request == nil)
    {
        return GD_ERR_FAILED;
    }
    return GD_ERR_OK;
}

/**
 *	周边搜索请求接口
 *
 *	@param	type	请求类型
 *	@param	option	周边搜索条件
 *	@param	delegate回调委托
 *
 *	@return 成功返回GD_ERR_OK, 失败返回对应出错码
 */

+ (GSTATUS)MWNetAroundSearchWith:(RequestType)type  option:(MWNetAroundSearchOption *)option delegate:(id<NetReqToViewCtrDelegate>)delegate
{
    NetBaseRequestCondition *condition = [NetBaseRequestCondition requestCondition];
    condition.baceURL = NetSearchURL;
    condition.requestType = type;
    condition.httpMethod = @"POST";
    condition.bodyData = [option getAllPropertiesAndVaulesData];
    
    MWNetSearchListener *deal = [MWNetSearchListener  createListenerWith:type delegate:delegate];   //创建请求监听对象
    NetRequestExt* request = [[NetExt sharedInstance] requestWithCondition:condition delegate:deal]; //开始请求
    if (request == nil)
    {
        return GD_ERR_FAILED;
    }
    return GD_ERR_OK;
}

/**
 *	取消请求接口
 *
 *	@param	type	取消请求的类型
 *
 */
+ (void)MWCancelNetSearchWith:(RequestType)type
{
    [[NetExt sharedInstance] Net_CancelRequestWithType:type];
    [MWNetSearchListener  deleteListenerWith:type];
}

@end
