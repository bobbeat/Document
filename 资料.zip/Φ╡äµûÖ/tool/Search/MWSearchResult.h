//
//  MWSearchResult.h
//  AutoNavi
//
//  Created by gaozhimin on 13-7-29.
//
//

#import <Foundation/Foundation.h>

@interface MWPoi : NSObject

/*!
  @brief 经度坐标
  */
@property (nonatomic,assign) long longitude;

/*!
  @brief 纬度坐标
  */
@property (nonatomic,assign) long latitude;

/*!
  @brief 类别编码，参见POI类别编码表
  */
@property (nonatomic,assign) int lCategoryID;

/*!
  @brief 距参考点的距离
  */
@property (nonatomic,assign) int lDistance;

/*!
  @brief 匹配度，表示关键字匹配程度
  */
@property (nonatomic,assign) int lMatchCode;

/*!
  @brief 匹配高亮显示，从低位到高位匹配名称字段，最多32位
  */
@property (nonatomic,assign) int lHilightFlag;

/*!
  @brief 行政编码，参见行政区域编码表
  */
@property (nonatomic,assign) int lAdminCode;

/*!
  @brief POI唯一ID
  */
@property (nonatomic,assign) int lPoiId;

/*!
  @brief 导航经度坐标, 与longitude差值
  */
@property (nonatomic,assign) int siELonOff;


/*!
  @brief 导航纬度坐标, 与latitude差值
  */
@property (nonatomic,assign) int siELatOff;

/*!
  @brief 名称
  */
@property (nonatomic,copy) NSString * szName;

/*!
  @brief 地址
  */
@property (nonatomic,copy) NSString * szAddr;

/*!
  @brief 电话
  */
@property (nonatomic,copy) NSString * szTel;

/*!
  @brief 电话
  */
@property (nonatomic,copy) NSString * szTown;

/*!
  @brief POI索引，内部使用
  */
@property (nonatomic,assign) int lPoiIndex;

/*!
  @brief bit0:出入口；bit1:楼宇；bit2:亲属关系；bit3:用户POI；
  */

@property (nonatomic,assign) int ucFlag;

/*!
  @brief 保留(行程点：0表示未达到、1表示已到达)
  */
@property (nonatomic,assign) int Reserved;

/*!
  @brief 交叉节点ID
  */
@property (nonatomic,assign) int usNodeId;

@end


/*!
 @brief POI检索结果结构体
 * 用于存储POI检索结果
 */
@interface MWSearchResult : NSObject

/*!
 @brief 总的个数
 */
@property (nonatomic,assign) int numberOfTotalItem;

/*!
 @brief 获取的第一个索引
 */
@property (nonatomic,assign) int index;

/*!
 @brief 获取的POI个数
 */
@property (nonatomic,assign) int numberOfItemGet;

/*!
 @brief 保留
 */
@property (nonatomic,assign) int reserved;

/*!
 @brief 返回的MWPoi对象的序列
 */
@property (nonatomic,retain) NSArray *pois;

@end

/*!
 @brief  POI类别列表结构
 * 用于存储POI类别信息
 */
@interface MWPoiCategoryList : NSObject

/*!
 @brief 类别个数
 */
@property (nonatomic,assign) int lNumberOfCategory;

/*!
 @brief 类别信息 存储 MWPoiCategory 对象
 */
@property (nonatomic,retain) NSArray *pCategoryArray;

@end

/*!
 @brief  POI类别信息结构
 * 用于存储POI类别信息
 */
@interface MWPoiCategory : NSObject

/*!
 @brief 类别编号，参见POI类别编码表
 */
@property (nonatomic,assign) int lCategoryID;

/*!
 @brief 子类个数
 */
@property (nonatomic,assign) int nNumberOfSubCategory;

/*!
 @brief 保留
 */
@property (nonatomic,assign) int Reserved;

/*!
 @brief 类别编号，参见POI类别编码表
 */
@property (nonatomic,copy) NSString* szName;

/*!
 @brief 子类别 存储 MWPoiCategory 对象
 */
@property (nonatomic,retain) NSArray *pSubCategoryArray;

@end


/*!
 @brief  行政区域列表结构体
 * 用于存储行政区域
 */
@interface MWAreaList : NSObject

/*!
 @brief 类别个数
 */
@property (nonatomic,assign) int lNumberOfAdarea;

/*!
 @brief 行政区域 存储 MWArea 对象
 */
@property (nonatomic,retain) NSArray *pAdareaArray;

@end

/*!
 @brief  行政区域结构体
 * 用于存储行政区域编码、名称、简拼及其子行政区信息
 */
@interface MWArea : NSObject

/*!
 @brief 行政区域编码，参见行政区域编码表
 */
@property (nonatomic,assign) int lAdminCode;
/*!
 @brief 下级行政区域个数
 */
@property (nonatomic,assign) int lNumberOfSubAdarea;

/*!
 @brief 行政区域名称首拼
 */
@property (nonatomic,copy) NSString* szAdminSpell;

/*!
 @brief 行政区域名称
 */
@property (nonatomic,copy) NSString* szAdminName;

/*!
 @brief 下级行政区域信息 存储 MWPoiCategory 对象
 */
@property (nonatomic,retain) NSArray *pSubAdareaArray;

@end
