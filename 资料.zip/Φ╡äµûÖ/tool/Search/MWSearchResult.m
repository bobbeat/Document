//
//  MWSearchResult.m
//  AutoNavi
//
//  Created by gaozhimin on 13-7-29.
//
//

#import "MWSearchResult.h"

@implementation MWPoi

@synthesize lCategoryID,latitude,longitude,lAdminCode,lDistance,lHilightFlag,lMatchCode,lPoiId,lPoiIndex,Reserved,siELatOff,siELonOff,szAddr,szName,szTel,ucFlag,usNodeId,szTown;

//- (int)lDistance
//{
//    if (lDistance == 0)
//    {
//        GCARINFO pCarInfo = {};
//        GDBL_GetCarInfo(&pCarInfo);
//        GCOORD coord = {0};
//        coord.x = longitude;
//        coord.y = latitude;
//        lDistance = [[ANDataSource sharedInstance] GMD_CalculateDistanceWithStart:pCarInfo.Coord Des:coord];
//    }
//    return lDistance;
//}

- (void)encodeWithCoder:(NSCoder *)encoder
{
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.lCategoryID] forKey:@"lCategoryID"];
    
	[encoder encodeObject:[NSString stringWithFormat:@"%d",self.lDistance] forKey:@"lDistance"];
	[encoder encodeObject:[NSString stringWithFormat:@"%d",self.lHilightFlag] forKey:@"lHilightFlag"];
	[encoder encodeObject:[NSString stringWithFormat:@"%d",self.lMatchCode] forKey:@"lMatchCode"];
    
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.lPoiId] forKey:@"lPoiId"];
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.lPoiIndex] forKey:@"lPoiIndex"];
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.Reserved] forKey:@"Reserved"];
    
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.siELatOff] forKey:@"siELatOff"];
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.siELonOff] forKey:@"siELonOff"];
    [encoder encodeObject:self.szName forKey:@"szName"];
    
    [encoder encodeObject:self.szAddr forKey:@"szAddr"];
    [encoder encodeObject:self.szTel forKey:@"szTel"];
    [encoder encodeObject:self.szTown forKey:@"szTown"];
    
    
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.lAdminCode] forKey:@"lAdminCode"];
    [encoder encodeObject:[NSString stringWithFormat:@"%ld",self.longitude] forKey:@"longitude"];
    [encoder encodeObject:[NSString stringWithFormat:@"%ld",self.latitude] forKey:@"latitude"];
    
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.ucFlag] forKey:@"ucFlag"];
    [encoder encodeObject:[NSString stringWithFormat:@"%d",self.usNodeId] forKey:@"usNodeId"];
}


- (id)initWithCoder:(NSCoder *) decoder
{
	if (self = [super init])
	{

        self.usNodeId = [[decoder decodeObjectForKey:@"usNodeId"] intValue];
        self.lPoiId = [[decoder decodeObjectForKey:@"lPoiId"] intValue];
        self.lCategoryID = [[decoder decodeObjectForKey:@"lCategoryID"] intValue];
        
        self.ucFlag = [[decoder decodeObjectForKey:@"ucFlag"] intValue];
        self.siELonOff = [[decoder decodeObjectForKey:@"siELonOff"] intValue];
        self.siELatOff = [[decoder decodeObjectForKey:@"siELatOff"] intValue];
        
        self.latitude = [[decoder decodeObjectForKey:@"latitude"] intValue];
        self.longitude = [[decoder decodeObjectForKey:@"longitude"] intValue];
        self.szName = [decoder decodeObjectForKey:@"szName"];
        
        self.szTown = [decoder decodeObjectForKey:@"szTown"];
        self.szTel = [decoder decodeObjectForKey:@"szTel"];
        self.szAddr = [decoder decodeObjectForKey:@"szAddr"];
        
        self.lAdminCode = [[decoder decodeObjectForKey:@"lAdminCode"] intValue];
        self.Reserved = [[decoder decodeObjectForKey:@"Reserved"] intValue];
        self.lPoiIndex = [[decoder decodeObjectForKey:@"lPoiIndex"] intValue];
        
        self.lMatchCode = [[decoder decodeObjectForKey:@"lMatchCode"] intValue];
        self.lHilightFlag = [[decoder decodeObjectForKey:@"lHilightFlag"] intValue];
        self.lDistance = [[decoder decodeObjectForKey:@"lDistance"] intValue];
	}
	
	return self;
}

- (void)dealloc
{
    self.szTel = nil;
    self.szName = nil;
    self.szAddr = nil;
    self.szTown = nil;
    [super dealloc];
}

- (NSString *)szName
{
    if (szName == nil)
    {
        return @"";
    }
    return szName;
}

-(NSString *)szTel
{
    if (szTel == nil)
    {
        return @"";
    }
    return szTel;
}

- (NSString *)szAddr
{
    if (szAddr == nil)
    {
        return @"";
    }
    return szAddr;
}

- (NSString *)szTown
{
    if (szTown == nil)
    {
        return @"";
    }
    return szTown;
}

@end

@implementation MWSearchResult

@synthesize index,numberOfItemGet,numberOfTotalItem,pois,reserved;

- (void)dealloc
{
    self.pois = nil;
    [super dealloc];
}

@end

@implementation MWPoiCategoryList

@synthesize lNumberOfCategory,pCategoryArray;

- (void)dealloc
{
    self.pCategoryArray = nil;
    [super dealloc];
}

@end


@implementation MWPoiCategory

@synthesize szName,lCategoryID,nNumberOfSubCategory,pSubCategoryArray,Reserved;

- (void)dealloc
{
    self.szName = nil;
    self.pSubCategoryArray = nil;
    [super dealloc];
}

@end

@implementation MWAreaList

@synthesize lNumberOfAdarea,pAdareaArray;

- (void)dealloc
{
    self.pAdareaArray = nil;
    [super dealloc];
}

@end

@implementation MWArea

@synthesize lAdminCode,lNumberOfSubAdarea,pSubAdareaArray,szAdminName,szAdminSpell;

- (void)dealloc
{
    self.pSubAdareaArray = nil;
    self.szAdminSpell = nil;
    self.szAdminName = nil;
    [super dealloc];
}

@end
