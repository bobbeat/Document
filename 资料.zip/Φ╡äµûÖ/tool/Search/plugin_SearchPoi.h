//
//  plugin_SearchPoi.h
//  AutoNavi
//
//  Created by huang longfeng on 12-4-19.
//  Copyright 2012 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MySearchPOIDelegate

- (void)dataparseDone;//数据解析完毕
- (void)dataparseFail:(NSError*)error;//数据解析失败

@end

@interface plugin_SearchPoi : NSObject {
    id<MySearchPOIDelegate> delegate;
@protected
    NSMutableArray* searchPOIList;
}

@property(nonatomic,assign) id<MySearchPOIDelegate> delegate;


/**********************************************************************
 * 函数名称: searchPOI
 * 功能描述: 获取poi列表
 * 输入参数: (NSString *)Keyword（搜索关键字） (int)type（搜索类型）:0-智能 1－门址 2－交叉路口 3-周边 (int)sortType（排序类型）：0－正常 1－按距离排序
 * 输出参数: 
 * 返 回 值: NO：失败 YES:成功
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(BOOL)searchPOI:(NSString *)Keyword SearchType:(SEARCHPOITYPE)type SortType:(int)sortType;

/**********************************************************************
 * 函数名称: localPOIList
 * 功能描述: 返回poi列表
 * 输入参数: 
 * 输出参数: 
 * 返 回 值: poi列表
 * 其它说明: 
 * 修改日期			版本号		修改人		修改内容
 * ---------------------------------------------------------------------
 * 2012/4/20		1.0			黄龙锋
 **********************************************************************/
-(NSMutableArray *)localPOIList;


@end
