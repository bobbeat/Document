/*!
 \file       ITBTStruct.h
 \brief      定义TBT模块对外提供的接口所含数据结构
 \details    无
 */
#ifndef __AUTONAVI_ITBTSTRUCT_H__
#define __AUTONAVI_ITBTSTRUCT_H__

//--------------------------------------------------------------------------

#ifndef _Interface_
#define _Interface_ struct
#endif

#if defined(WIN32) || defined(WINCE)
#define IMPORT_C _declspec(dllexport)
#define EXPORT_C _declspec(dllexport)
#else
#define IMPORT_C
#define EXPORT_C
#endif

typedef unsigned char     	    BYTE;
typedef unsigned char     	    byte;
typedef unsigned short     	    WORD;
typedef unsigned long       	DWORD;

//--------------------------------------------------------------------------


/*!
 \brief      DG对外更新数据结构
 \details
 导航段转向图标定义如下：
 1			// 自车图标
 2			// 左转图标
 3			// 右转图标
 4			// 左前方图标
 5			// 右前方图标
 6			// 左后方图标
 7			// 右后方图标
 8			// 左转掉头图标
 9			// 直行图标
 10		// 到达途经点图标
 11		// 进入环岛图标
 12		// 驶出环岛图标
 13		// 到达服务区图标
 14		// 到达收费站图标
 15		// 到达目的地图标
 16		// 进入隧道图标
 */
typedef struct tag_DGNaviInfo
{
    int m_iType;            //!> 更新类型,1 GPS导航更新,2 模拟导航更新
    WORD* m_pwCurRoadName;  //!> 当前道路名称，Unicode编码方式
    int m_iCurNameLen;      //!> 当前道路名称长度（单位字）
    WORD* m_pwNextRoadName;	//!> 下条道路名称，Unicode编码方式
    int m_iNextNameLen;    	//!> 下条道路名称长度，字的个数
    int m_iSAPADist;        //!> 距离最近服务区的距离（单位米），若为-1则说明距离无效，没有服务区
    int m_iCameraDist;      //!> 距离最近电子眼距离（单位米），若为-1则说明距离无效，没有电子眼
    int m_iCameraType;      //!> 电子眼类型，0 测速摄像头，1为监控摄像头
    int m_iCameraSpeed;     //!> 电子眼限速，若无限速信息则为0
    int m_iIcon;            //!> 导航段转向图标，如上定义
    int m_iRouteRemainDis;  //!> 路径剩余距离（单位米）
    int m_iRouteRemainTime; //!> 路径剩余时间（单位秒）
    int m_iSegRemainDis;    //!> 当前导航段剩余距离（单位米）
    int m_iSegRemainTime;   //!> 当前导航段剩余时间（单位秒）
    int m_iCarDirection;    //!> 自车方向（单位度），以正北为基准，顺时针增加
    double m_dLongitude;    //!> 自车经度
    double m_dLatitude;	    //!> 自车纬度
    int m_iLimitedSpeed;    //!> 当前道路速度限制（单位公里每小时），－1为无效
    int m_iCurSegNum;       //!> 当前自车所在segment段，从0开始
    int m_iCurLinkNum;      //!> 当前自车所在Link，从0开始
    int m_iCurPointNum;     //!> 当前位置的前一个形状点号，从0开始
}DGNaviInfo;

//! 通知自车位置信息的数据结构
typedef struct tag_CarLocation
{
    double m_dLongitude;    //!> 自车经度
    double m_dLatitude;     //!> 自车纬度
    int m_iCarDir;          //!> 当前车辆的方向（单位度），以正北为基准，顺时针增加
    int m_iSpeed;           //!> 当前自车速度，单位公里每小时
    int m_iMatchStatus;	    //!> 匹配状态，0 未匹配到路径上，1 匹配到路径上
}CarLocation;

//! 导航段信息的数据结构
typedef struct tag_NaviGuideItem
{
    int m_iLength;		    //!> 导航段长度（单位米）
    int m_iUseTime;	      //!> 导航段行驶时间（单位秒）
    int m_iIcon;			    //!> 导航段转向图标，如上定义
    WORD* m_pwName;		    //!> 名称，Unicode编码方式
    int m_iNameLengh;		  //!> 名称长度（单位字）
    double m_dLongitude; 	//!> 经度
    double m_dLatitude;  	//!> 纬度
}NaviGuideItem;

//! 电子眼信息的数据结构
typedef struct tag_CameraInfo
{
    int m_iCameraType;		//!> 电子眼类型，0 测试摄像头，1为监控摄像头
    int m_iCameraSpeed;		//!> 电子眼限速，若无限速信息则为0
    double m_dLongitude; 	//!> 经度
    double m_dLatitude;  	//!> 纬度
}CameraInfo;

//! 光柱信息的数据结构
typedef struct tag_TMCBarItem
{
    int m_iStatus;	      //!> 状态：0 未知状态，1 通畅，2 缓行，3 阻塞严重
    int m_iLength;	      //!> 长度
}TMCBarItem;

#endif
