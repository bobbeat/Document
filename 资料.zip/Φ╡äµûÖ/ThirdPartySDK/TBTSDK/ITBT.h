/*!
 \file       ITBT.h
 \brief      定义TBT模块对外提供的接口
 \details    此文件用来定义高德对外提供的TBT模块的接口，以及对外依赖的接口，
 TBT主要实现功能有导航指引、位置匹配、路径请求与解析、态势播报、
 情报板、动态光柱、道路状态查询
 \warning    使用TBT的对象必须继承并实现IFrameForTBT接口
 */
#ifndef __AUTONAVI_ITBT_H__
#define __AUTONAVI_ITBT_H__

#include "ITBTStruct.h"

/*!
 \brief      TBT使用外部依赖接口
 \details    TBT调用此接口通知TBT使用者消息或信息
 */
_Interface_ IFrameForTBT
{
public:
    /*!
     \brief          HTTP请求
     \details        TBT调用此接口进行HTTP网络请求，此接口为异步接口，占用实现者的线程，函数调用必须立即返回
     \param[in]      iModuleID {int}. 模块号：1 请求路径，2 实施交通信息，3 前方路况播报，4 情报看板，5 整体路况概览，6 路口扩大图
     \param[in]      iConnectID {int}. 连接ID，请求到数据后用此ID将数据传给TBT
     \param[in]      iType {int}. 0为Post方式，1为Get方式
     \param[in]      pstrUrl {char*}. 请求的URL串
     \param[in]      pstrHead {char*}. HTTP头，默认为空
     \param[in]      pData {BYTE*}. Post方式的Data数据，默认为空
     \param[in]      iDataLength {int}. Post方式的Data数据长度，默认为0
     \return         {void}. 无返回值
     */
    virtual void RequestHTTP(int iModuleID, int iConnectID, int iType, char* pstrUrl, char* pstrHead, BYTE* pData, int iDataLength) = 0;
    
    /*!
     \brief          更新导航信息
     \details        通知Frame导航信息更新，参见DGNaviInfo定义
     \param[in]      stDGNaviInfo {DGNaviInfo&}. 导航信息，参见DGNaviInfo定义
     \return         {void}. 无返回值
     */
    virtual void UpdateNaviInfo(DGNaviInfo & stDGNaviInfo) = 0;
    
    /*!
     \brief          显示路口扩大图
     \details        通知Frame显示扩大图，可能有PNG与BMP两种格式
     \param[in]      iPicFormat {int}. 图片格式，1 为PNG图片，2 为BMP图片
     \param[in]      pPicBuf1 {BYTE*}. 图片数据1，当图片格式为PNG图片时，此数据为PNG格式的背景数据，若图片格式为BMP时此数据为整个的扩大图的BMP数据
     \param[in]      pPicBuf2 {BYTE*}. 图片数据2，当图片格式为PNG图片时，此数据为PNG格式的箭头数据，若图片格式为BMP时此数据为NULL
     \param[in]      iPicSize1 {int}. 图片数据大小1，当图片格式为PNG图片时，此大小为pPicBuf1的数据大小，若图片格式为BMP时此数据为扩大图的宽度
     \param[in]      iPicSize2 {int}. 图片数据大小2，当图片格式为PNG图片时，此大小为pPicBuf2的数据大小，若图片格式为BMP时此数据为扩大图的高度
     \return         {void}. 无返回值
     */
    virtual void ShowCross(int iPicFormat, BYTE* pPicBuf1, BYTE* pPicBuf2, int iPicSize1, int iPicSize2) = 0;
    
    /*!
     \brief          隐藏路口扩大图
     \details        通知Frame隐藏扩大图
     \return         {void}. 无返回值
     */
    virtual void HideCross() = 0;
    
    /*!
     \brief          显示车道信息
     \details        通知Frame显示车道信息
     \param[in]      pLaneBackInfo {BYTE*}. 车道背景信息,指针大小为8
     \param[in]      pLaneSelectInfo {BYTE*}. 车道选择信息,指针大小为8
     \return         {void}. 无返回值
     */
    virtual void ShowLaneInfo(BYTE* pLaneBackInfo, BYTE* pLaneSelectInfo) = 0;
    
    /*!
     \brief          隐藏车道信息
     \details        通知Frame隐藏车道信息。
     \return         {void}. 无返回值
     */
    virtual void HideLaneInfo() = 0;
    
    /*!
     \brief          播报字符串
     \details        使用TTS播报一个字符串，函数占用Frame的线程，此函数调用后马上返回
     \param[in]      iSoundType {int}. 语音类型：1 导航播报，2 前方路况播报，3 整体路况播报
     \param[in]      pwSoundStr {WORD*}. 要播报的字符串，Unicode编码
     \param[in]      iLength {int}. 字符串长度（单位:字）
     \return         {void}. 无返回值
     */
    virtual void PlayNaviSound(int iSoundType, WORD* pwSoundStr, int iLength) = 0;
    
    /*!
     \brief          停止模拟导航
     \details        模拟导航结束后通知Frame以便更新UI界面等
     \return         {void}. 无返回值
     */
    virtual void EndEmulatorNavi() = 0;
    
    /*!
     \brief          通知到达途经点或目的地
     \details        当GPS导航到达途径点或目的地时调用此接口通知Frame
     \param[in]      iWayId {int}. 到达途径点的编号，标号从1开始，如果到达目的地iWayID为0
     \return         {void}. 无返回值
     */
    virtual void ArriveWay(int iWayId) = 0;
    
    /*!
     \brief          通知GPS导航偏离路径
     \details        当车辆偏离路径后通知Frame，需要重新计算路径
     \return         {void}. 无返回值
     */
    virtual void OffRoute() = 0;
    
    /*!
     \brief          拥堵重算通知
     \details        导航路径前方出现拥堵后，通知Frame切换导航路径
     \param          iRouteID {int}. 规避前方拥堵的新路径，若为0则路径无效，需要调用TBT的算路接口并将算路策略设置为规避拥堵，
     若iRouteID为非0，则可以直接用iRouteID切换导航路径。
     \return         {void}. 无返回值
     */
    virtual void RerouteForTMC(int iRouteID) = 0;
    
    /*!
     \brief          路径销毁
     \details        停止导航时会删除TBT内部所有路径，在删除先调用此接口，Frame在收到此消息后不能再使用TBT获取任何路径相关信息
     \return         {void}. 无返回值
     */
    virtual void RouteDestroy() = 0;
    
    /*!
     \brief          通知当前匹配后的自车位置点
     \details        Frame在收到此消息后可以使用新的匹配后的位置点与方向更新地图中心点与地图角度
     \param[in]      stCarLocation {CarLocation}. 当前匹配后的点，参见CarLocation结构
     \return         {void}. 无返回值
     */
    virtual void CarLocationChange(CarLocation  stCarLocation) = 0;
    
    /*!
     \brief          通知路径计算状态
     \details        RouteRequestState含义如下
     1	路径计算成功
     2	网络超时
     3	网络失败
     4	请求参数错误
     5	返回数据格式错误
     6	起点周围没有道路
     7	起点在步行街
     8	终点周围没有道路
     9	终点在步行街
     10	途经点周围没有道路
     11	途经点在步行街
     \param[in]      iState {int}. 路径计算结果，参见如上定义
     \return         {void}. 无返回值
     */
    virtual void SetRouteRequestState(int iState) = 0;
    
    /*!
     \brief          通知动态信息更新
     \details        当动态信息更新后会调用此接口，此需要更新光柱等使用了动态信息的应用，使用新的动态信息重新计算
     \param[in]      iHour {int}. 更新批次时
     \param[in]      iMinute {int}. 更新批次分
     \param[in]      iSecond {int}. 更新批次秒
     \return         {void}. 无返回值
     */
    virtual void TMCUpdate(int iHour, int iMinute, int iSecond) = 0;
    
    /*!
     \brief          通知显示情报板
     \details        无
     \param[in]      pPanelBuf {BYTE*}. PNG格式情报板图片
     \param[in]      iSize {int}. PNG格式情报板图片数据大小
     \return         {void}. 无返回值
     */
    virtual void ShowTrafficPanel(BYTE* pPanelBuf, int iSize) = 0;
    
    /*!
     \brief          通知隐藏情报板
     \details        无
     \return         {void}. 无返回值
     */
    virtual void HideTrafficPanel() = 0;
    
    /*!
     * \brief      查询TTS是否正在播报
     * \details    TBT会使用此接口来计算导航播报，此接口是否准确将影响到导航播报的质量，若应用层无法获得TTS的状态，返回未知状态
     * \return     {int} 0 未知状态，1 空闲，2 正在播报
     * \date       2012/9/28 17:29:32
     */
    virtual int GetPlayState() = 0;
    
    /*!
     * \brief      锁屏导航提示
     * \details    锁屏状态导航远距离提示点亮屏幕
     \param[in]      pwSoundStr {WORD*}. 通知文字
     \param[in]      iLeng {int}. 通知文字长度
     \param[in]      iTurnIcon {int}. 拐弯图标，参见DGNaviInfo数据结构中m_iIcon定义
     \param[in]      iSegRemainLeng {int}. 当前导航端剩余距离
     * \return     {void}. 无返回值
     * \date       2013/1/14 17:29:32
     */
    virtual void LockScreenNaviTips(WORD* pwSoundStr, int iLeng, int iTurnIcon, int iSegRemainLeng) = 0;
};

/*!
 \brief      TBT接口类
 \details    此类定义了TBT SDK的所有功能，请严格按照接口描述使用
 \author     余新彦	xinyan.yu@autonavi.com
 */
_Interface_ ITBT
{
public:
    /*!
     \brief          初始化TBT
     \details        在使用TBT接口前必须先调用此接口对TBT进行初始化，初始化成功后才能使用TBT
     \param[in]      pstFrame {IFrameForTBT*}. TBT使用依赖接口，TBT用此接口来给使用者发消息，参见IFrameForTBT定义
     \param[in]      pstrWorkPath {const char*}. 工作路径，TBT的一些配置文件以及输出信息等资料将输出到此路径下
     \param[in]      pstrUsercode {const char*}. 用户码，从高德申请得到
     \param[in]      pstrUserbatch {const char*}. 用户码，从高德申请得到
     \param[in]      pstrDeviceID {const char*}. 设备号，设备号必须唯一，可以是SIM卡号，也可以是硬件设备号
     \return         {int}. 0 初始化失败，1 初始化成功
     */
    virtual int Init(IFrameForTBT* pstFrame, const char* pstrWorkPath, const char* pstrUsercode, const char* pstrUserbatch, const char* pstrDeviceID) = 0;
    
    /*!
     \brief         销毁TBT
     \details       系统退出时调用此接口释放TBT资源，在调用此接口后不能再调用TBT的其它接口。
     \return        {void}. 无返回值
     */
    virtual void Destroy() = 0;
    
    /*!
     \brief          获得TBT的版本号
     \details        不同的版本版本好不同，此信息用来问题调查时的版本确定
     \return         {char*}. TBT的版本号，例如“BASE_2.5.0_12-10-15_1”
     */
	virtual const char* GetVersion() = 0;
    
    /*!
     \brief          接收网络数据
     \details        接收网络数据
     \param[in]      iModuleID {int}. 模块号，TBT请求时传入
     \param[in]      iConnectID {int}. 连接号，TBT请求时传入
     \param[in]      pData {BYTE*}. 下载的数据
     \param[in]      iLength {int}. 数据长度
     \return         {void}. 无返回值
     */
    virtual void ReceiveNetData(int iModuleID, int iConnectID, BYTE* pData, int iLength) = 0;
    
    /*!
     \brief          设置网络请求状态
     \details        使用者通过此接口通知TBT网络请求结果，成功失败调用此接口通知TBT，TBT在收到此消息后才认为一次HTTP请求结束，TBT的每一个
     HTTP网络请求都需要调用此接口通知TBT网络请求结果
     1	请求成功
     2	请求失败
     3	请求超时
     4	用户手动结束请求
     \param[in]      iModuleID {int}. 模块号，此ID由TBT创建在网络请求时传入
     \param[in]      iConnectID {int}. 连接号，此ID由TBT创建在网络请求时传入
     \param[in]      iNetState {int}. 请求状态如上定义
     \return         {void}. 无返回值
     */
    virtual void SetNetRequestState(int iModuleID, int iConnectID, int iNetState) = 0;
    
    /*!
     \brief          设置自车初始位置
     \details        在系统初始化时，以及非TBT通知的位置变化时，调用此接口通知TBT自车位置改变
     \param[in]      iOffFlag {int}. 是否有偏移，1 没偏移，2 有偏移(一般直接从GPS接收过来的位置是没偏转的，从TBT得到的位置都是偏转过的)
     \param[in]      dLongitude {double}. 自车经度
     \param[in]      dLatitude {double}. 自车纬度
     \return         {void}. 无返回值
     */
    virtual void SetCarLocation(int iOffFlag, double dLongitude, double dLatitude) = 0;
    
    /*!
     \brief          打开动态交通
     \details        需要动态交通信息相关功能时需要调用此接口打开交通信息功能，初始动态交通信息是打开的，打开后会每2分钟请求一次新的交通信息来更新交通信息，
     此接口影响的接口参见如下接口描述中依赖交通信息的接口
     \return         {void}. 无返回值
     */
    virtual void OpenTMC() = 0;
    
    /*!
     \brief          关闭动态交通
     \details        关闭动态交通信息后使用交通信息的相关信息的功能将无法正常使用，关闭后也就不进行路况信息请求
     \return         {void}. 无返回值
     */
    virtual void CloseTMC() = 0;
    
    /*!
     \brief          打开移动交通台功能
     \details        打开此功能后将有整体路况概览与前方路况播报功能，打开此功能后TBT会基本1分钟请求一次前方路况（此时间间隔不是固定的）
     \return         {void}. 无返回值
     */
    virtual void OpenTrafficRadio() = 0;
    
    /*!
     \brief          关闭移动交通台功能
     \details        关闭交通台后将没有路况播报功能
     \return         {void}. 无返回值
     */
    virtual void CloseTrafficRadio() = 0;
    
    /*!
     \brief          打开情报板功能
     \details        在打开了移动交通台的时候，可以通过此接口打开情报板功能，初始关闭状态，打开状态下当车辆前方有情报板时，请请求网络下载当前位置的情报板，并通知Frame显示
     \return         {void}. 无返回值
     */
    virtual void OpenTrafficPanel() = 0;
    
    /*!
     \brief          关闭情报板功能
     \details        无
     \return         {void}. 无返回值
     */
    virtual void CloseTrafficPanel() = 0;
    
    /*!
     \brief          打开电子眼播报
     \details        初始电子眼播报是打开的，当电子眼播报打开事，电子眼数据中有限速信息时，同时会播报限速信息
     \return         {void}. 无返回值
     */
    virtual void OpenCamera() = 0;
    
    /*!
     \brief          关闭电子眼播报
     \details        无
     \return         {void}. 无返回值
     */
    virtual void CloseCamera() = 0;
    
    /*!
     \brief          设置模拟导航的速度
     \details        需要设置模拟导航速度时调用
     \param[in]      iEmulatorSpeed {int}. 模拟导航速度，单位km/h
     \return         {void}. 无返回值
     */
    virtual void SetEmulatorSpeed(int iEmulatorSpeed) = 0;
    
    /*!
     * \brief      设置模拟导航是否直接跳到导航段的导航点
     * \details    此功能仅能跳过本段导航，下段起恢复正常
     * \return     {void}
     * \date       2012/11/12 09:59:15
     */
    virtual void SetEmulatorJump() = 0;
    
    /*!
     \brief          设置TTS每播报一个字需要的时间
     \details        TBT会用这个值来计算播报语音，为了获得更好的播报效果，在导航前必须调用此接口来设置比较精确的值
     \param[in]      iUseTime {int}. 播报每个字需要的时间，单位为毫秒
     \return         {void}. 无返回值
     */
    virtual void SetTimeForOneWord(int iUseTime) = 0;
    
    /*!
     \brief          开始模拟导航
     \details        收到路径计算成功消息后可以通过此接口开始模拟导航，如果当前有多路径在开始导航前必须先调用SelectRoute选择使用那条路模拟导航
     \return         {int}. 0 失败， 1 成功
     */
    virtual int StartEmulatorNavi() = 0;
    
    /*!
     \brief          开始GPS导航
     \details        收到路径计算成功消息后可以通过此接口开始GPS导航，如果当前有多路径在开始导航前必须先调用SelectRoute选择使用那条路模拟导航
     \return         {int}. 0 失败， 1 成功
     */
    virtual int StartGPSNavi() = 0;
    
    /*!
     \brief          停止模拟导航
     \details        调用此接口停止导航，若在开始导航前已经开始了GPS导航，则继续GPS导航
     \return         {void}. 无返回值
     */
    virtual void StopEmulatorNavi() = 0;
    
    /*!
     \brief          暂停导航
     \details        暂停导航后将不再有导航播报，也不会更新剩余距离等导航信息
     \return         {void}. 无返回值
     */
    virtual void PauseNavi() = 0;
    
    /*!
     \brief          恢复导航
     \details        无
     \return         {void}. 无返回值
     */
    virtual void ResumeNavi() = 0;
    
    /*!
     \brief          结束导航
     \details        调用该接口后会停止导航并删除TBT内的所有路径。
     \return         {void}. 无返回值
     */
    virtual void StopNavi() = 0;
    
    /*!
     \brief          获得行程Guide列表
     \details        列表数目为导航段的个数。
     \param[out]     iItemNum {int&}. 行程列表个数
     \return         {NaviGuideItem*}. 行程列表，参见NaviGuideItem结构。
     */
    virtual NaviGuideItem* GetNaviGuideList(int& iItemNum) = 0;
    
    /*!
     \brief          获得整条路径的电子眼列表
     \details        无
     \param[out]     iCameraNum {int&}. 电子眼个数
     \return         {CameraInfo*}. 返回电子眼列表，失败返回NULL。参见CameraPoint结构。
     */
    virtual CameraInfo* GetAllCamera(int& iCameraNum) = 0;
    
    /*!
     \brief          手动播报导航提示
     \details        如果正在播报导航信息，则返回失败。
     \return         {int}. 0失败，1成功
     */
    virtual int PlayNaviManual() = 0;
    
    /*!
     \brief          手动播报前方路况
     \details        此接口需要向服务器请求最新的前方路况，不一定请求成功，失败会有相应的语音提示
     \param[in]      iFrontDistance {int}. 要播报的前方路径距离，0为SDK默认距离，-1为整条路径，一般的前方路况播报设置为0就可以了
     \return         {int}. 0失败，1成功
     */
    virtual int PlayTrafficRadioManual(int iFrontDistance) = 0;
    
    /*!
     \brief          设置GPS信息
     \details        TBT初始化成功后，只要GPS有效就可以调用此接口将GPS设置给TBT，知道TBT被销毁，不论是否有路径，是否开始导航
     \param[in]      iOffsetFlag {int}. 是否偏转标识，1无偏转，2有偏转
     \param[in]      dLongitude {double}. 经度
     \param[in]      dLatitude {double}. 纬度
     \param[in]      dSpeed {double}. 速度（单位km/h）
     \param[in]      dDirection {double}. 方向，单位度，以正北为基准，顺时针增加
     \param[in]      iYear {int}. 年
     \param[in]      iMonth {int}. 月
     \param[in]      iDay {int}. 日
     \param[in]      iHour {int}. 时
     \param[in]      iMinute {int}. 分
     \param[in]      iSecond {int}. 秒
     \return         {void}. 无返回值
     */
    virtual void SetGPSInfo(int iOffsetFlag, double dLongitude, double dLatitude, double dSpeed, double dDirection, int iYear, int iMonth, int iDay, int iHour, int iMinute, int iSecond) = 0;
    
    /*!
     \brief          请求路径
     \details        调用此接口前需要调用过SetGPSInfo设置过GPS位置或调用过SetCarLocation设置过自车当前位置，以便TBT知道算路的起点
     0	速度优先（推荐道路）
     1	费用优先（尽量避开收费道路）
     2	距离优先（距离最短）
     3	普通路优先（不走快速路，包含高速路）
     4	考虑实时路况的路线（时间优先）
     5	多路径（一条速度优先路线，一条考虑实时交通路况路线）
     \param[in]      iCalcType {int}. 路径类型，如上定义
     \param[in]      iEndPosNum {int}. 终点个数
     \param[in]      pdEndPos {double*}.终点经纬度序列，最后一个点为目的地，其它为途径点，最多支持3个途径点
     \return         {int}. 0失败，1成功
     */
    virtual int RequestRoute(int iCalcType, int iEndPosNum, double* pdEndPos) = 0;
    
    /*!
     \brief          带起点的路径请求
     \details        此接口一般用户路径浏览，而非导航
     \param[in]      iCalcType {int}. 路径类型，参见RequestRoute 中 iCalcType参数定义
     \param[in]      iStartPosNum {int}. 起点个数
     \param[in]      pdStartPos {double*}.起点经纬度序列
     \param[in]      iEndPosNum {double}. 终点个数
     \param[in]      pdEndPos {double*}.终点经纬度序列，最后一个点为目的地，其它为途径点
     \return         {int}. 0失败，1成功
     */
    virtual int RequestRouteWithStart(int iCalcType, int iStartPosNum, double* pdStartPos, int iEndPosNum, double* pdEndPos) = 0;
    
    /*!
     \brief          重新计算路径
     \details        当TBT通知偏离导航路径时，或通知发现前方拥堵但没有备选路径可以切换，以及用户手动重算路
     -1  沿用重算前路径策略
     0	速度优先（推荐道路）
     1	费用优先（尽量避开收费道路）
     2	距离优先（距离最短）
     3	普通路优先（不走快速路，包含高速路）
     4	考虑实时路况的路线（时间优先）
     \param[in]      iCalcType {int}. 路径类型，
     \return         {int}. 0失败，1成功
     */
    virtual int Reroute(int iCalcType) = 0;
    
    /*!
     \brief          切换导航路径
     \details        若切换前已经开始GPS导航，切换后将自动开始GPS导航
     \param[in]      iRouteID {int}. 要切换的导航路径
     \return         {int}. 0失败，1成功
     */
    virtual int SwitchNaviRoute(int iRouteID) = 0;
    
    /*!
     \brief          切换平行路
     \details        此函数只有在GPS导航开始后才能使用，用来将路径的起点切换到当前导航路径平行的其它路径上，例如当前路径在主路上，调用此接口将把路径切换到辅路上，
     如果当前道路周围没有平行道路，则路径不变，切换成功后将自动开始导航
     \return         {void}. 无返回值
     */
    virtual void SwitchParallelRoad() = 0;
    
    /*!
     \brief          将路径Push到TBT中
     \details        如果正在导航，调用此方法将停止导航，并删除现有路径，成功后与正常算路成功后一样进行导航与数据访问
     \param          pData {BYTE*}. 路径二进制数据
     \param          iLength {int}. 二进制数据大小
     \return         {int}. 0失败，1成功
     */
    virtual int PushRouteData(BYTE* pData, int iLength) = 0;
    
    /*!
     \brief          获得TBT中的所有路径的ID
     \details        此接口一般在路径计算成功后，或PushRouteData成功后用来获得路径的ID，以便之后选择并操作路径
     \param[out]          iRouteNum {int&}. 路径ID个数，也就是路径个数
     \return         {int*}. 路径ID的列表，每一个路径ID是一个Int的数值
     */
    virtual int* GetAllRouteID(int& iRouteNum) = 0;
	
    /*!
     \brief          选择路径
     \details        在路径计算完成，或PushRouteData完成后，导航或访问路径数据前必须调用此接口选作路径
     \param[in]      iRouteID {int}. 要选择道路的ID
     \return         {int}. 失败返回-1，成功返回选择道路的类型，道路类型参见RequestRoute接口中的描述
     */
    virtual int SelectRoute(int iRouteID) = 0;
    
    /*!
     \brief          获得当前路径的长度
     \details        在调用此接口前必须调用过SelectRoute
     \return         {int}. 成功返回路径长度，单位：米，否则返回-1
     */
    virtual int GetRouteLength() = 0;
    
    /*!
     \brief          获得当前路径的旅行时间
     \details        在调用此接口前必须调用过SelectRoute
     \return         {int}. 成功返回路径的旅行时间，单位：秒，否则返回-1
     */
    virtual int GetRouteTime() = 0;
    
    /*!
     \brief          获得当前路径的导航段个数
     \details        在调用此接口前必须调用过SelectRoute
     \return         {int}. 成功返回导航段个数，否则返回-1
     */
    virtual int GetSegNum() = 0;
    
    /*!
     \brief          获得一个导航段的长度
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \return         {int}. 成功返回导航段的长度，单位：米。否则返回-1
     */
    virtual int GetSegLength(int iSegIndex) = 0;
    
    /*!
     \brief          获得导航段的旅行时间
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \return         {int}. 成功返回导航段的旅行时间，单位：秒。否则返回-1
     */
    virtual int GetSegTime(int iSegIndex ) = 0;
    
    /*!
     \brief          获得导航段的转向箭头
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \return         {int}. 成功返回导航段的转向箭头。否则返回-1
     */
    virtual int GetSegTurnIcon(int iSegIndex ) = 0;
    
    
    /*!
     \brief          获得一个导航段中Link的数量
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \return         {int}. 当iSegIndex小于总导航个数时返回Link个数，否则返回-1
     */
    virtual int GetSegLinkNum(int iSegIndex) = 0;
    
    /*!
     \brief          获得一个导航段的收费路长度
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \return         {int}. 成功返回导航段中收费道路的长度，单位：米。否则返回-1
     */
    virtual int GetSegChargeLength(int iSegIndex) = 0;
    
    /*!
     \brief          获得一个导航段的形状点
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[out]     iPointNum {int&}. 导航段形状点的个数
     \return         {double*}. 返回形状点列表
     */
    virtual double* GetSegCoor(int iSegIndex, int& iPointNum) = 0;
    
    /*!
     \brief          获得一个导航段的LocationCode个数
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \return         {int}. 成功返回LocationCode个数，否则返回-1
     */
    virtual int GetSegLocationCodeNum(int iSegIndex) = 0;
    
    /*!
     \brief          获得一个LocationCode
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLocationIndex {int}. LocationCode编号，从0开始编号
     \param[out]     iLocationCode {int&}. 查询的LocationCode
     \param[out]     iLocationCodeLength {int&}. LocationCode的长度，单位：米
     \param[out]     iLocationCodeTime {int&}. LocationCode的时间，单位：秒
     \return         {int}. 0失败，1成功
     */
    virtual int GetSegLocationCode(int iSegIndex, int iLocationIndex, int& iLocationCode, int& iLocationCodeLength, int& iLocationCodeTime) = 0;
    
    /*!
     \brief          获得一个Link的道路名称
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex {int}. Link编号，从0开始编号
     \param[out]     iNameLength {int&}. 路名长度，字数
     \return         {WORD*}. 返回Link的名称
     */
    virtual WORD* GetLinkRoadName(int iSegIndex, int iLinkIndex, int& iNameLength) = 0;
    
    /*!
     \brief          获得一个Link的形状坐标点
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex {int}. Link编号，从0开始编号
     \param[out]     iPointNum {int&}. Link形状点的个数
     \return         {double*}. 返回Link的形状点序列
     */
    virtual double* GetLinkCoor(int iSegIndex, int iLinkIndex, int& iPointNum) = 0;
    
    /*!
     \brief          获得一个Link的长度（单位米）
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex {int}. Link编号，从0开始编号
     \return         {int}. 成功返回Link的长度，否则返回-1
     */
    virtual int GetLinkLength(int iSegIndex, int iLinkIndex) = 0;
    
    /*!
     \brief          获得一个Link的旅行时间（单位秒）
     \details        在调用此接口前必须调用过SelectRoute，建议尽量不要使用此接口
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex {int}. Link编号，从0开始编号
     \return         {int}. 成功返回Link的旅行时间，否则返回-1
     */
    virtual int GetLinkTime(int iSegIndex, int iLinkIndex) = 0;
    
    /*!
     \brief          获得一个Link的FormWay
     \details        在调用此接口前必须调用过SelectRoute
     FormWay定义如下
     1	// 主路
     2	// 路口内部道路
     3	// JCT道路
     4	// 环岛
     5	// 服务区
     6	// 匝道
     7	// 辅路
     8	// 匝道与JCT
     9	// 出口
     10	// 入口
     11	// A类右转专用道
     12	// B类右转专用道
     13	// A类左转专用道
     14	// B类左转专用道
     15	// 普通道路
     16	// 左右转专用道
     56	// 服务区与匝道
     53	// 服务区与JCT
     58	// 服务区与匝道以及JCT
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex {int}. Link编号，从0开始编号
     \return         {int}. 成功返回Link的FormWay信息，否则返回-1
     */
    virtual int GetLinkFormWay(int iSegIndex, int iLinkIndex) = 0;
    
    /*!
     \brief          获得一个Link的RoadClass
     \details        在调用此接口前必须调用过SelectRoute
     RoadClass定义如下
     0	高速公路
     1	国道
     2	省道
     3	县道
     4	乡公路
     5	县乡村内部道路
     6	主要大街、城市快速道
     7	主要道路
     8	次要道路
     9	普通道路
     10	非导航道路
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex {int}. Link编号，从0开始编号
     \return         {int}. 成功返回Link的RoadClass信息，否则返回-1
     */
    virtual int GetLinkRoadClass(int iSegIndex, int iLinkIndex) = 0;
    
    /*!
     \brief          获得一个Link的LinkType
     \details        在调用此接口前必须调用过SelectRoute
     LinkType定义如下
     0	普通道路
     1	航道
     2	隧道
     3	桥梁
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex {int}. Link编号，从0开始编号
     \return         {int}. 成功返回Link的LinkType信息，否则返回-1
     */
    virtual int GetLinkType(int iSegIndex, int iLinkIndex) = 0;
    
    /*!
     \brief          获得一个Link上是否有红绿灯
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iSegIndex {int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex {int}. Link编号，从0开始编号
     \return         {int}. 0：无红绿灯，1：有红绿灯，失败返回-1
     */
    virtual int HaveTrafficLights(int iSegIndex, int iLinkIndex) = 0;
    
    /*!
     \brief          创建一个光柱
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      iStartPos {int}. 光柱范围在路径中的起始位置
     \param[in]      iDistance {int}. 光柱范围长度
     \param[out]     iItemNum {int&}. TMCBarItem的个数
     \return         {TMCBarItem*}. 成功返回光柱数据列表，参见TMCBarItem结构,失败返回NULL
     */
    virtual TMCBarItem* CreateTMCBar(int iStartPos, int iDistance, int& iItemNum) = 0;
    
    /*!
     \brief          获得一个LocationCode的状态
     \details        在调用此接口前必须调用过SelectRoute
     \param[in]      sLocationCode {short}. 要查询道路的LocationCode
     \param[out]     iSpeed {int&}. 速度，km/h
     \param[out]     iStatus {int&}. 状态：0 未知状态，1 通畅，2 缓行，3 阻塞严重
     \param[out]     iPassTime {int&}. 预计通过该路段所需时间，单位：s
     \param[out]     iDelayTime {int&}. 通过该路段所延误时间，单位：s
     \return         {int}. 0失败，1成功
     */
    virtual int GetRoadStatus(short sLocationCode, int& iSpeed, int& iStatus, int& iPassTime, int& iDelayTime) = 0;
    /*!
     \brief          设置静默算路策略
     \details        无
     \param[in]      iStrategy {int}.
     0 满足拥堵条件， 当前路况耗时比算路时要长，通知reroute
     1 满足同上条件， 自动算路后 有不同则通知
     2 满足拥堵条件， 不考虑时间，自动算路后有不同则通知
     \return
     */
	virtual void SetTMCRerouteStrategy(int iStrategy) = 0;
    /*!
     \brief          设置路口放大图显示模式
     \details        无
     \param[in]      iMode {int}. 0 不显示 1 栅格 2 矢量
     \return         {void}
     */
	virtual void SetCrossDisplayMode(int iMode) = 0;
    /*!
     \brief          获得link是否有岔路
     \details        无
     \param[in]      iSegIndex{int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex{int}. Link编号，从0开始编号
     \return         {int} 0 无岔路 1 有岔路
     */
	virtual int  GetLinkIsBranched(int iSegIndex, int iLinkIndex) = 0;
    /*!
     \brief          获得对应link是否存在出口或入口的状态
     \details        无
     \param[in]      iSegIndex{int}. 导航段编号，从0开始编号
     \param[in]      iLinkIndex{int}. Link编号，从0开始编号
     \return         {int} 0 普通link 1 带有出口或入口
     */
    virtual int  GetLinkIOFlag(int iSegIndex, int iLinkIndex) = 0;
    
};

/*!
 \brief      该类用来获得ITBT接口
 \details    在程序退出时必须调用Release()TBT释放TBT对象
 */
class EXPORT_C CTBTFactory
{
public:
    
    /*!
     \brief          获得ITBT接口
     \details        无
     \return         {ITBT*}. ITBT接口，NULL
     */
    static ITBT* GetInstance();
    
    /*!
     \brief          释放TBT模块
     \details        无
     \return         {void}. 无返回值
     */
    static void Release();
};

#endif