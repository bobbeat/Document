/*--------------------------------------------------------------+
 |																|
 |	ivTTSInUse.h - AiSound 4 Kernel API	            			|
 |																|
 |		Copyright (c) 1999-2008, ANHUI USTC iFLYTEK CO.,LTD.	|
 |		All rights reserved.									|
 |																|
 +--------------------------------------------------------------*/

#ifndef IFLYTEK_VOICE_TTS_INUSE_H
#define IFLYTEK_VOICE_TTS_INUSE_H

#define ivTTS_PARAM_TEXT_SCOPE			0x00000103	/* text scope, e.g. number */
#define ivTTS_PARAM_VE_AMPLIFY			0x00000601	/* voice effect - amplify */
#define ivTTS_PARAM_VE_ECHO				0x00000602	/* voice effect - echo */
#define ivTTS_PARAM_VE_REVERB			0x00000603	/* voice effect - reverb */
#define ivTTS_PARAM_VE_CHROUS			0x00000604	/* voice effect - chrous */
#define ivTTS_PARAM_VE_PITCH			0x00000605	/* voice effect - pitch adjust */

#define ivTTS_PARAM_READ_PUNCTUATIONS	0x00000300	/* whether read punctuations */
#define ivTTS_PARAM_OUTPUT_VOICE		0x00000400	/* output voice or not */
#define ivTTS_PARAM_PHONEME_WATCH		0x00000402	/* how to watch phoneme, e.g. Chinese Pin-Yin */
#define ivTTS_PARAM_WATCH_CALLBACK		0x00000403	/* watch callback entry */
#define ivTTS_PARAM_VOLUME_INCREASE		0X00000505	/* volume value increase */

/* constants for values of parameter ivTTS_PARAM_TEXT_SCOPE */
#define ivTTS_SCOPE_UNLIMITED			0			/* unlimited scope (default) */
#define ivTTS_SCOPE_CHINESE_NUMBER		1			/* Chinese number */
#define ivTTS_SCOPE_CHINESE_VALUE		2			/* Chinese value */
#define ivTTS_SCOPE_CHINESE_DATETIME	3			/* Chinese date or time */

/* constants for values of parameter ivTTS_PARAM_PHONEME_WATCH */
#define ivTTS_PHONEME_NONE				0			/* none (default) */
#define ivTTS_PHONEME_PINYIN			1			/* Chinese Pin-Yin */

/* constants for values of parameter ivTTS_PARAM_VOLUME_INCREASE */
/* the range of volume value is from 0 to 10 */
#define ivTTS_VOLUME_INCREASE_MIN				0		/* minimized volume (default) */
#define ivTTS_VOLUME_INCREASE_MAX				10		/* maximized volume */

/* constants for values of parameter ivTTS_PARAM_TEXT_MARK */
#define ivTTS_TEXTMARK_CSSML			2			/* CSSML */

/* constants for values of parameter ivTTS_PARAM_LANGUAGE */
#define ivTTS_LANGUAGE_FRENCH			3			/* French */

/* constants for values of parameter ivTTS_PARAM_SPEAK_STYLE */
#define ivTTS_STYLE_VIVID				2			/* vivid speak style */

/* watch callback type */
typedef ivTTSErrID (ivProc ivTTSCB_Watch)(
		ivPointer		pParameter,		/* [in] user callback parameter */
		ivUInt16		nSylType,		/* [in] syllable type */
		ivCPointer		pcSylText,		/* [in] syllable text buffer */
		ivSize			nTextLen,		/* [in] syllable text length */
		ivCPointer		pcSylPhone,		/* [in] syllable phoneme buffer */
		ivSize			nPhoneLen );	/* [in] syllable phoneme length */

/* constants for values of parameter wSylType */
#define ivTTS_SYL_SYMBOL				0			/* symbol */
#define ivTTS_SYL_PROMPT				1			/* prompt */
#define ivTTS_SYL_CHINESE				2			/* chinese syllable */
#define ivTTS_SYL_ENGLISH				3			/* english syllable */

#define ivTTS_SYL_ENDL1				(ivUInt16)-1	/* end L1 */
#define ivTTS_SYL_ENDL3				(ivUInt16)-3	/* end L3 */
#define ivTTS_SYL_ENDSENT			(ivUInt16)-5	/* end sentense */


/* structure for output command */
typedef struct tagTTSOutputCommand ivTTTSOutputCommand;
typedef ivTTTSOutputCommand ivPtr ivPTTSOutputCommand;

struct tagTTSOutputCommand
{
	ivUInt32		dwCommand;		/* command name */
	ivUInt32		dwParam1;		/* parameter 1 */
	ivUInt32		dwParam2;		/* parameter 2 */
};

/* constants for values of command name */
#define ivTTS_OUTCMD_SILENCE			0			/* output silence (dwParam1 is the length by ms) */
#define ivTTS_OUTCMD_RESET				1			/* reset the decoder */

/* constants for values of parameter wCode */
#define ivTTS_CODE_COMMAND				0x0000		/* command */
#define ivTTS_CODE_PCM22K16B			0x0216		/* PCM 22K 16bit */

#endif /* !IFLYTEK_VOICE_TTS_INUSE_H */

