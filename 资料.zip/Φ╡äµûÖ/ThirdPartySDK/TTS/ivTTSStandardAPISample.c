// ivTTSStandardAPISample.c : Defines the entry point for the console application.
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ivTTS.h"
//#include "PublicDefine.h"
#include <TargetConditionals.h>
//#import	"Globall.h"
/* constant for TTS heap size */
/*
 #define ivTTS_HEAP_SIZE		50000 / * 混合，无音效 * /
 */
#define ivTTS_HEAP_SIZE		70000 /* 混合，音效 */




/* Message */
ivTTSErrID DoMessage()
{
	/* 获取消息，用户实现 */
	if(1)
	{
		/* 继续合成 */
		return ivTTS_ERR_OK;
	}
	else
	{
		/* 退出合成 */
		return ivTTS_ERR_EXIT;
	}
}

FILE *fpOutput = 0;
/* output callback */
ivTTSErrID OnOutput(
					ivUInt16		nCode,			/* [in] output data code */
					ivCPointer		pcData,			/* [in] output data buffer */
					ivSize			nSize )			/* [in] output data size */
{
	/* play */
	/* 根据实际平台将语音数据传给播音接口，这里只是简单的将语音数据保存在文件中 */
	fwrite(pcData, 1, nSize, fpOutput);
	fflush(fpOutput);
	return ivTTS_ERR_OK;
}

/* read resource callback */
ivBool ivCall ReadResCB(
						ivPointer		pParameter,		/* [in] user callback parameter */
						ivPointer		pBuffer,		/* [out] read resource buffer */
						ivResAddress	iPos,			/* [in] read start position */
						ivResSize		nSize )			/* [in] read size */
{
	FILE* pFile = (FILE*)pParameter;
    int err;
	
	navi_fseek(pFile, iPos, SEEK_SET); //modi by zzl for 调用其他接口偏移文件 2011.05.10
	err = fread(pBuffer, 1, nSize, pFile);
    if ( err == (int)nSize )
	    return ivTrue;
    else
        return ivFalse;
}

/* output callback */
ivTTSErrID ivCall OutputCB(
						   ivPointer		pParameter,		/* [in] user callback parameter */
						   ivUInt16		nCode,			/* [in] output data code */
						   ivCPointer		pcData,			/* [in] output data buffer */
						   ivSize			nSize )			/* [in] output data size */
{
	/* 获取线程消息，是否退出合成 */
	ivTTSErrID tErr = DoMessage();
	if ( tErr != ivTTS_ERR_OK ) return tErr;
	/* 把语音数据送去播音 */
	return OnOutput(nCode, pcData, nSize);
}

/* parameter change callback */
ivTTSErrID ivCall ParamChangeCB(
								ivPointer       pParameter,		/* [in] user callback parameter */
								ivUInt32		nParamID,		/* [in] parameter id */
								ivUInt32		nParamValue )	/* [in] parameter value */
{
	return ivTTS_ERR_OK;
}

/* progress callback */
ivTTSErrID ivCall ProgressCB(
							 ivPointer       pParameter,		/* [in] user callback parameter */
							 ivUInt32		iProcPos,		/* [in] current processing position */
							 ivUInt32		nProcLen )		/* [in] current processing length */
{
	return ivTTS_ERR_OK;
}

FILE *fpCBLog = 0;
ivUInt16 ivCall LogCB(
					  ivPointer	pParameter,			/* [out] user callback parameter */
					  ivCPointer	pcData,				/* [in] output data buffer */
					  ivSize		nSize				/* [in] output data size */
					  )
{
	FILE *pFile = (FILE*)pParameter;
	ivSize nWriten = fwrite(pcData,1,nSize,pFile);
	if( nWriten == nSize )
		return ivTTS_ERR_OK;
	else
		return ivTTS_ERR_FAILED;
}

#define ivTTS_CACHE_SIZE	512
#define ivTTS_CACHE_COUNT	1024
#define ivTTS_CACHE_EXT		8
//获取语音角色名字，返回0表示失败，1表示成功,languageIndex为0和1时是中文，为2时是英文
int getSpeakerName(char * speakerName,int languageIndex,int spekerIndex)
{
    if(languageIndex == 2)
    {
        switch (spekerIndex) {
            case 0:
                memcpy(speakerName, "Catherine", strlen("Catherine"));
                return 1;
                break;
            case 1:
                 memcpy(speakerName, "John", strlen("John"));
                return 1;
                break;
            default:
                break;
        }
    }
    else
    {
        switch (spekerIndex) {
            case 1:
                memcpy(speakerName, "XiaoFeng", strlen("XiaoFeng"));
                return 1;
                break;
            case 2:
                memcpy(speakerName, "XiaoLin", strlen("XiaoLin"));
                return 1;
                break;
            case 3:
                memcpy(speakerName, "XiaoMei", strlen("XiaoMei"));
                return 1;
                break;
            case 4:
                memcpy(speakerName, "XiaoQian", strlen("XiaoQian"));
                return 1;
                break;
            case 5:
                memcpy(speakerName, "XiaoRong", strlen("XiaoRong"));
                return 1;
                break;
            case 6:
                memcpy(speakerName, "XiaoQiang", strlen("XiaoQiang"));
                return 1;
                break;
            case 7:
                memcpy(speakerName, "XiaoKun", strlen("XiaoKun"));
                return 1;
            case 0:
                memcpy(speakerName, "XiaoYan", strlen("XiaoYan"));
                return 1;
                break;
            default:
                break;
        }
    }
    return 0;
}

//codeType:0 GBK,1 UTF8
int TTS_fun(char *szOutputFile,const char *pszText,int codeType,const char *sourceFileFolder,int languageIndex,int speakerIndex,int ttsType,int ttsVoiceSpeed,int ttsUsePrompts,const char *ttsFolderName)
{
#if !(TARGET_IPHONE_SIMULATOR)
	ivHTTS			hTTS;
	ivPByte			pHeap;
	ivTResPackDesc	tResPackDesc;
	ivTTSErrID		ivReturn;
	char pVoiceData[50];
	char TTS_name[200];
	memset(&TTS_name,0x0,200);
	if (!strlen(szOutputFile)) 
	{
		return 0;
	}
	fpOutput = fopen(szOutputFile,"wb");
	if( !fpOutput )
	{
//		printf("fpoutput is error");
		return 0;
	}
	pVoiceData[0] = 0x52;
	pVoiceData[1] = 0x49 ;
	pVoiceData[2] = 0x46;
	pVoiceData[3] = 0x46;
	pVoiceData[4] = 0xBC;
	pVoiceData[5] = 0x7A;
	pVoiceData[6] = 0x06;
	pVoiceData[7] = 0x00;
	pVoiceData[8] = 0x57;
	pVoiceData[9] = 0x41;
	pVoiceData[10] = 0x56;
	pVoiceData[11] = 0x45;
	pVoiceData[12] = 0x66;
	pVoiceData[13] = 0x6D;
	pVoiceData[14] = 0x74;
	pVoiceData[15] = 0x20;
	
	pVoiceData[16] = 0x10;
	pVoiceData[17] = 0x00;
	pVoiceData[18] = 0x00;
	pVoiceData[19] = 0x00;
	pVoiceData[20] = 0x01;
	pVoiceData[21] = 0x00;
	pVoiceData[22] = 0x01;
	pVoiceData[23] = 0x00;
	pVoiceData[24] = 0x80;
	pVoiceData[25] = 0x3E;
	pVoiceData[26] = 0x00;
	pVoiceData[27] = 0x00;
#if 1
	pVoiceData[28] = 0x80;
	pVoiceData[29] = 0x3e;
	pVoiceData[30] = 0x00;
	pVoiceData[31] = 0x00;
#else
	pVoiceData[28] = 0x00;
	pVoiceData[29] = 0x2e;
	pVoiceData[30] = 0x00;
	pVoiceData[31] = 0x00;
#endif
	
	
	pVoiceData[32] = 0x02;
	pVoiceData[33] = 0x00;
	pVoiceData[34] = 0x10;
	pVoiceData[35] = 0x00;
	pVoiceData[36] = 0x64;
	pVoiceData[37] = 0x61;
	pVoiceData[38] = 0x74;
	pVoiceData[39] = 0x61;
	pVoiceData[40] = 0x98;
	pVoiceData[41] = 0x7a;
	pVoiceData[42] = 0x06;
	pVoiceData[43] = 0x00;
	
	
	
	fwrite(pVoiceData,1,44,fpOutput);
	
	
	
	
	if (1)
	{
		/* ∑÷≈‰∂— */
		pHeap = (ivPByte)malloc(ivTTS_HEAP_SIZE);
		memset(pHeap, 0, ivTTS_HEAP_SIZE);
		
        if (ttsType > 0) //add by hlf for 切换为非系统自带方言，则用传入的文件名来读取 2014.01.18
        {
            sprintf(TTS_name, "%s/%s/Resource.irf",sourceFileFolder,ttsFolderName);
            
        }
        else
        {
            
            char speakerName[64] = {0};
            getSpeakerName(speakerName, languageIndex, speakerIndex);
            sprintf(TTS_name, "%s/%s/Resource.irf",sourceFileFolder,speakerName);
            
        }
        
        
        memset(&tResPackDesc, 0x0, sizeof(ivTResPackDesc));
		tResPackDesc.pCBParam = navi_fopen(TTS_name, "rb"); //modi by zzl for 调用其他接口打开文件 2011.05.10
		tResPackDesc.pfnRead = ReadResCB;
		tResPackDesc.pfnMap = NULL;
		tResPackDesc.nSize = 0;
		
		if (tResPackDesc.pCBParam)
		{
			tResPackDesc.pCacheBlockIndex = (ivPUInt8)malloc(ivTTS_CACHE_COUNT + ivTTS_CACHE_EXT);
			tResPackDesc.pCacheBuffer = (ivPUInt8)malloc((ivTTS_CACHE_COUNT + ivTTS_CACHE_EXT)*(ivTTS_CACHE_SIZE));
			tResPackDesc.nCacheBlockSize = ivTTS_CACHE_SIZE;
			tResPackDesc.nCacheBlockCount = ivTTS_CACHE_COUNT;
			tResPackDesc.nCacheBlockExt = ivTTS_CACHE_EXT;
		}
		else
		{
			fclose(fpOutput);
			//printf("tResPackDesc is error");
			return 0;
		}
		
		/* ¥¥Ω® TTS  µ¿˝ */
		ivReturn = ivTTS_Create(&hTTS, (ivPointer)pHeap, ivTTS_HEAP_SIZE, ivNull, (ivPResPackDescExt)&tResPackDesc, (ivSize)1,NULL);
		
		/* …Ë÷√“Ù∆µ ‰≥ˆªÿµ˜ */
		ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_OUTPUT_CALLBACK, (ivUInt32)OutputCB);
		
		/* …Ë÷√ ‰»ÎŒƒ±æ¥˙¬Î“≥ */
		//@modi start by lzb for sound_flag
		
		if(codeType == 1)
		{
		
			ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_INPUT_CODEPAGE, ivTTS_CODEPAGE_UTF8);
		}
		else
		{
			ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_INPUT_CODEPAGE, ivTTS_CODEPAGE_GBK);
		}	
		
		//@modi end by lzb for sound_flag
		/* …Ë÷√”Ô÷÷ */
		if (languageIndex == 2)
		{
			ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_LANGUAGE, ivTTS_LANGUAGE_ENGLISH);	
		}
		else
		{
			ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_LANGUAGE, ivTTS_LANGUAGE_CHINESE);	
		}
	
		/* …Ë÷√“Ù¡ø */
		ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_VOLUME, ivTTS_VOLUME_MAX);
		
        if (ttsType > 0) //add by hlf for 切换为非系统自带方言，则用传入的文件名来读取 2014.01.18
        {
            
            ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_VOICE_SPEED, ttsVoiceSpeed);
            ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_USE_PROMPTS, ttsUsePrompts);
        }
        else
        {
            ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_VOICE_SPEED, 0);
            ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_USE_PROMPTS, 0);
        }
        
		/************************************************************************
		 øÈ Ω∫œ≥…
		 ************************************************************************/
		/* …Ë÷√∑¢“Ù»ÀŒ™ XIAOYAN */
		if (languageIndex == 2)
		{
			if(speakerIndex == 1)
			{
				ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_CATHERINE);
			}
			else if(speakerIndex == 0)
			{
				ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_JOHN);
			}
		}
		else
		{
            if (ttsType > 0) {//add by hlf for 切换为非系统自带方言 2014.01.18
                ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, speakerIndex);
            }
            else{
                switch (speakerIndex) {
                    case 1:
                        ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAOFENG);
                        break;
                    case 2:
                        ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAOLIN);
                        break;
                    case 3:
                        ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAOMEI);
                        break;
                    case 4:
                        ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAOQIAN);
                        break;
                    case 5:
                        ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAORONG);
                        break;
                    case 6:
                        ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAOQIANG);
                        break;
                    case 7:
                        ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAOKUN);
                        break;
                    case 0:
                        ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAOYAN);
                        break;
                    default:
                        break;
                }
            }
			
		}		
		ivReturn = ivTTS_SynthText(hTTS, ivText(pszText), -1);
		//	ivReturn = ivTTS_SynthText(hTTS, ivText("Hello, this is iFLYTEK TTS system."), -1);
		
		/* …Ë÷√∑¢“Ù»ÀŒ™ XIAOFENG */
		//	ivReturn = ivTTS_SetParam(hTTS, ivTTS_PARAM_ROLE, ivTTS_ROLE_XIAOFENG);
		//ivReturn = ivTTS_SynthText(hTTS, ivText("高德软件导航系统"), -1);
		//	ivReturn = ivTTS_SynthText(hTTS, ivText("Hello, this is iFLYTEK TTS system."), -1);		
		
		/* ƒÊ≥ı ºªØ */
		ivReturn = ivTTS_Destroy(hTTS);
		
		if ( tResPackDesc.pCacheBlockIndex )
		{
			free(tResPackDesc.pCacheBlockIndex);
		}
		if ( tResPackDesc.pCacheBuffer )
		{
			free(tResPackDesc.pCacheBuffer);
		}
		if ( pHeap )
		{
			free(pHeap);
		}
	}
	fclose(tResPackDesc.pCBParam);
	long len;
	fseek(fpOutput, 0, SEEK_END);
	len = ftell(fpOutput);
	len = len - 8;
	
	
	
	fseek(fpOutput,4,SEEK_SET);
	fwrite(&len, 1, 4, fpOutput);
	
	len = len - 0x44;
	
	fseek(fpOutput,0x28,SEEK_SET);
	fwrite(&len, 1, 4, fpOutput);
	
	
	
	fclose(fpOutput);	
	//	printf("fpOutput is success");
	return 1;

#endif
}
