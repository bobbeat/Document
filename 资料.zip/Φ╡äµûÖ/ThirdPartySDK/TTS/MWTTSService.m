//
//  MWTTSService.m
//  middleware
//
//  Archite by mark
//  Created by  on 12-2-8.
//  Copyright (c) 2012年 Autonavi. All rights reserved.
//

#import "MWTTSService.h"
#import <CoreTelephony/CTCallCenter.h>
#import <CoreTelephony/CTCall.h>
#import "GDBL_Location.h"

int TTS_fun(char *szOutputFile,const char *pszText,int codeType,const char *sourceFileFolder,int languageIndex,int speakerIndex,int ttsType,int ttsVoiceSpeed,int ttsUsePrompts,const char *ttsFolderName);
@implementation MWTTSService
@synthesize delegate;
@synthesize isPlaying;
@synthesize ttsResourcePath;
@synthesize codingType;
@synthesize languageIndex;
@synthesize speakerIndex;
@synthesize playString;
@synthesize voiceSpeed,usePrompts,ttsFolderName,beLZLDialect;

static MWTTSService * instance;

+(MWTTSService*)sharedInstance
{
    @synchronized(self)
    {
        if(instance==nil)
        {
            instance = [[MWTTSService alloc] init];
            
            //后台语音播报
            [[AVAudioSession sharedInstance] setCategory: AVAudioSessionCategoryPlayback error: nil];
            UInt32 doSetProperty = true;
            //支持多种语音混合
            AudioSessionSetProperty (
                                     kAudioSessionProperty_OverrideCategoryMixWithOthers,
                                     sizeof (doSetProperty),
                                     &doSetProperty
                                     );
            
            [[AVAudioSession sharedInstance] setActive:YES error:nil];
            [[AVAudioSession sharedInstance] setDelegate:self];
            
        }
    }
    
    return instance;
}

+(MWTTSService*)sharedInstanceWithResourcePath:(NSString*)path
{
    @synchronized(self)
    {
        if(instance==nil)
        {
            instance = [[MWTTSService alloc] init];
            
            //后台语音播报
            [[AVAudioSession sharedInstance] setCategory: AVAudioSessionCategoryPlayback error: nil];
            UInt32 doSetProperty = true;
            //支持多种语音混合
            AudioSessionSetProperty (
                                     kAudioSessionProperty_OverrideCategoryMixWithOthers,
                                     sizeof (doSetProperty),
                                     &doSetProperty
                                     );
            
            [[AVAudioSession sharedInstance] setActive:YES error:nil];
            [[AVAudioSession sharedInstance] setDelegate:self];
            
        }
    }
    instance.ttsResourcePath = path;
    return instance;
}
-(id) init
{
    if(self = [super init]){
        [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(TTSDidEnterBackgroundNotification:) name:UIApplicationDidEnterBackgroundNotification object: nil];
        [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(TTSWillResignActiveNotification:) name:UIApplicationWillResignActiveNotification object: nil];
        [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(TTSDidBecomeActiveNotification:) name:UIApplicationDidBecomeActiveNotification object: nil];
        CTCallCenter *callCenter = [[CTCallCenter alloc] init];
        
        callCenter.callEventHandler=^(CTCall* call){
            
            if (call.callState == CTCallStateIncoming) {
                _interruptedOnPlayback = YES;
                NSLog(@"Call incoming");
            }
            if (call.callState == CTCallStateDialing){
                _interruptedOnPlayback = YES;
                NSLog(@"Call Dialing");
            }
            
            if (call.callState == CTCallStateConnected){
                
                NSLog(@"Call Connected");
                
            }
            
            if (call.callState == CTCallStateDisconnected){
                _interruptedOnPlayback = NO;
                NSLog(@"Call Disconnected");
                
            }
        };
    }
    return self;
}
+(void)releaseInstance
{
    @synchronized(self)
    {
        if(instance != nil)
        {
            [instance release];
            instance = nil;
        }
    }
}


-(id)initWithResourcePath:(NSString *)path
{
    self = [super init];
    if(self != nil)
    {
        ttsResourcePath = [[NSString alloc] initWithFormat:@"%@",path];
    }
    return self;
}
-(void)dealloc
{
    [ttsResourcePath release];
    if (ttsFolderName) {
        [ttsFolderName release];
        ttsFolderName = nil;
    }
    [super dealloc];
}

-(void)safeCallDelegate:(id)del Selector:(SEL)sel withObject:(id)object
{
    if([del respondsToSelector:sel])
    {
        [del performSelector:sel withObject:object];
    }
}
#pragma mark AV Foundation 播报接口
-(void)playWavByPath:(NSString *)path
{
    if (![self isAllowedPlay])
    {
        return;
    }
    NSLog(@"playWavByPath = %@",path);
    
    [self playByVoicePath:path];
}

-(void)playByVoicePath:(NSString *)path
{
    
    [self safeCallDelegate:delegate Selector:@selector(playerWillBeginPlaying) withObject:nil];
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0);
    dispatch_async(queue, ^{
        //后台语音播报
        BOOL tmpValue;
        GDBL_GetParamExt(BACKGROUND_NAVI, &tmpValue);
        if (tmpValue) {
            [[AVAudioSession sharedInstance] setCategory: AVAudioSessionCategoryPlayback error: nil];
        }
        else{
            [[AVAudioSession sharedInstance] setCategory: AVAudioSessionCategoryAmbient error: nil];
            
        }
        UInt32 doSetProperty = true;
        //支持多种语音混合
        AudioSessionSetProperty (
                                 kAudioSessionProperty_OverrideCategoryMixWithOthers,
                                 sizeof (doSetProperty),
                                 &doSetProperty
                                 );
        
       // [self setOtherMixableAudioShouldDuck:YES];
        
        [[AVAudioSession sharedInstance] setActive:YES error:nil];
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:path] == 0)
        {
            isPlaying = NO;
            return;
        }
        NSError * error = nil;
        NSURL *tts_url = [[NSURL alloc] initFileURLWithPath: path];
        
        if(_appSoundPlayer != nil)
        {
            [_appSoundPlayer release];
            _appSoundPlayer = nil;
        }
        _appSoundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:tts_url  error: &error];
        [tts_url release];
        
        if(( 0 != error.code ) || ( _appSoundPlayer == nil ))
        {
            isPlaying = NO;
            
            if(_appSoundPlayer != nil)
            {
                [_appSoundPlayer release];
                _appSoundPlayer = nil;
            }
            return;
            
        }
        BOOL res = YES;
        [_appSoundPlayer setVolume: 1.0];
        [_appSoundPlayer setDelegate: self];
        
        res = [_appSoundPlayer prepareToPlay];
        
        if (res == YES)
        {
            
            res = [_appSoundPlayer play];
            
            if (res == NO)
            {
                isPlaying = NO;
                if(_appSoundPlayer != nil)
                {
                    [_appSoundPlayer release];
                    _appSoundPlayer = nil;
                }
                return;
            }
        }
        else
        {
            isPlaying = NO;
            if(_appSoundPlayer != nil)
            {
                [_appSoundPlayer release];
                _appSoundPlayer = nil;
            }
            return;
        }
        
        return;
        
        dispatch_sync(dispatch_get_main_queue(), ^{
            
        });
    });

}

-(void)playByStr:(NSString *)str
{
    //转换str为音频，调用TTS库，然后在完成的处理方法中播放
    if (![self isAllowedPlay])
    {
        return;
    }
    
    NSString * text;
    NSLog(@"%@",str);
    if([str hasPrefix:@"[z1]"])
    {
        text = [NSString stringWithFormat:@"%@",str];
    }
    else
    {
        text = [NSString stringWithFormat:@"[z1]%@",str];
    }
    [self safeCallDelegate:delegate Selector:@selector(transformWillBegin) withObject:nil];
    [NSThread detachNewThreadSelector:@selector(transformThread:) toTarget:self
						   withObject:text];
}

-(void)playByCStr:(const char*)str
{
    

    if(codingType == 1)
    {
        [self playByStr:[NSString stringWithUTF8String:str]];
    }
    else if(codingType == 0)
    {
    
        [self playByStr:[NSString chinaFontStringWithCString:str]];
       
    }
        
}

-(void)stop
{
    if(_transeforming)
    {
        _stoping = YES;
    }  
    else if(_appSoundPlayer != nil)
    {
        [_appSoundPlayer stop];
        
        [self safeCallDelegate:delegate Selector:@selector(playerDidStopPlaying) withObject:nil];
    }
    isPlaying = NO;
}

- (BOOL)status
{
    return isPlaying;
}

-(void)transeformDone:(NSString *)voicePath
{
    
    [self safeCallDelegate:delegate Selector:@selector(transformDidFinished) withObject:nil];
    if(_stoping)
    {
        _stoping = NO;
        [self safeCallDelegate:delegate Selector:@selector(playerDidStopPlaying) withObject:nil];
        return;
    }
    [self playByVoicePath:voicePath];
}

-(void)transeformFail
{
    [self safeCallDelegate:delegate Selector:@selector(transformDidFailed) withObject:nil];
    isPlaying = NO;
}

-(void)strToVoice:(NSString *)str
{
    self.playString = str;
    char szOutputFilePath[512] = {0};
    NSString *docPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    sprintf(szOutputFilePath, "%s/VoiceData.wav",[docPath UTF8String]);
    
    if (2 == GDBL_GetVoicePlayType()) {//本网结合屏蔽过渡区域到达目的地播报
        if (0 == languageIndex)
        {
            if ([str hasSuffix:@"目的地"]) {
                str = [NSString stringWithFormat:@"前方进入网络导航，请保持网络畅通"];
            }
        }
        else if(1 == languageIndex)
        {
            if ([str hasSuffix:@"目的地"]) {
                str = [NSString stringWithFormat:@"前方進入網絡導航，請保持網絡暢通"];
            }
        }
        else{
            if ([str hasSuffix:@"destination"]) {
                str = [NSString stringWithFormat:@"Start using online navigation, please ensure the network connection."];
            }
        }
        if(TTS_fun(szOutputFilePath,[str UTF8String],1,[ttsResourcePath UTF8String],languageIndex,speakerIndex,self.beLZLDialect,voiceSpeed,usePrompts,[ttsFolderName UTF8String]))
        {
            NSString * strPath = [NSString stringWithFormat:@"%s",szOutputFilePath];
            [self transeformDone:strPath];
            //[self performSelectorOnMainThread:@selector(transeformDone:) withObject:strPath waitUntilDone:NO];
        }
        else
        {
            [self performSelectorOnMainThread:@selector(transeformFail) withObject:nil waitUntilDone:NO];
        }
    }
    else if (1 == GDBL_GetVoicePlayType()) {//网络地图播报－只支持中文简体
        
        if(TTS_fun(szOutputFilePath,[str UTF8String],1,[ttsResourcePath UTF8String],0,speakerIndex,beLZLDialect,voiceSpeed,usePrompts,[ttsFolderName UTF8String]))
        {
            NSString * strPath = [NSString stringWithFormat:@"%s",szOutputFilePath];
            [self transeformDone:strPath];
            //[self performSelectorOnMainThread:@selector(transeformDone:) withObject:strPath waitUntilDone:NO];
        }
        else
        {
            [self performSelectorOnMainThread:@selector(transeformFail) withObject:nil waitUntilDone:NO];
        }
    }
    else if(0 == GDBL_GetVoicePlayType()){
        if(TTS_fun(szOutputFilePath,[str UTF8String],1,[ttsResourcePath UTF8String],languageIndex,speakerIndex,self.beLZLDialect,voiceSpeed,usePrompts,[ttsFolderName UTF8String]))
        {
            NSString * strPath = [NSString stringWithFormat:@"%s",szOutputFilePath];
            [self transeformDone:strPath];
            //[self performSelectorOnMainThread:@selector(transeformDone:) withObject:strPath waitUntilDone:NO];
        }
        else
        {
            [self performSelectorOnMainThread:@selector(transeformFail) withObject:nil waitUntilDone:NO];
        }
    }
    
}
-(void)transformThread:(NSString *)str
{
    
    NSAutoreleasePool *pool = [NSAutoreleasePool new];
    _transeforming = YES;
    [self strToVoice:str];
    _transeforming = NO;
    [pool release];
    
}
//设置当导航语音播报时是否降低其他程序的音量
- (void)setOtherMixableAudioShouldDuck:(BOOL)isDuck
{
    isOtherShouldDuck = isDuck;
    UInt32 doSetProperty;
    if (isDuck) {
        doSetProperty = true;
        AudioSessionSetProperty (
                                 kAudioSessionProperty_OtherMixableAudioShouldDuck,
                                 sizeof (doSetProperty),
                                 &doSetProperty
                                 );
    }
    else{
        doSetProperty = true;
        //支持多种语音混合
        AudioSessionSetProperty (
                                 kAudioSessionProperty_OverrideCategoryMixWithOthers,
                                 sizeof (doSetProperty),
                                 &doSetProperty
                                 );
    }
    
}

//设置是否存在路径
- (void)setIsPath:(BOOL)path
{
    isExistPath = path;
}


- (void)isMuted:(BOOL)muted {
   // NSLog(@"ismuted:%d",muted);
    isSystemMuted = muted;
    BOOL tmpValue;
    GDBL_GetParamExt(BACKGROUND_NAVI, &tmpValue);
    if (isSystemMuted && isPlaying && tmpValue) {
        [self stop];
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0);
        dispatch_async(queue, ^{
            [[AVAudioSession sharedInstance] setActive:NO error:nil];
            
            dispatch_sync(dispatch_get_main_queue(), ^{
                
            });
        });
    }
}

- (BOOL)isAllowedPlay
{
    
    int bMute;
    BOOL isPath = NO;
    BOOL isBackground = NO;
    GDBL_GetParam(G_MUTE , &bMute);
    GDBL_GetParam(G_GUIDE_STATUS, &isPath);
    GDBL_GetParam(G_BACKGROUND_MODE, &isBackground);
    
    BOOL isWarningView = NO;
    GDBL_GetParamExt(WARNINGVIEW, &isWarningView);
    
    if ((isPlaying || _interruptedOnPlayback || bMute || (!isPath && isBackground && !isExistPath) ) || isWarningView)
    {
        return NO;
    }
    
    backgroundSoundFlag = NO;
    isPlaying = YES;
    return YES;
}
#pragma mark AV Foundation delegate methods____________



- (void)audioPlayerEndInterruption:(AVAudioPlayer *)player withFlags:(NSUInteger)flags
{
    NSLog(@"audioPlayerEndInterruption");
#ifdef __IPHONE_4_0
    [[AVAudioSession sharedInstance] setActive: YES error: nil];
	
	if (_interruptedOnPlayback) {
		
		[_appSoundPlayer prepareToPlay];
		[_appSoundPlayer play];
        
		_interruptedOnPlayback = NO;
	}
//	isPlaying = NO;
//	[player release];
//	player = nil;
//	if(_appSoundPlayer != nil)
//	{
//		_appSoundPlayer = nil;
//	}
#endif
}

- (void) audioPlayerDidFinishPlaying: (AVAudioPlayer *) player successfully: (BOOL) flag 
{
    //add by hlf for 降低其他程序音量后恢复 2014.01.06
//    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0);
//    dispatch_async(queue, ^{
//        [[AVAudioSession sharedInstance] setActive:NO error:nil];
//        
//        dispatch_sync(dispatch_get_main_queue(), ^{
//            
//        });
//    });
    
    
	isPlaying = NO;
	[player release];
	player = nil;
	if(_appSoundPlayer != nil)
	{
		_appSoundPlayer = nil;
	}
    if([delegate respondsToSelector:@selector(playerDidFinishPlaying)])
    {
        [delegate playerDidFinishPlaying:flag];
    }
    
}
- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
    if (isPlaying)
	{
		isPlaying = NO;
		
	}
}
- (void)audioPlayerBeginInterruption:(AVAudioPlayer *)player {
	NSLog(@"audioPlayerBeginInterruption");
#ifdef __IPHONE_4_0
	if (isPlaying)
	{
		isPlaying = NO;
        _interruptedOnPlayback = YES;
		
	}
    
#endif
}

- (void) audioPlayerEndInterruption: (AVAudioPlayer *)player {
#ifdef __IPHONE_4_0
	NSLog(@"audioPlayerEndInterruption");
	////NSLog (@"Interruption ended. Resuming audio playback.");
	
	// Reactivates the audio session, whether or not audio was playing
	//		when the interruption arrived.
	[[AVAudioSession sharedInstance] setActive: YES error: nil];
	
	if (_interruptedOnPlayback) {
		
		[_appSoundPlayer prepareToPlay];
		[_appSoundPlayer play];
	
		_interruptedOnPlayback = NO;
	}
#endif
}
- (void)audioPlayerEndInterruption:(AVAudioPlayer *)player withOptions:(NSUInteger)flags
{
    NSLog(@"audioPlayerEndInterruption");
#ifdef __IPHONE_4_0
    [[AVAudioSession sharedInstance] setActive: YES error: nil];
	
	if (_interruptedOnPlayback) {
		
		[_appSoundPlayer prepareToPlay];
		[_appSoundPlayer play];
        
		_interruptedOnPlayback = NO;
	}
#endif
}
#pragma mark --
#pragma mark Notification
- (void)playAutoNavi
{
    backgroundSoundFlag = YES;
    BOOL isBackground = NO;
    GLANGUAGE eMapLanguage;
    GDBL_GetParam(G_LANGUAGE, &eMapLanguage);
    GDBL_GetParam(G_BACKGROUND_MODE, &isBackground);
    if (isPlaying) {
        [self performSelector:@selector(playAutoNavi) withObject:nil afterDelay:0.5];
    }
    else if (isBackground){
        if (![self isAllowedPlay])
        {
            return;
        }
        if (eMapLanguage == 1) {
            _transeforming = YES;
            [self strToVoice:@"[z1]Autonavi will continue for your navigation"];
            _transeforming = NO;
           // [self playByStr:@"[z1]Autonavi will continue for your navigation"];
        }
        else{
            _transeforming = YES;
            [self strToVoice:@"[z1]高德导航持续为[=wei4]您服务"];
            _transeforming = NO;
           // [self playByStr:@"[z1]高德导航将持续为您导航"];
        }
    }
    
}
- (void)TTSWillResignActiveNotification:(NSNotification *)notification
{
    
    
}
- (void)TTSDidEnterBackgroundNotification:(NSNotification *)notification
{
    if (isEngineInit != 1) {
        return;
    }
    
    BOOL isPath = NO;
    GDBL_GetParam(G_GUIDE_STATUS, &isPath);
    BOOL tmpValue;
    GDBL_GetParamExt(BACKGROUND_NAVI, &tmpValue);
    if ((isPath || isExistPath) && tmpValue && !_interruptedOnPlayback)
    {
        [self playAutoNavi];
    }

}
- (void)TTSDidBecomeActiveNotification:(NSNotification *)notification
{
    backgroundSoundFlag = NO;
    if (isPlaying && ([self.playString hasSuffix:@"高德导航持续为[=wei4]您服务"] || [self.playString hasSuffix:@"Autonavi will continue for your navigation"])) {
        [self stop];
    }
   // _interruptedOnPlayback = NO;
}
@end
