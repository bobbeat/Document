//
//  MWTTSService.h
//  middleware
//
//
//  Archite by mark
//  Created by  on 12-2-8.
//  Copyright (c) 2012年 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>

@protocol MWTTSServiceDelegate <NSObject>
@optional
-(void)transformWillBegin;//即将开始将文字转为音频
-(void)transformDidFinished;//将文字转为音频完成
-(void)transformDidFailed;//将文字转为音频发生错误
-(void)playerWillBeginPlaying;//即将开始播放已生成的音频
-(void)playerDidFinishPlaying:(BOOL)isSeccsess;//播放已生成的音频完成
-(void)playerDidStopPlaying;//播放已生成的音频
@end

@interface MWTTSService : NSObject <AVAudioPlayerDelegate>
{
    @private
    BOOL _interruptedOnPlayback;
    BOOL _stoping;
    BOOL _transeforming;
    BOOL backgroundSoundFlag;
    BOOL isExistPath;        //是否存在路径
    BOOL isOtherShouldDuck;         //是否降低其他程序声音
    BOOL isSystemMuted;           //系统静音
    
    NSTimer *updateTimer;
	AVAudioPlayer *_appSoundPlayer;
}
@property(nonatomic,assign)id <MWTTSServiceDelegate> delegate;
@property(nonatomic,copy)NSString * ttsResourcePath;//语音资源路径,如.../app/TTS_Resource
@property(nonatomic,readonly)BOOL isPlaying;//是否正在播放
@property(nonatomic,assign)int codingType;//文本编码格式:0 GBK,1 UTF8,默认为GBK
@property(nonatomic,assign)int languageIndex;//语言索引，0：中文简体，1：中文繁体，2：英文，默认为中文简体
@property(nonatomic,assign)int speakerIndex;//语音角色索引，默认为国语女声
@property(nonatomic,copy)NSString *playString;//语音播报内容
@property(nonatomic,assign)int voiceSpeed; //语速
@property(nonatomic,assign)int usePrompts; //是否使用录音方式
@property(nonatomic,copy) NSString *ttsFolderName; //语音资源文件名称
@property(nonatomic,assign) int beLZLDialect; //是否是志玲语音
//0，XiaoYan，国语女声
//1，XiaoFeng，国语男声
//2，XiaoLin，台湾普通话女声
//3，XiaoMei，粤语女声
//4，XiaoQian，东北话女声
//5，XiaoRong，四川话女声
//6，XiaoQiang，湖南话男声
//7，XiaoKun，河南话男声

//在第一次调用该类的时候使用sharedInstanceWithResourcePath，
//之后既可调用sharedInstanceWithResourcePath，也可调用sharedInstance
+(MWTTSService*)sharedInstanceWithResourcePath:(NSString*)path;
+(MWTTSService*)sharedInstance;
+(void)releaseInstance;
//转换一段文字为语音并播放
-(void)playByStr:(NSString *)str;
-(void)playByCStr:(const char*)str;
-(void)playWavByPath:(NSString *)path;
//停止
-(void)stop;
- (BOOL)status;
//设置当导航语音播报时是否降低其他程序的音量
- (void)setOtherMixableAudioShouldDuck:(BOOL)isDuck;
//设置是否存在路径
- (void)setIsPath:(BOOL)path;
//是否允许播报
- (BOOL)isAllowedPlay;

@end
