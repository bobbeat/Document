//
//  SpeechService.m
// 
//
//  Created by mark on 11-11-18.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "SpeechService.h"


@implementation SpeechService

@synthesize speechServiceDelegate;


@end
