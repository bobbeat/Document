//
//  iFlySpeechService.m
//  AutoNavi
//
//  Created by lin jingjie on 11-12-14.
//  Copyright 2011 autonavi. All rights reserved.
//

#import "iFlySpeechService.h"
#import "iflyMSC/IFlySetting.h"

#define H_CONTROL_ORIGIN CGPointMake([[UIScreen mainScreen] bounds].size.width/2, [[UIScreen mainScreen] bounds].size.height/2)
#define APPID @"4e9175b8" // appid for 开心网 iphone，请勿修改！

@implementation iFlySpeechService
@synthesize voiceRecognizeController;
-(id)initWithView:(UIView *) view Lon:(int)lon Lat:(int)lat AdminCode:(int)adminCode
{
	self = [super init];

    //[IFlySetting setLogFile:LVL_NONE];
    [IFlySetting showLogcat:NO];
    
	NSString *initParam = [[NSString alloc] initWithFormat:
						   @"server_url=http://autonavi.voicecloud.cn:1028/index.htm,search_best_url=false,appid=%@",APPID];

	// 识别控件
	self.voiceRecognizeController = [[IFlyRecognizerView alloc] initWithOrigin:H_CONTROL_ORIGIN atCenter:YES initParam:initParam relative:NO];
	[self.voiceRecognizeController release];
	self.voiceRecognizeController.delegate = self;
    // 参数设置
    [self setPosition:lon Lat:lat AdminCode:adminCode];
    [self.voiceRecognizeController setParameter:@"domain" value:@"autonavi"];
    [self.voiceRecognizeController setParameter:@"sample_rate" value:@"16000"];
    [self.voiceRecognizeController setParameter:@"vad_eos" value:@"1800"];
    [self.voiceRecognizeController setParameter:@"vad_bos" value:@"1500"];
    
    [self.voiceRecognizeController setParameter:@"asr_ptt" value:@"0"];
    [self.voiceRecognizeController setParameter:@"plain_result" value:@"1"];
	[initParam release];
    
    UIInterfaceOrientation ori = [[UIApplication sharedApplication] statusBarOrientation];
    [self.voiceRecognizeController rotationToInterfaceOrientation:ori];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeDeviceOrientation:) name:UIApplicationWillChangeStatusBarOrientationNotification object:NULL];
	return self;
}

- (void) updateResult:(NSString *)resultText{
    
    [speechServiceDelegate speechResultText:resultText];
}

- (void) errorHappend:(NSNumber *)errorCode
{
	[speechServiceDelegate errorOccur:[errorCode intValue]];
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [voiceRecognizeController removeFromSuperview];
    voiceRecognizeController = nil;
	[super dealloc];
}
#pragma mark IFlyRecognizeControl Callback

- (void)onResult:(IFlyRecognizerView *)iFlyRecognizerView theResult:(NSArray *)resultArray
{
	NSDictionary *dic = (NSDictionary*)[resultArray objectAtIndex:0];
	[self performSelectorOnMainThread:@selector(updateResult:) 
						   withObject:[[dic allKeys] lastObject]
						waitUntilDone:YES];
}

- (void)onEnd:(IFlyRecognizerView *)iFlyRecognizerView theError:(IFlySpeechError *)error
{
	[self performSelectorOnMainThread:@selector(errorHappend:) 
						   withObject:[NSNumber numberWithInt:error.errorCode]
						waitUntilDone:YES];
}
#pragma mark SpeechService Method
-(void)setResultType:(int)resultType
{
	mResultType = resultType;
}

-(void)setPosition:(int)gaoLon Lat:(int)gaoLat AdminCode:(int)adminCode
{
    [self.voiceRecognizeController setParameter:@"params" value:[NSString  stringWithFormat:@"area=%.6f;%.6f;%d",gaoLon/1000000.0,gaoLat/1000000.0,adminCode]];
}

-(void)start
{
	if([voiceRecognizeController start])
	{
		//[self disableButton];
	}
}

#pragma mark - UIDeviceOrientationDidChangeNotification
- (void)changeDeviceOrientation:(NSNotification *)notification {
    
    
    
    UIDeviceOrientation interfaceOrientation = [[UIDevice currentDevice] orientation];
    NSLog(@"%d",interfaceOrientation);
//    UIInterfaceOrientation interfaceOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    [self.voiceRecognizeController rotationToInterfaceOrientation:interfaceOrientation];

}

@end
