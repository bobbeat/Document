//
//  main.m
//  TableViewMultiSelect
//
//  Created by HJC on 10-12-17.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"MultiSelectAppDelegate");
    [pool release];
    return retVal;
}
