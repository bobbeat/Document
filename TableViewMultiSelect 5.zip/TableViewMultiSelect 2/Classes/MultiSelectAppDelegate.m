//
//  TableViewMultiSelectAppDelegate.m
//  TableViewMultiSelect
//
//  Created by HJC on 10-12-17.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MultiSelectAppDelegate.h"
#import "FileTableViewController.h"

@implementation MultiSelectAppDelegate

//- (UIBarButtonItem*) createButtonItemWithTitle:(NSString*)title action:(SEL)action
//{
//	UIBarButtonItem* buttonItem = [[UIBarButtonItem alloc] initWithTitle:title
//																   style:UIBarButtonItemStyleBordered
//																  target:self
//																  action:action];
//	return [buttonItem autorelease];
//}
//
//
//- (void) editButtonItemPressed:(UIBarButtonItem*)buttonItem
//{
//	UIBarButtonItem* doneItem = [self createButtonItemWithTitle:NSLocalizedString(@"Done", @"")
//														 action:@selector(doneButtonItemPressed:)];
//	doneItem.style = UIBarButtonItemStyleDone;
//	m_navigationController.navigationBar.topItem.rightBarButtonItem = doneItem;
//	[m_fileTableViewController setEditing:YES animated:YES];
//}
//
//
//- (void) doneButtonItemPressed:(UIBarButtonItem*)buttonItem
//{
//	UIBarButtonItem* editItem = [self createButtonItemWithTitle:NSLocalizedString(@"Edit", @"")
//														 action:@selector(editButtonItemPressed:)];
//	m_navigationController.navigationBar.topItem.rightBarButtonItem = editItem;
//	[m_fileTableViewController setEditing:NO animated:YES];
//}
//




#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{    
	m_window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
	
	m_fileTableViewController = [[FileTableViewController alloc] initWithStyle:UITableViewStylePlain];
	m_navigationController = [[UINavigationController alloc] initWithRootViewController:m_fileTableViewController];
	
	//UIBarButtonItem* editItem = [self createButtonItemWithTitle:NSLocalizedString(@"Edit", @"")
//														 action:@selector(editButtonItemPressed:)];
//	m_navigationController.navigationBar.topItem.rightBarButtonItem = editItem;
    
    // Override point for customization after app launch. 
	[m_window addSubview:m_navigationController.view];
    [m_window makeKeyAndVisible];

	return YES;
}



- (void)dealloc {
    [m_window release];
    [super dealloc];
}


@end
