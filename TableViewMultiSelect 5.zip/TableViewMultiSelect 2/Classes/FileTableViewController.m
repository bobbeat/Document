//
//  FileTableViewController.m
//  SiteVistor
//
//  Created by HJC on 10-11-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "FileTableViewController.h"
#import "FileItemTableCell.h"


@implementation FileItem
@synthesize name = m_name;
//@synthesize type = m_type;
@synthesize checked = m_checked;
@synthesize url =  m_url;
@synthesize adminCode = m_adminCode;
@synthesize totalSize = m_totalSize;


+ (FileItem*) fileItem
{
	return [[[self alloc] init] autorelease];
}

- (void) dealloc
{
	[m_url release];
	[m_name release];
	[super dealloc];
}


- (NSComparisonResult)compare:(FileItem*)aItem
{
	if (self.totalSize != aItem.totalSize)
	{
		if (self.totalSize < aItem.totalSize)
		{
			return NSOrderedAscending; 
		}
		else 
		{
			return NSOrderedDescending; 
		}
	}
	return [self.name caseInsensitiveCompare:aItem.name];
}


//- (UIImage*) fileTypeImage
//{
//	switch (self.type) 
//	{
//		case FileItemType_Directory:
//			return [UIImage imageNamed:@"iconFolder.png"];
//			
//		case FileItemType_ZipFile:
//			return [UIImage imageNamed:@"iconZIP.png"];
//			
//		case FileItemType_WebPageFile:
//			return [UIImage imageNamed:@"iconWeb.png"];
//			
//		case FileItemType_UnknownFile:
//			return [UIImage imageNamed:@"iconUnknown.png"];
//	}
//	return nil;
//}

@end



@implementation FileTableViewController

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
	return YES;
}


- (void) _listTestFileItems
{
	[m_fileItems removeAllObjects];
	//DataList *dataList = [[DataList alloc] init];
//	[m_fileItems addObjectsFromArray:[dataList getList]];
//	[dataList release];
	
	//srand(time(0));
//	
//	for (NSInteger idx = 0; idx < 50; idx++)
//	{
//		FileItem* fileItem = [FileItem fileItem];
//		fileItem.name = [NSString stringWithFormat:@"Name %2d", idx];
//		fileItem.type = (FileItemType)(rand() % FiltItemType_Max);
//		[m_fileItems addObject:fileItem];
//	}
	
	NSMutableArray  *items = [NSArray arrayWithObjects:[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"福建省", @"142",@"1",@"142",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]], 
					                           [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"广东省", @"75", @"2",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]], 
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"江西省", @"75", @"3",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
											   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"云南省", @"75", @"4",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"湖北省", @"75", @"5",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"湖南省", @"75", @"6",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"新疆省", @"75", @"7",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"陕西省", @"75", @"8",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"山东省", @"75", @"9",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"四川省", @"75", @"10",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"河南省", @"75", @"11",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"河北省", @"75", @"12",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
											   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"海南省", @"75", @"13",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
							                   [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"内蒙古", @"75", @"14",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],
	                                           [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:@"浙江省", @"88", @"15",@"2",nil] forKeys: [NSArray arrayWithObjects: @"name",@"url", @"totalSize",@"adminCode",nil]],nil ];
	//[m_fileItems addObjectsFromArray:items];
	      //for (NSInteger idx = 0; idx < [items count]; idx++)
//			{
//				FileItem* fileItem = [FileItem fileItem];
//				fileItem.name = [items objectForKey:@"name" ];
//				//fileItem.type = (FileItemType)(rand() % FiltItemType_Max);
//				[m_fileItems addObject:fileItem];
//			}
	            for (NSArray *item in items)
				{
					NSLog(@"fil=%@",item);
					FileItem* fileItem = [FileItem fileItem];
					fileItem.name = [item objectForKey:@"name"];
					fileItem.url = [item objectForKey:@"url"];
					fileItem.totalSize = [item objectForKey:@"totalSize"];
					fileItem.adminCode = [item objectForKey:@"adminCode"];
					[m_fileItems addObject:fileItem];
				}	
	NSLog(@"fil=%@",m_fileItems);
	[m_fileItems sortUsingSelector:@selector(compare:)];
}
#pragma mark -
#pragma mark UIAction

- (UIBarButtonItem*) createButtonItemWithTitle:(NSString*)title action:(SEL)action
{
	UIBarButtonItem* buttonItem = [[UIBarButtonItem alloc] initWithTitle:title
																   style:UIBarButtonItemStyleBordered
																  target:self
																  action:action];
	return [buttonItem autorelease];
}
- (void) editButtonItemPressed:(UIBarButtonItem*)buttonItem
{
	UIBarButtonItem* doneItem = [self createButtonItemWithTitle:NSLocalizedString(@"下载", @"")
														 action:@selector(doneButtonItemPressed:)];
	doneItem.style = UIBarButtonItemStyleDone;
	self.navigationItem.rightBarButtonItem = doneItem;
	[self setEditing:YES animated:YES];
}


- (void) doneButtonItemPressed:(UIBarButtonItem*)buttonItem
{
	UIBarButtonItem* editItem = [self createButtonItemWithTitle:NSLocalizedString(@"选择城市", @"")
														 action:@selector(editButtonItemPressed:)];
	self.navigationItem.rightBarButtonItem = editItem;
	[self setEditing:NO animated:YES];
}

#pragma mark -
#pragma mark Initialization
- (id) initWithStyle:(UITableViewStyle)style
{
	if ([super initWithStyle:style])
	{
		UIBarButtonItem* editItem = [self createButtonItemWithTitle:NSLocalizedString(@"选择城市", @"")
															 action:@selector(editButtonItemPressed:)];
		self.navigationItem.rightBarButtonItem = editItem;
		
		m_fileItems = [[NSMutableArray alloc] initWithCapacity:4];
		[self _listTestFileItems];
		
		self.tableView.rowHeight = 50;
		self.tableView.allowsSelectionDuringEditing = YES;
	}
	return self;
}


- (void)dealloc 
{
	[m_fileItems release];
    [super dealloc];
}


- (void) setEditing:(BOOL)editting animated:(BOOL)animated
{
	if (!editting)
	{
		for (FileItem* item in m_fileItems)
		{
			item.checked = NO;
		}
	}
	[super setEditing:editting animated:animated];
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
	NSString *secstring = @"省份查找";
	return secstring;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return [m_fileItems count];
}


- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleNone;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    FileItemTableCell *cell = (FileItemTableCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[FileItemTableCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
		cell.textLabel.font = [cell.textLabel.font fontWithSize:17];
    }
	
	cell.accessoryType = UITableViewCellAccessoryNone;
	cell.textLabel.textColor = [UIColor blackColor];
	
	FileItem* fileItem = [m_fileItems objectAtIndex:indexPath.row];
	NSLog(@"name=%@",fileItem.name);
	NSLog(@"name=%@",fileItem.name);
	cell.textLabel.text = fileItem.name;
	//cell.imageView.image = [fileItem fileTypeImage];
	
	[cell setChecked:fileItem.checked];
	
	//if (fileItem.type == FileItemType_Directory)
//	{
//		cell.textLabel.textColor = [UIColor colorWithRed:0.22 green:0.33 blue:0.53 alpha:1.0];
//		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//	}
	
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	FileItem* fileItem = [m_fileItems objectAtIndex:indexPath.row];
	
	if (self.editing)
	{
		FileItemTableCell *cell = (FileItemTableCell*)[tableView cellForRowAtIndexPath:indexPath];
		fileItem.checked = !fileItem.checked;
		[cell setChecked:fileItem.checked];
	}
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}




@end

