//
//  TableViewMultiSelectAppDelegate.h
//  TableViewMultiSelect
//
//  Created by HJC on 10-12-17.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FileTableViewController;
@interface MultiSelectAppDelegate : NSObject <UIApplicationDelegate> 
{
    UIWindow*					m_window;
    UINavigationController*		m_navigationController;
	FileTableViewController*	m_fileTableViewController;
}

@end

