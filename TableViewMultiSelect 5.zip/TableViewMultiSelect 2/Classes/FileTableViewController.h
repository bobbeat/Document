//
//  FileTableViewController.h
//  SiteVistor
//
//  Created by HJC on 10-11-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "plugin-cdm-RemoteDataList.h"

typedef enum
{
	FileItemType_Directory,			// 文件夹
	FileItemType_ZipFile,			// zip压缩文件
	FileItemType_WebPageFile,		// 网页文件
	FileItemType_UnknownFile,		// 未知类型文件
	FiltItemType_Max,			
} FileItemType;


@interface FileItem : NSObject
{
@private
	NSString*		m_name;
	NSString*       m_url;
    int             m_totalSize;
    int             m_adminCode;
	//FileItemType	m_type;
	BOOL			m_checked;
	
    
}

@property (nonatomic, copy)		NSString*		name;
@property (nonatomic, copy)		NSString*		url;
//@property (nonatomic, assign)	FileItemType	type;
@property (nonatomic, assign)	int			    totalSize;
@property (nonatomic, assign)	int			    adminCode;
@property (nonatomic, assign)	BOOL			checked;


+ (FileItem*) fileItem;
- (UIImage*) fileTypeImage;
@end



@interface FileTableViewController : UITableViewController 
{
	
@private
	NSMutableArray*						m_fileItems;
}

@end
