//
//  DownloadTask.h
//  plugin-CityDataManager
//
//  Created by mark on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "plugin-cdm-Task.h"

@interface DownloadTask : Task
{
@private
    NSString* url;
}

@property (nonatomic,copy)NSString* url;


@end
