//
//  TaskManager.m
//  plugin-CityDataManager
//
//  Created by mark on 11-11-3.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "plugin-cdm-TaskManager.h"
#import "plugin-cdm-Task.h"


static TaskManager* instance;

@implementation TaskManager

@synthesize delegate,taskList;

+(TaskManager*)taskManager
{
    if(instance==nil)
    {
        instance = [[TaskManager alloc]init];
    }
    return instance;
}

+(void)releaseInstance
{
    if(instance!=nil)
    {
        [instance release];
        instance = nil;
    }
}

-(void)dealloc
{
    [taskList release];
    //[mTaskStatusList release];
    [super dealloc];
}

-(id)init
{
    self = [super init];
    if(self!=nil)
    {
        //mTaskStatusList = [[NSMutableArray alloc]init];
        taskList = [[NSMutableArray alloc]init];
    }
    return self;
}


// 返回任务队列中的任务id列表
//-(NSArray*)getTaskId
//{
//    NSMutableArray* idlist = nil;
//    int count = [mTaskList count];
//    if (count>0) {
//        idlist = [[NSMutableArray alloc]init];
//        for(int i=0;i<count;i++)
//        {
//            [idlist addObject:[NSNumber numberWithInt:[[mTaskList objectAtIndex:i] taskId]]];
//        }
//    }
//    return [idlist autorelease];
//}

// 返回-1表示加入失败，>=0表示成功加入后在TaskManager中的索引
-(int)addTask:(Task*) task atFirst:(BOOL) first
{
    if(NO==[self _taskExisted:task])
    {
        task.delegate = self;
        task.status = TASK_STATUS_READY;
        //NSNumber* s = [NSNumber numberWithInt:TASK_STATUS_READY];
        if(first)
        {
            [taskList insertObject:task atIndex:0];
            //[mTaskStatusList insertObject:s atIndex:0];
            return 0;
        }
        else
        {
            [taskList addObject:task];
            //[mTaskStatusList addObject:s];
            return [taskList count]-1; 
        }
    }
    else
    {
        return -1;
    }
}

// 移除索引为index处的任务，该操作会删除该任务。
// 如果恰好该任务处于运行状态，removeTask后，整个TaskManager中将无任务在执行
-(BOOL)removeTask:(int) index
{
    int count = [taskList count];
    if(index>=0 && index < count)
    {
        Task* t = [taskList objectAtIndex:index];
        [t erase];
        [taskList removeObjectAtIndex:index];
        //[mTaskStatusList removeObjectAtIndex:index];
        return  YES;
    }
    return NO;
}

// 移除所有状态为status的任务，返回移除的个数
-(int)removeTasksForStatus:(int) status
{
    int count = 0;
    while (1) {
        int index = [self _firstIndexWithStatus:status];
        if(index>=0)
        {
            [self removeTask:index];
            ++count;
        }
        else
        {
            break;
        }
    }
    return count;
}

// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按某种策略选择一个任务来执行
// 2、有任务在执行：直接返回
-(BOOL)start
{
    if([self isRunning])
    {
        return NO;
    }
    else
    {
        int index = [self _selectOneTaskToRun];
        if(index<0)
        {
            return NO;
        }
        else
        {
            return [self start:index];
        }
    }
}

// 停止TaskManager中正在执行的任务，整个TaskManager处于停止状态
-(BOOL)stop
{
    int index = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (index>=0) {
        return [self stop:index];
    }
    return NO;
}

// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按index来选择任务
// 2、有任务在执行：
//      分两种情况：
//      1、正在执行的任务就是index，那么直接返回；
//      2、正在执行的任务不是index，那么让正在执行的任务变为等待，转而执行index指定的任务
-(BOOL)start:(int)index
{
    int indexRunning = [self _firstIndexWithStatus:TASK_STATUS_RUNNING];
    if (indexRunning == index) {
        return NO;
    }
    else 
    {
        // 先停止正在执行的任务
        if (indexRunning >= 0)
        {
            //[(Task*)[mTaskList objectAtIndex:indexRunning] stop];
            //[mTaskStatusList replaceObjectAtIndex:indexRunning withObject:[NSNumber numberWithInt:TASK_STATUS_READY]];
            Task* t = [taskList objectAtIndex:indexRunning];
            t.status = TASK_STATUS_READY;
            [t stop];
        }
        
        //[(Task*)[mTaskList objectAtIndex:index] run];
        //[mTaskStatusList replaceObjectAtIndex:index withObject:[NSNumber numberWithInt:TASK_STATUS_RUNNING]];
        Task* t = [taskList objectAtIndex:index];
        t.status = TASK_STATUS_RUNNING;
        [t run];
        
        return YES;
    }
}

// 停止TaskManager中index对应的任务：注意：只有状态为TASK_STATUS_RUNNING的任务才能被stop
// 1、index对应的任务处于等待状态，那么直接返回
// 2、index对应的任务处于执行状态，那么让正在执行的任务变为等待
-(BOOL)stop:(int)index
{
    int count = [taskList count];
    if(index>=0 && index<count)
    {
        // 只有状态为TASK_STATUS_RUNNING的任务才能被stop
        //if([(NSNumber*)[mTaskStatusList objectAtIndex:index] intValue]==TASK_STATUS_RUNNING)
        Task* t = [taskList objectAtIndex:index];
        if(t.status==TASK_STATUS_RUNNING)
        {
            //[(Task*)[mTaskList objectAtIndex:index] stop];
            //[mTaskStatusList replaceObjectAtIndex:index withObject:[NSNumber numberWithInt:TASK_STATUS_READY]];
            t.status = TASK_STATUS_READY;
            [t stop];
            return YES;
        }
    }
    return NO;
}

// 返回YES表示TaskManager中有任务正在运行
-(BOOL)isRunning
{
    return [self _firstIndexWithStatus:TASK_STATUS_RUNNING]<0?NO:YES;
}

// 把TaskManager中的所有任务信息保存到文件系统，一般是在退出程序时调用
-(BOOL)store
{
    /*
     1、序列化整个mTaskList
     */
    return NO;
}

// 从文件系统还原通过save保存的所有任务信息，一般是在进入程序时调用，该方法调用将把TaskManager中的所有任务更新为最后一次调用save保存的任务
-(BOOL)restore
{
    /*
     1、反序列化各个Task对象，构建处mTaskList
     2、遍历mTaskList，把task.delegate = self;
     */
    return NO;
}


//-(BOOL)moveUp:(int)index;
//-(BOOL)moveDown:(int)index;















#pragma mark - 私有方法

// 从头开始向尾扫描mTaskList列表，直到遇到一个状态为TASK_STATUS_READY的任务对象
// 返回指<0则表示没找到可被执行的任务，否则表示所选任务的索引
-(int)_selectOneTaskToRun
{
    return [self _firstIndexWithStatus:TASK_STATUS_READY];
}


// 返回队列中，状态为status的第一个任务的索引
// 返回指<0则表示没找到可被执行的任务，否则表示任务的索引
-(int)_firstIndexWithStatus:(int)status
{
    int count = [taskList count];
    for (int i=0;i<count;i++) {
        //if([((NSNumber*)[mTaskStatusList objectAtIndex:i]) intValue] == status)
        if(((Task*)[taskList objectAtIndex:i]).status == status)
        {
            return i;
        }
    }
    return -1;
}

// 根据taskId来判断task是否已经存在队列中
-(BOOL)_taskExisted:(Task*)task
{
    for (Task* t in taskList) {
        // 用任务id来比较
        if(t.taskId == task.taskId)
        {
            return YES;
        }
    }
    return NO;
}















#pragma mark - TaskStatusDelegate委托回调

-(void)progress:(Task*)sender current:(int)current total:(int)total
{
    //[delegate progress:sender current:current total:total];
}

-(void)finished:(Task*)sender
{
    
}

-(void)exception:(Task*)sender exception:(id)exception
{
    
}



@end
