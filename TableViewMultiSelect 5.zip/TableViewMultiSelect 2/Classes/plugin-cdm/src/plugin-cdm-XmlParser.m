//
//  plugin-cdm-XmlParser.m
//  plugin-CityDataManager
//
//  Created by GHY on 11-11-14.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import "plugin-cdm-XmlParser.h"
#import "plugin-cdm-DataList.h"


@implementation XmlParser

@synthesize provinceArray;
@synthesize cityArray;

@synthesize baseurl;
@synthesize iname;
@synthesize currentProperty;

@synthesize item;
@synthesize city;
@synthesize province;
@synthesize optional;

@synthesize found;
@synthesize required;

@synthesize infoD;
@synthesize opg;


- (id)initWitharray:(NSMutableArray *)parray
{
	if (self = [super init]) 
	{
		self.provinceArray = parray;
	}
	
	return self;
}


- (BOOL)parserStart:(NSData *)data
{
	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
    [parser parse]; 
	if ([parser parserError]) 
	{
		UIAlertView *ParseFailedAlert = [[UIAlertView alloc] initWithTitle:@"Xml解析失败" 
																   message:@"xml数据错误" 
																  delegate:self 
														 cancelButtonTitle:@"确定" 
														 otherButtonTitles:nil];
		[ParseFailedAlert show];
		[ParseFailedAlert release];
		return NO;
	}
	
    [parser release];
	return YES;
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict 
{
    if (qName) 
	{
        elementName = qName;
	}
	
	if (self.city)
	{
        if ([elementName isEqualToString:@"adcode"] || [elementName isEqualToString:@"size"] || [elementName isEqualToString:@"unzip_size"] || [elementName isEqualToString:@"suburl"]) 
		{
            self.currentProperty = [NSMutableString string];
        }
    }
	else if (self.province)
	{
		if ([elementName isEqualToString:@"adcode"] || [elementName isEqualToString:@"suburl"] || [elementName isEqualToString:@"size"] || [elementName isEqualToString:@"unzip_size"]) 
		{
            self.currentProperty = [NSMutableString string];
        }
		else if ([elementName isEqualToString:@"city"]) 
		{
			self.iname = [attributeDict valueForKey:@"name"];
			self.city = [[City alloc] init];
			
			if (self.item) 
			{
				[self.item release];
			}
			self.item = [[Item alloc] init];
        }
	}
	else if (self.optional) 
	{
        if ([elementName isEqualToString:@"item"]) 
		{
			self.iname = [attributeDict valueForKey:@"name"];
			self.province = [[Province alloc] init];
			
			self.cityArray = [NSMutableArray array];
			if (self.item) 
			{
				[self.item release];
			}
			self.item = [[Item alloc] init];
        }
    } 
    else if (self.found)
	{
        if ([elementName isEqualToString:@"suburl"] || [elementName isEqualToString:@"size"] || [elementName isEqualToString:@"unzip_size"]) 
		{
            self.currentProperty = [NSMutableString string];
        }
    }  
	else if (self.required) 
	{
        if ([elementName isEqualToString:@"item"]) 
		{
			self.iname = [attributeDict valueForKey:@"name"];
			self.found = [[Found alloc] init];
			
			self.cityArray = [NSMutableArray array];
			if (self.item) 
			{
				[self.item release];
			}
			self.item = [[Item alloc] init];
        }
    } 
	else if (self.infoD) 
	{
        if ([elementName isEqualToString:@"version_data"] || [elementName isEqualToString:@"baseurl"]) 
		{
            self.currentProperty = [NSMutableString string];
        } 
		else if ([elementName isEqualToString:@"required"]) 
		{
            self.required = [[Required alloc] init]; // Create the element
        }
		else if ([elementName isEqualToString:@"optional"])
		{
            self.optional = [[Optional alloc] init]; // Create the element
        }
    } 
	else if (self.opg) 
	{
        if ([elementName isEqualToString:@"activitycode"] || [elementName isEqualToString:@"processtime"] || [elementName isEqualToString:@"actioncode"] || [elementName isEqualToString:@"rspcode"]) 
		{
            self.currentProperty = [NSMutableString string];
        } 
		else if ([elementName isEqualToString:@"info"]) 
		{
            self.infoD = [[Info alloc] init]; 
        }
    } 
	else 
	{
        if ([elementName isEqualToString:@"opg"]) 
		{
            self.opg = [[Opg alloc] init];// Create the element
        }
    }
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if (self.currentProperty) 
	{
        [currentProperty appendString:string];
    }
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName 
{
    if (qName) 
	{
        elementName = qName;
    }
	
	if (self.city) 
	{
		if ([elementName isEqualToString:@"adcode"]) 
		{
			self.city.cadcode = self.currentProperty;
			self.item.adminCode = [self.currentProperty intValue];
        }
        else if ([elementName isEqualToString:@"suburl"]) 
		{
            self.city.csuburl = [self.baseurl stringByAppendingString:self.currentProperty];
			self.item.url = [self.baseurl stringByAppendingString:self.currentProperty];
        } 
		else if ([elementName isEqualToString:@"size"]) 
		{
            self.city.csize = self.currentProperty;
			self.item.totalSize = [self.currentProperty intValue];
        }
		else if ([elementName isEqualToString:@"unzip_size"]) 
		{
            self.city.cunzip_size = self.currentProperty;
        }
		else if ([elementName isEqualToString:@"city"]) 
		{
			self.city.cname = self.iname;
			//[self.citydata addObject:self.city];
			
			self.item.name = self.iname;
			[self.cityArray addObject:self.item];
			
			[city release];
			self.city = nil;
        }
    }
	else if (self.province) 
	{
		if ([elementName isEqualToString:@"adcode"]) 
		{
			self.province.padcode = self.currentProperty;
			self.item.adminCode = [self.currentProperty intValue];
        }
        else if ([elementName isEqualToString:@"suburl"]) 
		{
            self.province.psuburl = [self.baseurl stringByAppendingString:self.currentProperty];
			self.item.url = [self.baseurl stringByAppendingString:self.currentProperty];
        } 
		else if ([elementName isEqualToString:@"size"]) 
		{
            self.province.psize = self.currentProperty;
			self.item.totalSize = [self.currentProperty intValue];
        }
		else if ([elementName isEqualToString:@"unzip_size"]) 
		{
            self.province.punzip_size = self.currentProperty;
        }
		else if ([elementName isEqualToString:@"item"]) 
		{
			self.province.pname = self.iname;
			//self.province.pcity = [citydata copy];
			//[optiondata addObject:self.province];
			
			self.item.name = self.iname;
			[self.provinceArray addObject:self.cityArray];
			[self.cityArray addObject:self.item];
			
			[province release];
			self.province = nil;
			
			//[self.citydata removeAllObjects];
        }
    }
	else if (self.optional) 
	{
        if ([elementName isEqualToString:@"optional"]) 
		{
			[optional release];
			self.optional = nil;
        }
    }
	else if (self.found) 
	{
		if ([elementName isEqualToString:@"suburl"]) 
		{
            self.found.fsuburl = [self.baseurl stringByAppendingString:self.currentProperty];
			self.item.url = [self.baseurl stringByAppendingString:self.currentProperty];
        }
		else if ([elementName isEqualToString:@"size"]) 
		{
            self.found.fsize = self.currentProperty;
			self.item.totalSize = [self.currentProperty intValue];
        }
		else if ([elementName isEqualToString:@"unzip_size"]) 
		{
            self.found.funzip_size = self.currentProperty;
        }
        else if ([elementName isEqualToString:@"item"]) 
		{
			self.found.fname = self.iname;
			
			self.item.name = self.iname;
			[self.provinceArray addObject:self.cityArray];
			[self.cityArray addObject:self.item];
			
            [found release];
			self.found = nil;
        }
    }
	else if (self.required) 
	{
        if ([elementName isEqualToString:@"required"]) 
		{
			[required release];
			self.required = nil;
        }
    }
	else if (self.infoD) 
	{
        if ([elementName isEqualToString:@"version_data"]) 
		{
            self.infoD.version_data = self.currentProperty;
        } 
		else if ([elementName isEqualToString:@"baseurl"]) 
		{
            self.infoD.baseurl = self.currentProperty;
			self.baseurl = self.currentProperty;
        }
		else if ([elementName isEqualToString:@"info"]) 
		{
			//[self.founddata addObject:self.infoD];
			[infoD release];
			self.infoD = nil;
        }
    }
	else if (self.opg) 
	{
        if ([elementName isEqualToString:@"activitycode"]) 
		{
            self.opg.activitycode = self.currentProperty;
        } 
		else if ([elementName isEqualToString:@"processtime"]) 
		{
            self.opg.processtime = self.currentProperty;
        } 
		else if ([elementName isEqualToString:@"actioncode"]) 
		{
            self.opg.actioncode = self.currentProperty;
        }
		else if ([elementName isEqualToString:@"rspcode"]) 
		{
			self.opg.actioncode = self.currentProperty;
        }
		else if ([elementName isEqualToString:@"opg"]) 
		{
			//[self.founddata addObject:self.opg];
			[opg release];
			self.opg = nil;
        }
    }
	
	self.currentProperty = nil;
}


- (void)dealloc
{	
	[super dealloc];
}

@end
