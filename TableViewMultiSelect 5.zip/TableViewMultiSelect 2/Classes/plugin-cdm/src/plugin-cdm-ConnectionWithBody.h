//
//  plugin-cdm-ConnectionWithBody.h
//  plugin-CityDataManager
//
//  Created by GHY on 11-11-14.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ConnectionWithBodyDelegate
- (void)returnResult:(NSData *)result;
@end


@interface ConnectionWithBody : NSObject 
{
	id<ConnectionWithBodyDelegate> delegate;
	
	NSMutableData *resultData;//返回数据
}

@property (nonatomic, assign) id<ConnectionWithBodyDelegate> delegate;

- (id)initWithUrl:(NSString *)turl requstbody:(NSData *)body;

@end
