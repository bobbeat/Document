//
//  RemoteDataList.m
//  plugin-CityDataManager
//
//  Created by  on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "plugin-cdm-RemoteDataList.h"
#import "plugin-cdm-ConnectionWithBody.h"
#import "plugin-cdm-XmlParser.h"

static RemoteDataList* instance;

@implementation RemoteDataList

+(DataList*)remoteDataList
{
    if(instance==nil)
    {
        instance = [[RemoteDataList alloc]init];
    }
    return instance;
}

+(void)releaseInstance
{
    if(instance!=nil)
    {
        [instance release];
        instance = nil;
    }
}

-(BOOL)parse
{
    /*
     1、启动一个线程，从服务器获取数据清单
     2、解析到list成员中，注意list的数据结构
     3、成功返回YES，失败返回NO
     */
	flag = YES;
	[NSThread detachNewThreadSelector:@selector(xmlParser) toTarget:self withObject:nil];    
	
    return flag;
}

- (void)xmlParser
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	NSString *url = @"http://besideyou.mapabc.com:8080/naviservices/datadown";
	
	NSString *temp = @"<?xml version=\"1.0\" encoding=\"GBK\" ?><opg><activitycode>0001</activitycode><processtime>20111011095252</processtime><actioncode>0</actioncode><svccont><info>";
	temp = [temp stringByAppendingString:@"<udid>30303030303030303030303030303030</udid><syscode>3043</syscode><engine_version>5.0.1012.1083</engine_version><app_version>5.1.1603.0001.0004</app_version>"];
	temp = [temp stringByAppendingString:@"<map_version>14.1.1010.0007</map_version><cellid></cellid><wifi></wifi><cx></cx><cy></cy></info></svccont></opg>"];
	
	NSData *requstBody = [temp dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
	connection = [[ConnectionWithBody alloc] initWithUrl:url requstbody:requstBody];
	
	[pool release];
}


- (void)returnResult:(NSData *)result
{
	//解析服务器返回的xml内容
	if (result) 
	{
		NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
		
		NSString *string = [[NSString alloc] initWithData:result encoding:enc];
		NSString *stringt = @"opg";
		
		NSRange range = [string rangeOfString:stringt];
		if (range.length==0) 
		{
			//返回内容出错，提示又产品定义，退出
			flag = NO;
		}
		
		NSString *strdata = [string substringFromIndex:range.location-1];//去除前面的无关信息
		[string release];
		
		NSData *data = [strdata dataUsingEncoding:NSUTF8StringEncoding];
		
		XmlParser *xmlParser = [[XmlParser alloc] initWitharray:list];
		BOOL xmlresult = [xmlParser parserStart:data];
		if (xmlresult) 
		{
			
		}
		else 
		{
			//解析失败处理
			flag = NO;
		}
		
		[xmlParser release];
		[connection release];
	}
}


@end
