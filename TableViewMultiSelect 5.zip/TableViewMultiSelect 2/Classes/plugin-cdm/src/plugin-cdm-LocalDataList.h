//
//  LocalDataList.h
//  plugin-CityDataManager
//
//  Created by  on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-DataList.h"

@interface LocalDataList : DataList
{
    
}

+(DataList*)localDataList;
+(void)releaseInstance;

@end
