//
//  plugin-cdm-Node.m
//  plugin-CityDataManager
//
//  Created by GHY on 11-11-14.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import "plugin-cdm-Node.h"


@implementation City

@synthesize cname;
@synthesize cadcode;
@synthesize csuburl;
@synthesize csize;
@synthesize cunzip_size;

@end


@implementation Province

@synthesize pname;
@synthesize padcode;
@synthesize psuburl;
@synthesize psize;
@synthesize punzip_size;

@synthesize pcity;

@end


@implementation Found

@synthesize fname;
@synthesize fsuburl;
@synthesize fsize;
@synthesize funzip_size;

@end


@implementation Optional

@end


@implementation Required

@end


@implementation Info

@synthesize version_data;
@synthesize baseurl;

@end


@implementation Opg

@synthesize activitycode;
@synthesize processtime;
@synthesize actioncode;
@synthesize rspcode;

@end
