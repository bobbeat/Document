//
//  RemoteDataList.h
//  plugin-CityDataManager
//
//  Created by  on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-DataList.h"
#import "plugin-cdm-ConnectionWithBody.h"

/*
 1、从服务器获取数据下载清单
 2、解析清单到成员变量
 */
@interface RemoteDataList : DataList <ConnectionWithBodyDelegate>
{
    ConnectionWithBody *connection;
	BOOL flag;
}

+(DataList*)remoteDataList;
+(void)releaseInstance;



@end
