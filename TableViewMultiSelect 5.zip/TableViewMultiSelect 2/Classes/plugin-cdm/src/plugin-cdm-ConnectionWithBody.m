//
//  plugin-cdm-ConnectionWithBody.m
//  plugin-CityDataManager
//
//  Created by GHY on 11-11-14.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import "plugin-cdm-ConnectionWithBody.h"


@implementation ConnectionWithBody

@synthesize delegate;


- (id)initWithUrl:(NSString *)turl requstbody:(NSData *)body
{
	if (self = [super init]) 
	{
		resultData = [[NSMutableData alloc] init];;
	}
	
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
	NSURL *url = [NSURL URLWithString:turl];
	[request setURL:url];// 設置URL
	[request setHTTPMethod:@"POST"];// 设置方法
	
	if(body != nil)
	{
		[request setHTTPBody:body];//设置xml
	}
	
	NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	[connection start];
	[request release];
	
	return self;
}


- (void)connection:(NSURLConnection *)aConnection didReceiveResponse:(NSURLResponse *)aResponse
{
	[resultData setLength:0];
}


- (void)connection:(NSURLConnection *)aConnection didReceiveData:(NSData *)data
{
	[resultData appendData:data];
}


- (void)connection:(NSURLConnection *)aConnection didFailWithError:(NSError *)error
{
	NSLog(@"netfail");
}


- (void)connectionDidFinishLoading:(NSURLConnection *)aConnection
{
	[aConnection cancel];
	[self.delegate returnResult:resultData];
}


- (void)dealloc
{
	[resultData release];
	
	[super dealloc];
}


@end
