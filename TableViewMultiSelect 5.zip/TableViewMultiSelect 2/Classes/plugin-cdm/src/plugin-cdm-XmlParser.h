//
//  plugin-cdm-XmlParser.h
//  plugin-CityDataManager
//
//  Created by GHY on 11-11-14.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "plugin-cdm-Node.h"

@class Item;

@interface XmlParser : NSObject <NSXMLParserDelegate>
{
	NSMutableArray *provinceArray;
	NSMutableArray *cityArray;
	
	NSMutableString *baseurl;//基地址
	NSMutableString *iname;
	NSMutableString *currentProperty;//信息
	
	Item *item;
	City *city;//城市
	Province *province;//省份或直辖市
	Optional *optional;
	
	Found *found;//基础数据
	Required *required;
	
	Info *infoD;//版本信息
	Opg *opg;//状态信息
}

@property (nonatomic,retain) NSMutableArray *provinceArray;
@property (nonatomic,retain) NSMutableArray *cityArray;

@property (nonatomic,retain) NSMutableString *baseurl;//基地址
@property (nonatomic,retain) NSMutableString *iname;
@property (nonatomic,retain) NSMutableString *currentProperty;

@property (nonatomic,retain) Item *item;
@property (nonatomic,retain) City *city;
@property (nonatomic,retain) Province *province;
@property (nonatomic,retain) Optional *optional;

@property (nonatomic,retain) Found *found;
@property (nonatomic,retain) Required *required;

@property (nonatomic,retain) Info *infoD;
@property (nonatomic,retain) Opg *opg;

- (id)initWitharray:(NSMutableArray *)parray;
- (BOOL)parserStart:(NSData *)data;

@end
