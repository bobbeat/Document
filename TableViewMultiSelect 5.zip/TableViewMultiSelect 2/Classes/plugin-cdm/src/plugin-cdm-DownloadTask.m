//
//  DownloadTask.m
//  plugin-CityDataManager
//
//  Created by mark on 11-11-4.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import "plugin-cdm-DownloadTask.h"

static NSString* KB = @"KB";
static NSString* MB = @"MB";
static NSString* DOWNLOAD_DIR = @"";

@implementation DownloadTask

@synthesize url;

-(void)run     // 执行任务
{
    /*
     1、从url提取出数据文件名
     2、判断DOWNLOAD_DIR里面是否存在文件名+.unf的文件
     3、if(存在)
        {
            读取该文件
        }
        else
        {
            新建一个文件，取名为上述文件名+.unf
        }
     4、把每帧从服务器传过来的数据流写入文件，并不断调用[delegate progress:self current:(int) total:(int)]
     5、下载结束
            关闭文件
            调用[delegate finished:self]
     
        下载出现异常
            关闭文件
            调用[delegate exception:self exception:(id)]
     */
}

-(void)stop    // 停止任务，对停止的任务执行run操作，任务须能从停止处继续执行
{
    /*
     1、记下一些状态（例如已下载的字节个数），以便再次调用run操作，能从停止处继续执行
     2、自然退出线程
     */
}

-(void)erase   // 删除任务以及任务相关的资源
{
    /*
     自然退出线程，删除半成品
     */
}


-(int)percent // 返回任务的进度百分比[0~100]
{
    return (current*100.0/total);
}

//-(BOOL)store     // 任务保存
//{
//    
//}
//
//-(BOOL)restore  // 任务恢复
//{
//    
//}

-(NSString*)description // 某个任务的进度描述
{
    /*
     1、字节>=1MB的，以MB为单位，保留2位小数
     2、字节<1MB的，以KB为单位，保留2位小数
     */
    float cur,tot;
    NSString* unit1,*unit2;
    int mb = 1024*1024;
    int kb = 1024;
    if(current<mb)
    {
        cur = current*1.0f/kb;
        unit1 = KB;
    }
    else
    {
        cur = current*1.0f/mb;
        unit1 = MB;
    }
    if(total<mb)
    {
        tot = total*1.0f/kb;
        unit2 = KB;
    }
    else
    {
        tot = total*1.0f/mb;
        unit2 = MB;
    }
    return [NSString stringWithFormat:@"%.2f%@/%.2f%@",cur,unit1,tot,unit2];
}

@end















