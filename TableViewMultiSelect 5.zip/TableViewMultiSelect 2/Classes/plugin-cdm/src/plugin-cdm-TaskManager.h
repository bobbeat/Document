//
//  TaskManager.h
//  plugin-CityDataManager
//
//  Created by mark on 11-11-3.
//  Copyright (c) 2011年 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Task;

enum {
    TASK_STATUS_READY       = 0,    // 就绪状态：可以切换为运行，或阻塞
    TASK_STATUS_RUNNING     = 1,    // 运行状态：可以切换为就绪，或阻塞
    TASK_STATUS_FINISH      = 2,    // 完成状态：不可再切换为任何别的状态
    TASK_STATUS_BLOCK       = 3,    // 阻塞状态：可以切换为就绪。阻塞状态不能直接切换到运行状态
};

//@protocol TaskDelegate <NSObject>
//
//-(void)run;     // 执行某个任务
//-(void)stop;    // 停止某个任务
//-(void)erase;   // 删除某个任务
//-(int)progress; // 获取某个任务的进度百分比[0~100]
//-(BOOL)store;    // 通知某个任务做保存
//-(BOOL)restore;  // 通知某个任务做恢复
//-(NSString*)description; // 某个任务的进度描述
//
//@end

/*
 正在执行的任务对象使用该委托来通知TaskManager执行进度、状况
 */
@protocol TaskStatusDelegate <NSObject>

/*
 进度通知
 sender：通知发送者
 current：当前已完成的工作量
 total：总的工作量
 */
-(void)progress:(Task*)sender current:(int)current total:(int)total;

/*
 任务完成通知
 sender：通知发送者
 */
-(void)finished:(Task*)sender;

/*
 出现异常通知
 sender：通知发送者
 exception：异常内容
 */
-(void)exception:(Task*)sender exception:(id)exception;

@end


///*
// TaskManager使用该委托来通知客户类各个任务的执行进度、状况
// 客户类通过处理该委托来更新界面等
// */
//@protocol ClientDelegate <NSObject>
//
///*
// 进度通知
// tasks：任务列表
// current：当前已完成的工作量列表
// total：总的工作量列表
// */
//-(void)progress:(NSArray*)tasks current:(NSArray*)current total:(NSArray*)total;
//
///*
// 任务完成通知
// tasks：任务列表
// */
//-(void)finished:(NSArray*)tasks;
//
///*
// 出现异常通知
// tasks：任务列表
// exception：异常内容列表
// */
//-(void)exception:(NSArray*)tasks exception:(NSArray*)exception;
//
//@end



/*
 TaskManager职责：
 1、存储各个任务对象，维护各个任务状态
 2、启动、停止、移除任务队列中某个任务，并处理TaskStatusDelegate委托，进而把任务进度、状况通知给客户
 3、序列化、反序列化队列中的所有任务对象
 */

@interface TaskManager : NSObject<TaskStatusDelegate>
{
@private
    // 这两个数组是一一对应的，一个任务对应一个状态值
    NSMutableArray* taskList;          // 用于保存各项任务
    //NSMutableArray* mTaskStatusList;    // 用于保存各项任务的状态
    id<TaskStatusDelegate> delegate;    // 客户类填充该属性，以便TaskManager把通知发送给客户类
}

@property(nonatomic,assign)id<TaskStatusDelegate> delegate; // 客户类填充该属性，以便TaskManager把通知发送给客户类
@property(nonatomic,readonly)NSArray* taskList;             // 客户类可以读取该列表，以便得到任务的信息

+(TaskManager*)taskManager;
+(void)releaseInstance;

// 返回任务队列中的任务id列表
//-(NSArray*)getTaskId;

// 返回-1表示加入失败，>=0表示成功加入后在TaskManager中的索引
-(int)addTask:(Task*) task atFirst:(BOOL) first;

// 移除索引为index处的任务，该操作会删除该任务。
// 如果恰好该任务处于运行状态，removeTask后，整个TaskManager中将无任务在执行
-(BOOL)removeTask:(int) index;  

// 移除所有状态为status的任务，返回移除的个数
-(int)removeTasksForStatus:(int) status;

// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按某种策略选择一个任务来执行
// 2、有任务在执行：直接返回
-(BOOL)start;

// 停止TaskManager中正在执行的任务，整个TaskManager处于停止状态
-(BOOL)stop;

// TaskManager可能处于两种状态：
// 1、无任何任务在执行：TaskManager按index来选择任务
// 2、有任务在执行：
//      分两种情况：
//      1、正在执行的任务就是index，那么直接返回；
//      2、正在执行的任务不是index，那么让正在执行的任务变为等待，转而执行index指定的任务
-(BOOL)start:(int)index;

// 停止TaskManager中index对应的任务：
// 1、index对应的任务处于等待状态，那么直接返回
// 2、index对应的任务处于执行状态，那么让正在执行的任务变为等待
-(BOOL)stop:(int)index;

// 返回YES表示TaskManager中有任务正在运行
-(BOOL)isRunning;

// 把TaskManager中的所有任务信息保存到文件系统，一般是在退出程序时调用
-(BOOL)store;

// 从文件系统还原通过save保存的所有任务信息，一般是在进入程序时调用，该方法调用将把TaskManager中的所有任务更新为最后一次调用save保存的任务
-(BOOL)restore;


//-(BOOL)moveUp:(int)index;
//-(BOOL)moveDown:(int)index;












// 从头开始向尾扫描mTaskList列表，直到遇到一个状态为TASK_STATUS_READY的任务对象
// 返回指<0则表示没找到可被执行的任务，否则表示所选任务的索引
-(int)_selectOneTaskToRun;


// 返回队列中，状态为status的第一个任务的索引
// 返回指<0则表示没找到可被执行的任务，否则表示任务的索引
-(int)_firstIndexWithStatus:(int)status;

// 根据taskId来判断task是否已经存在队列中
-(BOOL)_taskExisted:(Task*)task;


@end
