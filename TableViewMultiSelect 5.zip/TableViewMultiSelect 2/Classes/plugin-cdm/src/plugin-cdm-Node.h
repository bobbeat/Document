//
//  plugin-cdm-Node.h
//  plugin-CityDataManager
//
//  Created by GHY on 11-11-14.
//  Copyright 2011 Autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface City : NSObject 
{
	NSString *cname;
	NSString *cadcode;
	NSString *csuburl;
	NSString *csize;
	NSString *cunzip_size;
}

@property (nonatomic,retain) NSString *cname;
@property (nonatomic,retain) NSString *cadcode;
@property (nonatomic,retain) NSString *csuburl;
@property (nonatomic,retain) NSString *csize;
@property (nonatomic,retain) NSString *cunzip_size;

@end


@interface Province : NSObject 
{
	NSString *pname;
	NSString *padcode;
	NSString *psuburl;
	NSString *psize;
	NSString *punzip_size;
	
	NSMutableArray *pcity;
}

@property (nonatomic,retain) NSString *pname;
@property (nonatomic,retain) NSString *padcode;
@property (nonatomic,retain) NSString *psuburl;
@property (nonatomic,retain) NSString *psize;
@property (nonatomic,retain) NSString *punzip_size;

@property (nonatomic,retain) NSMutableArray *pcity;

@end


@interface Found : NSObject
{
	NSString *fname;
	NSString *fsuburl;
	NSString *fsize;
	NSString *funzip_size;
}

@property (nonatomic,retain) NSString *fname;
@property (nonatomic,retain) NSString *fsuburl;
@property (nonatomic,retain) NSString *fsize;
@property (nonatomic,retain) NSString *funzip_size;

@end


@interface Optional : NSObject
{
	
}

@end


@interface Required : NSObject
{
	
}

@end


@interface Info : NSObject
{
	NSString *version_data;
	NSString *baseurl;
}

@property (nonatomic,retain) NSString *version_data;
@property (nonatomic,retain) NSString *baseurl;

@end


@interface Opg : NSObject
{
	NSString *activitycode;
	NSString *processtime;
	NSString *actioncode;
	NSString *rspcode;
}

@property (nonatomic,retain) NSString *activitycode;
@property (nonatomic,retain) NSString *processtime;
@property (nonatomic,retain) NSString *actioncode;
@property (nonatomic,retain) NSString *rspcode;

@end
