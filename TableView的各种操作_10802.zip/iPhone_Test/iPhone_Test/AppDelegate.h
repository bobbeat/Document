//
//  AppDelegate.h
//  iPhone_Test
//
//  Created by  on 12-9-17.
//  Copyright (c) 2012年 cofortune. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
