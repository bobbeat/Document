##Read me 
---

After use this project, you should compile ffmpeg following this project:  
[ffmpegc](https://github.com/lvjian700/ffmpegc) 


The origin ffmpeg demo is [iFrameExecutor](https://github.com/jayrparro/iFrameExtractor).I made some improve.   

1. Using newest ffmpeg library. Replace some deprecated method and enum.
2. Change xib UI to Storyboard.
3. Support ARC  

##How to use?
---

See:    
[How use ffmpegc-demo](http://witcheryne.iteye.com/blog/1734706)





