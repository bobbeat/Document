Version 1.1

- Added ARC support
- Improved performance of non-dynamic reflection rendering
- Fixed warning when view has a width or height of zero, or reflectionScale is zero

Version 1.0

- Initial release