//
//  UIViewController+JDSideMenu.h
//  JDSideMenu
//
//  Created by Markus Emrich on 11.11.13.
//  Copyright (c) 2013 Markus Emrich. All rights reserved.
//

#import "JDSideMenu.h"

@interface UIViewController (JDSideMenu)

- (JDSideMenu*)sideMenuController;

@end
