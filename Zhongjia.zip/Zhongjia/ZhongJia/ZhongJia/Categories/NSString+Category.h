//
//  NSString+Categorty.h
//  ZhongJia
//
//  Created by mac on 15/7/19.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(Category)

+ (NSString *)phonetic:(NSString*)sourceString;

- (NSString *) stringFromMD5;
+ (NSString*)getShaMd5With:(NSString *)str key:(NSString *)key;
//URL地址转义 与 反转义
- (NSString *)URLEncodedString;

- (NSString *)URLDecodedString;

/**
 *	检测字符串标准 ： 汉字、字母、数字、@、&、_
 *
 *	@param	checkStr	要检测字符串
 *
 *	@return	符合标准返回yes 不符合标准 返回no
 */
+ (BOOL) checkStringStandardWith:(NSString *)checkStr;

/**
 *	检测电话号码标准 ：数字、-、和“、”
 *
 *	@param	checkPhone	要检测电话字符串
 *
 *	@return	符合标准返回yes 不符合标准 返回no
 */
+ (BOOL) checkPhoneStandardWith:(NSString *)checkPhone;
@end
