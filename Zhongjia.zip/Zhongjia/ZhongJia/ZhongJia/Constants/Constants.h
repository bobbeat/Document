//
//  Constants.h
//  RoadFreightage
//
//  Created by mac on 15/6/3.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import <Foundation/Foundation.h>

#define LocalUserDataPath [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/accountinfo.dat"]

@interface Constants : NSObject

@end
