//
//  BaseTableViewController.m
//  RoadFreightage
//
//  Created by gaozhimin on 15/6/4.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "BaseTableViewController.h"

#define RowHeight 50

@interface BaseTableViewController ()<UITableViewDataSource,UITableViewDelegate>


@end

@implementation BaseTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.edgesForExtendedLayout=UIRectEdgeNone;
    self.extendedLayoutIncludesOpaqueBars=NO;
    self.automaticallyAdjustsScrollViewInsets=NO;
    
    // Do any additional setup after loading the view.
 
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return RowHeight;
}

@end
