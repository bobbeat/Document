//
//  AmapApi.h
//  ZhongJia
//
//  Created by mac on 15/8/2.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import <Foundation/Foundation.h>

#define CityLocationNotify @"CityLocationNotify"
#define CityGetAdcodeNotify @"CityGetAdcodeNotify"

@interface AmapApi : NSObject

+ (instancetype)SharedInstance;
@property (nonatomic,copy) NSString *cityName;  //城市名
@property (nonatomic,copy) NSString *cityAdcode;    //城市行政编码
@end
