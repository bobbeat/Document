//
//  MainTabBarController.m
//  RoadFreightage
//
//  Created by mac on 15/6/2.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "MainTabBarController.h"
#import "NewTaskViewController.h"
#import "MoreViewController.h"
#import "LoginViewController.h"
#import "AccountCenterViewController.h"
#import "CityChooseViewController.h"
#import "TaskScheduleViewController.h"
#import "RewardViewController.h"
#import "AmapApi.h"
#import "ZJNetAPI.h"
@interface MainTabBarController () <UITabBarControllerDelegate>
{
    UILabel *_labelCity;
    ZJNetAPI *_netApi;
}

@property (nonatomic,strong) NSMutableArray *arrayItems;

@end

@implementation MainTabBarController



- (void) viewDidLoad
{
    [super viewDidLoad];
    
    _netApi = [[ZJNetAPI alloc] init];
    
    self.arrayItems = [[NSMutableArray alloc]initWithCapacity:0];
    
    NSArray *arrayImageString = @[@"btn_newmission_normal",
                                  @"btn_percent_normal",
                                  @"btn_award_normal",
                                  @"btn_more_normal"];
    
    NewTaskViewController *viewCtr1 = [[NewTaskViewController alloc] initWithStyle:UITableViewStyleGrouped];
    viewCtr1.title = @"新任务";
    viewCtr1.tabBarItem.image = [UIImage imageNamed:[arrayImageString objectAtIndex:0]];
    [self.arrayItems addObject:viewCtr1];
    
    TaskScheduleViewController *viewCtr2 = [[TaskScheduleViewController alloc]init];
    viewCtr2.title = @"任务进度";
    viewCtr2.tabBarItem.image = [UIImage imageNamed:[arrayImageString objectAtIndex:1]];
    [self.arrayItems addObject:viewCtr2];
    
    RewardViewController *viewCtr3 = [[RewardViewController alloc]init];
    viewCtr3.title = @"奖励通知";
    viewCtr3.tabBarItem.image = [UIImage imageNamed:[arrayImageString objectAtIndex:2]];
    [self.arrayItems addObject:viewCtr3];
    
    MoreViewController *viewCtr4 = [[MoreViewController alloc] initWithStyle:UITableViewStyleGrouped];
    viewCtr4.title = @"更多众加";
    viewCtr4.tabBarItem.image = [UIImage imageNamed:[arrayImageString objectAtIndex:3]];
    [self.arrayItems addObject:viewCtr4];
    
    self.viewControllers = self.arrayItems;
    
    self.tabBar.tintColor =  [UIColor redColor];

    self.delegate = self;
    
    self.navigationItem.title = @"众加传媒";
    UIView *view = self.navigationItem.titleView;
    NSLog(@"%@",[[view class] description]);
    
    self.edgesForExtendedLayout=UIRectEdgeNone;
    self.extendedLayoutIncludesOpaqueBars=NO;
    self.automaticallyAdjustsScrollViewInsets=NO;
    
    UIImage *headImage = [UIImage imageNamed:@"HeadImage.png"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:headImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(EnterUserCtl) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = barButton;
    
    
    UIView *viewLocation = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 80, 40)];
    viewLocation.backgroundColor = [UIColor clearColor];
    _labelCity = [[UILabel alloc] initWithFrame:CGRectMake(34, 10, 46, 30)];
    _labelCity.backgroundColor = [UIColor clearColor];
    _labelCity.textColor = [UIColor whiteColor];
    _labelCity.font = [UIFont systemFontOfSize:10];
    _labelCity.textAlignment = NSTextAlignmentLeft;
    [viewLocation addSubview:_labelCity];
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_location_normal.png"] forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 74, 42);
    [button addTarget:self action:@selector(EnterCitySelect) forControlEvents:UIControlEventTouchUpInside];
    [viewLocation addSubview:button];
    barButton = [[UIBarButtonItem alloc] initWithCustomView:viewLocation];
    self.navigationItem.leftBarButtonItem = barButton;
    
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(cityLocation:) name:CityLocationNotify  object: nil];
}



- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
    
    if ([UserDataOperator getUserLoginStatus])
    {
        UserInfoObject *response = [UserDataOperator getUserData];
        UIImage *headImage = [UIImage getRoundImageWithImage:response.userHeadImage from:0 to:360];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setBackgroundImage:headImage forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 0, 35, 35);
        [button addTarget:self action:@selector(EnterUserCtl) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
        self.navigationItem.rightBarButtonItem = barButton;
    }
    else
    {
        UIImage *headImage = [UIImage imageNamed:@"HeadImage.png"];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setBackgroundImage:headImage forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 0, 35, 35);
        [button addTarget:self action:@selector(EnterUserCtl) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
        self.navigationItem.rightBarButtonItem = barButton;
    }
   

}

- (void)cityLocation:(NSNotification *)notification
{
    _labelCity.text = notification.object;
}

/*
 *  设置tabbar item的东西
 */
- (void) setTabBarItemsType
{
    UIView *tempView = [[UIView alloc]initWithFrame:self.tabBar.bounds];
    tempView.backgroundColor = [UIColor colorWithRed:49.0f green:49.0f blue:49.0f alpha:1];
    [self.tabBar insertSubview:tempView atIndex:0];
    
    self.tabBar.opaque = YES;
    self.tabBar.tintColor =  [UIColor redColor];
    
    NSArray *arrayImageString = @[@"wk_bottombar_state",
                                  @"wk_bottombar_order",
                                  @"wk_bottombar_map",
                                  @"wk_bottombar_more"];
    for (int i = 0 ; i < self.tabBar.items.count; i ++)
    {
        UITabBarItem *tabBaritem = [self.tabBar.items objectAtIndex:i];
        tabBaritem.tag = i;
        if(i < arrayImageString.count)
        {
            tabBaritem.image = [UIImage imageNamed:[arrayImageString objectAtIndex:i]];
            
        }
        
        [tabBaritem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                            [UIColor blackColor], NSForegroundColorAttributeName,
                                            nil]  forState:UIControlStateNormal];
        [tabBaritem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                            [UIColor redColor], NSForegroundColorAttributeName,
                                            nil]  forState:UIControlStateSelected];
    }
}

#pragma mark - action

- (void)EnterCitySelect
{
    CityChooseViewController *ctl = [[CityChooseViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:ctl animated:YES];
}

- (void)EnterUserCtl
{
    AccountCenterViewController *ctl = [[AccountCenterViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:ctl animated:YES];
}

#pragma mark - ---  tabbar delegate  ---
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    NSLog(@"select %lu",(unsigned long)tabBarController.selectedIndex);
//    self.title = viewController.title;
    switch (tabBarController.selectedIndex) {
        case 0:
        {
            self.navigationController.navigationBarHidden = NO;
        }
            break;
        case 1:
        {
            self.navigationController.navigationBarHidden = NO;
        }
            break;
        case 2:
        {
            self.navigationController.navigationBarHidden = NO;
        }
            break;
        case 3:
        {
            self.navigationController.navigationBarHidden = NO;
        }
            break;
        default:
            break;
    }
    
}

@end
