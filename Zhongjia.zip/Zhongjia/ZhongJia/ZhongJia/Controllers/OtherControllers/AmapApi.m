//
//  AmapApi.m
//  ZhongJia
//
//  Created by mac on 15/8/2.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "AmapApi.h"
#import <AMapSearchKit/AMapSearchAPI.h>
#import <MAMapKit/MAMapKit.h>

@interface AmapApi ()<MAMapViewDelegate,AMapSearchDelegate>
{
    MAMapView *_amapView;
    AMapSearchAPI *_amapSearch;
}


@end

@implementation AmapApi

+ (instancetype)SharedInstance
{
    static AmapApi *api = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        api = [[AmapApi alloc] init];
    });
    return api;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initAmapAndSearch];
    }
    return self;
}

- (void)initAmapAndSearch
{
    _amapView = [[MAMapView alloc] initWithFrame:CGRectZero];
    _amapView.delegate = self;
    _amapView.showsUserLocation = YES;
    _amapView.userTrackingMode = MAUserTrackingModeFollow;
    
    _amapSearch  = [[AMapSearchAPI alloc] initWithSearchKey:[MAMapServices sharedServices].apiKey Delegate:self];
    
}

/*!
 @brief 在地图View停止定位后，会调用此函数
 @param mapView 地图View
 */
- (void)mapViewDidStopLocatingUser:(MAMapView *)mapView
{
    MAUserLocation *userlocation = _amapView.userLocation;
    
    AMapSearchAPI *search  = [[AMapSearchAPI alloc] initWithSearchKey:[MAMapServices sharedServices].apiKey Delegate:self];
    
    AMapReGeocodeSearchRequest *regeo = [[AMapReGeocodeSearchRequest alloc] init];
    
    regeo.location = [AMapGeoPoint locationWithLatitude:userlocation.location.coordinate.latitude longitude:userlocation.location.coordinate.longitude];
    regeo.requireExtension = YES;
    [search AMapReGoecodeSearch:regeo];
}

/*!
 @brief 位置或者设备方向更新后，会调用此函数
 @param mapView 地图View
 @param userLocation 用户定位信息(包括位置与设备方向等数据)
 @param updatingLocation 标示是否是location数据更新, YES:location数据更新 NO:heading数据更新
 */
- (void)mapView:(MAMapView *)mapView didUpdateUserLocation:(MAUserLocation *)userLocation updatingLocation:(BOOL)updatingLocation
{
    static BOOL first = YES;
    if (first == YES)
    {
        MAUserLocation *userlocation = _amapView.userLocation;
        CLLocationCoordinate2D coordinate = userlocation.location.coordinate;
        AMapReGeocodeSearchRequest *regeo = [[AMapReGeocodeSearchRequest alloc] init];
        regeo.location = [AMapGeoPoint locationWithLatitude:coordinate.latitude longitude:coordinate.longitude];
        regeo.requireExtension = YES;
        [_amapSearch AMapReGoecodeSearch:regeo];
        first = NO;
        _amapView.userTrackingMode = MAUserTrackingModeNone;
    }
}

/*!
 @brief 定位失败后，会调用此函数
 @param mapView 地图View
 @param error 错误号，参考CLError.h中定义的错误号
 */
- (void)mapView:(MAMapView *)mapView didFailToLocateUserWithError:(NSError *)error
{
    NSLog(@"didFailToLocateUserWithError");
    
}

/*!
 当请求发生错误时，会调用代理的此方法.
 @param request 发生错误的请求.
 @param error   返回的错误.
 */
- (void)searchRequest:(id)request didFailWithError:(NSError *)error
{
     NSLog(@"didFailWithError");
}
/*!
 @brief 逆地理编码查询回调函数
 @param request 发起查询的查询选项(具体字段参考AMapReGeocodeSearchRequest类中的定义)
 @param response 查询结果(具体字段参考AMapReGeocodeSearchResponse类中的定义)
 */
- (void)onReGeocodeSearchDone:(AMapReGeocodeSearchRequest *)request response:(AMapReGeocodeSearchResponse *)response;
{
    NSLog(@"city = %@",response.regeocode.addressComponent.city);
    self.cityName = response.regeocode.addressComponent.city;
    [[NSNotificationCenter defaultCenter] postNotificationName:CityLocationNotify  object:self.cityName];
    
    AMapDistrictSearchRequest *dist = [[AMapDistrictSearchRequest alloc] init];
    dist.keywords = self.cityName;
    dist.requireExtension = NO;
    
    [_amapSearch AMapDistrictSearch:dist];
    
    
}

#pragma mark - AMapSearchDelegate

- (void)onDistrictSearchDone:(AMapDistrictSearchRequest *)request response:(AMapDistrictSearchResponse *)response
{
    for (AMapDistrict *district in response.districts) {
        NSLog(@"adcode: %@", district.adcode);
        self.cityAdcode = district.adcode;
    }
   [[NSNotificationCenter defaultCenter] postNotificationName:CityGetAdcodeNotify  object:self.cityAdcode];
}
@end
