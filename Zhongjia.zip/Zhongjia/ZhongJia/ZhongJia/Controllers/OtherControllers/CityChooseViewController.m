//
//  CityChooseViewController.m
//  RoadFreightage
//
//  Created by gaozhimin on 15/7/20.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "CityChooseViewController.h"
#import "CustomCellDataContainTextField.h"
#import "UIImage+Category.h"
#import "CustomTextFieldCell.h"
#import "MainTabBarController.h"
#import "ZJNetAPI.h"
#import "UIImage+Category.h"
#import "QLoadingView.h"
 #import "NSString+Category.h"
#import "CityCoreDataManage.h"
#import "AmapApi.h"
#define HotCityViewHeight 170

@interface CityChooseViewController ()<UITextFieldDelegate>
{
    UIImageView *_imageViewTextFieldBack;
    UIImageView *_imageViewSearch;
    
    UIButton *_loginButton;
    
    ZJNetAPI * _syNet;
    
    UILabel *_labelLetter;
    UITextField *_textField;
    
    UIView *_viewHotCity;
}

@property (nonatomic,strong)  NSArray *cellDataObj;
@property (nonatomic,strong)  NSArray *arraySearchResult;
@property (nonatomic,strong)  NSArray *arrayLetter; //字母列表
@property (nonatomic,strong)  NSMutableArray *arrayCityList; //字母列表
@property (nonatomic,copy)  NSString *strSearchKey;

@end

@implementation CityChooseViewController

- (void)dealloc
{
    self.arraySearchResult = nil;
    self.cellDataObj = nil;
    self.strSearchKey = nil;
    self.arrayLetter = nil;
    self.arrayCityList = nil;
}

- (NSString *)ChToP:(NSString *)chinese
{
    //先转换为带声调的拼音
    
    NSMutableString *str = [chinese mutableCopy];
    
    CFStringTransform((CFMutableStringRef)str,NULL, kCFStringTransformMandarinLatin,NO);
    
    //再转换为不带声调的拼音
    
    CFStringTransform((CFMutableStringRef)str,NULL, kCFStringTransformStripDiacritics,NO);
    
    return str;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.title = @"当前城市";
    CGSize size = self.view.bounds.size;
    
    int hotCityHeight = HotCityViewHeight;
    int row = 3;
    int line = 4;
    _viewHotCity = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, HotCityViewHeight)];
    _viewHotCity.backgroundColor = [UIColor clearColor];
    
    NSArray *hotCity = @[@"上海",@"北京",@"广州",@"深圳",@"成都",@"重庆",@"天健",@"杭州",@"南京",@"苏州",@"武汉",@"西安",];
    for (int i = 0; i < line; i++) {
        
        float buttony = (hotCityHeight/line)*i + (hotCityHeight/line)/2 + 10;
        
        for (int j = 0; j < row; j++)
        {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            [button addTarget:self action:@selector(HotCityChoose:) forControlEvents:UIControlEventTouchUpInside];
            [button setTitle:[hotCity objectAtIndex:i*row+j] forState:UIControlStateNormal];
            [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_city_normal"]] forState:UIControlStateNormal];
            [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_city_highlight"]] forState:UIControlStateHighlighted];
            [_viewHotCity addSubview:button];
            
            float buttonx = ((size.width - 30)/row)*j + ((size.width - 30)/row)/2;
            button.frame = CGRectMake(0, 0, 75, 35);
            button.center =CGPointMake(buttonx, buttony);
            button.tag = i*line + j;
        }
    }
    
    
    _textField = [[UITextField alloc] initWithFrame:CGRectMake(0, 10, size.width - 50, 40)];
    _textField.backgroundColor = [UIColor clearColor];
    _textField.textColor = [UIColor blackColor];
    _textField.borderStyle = UITextBorderStyleNone;
    _textField.autocorrectionType = UITextAutocorrectionTypeNo;
    _textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _textField.keyboardType = UIKeyboardTypeDefault;
    _textField.returnKeyType = UIReturnKeyDone;
    _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _textField.placeholder = @"城市名、拼音首字母...";
    _textField.leftView=nil;
    _textField.background=nil;
    _textField.delegate = self;
    [self.tableView addSubview:_textField];
    _textField.center = CGPointMake(size.width/2 + 20, 50/2);
    
    _syNet = [[ZJNetAPI alloc] init];
    _syNet.delegate = self;
    
    UIImage *textBackgroud = [UIImage imageNamed:@"back_imput"];
    _imageViewTextFieldBack = [[UIImageView alloc] init];
    _imageViewTextFieldBack.image = [UIImage getStrechableImageWith:textBackgroud];
    _imageViewTextFieldBack.bounds = CGRectMake(0, 0, size.width - 20,33);
    [self.view addSubview:_imageViewTextFieldBack];
    _imageViewTextFieldBack.center = CGPointMake(size.width/2, 50/2);
    
    _imageViewSearch = [[UIImageView alloc] init];
    _imageViewSearch.image = [UIImage imageNamed:@"ic_search"];
    _imageViewSearch.bounds = CGRectMake(0, 0, 18,17);
    [self.view addSubview:_imageViewSearch];
    _imageViewSearch.center = CGPointMake(25, 50/2);
    
    
    _loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_loginButton setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"wk_btn_background.png"]] forState:UIControlStateNormal];
    [_loginButton setTitle:@"登录" forState:UIControlStateNormal];
    [_loginButton addTarget:self action:@selector(loginAction) forControlEvents:UIControlEventTouchUpInside];
    
    NSMutableArray *dataArray = [NSMutableArray array];
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = [NSString stringWithFormat:@"定位城市：%@",[AmapApi SharedInstance].cityName];
    [sectionArray addObject:cellData];
    [dataArray addObject:sectionArray];
    
    NSMutableArray *existLetter = [NSMutableArray array];
    [existLetter addObject:@"热门"];
    
    self.arrayCityList = [NSMutableArray array];
    
    char aLetter[2] = {0};
    for (int i = 0; i < 26; i++) {
        
        aLetter[0] = 'a' + i;
        NSString *firstLetter = [NSString stringWithUTF8String:aLetter];
        [existLetter addObject:firstLetter];
        
        NSArray *array_temp = [[CityCoreDataManage SharedInstance] QueryCityWitchFirstLetter:firstLetter];
        if ([array_temp count] > 0) {
            sectionArray  = [NSMutableArray array];
            for (int j = 0; j < [array_temp count]; j++) {
                CityEntity *cityEntity = [array_temp objectAtIndex:j];
                cellData = [[CustomCellData alloc] init];
                cellData.text = cityEntity.cityName;
                cellData.otherObject = cityEntity;
                [sectionArray addObject:cellData];
            }
            [dataArray addObject:sectionArray];
            [self.arrayCityList addObject:array_temp];
        }
    }
    self.cellDataObj = [NSArray arrayWithArray:dataArray];
    
    _arrayLetter = [NSArray arrayWithArray:existLetter];
    NSString *letter = [[_arrayLetter componentsJoinedByString:@"\r"] uppercaseString];
    CGSize letterSize = [letter sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12]}];
    letterSize.height = ceilf(letterSize.height); //向上取整
    _labelLetter = [[UILabel alloc] initWithFrame:CGRectMake(self.view.bounds.size
                                                             .width-30, size.height - letterSize.height - 30, 30, letterSize.height + 1)];
    _labelLetter.numberOfLines = 28;
    _labelLetter.text = letter;
    _labelLetter.font = [UIFont systemFontOfSize:12];
    _labelLetter.backgroundColor = [UIColor clearColor];
    _labelLetter.textAlignment = NSTextAlignmentCenter;
    _labelLetter.textColor = [UIColor redColor];
    [self.navigationController.view addSubview:_labelLetter];
    _labelLetter.userInteractionEnabled = YES;
    _labelLetter.center = CGPointMake(self.view.bounds.size
                                      .width-15, self.view.bounds.size
                                      .height/2 + 20);
    
    UITapGestureRecognizer *recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureRecognizer:)];
    recognizer.numberOfTapsRequired = 1;
    recognizer.numberOfTouchesRequired = 1;
    [_labelLetter addGestureRecognizer:recognizer];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
}
- (void)viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_labelLetter removeFromSuperview];
    _labelLetter = nil;
    [super viewWillDisappear:animated];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(textFieldDidChange:) name: UITextFieldTextDidChangeNotification object: nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)goBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)tapGestureRecognizer:(UITapGestureRecognizer *)recognizer
{
    CGPoint touchPoint = [recognizer locationInView:recognizer.view];
    CGSize size = [recognizer.view bounds].size;
    float _oneHeight = size.height/(float)[_arrayLetter count];
    int index = touchPoint.y/_oneHeight;
    if (index < [_arrayLetter count]) {
        NSLog(@"%@",[_arrayLetter objectAtIndex:index]);
        int section = [self FindCityFirstLetterIndex:[_arrayLetter objectAtIndex:index]];
        CGRect rect = [self.tableView rectForHeaderInSection:section];
        
        float maxY = self.tableView.contentSize.height - self.tableView.frame.size.height;
        if (rect.origin.y > maxY)
        {
            rect.origin.y = maxY;
        }
        [self.tableView setContentOffset:CGPointMake(0, rect.origin.y)];
    }
}

//查找城市首字母所在section位置
- (int)FindCityFirstLetterIndex:(NSString *)city
{
    if ([city isEqualToString:@"#"]) {
        return (int)[self.arrayCityList count];
    }
    int section = 0;
    char city_letter = [city UTF8String][0];
    
    for (int i = 0; i < [self.arrayCityList count]; i++)
    {
        
        NSArray *array = [self.arrayCityList objectAtIndex:i];
        CityEntity *cityEntity = [array firstObject];
        if (cityEntity) {
            char temp = [cityEntity.firstLetter UTF8String][0];
            if (temp > city_letter)
            {
                break;
            }
        }
        section ++;
    }
    return section;
}



- (void)SearchAction:(NSString *)key
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//        NSMutableArray *searchResult = [NSMutableArray array];
        NSArray *searchResult  = nil;
        NSString *regex = @"^[\u4e00-\u9fa5A-Za-z\x20]+$";
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
        BOOL sign = [predicate evaluateWithObject:key];
        if (sign)
        {
            searchResult = [[CityCoreDataManage SharedInstance] QueryCityWithKeyword:key];
            regex = @"^[A-Za-z]+$";
            predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
        }
        self.arraySearchResult = searchResult;
        dispatch_sync(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
    });
    
   
    
}

//获取城市列表，时间较长，使用线程，启动程序调用
+ (void)initCityList
{
    return;
    static int temp_int = 0;
    CityCoreDataManage *citymanage = [CityCoreDataManage SharedInstance];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{        
        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"citylist" ofType:@"txt"];
        NSError *error;
        NSString *str = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
        NSArray *array = [str componentsSeparatedByString:@"\r"];
        for (int i = 0; i < [array count]; i++) {
            
            NSString *temp = [array objectAtIndexedSubscript:i];
            NSString *pinyin = [NSString phonetic:temp];
            
            CityEntity *cityEntity = [citymanage getCityEntntity];
            cityEntity.enName = pinyin;
            cityEntity.cityName = temp;
            cityEntity.adcode = [NSNumber numberWithInt:temp_int];
            
            if ([pinyin length] > 0)
            {
                NSString *firstLetter = [pinyin substringToIndex:1];
                if ([temp isEqualToString:@"厦门"]) {
                    int x = 0;
                }
                NSLog(@"x = %@ y = %@",firstLetter,temp);
                int index = [firstLetter UTF8String][0] - 'a';
                cityEntity.firstLetter = firstLetter;
            }
            [citymanage addIntoDataSource:cityEntity];
        }
    });
    
}

#pragma mark -  Action Handle

- (void)HotCityChoose:(UIButton *)button
{
    NSLog(@"button %ld",button.tag);
}

- (void)getVerificationCodeAction
{
    [QLoadingView showDefaultLoadingView:@"加载中"];
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:0];
    NSString *phone = cellData.cellFieldText;
    VerifyCodeRequest *verifyCode = [[VerifyCodeRequest alloc] init];
    verifyCode.requestType  = ZJNetType_VerifyCode;
    verifyCode.sid          = @"";
    verifyCode.userid       = 0;
    verifyCode.usertype     = @"driver";
    verifyCode.platform     = @"IOS";
    verifyCode.phone        = phone;
    
    [_syNet getVerifyCode:verifyCode];
}

- (void)loginAction
{
    [QLoadingView showDefaultLoadingView:@"加载中"];
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:0];
    NSString *phone = cellData.cellFieldText;
    
    cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:1];
    NSString *code = cellData.cellFieldText;
    
     
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    if ([self.strSearchKey length] > 0)
    {
        return 1;
    }
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self.strSearchKey length] > 0)
    {
        return [self.arraySearchResult count]?[self.arraySearchResult count]:1;
    }
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if ([self.strSearchKey length] > 0)
    {
        return 50;
    }
    if (section == 0)
    {
        return 50;
    }
    return 20;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if ([self.strSearchKey length] > 0)
    {
        return nil;
    }
    float height = [self tableView:tableView heightForHeaderInSection:section];
    
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        [self.tableView bringSubviewToFront:_textField];
    }
    else
    {
        UILabel *letterLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 100, height)];
        
        
        NSArray *array = [self.cellDataObj objectAtIndex:section];
        CustomCellData *celldata = [array firstObject];
        CityEntity *cityEntity = celldata.otherObject;
        letterLabel.text = cityEntity.firstLetter;
        letterLabel.backgroundColor = [UIColor clearColor];
        letterLabel.textColor = [UIColor grayColor];
        letterLabel.font = [UIFont systemFontOfSize:14];
        [view addSubview:letterLabel];
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if ([self.strSearchKey length] > 0)
    {
        return 10;
    }
    if (section == 0)
    {
        return HotCityViewHeight + 40;
    }
    return 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if ([self.strSearchKey length] > 0)
    {
        return nil;
    }
    float height = [self tableView:tableView heightForFooterInSection:section];
    
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        [view addSubview:_viewHotCity];
        _viewHotCity.center = CGPointMake(view.bounds.size.width/2, height/2);
        
        UILabel *hotCityLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 100, 40)];
        hotCityLabel.text = @"热门城市";
        hotCityLabel.backgroundColor = [UIColor clearColor];
        hotCityLabel.textColor = [UIColor grayColor];
        hotCityLabel.font = [UIFont systemFontOfSize:14];
        [view addSubview:hotCityLabel];
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    if ([self.strSearchKey length] > 0)
    {
        if ([self.arraySearchResult count] > 0) {
            CityEntity *cityEntity = [self.arraySearchResult objectAtIndex:indexPath.row];
            if (cityEntity) {
                cell.textLabel.text = cityEntity.cityName;
            }
        }
        else
        {
            cell.textLabel.text = @"无搜索结果";
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    else
    {
        CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        cell.textLabel.text = cellData.text;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
}

#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

- (void)textFieldDidChange:(NSNotification *)notification
{
    UITextField *textField = nil;
    
    NSObject* obj = [notification object];
    if ([obj isKindOfClass:[UITextField class]])
    {
        textField = (UITextField*)obj;
        
    }
    if (textField)
    {
        self.strSearchKey = textField.text;
        [self SearchAction:textField.text];
    }
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

#pragma mark - ZJNetDelegate

- (void)netRequest:(id)request didFailWithError:(NSError *)error;
{
    [QLoadingView hideWithAnimated:NO];
    
}

- (void)onVerifyCodeDone:(VerifyCodeRequest *)request response:(VerifyCodeResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    
    
    NSLog(@"\r\n%s: netRequest = %@, resoponse= %@\r\n", __func__, [request class], response);
}

- (void)onLoginDone:(LoginRequest *)request response:(LoginResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    
    MainTabBarController *ctl = [[MainTabBarController alloc] init];
    self.navigationController.viewControllers = @[ctl];
    
    
    NSLog(@"\r\n%s: netRequest = %@, resoponse= %@\r\n", __func__, [request class], response);
    
}




@end
