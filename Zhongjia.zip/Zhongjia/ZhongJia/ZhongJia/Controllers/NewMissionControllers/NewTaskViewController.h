//
//  WorkspaceViewController.h
//  RoadFreightage
//
//  Created by mac on 15/6/2.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "BaseTableViewController.h"

@interface NewTaskViewController : BaseTableViewController

@end
