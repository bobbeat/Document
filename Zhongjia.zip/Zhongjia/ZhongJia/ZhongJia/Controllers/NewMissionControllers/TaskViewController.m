//
//  TaskViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "TaskViewController.h"

@interface TaskViewController ()
{
    UIImageView *_imageViewTaskImage;
    UIImageView *_imageViewSawtooth;
    UITextView *_textViewForDetail;
    UILabel *_labelDetail;
}

@property (nonatomic,retain) TaskInfoObject *taskInfoObject;

@end

@implementation TaskViewController

- (instancetype)initWith:(TaskInfoObject *)object
{
    self = [super init];
    if (self) {
        self.taskInfoObject = object;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    
    CGSize size = self.view.bounds.size;
    
     TaskInfoObject *temp = self.taskInfoObject;
    
    self.title = temp.advertiser;
    
    float imageHeitght = 180;
    _imageViewTaskImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, imageHeitght)];
    _imageViewTaskImage.image = temp.image;
    [self.view addSubview:_imageViewTaskImage];
    
    UIImage *image = [UIImage imageNamed:@"bg_sawtooth"];
    UIImage *stretchableButtonImageNormal = [image stretchableImageWithLeftCapWidth:1 topCapHeight:1];
    
    float sawHeight = 100;
    _imageViewSawtooth = [[UIImageView alloc] initWithFrame:CGRectMake(0, imageHeitght, size.width, sawHeight)];
    _imageViewSawtooth.image = stretchableButtonImageNormal;
    [self.view addSubview:_imageViewSawtooth];
    
   
    
    NSArray *textArray = @[@"任务类型：",@"所在地点：",@"任务周期：",@"征车数量：",@"征车酬金："];
    NSArray *detailArray = @[temp.level,temp.city,temp.cycle,temp.quantity,temp.reward];
//    NSArray *detailArray = @[@"代言任务",@"厦门",@"三个月",@"500辆",@"900加油卡"];
    NSArray *imageArray = @[[UIImage imageNamed:@"ic_task_type"],[UIImage imageNamed:@"ic_task_city"],[UIImage imageNamed:@"ic_task_time"],[UIImage imageNamed:@"ic_task_carnumber"],[UIImage imageNamed:@"ic_task_pay"]];
    
    for (int i = 0; i < 5; i++)
    {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0 , 0, 120, 30)];
        label.backgroundColor = [UIColor clearColor];
        label.textAlignment = NSTextAlignmentLeft;
        label.textColor = [UIColor blackColor];
        label.font = [UIFont systemFontOfSize:12];
        label.text = [textArray objectAtIndex:i];
        [_imageViewSawtooth addSubview:label];
        
        UILabel * label1 = [[UILabel alloc] initWithFrame:CGRectMake(0 , 0, 120, 30)];
        label1.backgroundColor = [UIColor clearColor];
        label1.textAlignment = NSTextAlignmentLeft;
        label1.textColor = [UIColor grayColor];
        label1.font = [UIFont systemFontOfSize:12];
        label1.text = [detailArray objectAtIndex:i];
        [_imageViewSawtooth addSubview:label1];
        
        UIImage *image = [imageArray objectAtIndex:i];
        UIImageView *imageview = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0,image.size.width, image.size.height)];
        imageview.image = image;
        [_imageViewSawtooth addSubview:imageview];
        
        
        float imageX = (i%2)*size.width/2 + 20;
        float imagey = (i/2)* (_imageViewSawtooth.bounds.size.height/3.0) + 15;
        imageview.center = CGPointMake(imageX, imagey);
        label.center = CGPointMake(imageX + 70, imagey);
        label1.center = CGPointMake(imageX + 70 + 60, imagey);
    }
    
    UIView *redView = [[UIView alloc] initWithFrame:CGRectMake(10, imageHeitght+sawHeight + 9, 2, 13)];
    redView.backgroundColor = [UIColor redColor];
    [self.view addSubview:redView];
    
    _labelDetail = [[UILabel alloc] initWithFrame:CGRectMake(20, imageHeitght+sawHeight, 120, 30)];
    _labelDetail.backgroundColor = [UIColor clearColor];
    _labelDetail.textAlignment = NSTextAlignmentLeft;
    _labelDetail.textColor = [UIColor redColor];
    _labelDetail.font = [UIFont boldSystemFontOfSize:14];
    _labelDetail.text = @"任务详情";
    [self.view addSubview:_labelDetail];
    
    _textViewForDetail = [[UITextView alloc] initWithFrame:CGRectMake(10, imageHeitght+sawHeight + 30, size.width - 20, size.height - (imageHeitght+sawHeight + 30 + 80))];
    _textViewForDetail.backgroundColor = [UIColor whiteColor];
    _textViewForDetail.keyboardType = UIKeyboardTypeDefault;
    _textViewForDetail.returnKeyType = UIReturnKeyDone;
    _textViewForDetail.textColor = [UIColor blackColor];
    _textViewForDetail.font = [UIFont systemFontOfSize:16];
    _textViewForDetail.text = @"特别友情提示：\r报名时请大家注意自己的个人资料\r车主请勿报名\r车辆附加要求：\r。";
    [self.view addSubview:_textViewForDetail];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"报名" forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 60, 35);
    [button addTarget:self action:@selector(rightButtonAction) forControlEvents:UIControlEventTouchUpInside];
    barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightButtonAction
{
    NSLog(@"rightButtonAction");
}

@end
