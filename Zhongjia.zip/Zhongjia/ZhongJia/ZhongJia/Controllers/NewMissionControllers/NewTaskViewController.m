//
//  RewardViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/25.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "NewTaskViewController.h"
#import "CustomCellData.h"
#import "TaskViewController.h"
#import "AmapApi.h"
#import "ZJNetAPI.h"

#define NewTaskCellHeight 300
#define NewSectionHeaderHeight 200

@interface NewTaskTableViewCell : UITableViewCell
{
    
}

@property (retain,nonatomic) NSArray *taskArray;

@end

@implementation NewTaskTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

- (UIView *)CreateViewWith:(CGRect)Frame image:(UIImage *)image name:(NSString *)name detail:(NSString *)detail
{
    UIView *view = [[UIView alloc] initWithFrame:Frame];
    view.backgroundColor = [UIColor whiteColor];
    [self addSubview:view];
    
    float labelHeight = 20;
    
    CGSize size = view.bounds.size;
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0 , size.width, size.height - labelHeight)];
    imageView.image = image;
    [view addSubview:imageView];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(5, size.height - labelHeight - 30, size.width - 10, 30)];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentLeft;
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont boldSystemFontOfSize:14];
    label.text =name;
    [view addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(5, size.height - labelHeight, size.width - 10, labelHeight)];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentLeft;
    label.textColor = [UIColor grayColor];
    label.font = [UIFont boldSystemFontOfSize:8];
    label.text = detail;
    [view addSubview:label];
    
    UITapGestureRecognizer *recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureRecognizer:)];
    recognizer.numberOfTapsRequired = 1;
    recognizer.numberOfTouchesRequired = 1;
    [view addGestureRecognizer:recognizer];
    return view;
}

- (void)tapGestureRecognizer:(UITapGestureRecognizer *)recognizer
{
    NSLog(@"tap");    
    TaskInfoObject *object = [self.taskArray objectAtIndex:recognizer.view.tag - 1];
    
    TaskViewController *ctl = [[TaskViewController alloc] initWith:object];
    UIWindow *window = [[[UIApplication sharedApplication] windows]objectAtIndex:0];
    UINavigationController *navi = window.rootViewController;
    [navi pushViewController:ctl animated:YES];
}

- (void)SetTaskInfoWith:(NSArray *)taskArray
{
    CGSize size = self.bounds.size;
    float offset = 5;
    self.taskArray = [NSArray arrayWithArray:taskArray];
    
    for (TaskInfoObject *object in taskArray)
    {
        if (object.image == nil) {
            object.image = [UIImage imageNamed:@"default_img"];
        }
        if ([object.level isEqualToString:@"1"]) {
            
            UIView *view = [self CreateViewWith:CGRectMake(offset, offset, size.width/2 - 2*offset, NewTaskCellHeight/2 - 2*offset) image:object.image name:@"智行科技" detail:object.advertiser];
            [self addSubview:view];
            view.tag = 1;
        }
        else if ([object.level isEqualToString:@"2"]) {
            UIView *view = [self CreateViewWith:CGRectMake(size.width/2+offset, offset, size.width/2-2*offset, NewTaskCellHeight/2 - 2*offset) image:object.image name:@"加州葡萄酒" detail:object.advertiser];
            [self addSubview:view];
            view.tag = 2;
        }
        else if ([object.level isEqualToString:@"3"]) {
            UIView *view = [self CreateViewWith:CGRectMake(offset, NewTaskCellHeight/2+offset, size.width-2*offset, NewTaskCellHeight/2 - 2*offset) image:object.image name:@"铁观音" detail:object.advertiser];
            [self addSubview:view];
            view.tag = 3;
        }
    }
}

@end

@interface NewTaskViewController ()
{
    UIScrollView *_scrollView;
    UIView *_signView;
    ZJNetAPI *_netApi;
}

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation NewTaskViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    self.tableView.separatorColor = [UIColor clearColor];
    
    _netApi = [[ZJNetAPI alloc] init];
    _netApi.delegate = self;
    
    CGSize size = self.view.bounds.size;
    int page= 5;
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, NewSectionHeaderHeight)];
    _scrollView.bounces = NO;
    _scrollView.delegate = self;
    [_scrollView setContentSize:CGSizeMake(page*size.width, NewSectionHeaderHeight)];
    
    
    _signView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 120, 5)];
    _signView.backgroundColor = [UIColor clearColor];
    
    for (int i = 0; i < 5; i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i*self.view.bounds.size.width, 0, self.view.bounds.size.width, NewSectionHeaderHeight)];
        imageView.image = [UIImage imageNamed:@"img_test4"];
        [_scrollView addSubview:imageView];
        
        UIView *temp = [[UIView alloc] initWithFrame:CGRectMake(20*i,0,15,5)];
        temp.backgroundColor = [UIColor redColor];
        temp.tag = i+1;
        [_signView addSubview:temp];
    }
    
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(cityGetAdcode:) name:CityGetAdcodeNotify  object: nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setSubViewRed
{
    CGPoint point = _scrollView.contentOffset;
    int x = (point.x + _scrollView.bounds.size.width/2)/_scrollView.bounds.size.width;
    for (int i = 0; i < 5; i++) {
        UIView *subView = [_signView viewWithTag:i+1];
        if (i == x) {
            subView.backgroundColor = [UIColor redColor];
        }
        else
        {
            subView.backgroundColor = [UIColor grayColor];
        }
    }
}

#pragma mark - NSNotification

- (void)cityGetAdcode:(NSNotification *)notification
{
    NSString *adcode = notification.object;
    
    [QLoadingView showDefaultLoadingView:@"加载中"];
    
    GetCityInfoRequest *cityinfoRequest = [[GetCityInfoRequest alloc] init];
    cityinfoRequest.current_city = adcode;
    cityinfoRequest.dialog_id = @"1";
    [_netApi getCityInfoAction:cityinfoRequest];

    NSLog(@"%@",adcode);
}

- (void)getTaskResAction:(GetTaskResRequest *)request
{
    [_netApi getTaskResAction:request];
}

#pragma mark - tableview Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  ceil([self.cellDataObj  count]/3.0);
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return NewSectionHeaderHeight;
    }
    return 1.0;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return NewTaskCellHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (view) {
        [view addSubview:_scrollView];
        [view addSubview:_signView];
        
        CGSize size = view.bounds.size;
        _signView.center = CGPointMake(size.width - 70, size.height - 20);
        
        CGPoint point = _scrollView.contentOffset;
        int x = (point.x + _scrollView.bounds.size.width/2)/_scrollView.bounds.size.width;
        point.x = x*_scrollView.bounds.size.width;
        [_scrollView setContentOffset:point animated:YES];
        
        [self setSubViewRed];
    }
    return view;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"cellIdentifier1";
    NewTaskTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil )
    {
        cell = [[NewTaskTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    int offsetCount = [self.cellDataObj count]%3;
    int startIndex = (int)indexPath.row * 3;
    int endIndex = (int)indexPath.row * 3 + 3;
    if ((int)indexPath.row * 3 + 3 > [self.cellDataObj count]) {
        endIndex = (int)indexPath.row * 3 + offsetCount;
    }
   
    NSMutableArray *array = [NSMutableArray array];
    for (int i = startIndex; i < endIndex; i++) {
        TaskInfoObject *object = [self.cellDataObj objectAtIndex:i];
        [array addObject:object];
    }
    [cell SetTaskInfoWith:array];
    
    cell.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    return cell;
    
    
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark - UIScrollView  delegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView;
{
    if (scrollView ==  _scrollView) {
        [self setSubViewRed];
    }
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (scrollView ==  _scrollView) {
        CGPoint point = scrollView.contentOffset;
        int x = (point.x + scrollView.bounds.size.width/2)/scrollView.bounds.size.width;
        point.x = x*scrollView.bounds.size.width;
        [scrollView setContentOffset:point animated:YES];
        
        [self setSubViewRed];
    }
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (scrollView ==  _scrollView) {
        CGPoint point = scrollView.contentOffset;
        int x = (point.x + scrollView.bounds.size.width/2)/scrollView.bounds.size.width;
        point.x = x*scrollView.bounds.size.width;
        [scrollView setContentOffset:point animated:YES];
        
        [self setSubViewRed];
    }
    
}

#pragma mark - netapi delegate
/*!
 @brief 当请求发生错误时，会调用代理的此方法.
 @param request 发生错误的请求.
 @param error   返回的错误.
 */
- (void)netRequest:(id)request didFailWithError:(NSError *)error
{
    [QLoadingView hideWithAnimated:NO];
    ZJRequest *requestObject = (ZJRequest *)request;
    switch (requestObject.requestType) {
        case ZJNetType_GetCityInfo:
        {
            [AppUtils showAlertMessage:@"获取城市窗口数据失败"];
        }
            break;
            
        default:
            break;
    }
}
/*!
 @brief 获取城市窗口任务信息的回调函数
 @param request 发起请求的请求选项(具体字段参考GetCityInfoRequest类中的定义)
 @param response 请求结果(具体字段参考GetCityInfoResponse类中的定义)
 */
- (void)onGetCityInfoDone:(GetCityInfoRequest *)request response:(GetCityInfoResponse *)response
{
    for (TaskInfoObject *object in response.cityInfoArray) {
         NSLog(@"onGetCityInfoDone %@",object.advertiser);
        GetTaskResRequest *resRequest = [[GetTaskResRequest alloc] init];
        resRequest.isimg = @"1";
        resRequest.describe_id = object.describe_id;
        resRequest.task_id = object.task_id;
        resRequest.type = object.type;
        resRequest.res_id = @"0";
        
        [self getTaskResAction:resRequest];
    }
    
    self.cellDataObj = [NSArray arrayWithArray:response.cityInfoArray];
//    [self.tableView reloadData];
}

/*!
 @brief 获取资源的回调函数
 @param request 发起请求的请求选项(具体字段参考GetTaskResRequest类中的定义)
 @param response 请求结果(具体字段参考GetTaskResResponse类中的定义)
 */
- (void)onGetResDone:(GetTaskResRequest *)request response:(GetTaskResResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    for (TaskInfoObject *object in self.cellDataObj) {
        if ([object.task_id isEqualToString:request.task_id])
        {
            object.image = response.image;
        }
    }
    [self.tableView reloadData];
    NSLog(@"onGetResDone");
}

@end
