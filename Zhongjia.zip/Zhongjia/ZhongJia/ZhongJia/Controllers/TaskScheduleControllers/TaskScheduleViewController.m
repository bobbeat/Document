//
//  TaskScheduleViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/25.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "TaskScheduleViewController.h"
#import "HistoryListViewController.h"
#import "UIImage+Category.h"
#import "CurrentTaskViewController.h"
#import "TaskRecordViewController.h"
#import "StickerMessageViewController.h"

@interface TaskScheduleViewController ()
{
    UIImageView *_imageViewSawtooth;
    UIImageView *_imageViewTaskScheEmpty;
    UIImageView *_imageViewTaskScheFull;
    int _percentOfTask;
    UILabel *_labelPercent;
    UILabel *_labelCurTip;
}

@end

@implementation TaskScheduleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    CGSize size = self.view.bounds.size;
    UIImage *image = [UIImage imageNamed:@"bg_sawtooth"];
    
    UIImage *stretchableButtonImageNormal = [image stretchableImageWithLeftCapWidth:1 topCapHeight:1];
    _imageViewSawtooth = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, 200)];
    _imageViewSawtooth.image = stretchableButtonImageNormal;
    [self.view addSubview:_imageViewSawtooth];
    
    UIImage *logoimage = [UIImage imageNamed:@"task_sch_blue"];
    CGSize imagesize = [logoimage size];
    _imageViewTaskScheEmpty = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, imagesize.width, imagesize.height)];
    _imageViewTaskScheEmpty.image = logoimage;
    [self.view addSubview:_imageViewTaskScheEmpty];
    _imageViewTaskScheEmpty.center = CGPointMake(size.width/2, 100);
    
    logoimage = [UIImage imageNamed:@"task_sch_green"];
    imagesize = [logoimage size];
    _imageViewTaskScheFull = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, imagesize.width, imagesize.height)];
    _imageViewTaskScheFull.image = logoimage;
    [self.view addSubview:_imageViewTaskScheFull];
    _imageViewTaskScheFull.center = CGPointMake(size.width/2, 100);
    
    [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(TimeAction:) userInfo:nil repeats:YES];
    
    
    _labelPercent = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, size.width,100)];
    _labelPercent.font = [UIFont systemFontOfSize:20];
    _labelPercent.backgroundColor = [UIColor clearColor];
    _labelPercent.textAlignment = NSTextAlignmentCenter;
    _labelPercent.textColor = [UIColor greenColor];
    [self.view addSubview:_labelPercent];
    _labelPercent.center = CGPointMake(size.width/2, 95);
    
    _labelCurTip = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, size.width,100)];
    _labelCurTip.font = [UIFont systemFontOfSize:12];
    _labelCurTip.backgroundColor = [UIColor clearColor];
    _labelCurTip.textAlignment = NSTextAlignmentCenter;
    _labelCurTip.textColor = [UIColor grayColor];
    _labelCurTip.text = @"当前任务进度";
    [self.view addSubview:_labelCurTip];
    _labelCurTip.center = CGPointMake(size.width/2, 120);
    
    float buttonHeight = 60;
    float buttonOriY = 240;
    float imageEdgeR = 10;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_normal"]] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_high"]] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"btn_chetie_normal"] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:@"btn_chetie_highlight"] forState:UIControlStateHighlighted];
    [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, imageEdgeR)];
    [button setTitle:@"车贴信息" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(ButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.tag = 1;
    [self.view addSubview:button];
    button.frame = CGRectMake(0, buttonOriY, size.width/2, buttonHeight);
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_normal"]] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_high"]] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"btn_recTask_normal"] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:@"btn_recTask_highlight"] forState:UIControlStateHighlighted];
    [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, imageEdgeR)];
    [button setTitle:@"任务记录" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(ButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.tag = 2;
    [self.view addSubview:button];
    button.frame = CGRectMake(size.width/2, buttonOriY, size.width/2, buttonHeight);
    
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_normal"]] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_high"]] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"btn_curTask_normal"] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:@"btn_curTask_highlight"] forState:UIControlStateHighlighted];
    [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, imageEdgeR)];
    [button setTitle:@"当前任务" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(ButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.tag = 3;
    [self.view addSubview:button];
    button.frame = CGRectMake(0, buttonOriY + buttonHeight, size.width/2, buttonHeight);
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_normal"]] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_high"]] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"btn_hisTask_normal"] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:@"btn_hisTask_highlight"] forState:UIControlStateHighlighted];
    [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, imageEdgeR)];
    [button setTitle:@"历史任务" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(ButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    button.tag = 4;
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.view addSubview:button];
    button.frame = CGRectMake(size.width/2, buttonOriY + buttonHeight, size.width/2, buttonHeight);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}

#pragma mark - Action

- (void)ButtonAction:(UIButton *)button
{
    NSLog(@"%d",button.tag);
    switch (button.tag) {
        case 1:
        {
            StickerMessageViewController *ctl = [[StickerMessageViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [self.navigationController pushViewController:ctl animated:YES];
        }
            break;
        case 2:
        {
            TaskRecordViewController *ctl = [[TaskRecordViewController alloc] init];
            [self.navigationController pushViewController:ctl animated:YES];
        }
            break;
            
        case 3:{
            CurrentTaskViewController *ctl = [[CurrentTaskViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [self.navigationController pushViewController:ctl animated:YES];
        }
            
            break;
        case 4:{
            HistoryListViewController *ctl = [[HistoryListViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [self.navigationController pushViewController:ctl animated:YES];
        }
            
            break;
            
        default:
            break;
    }
}

-(void)TimeAction:(NSTimer *)timer
{
    UIImage *logoimage = [UIImage imageNamed:@"task_sch_green"];
    UIImage *image = [UIImage getRoundImageWithImage:logoimage from:0 to:(_percentOfTask*360.0)/100.0];
    _labelPercent.text = [NSString stringWithFormat:@"%d%@",_percentOfTask,@"%"];
    _imageViewTaskScheFull.image = image;
    _percentOfTask+=2;
    if (_percentOfTask > 100) {
        [timer invalidate];
    }
    
}



@end
