//
//  HistoryTableViewCell.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "HistoryTableViewCell.h"
#import "UIImage+Category.h"


@interface HistoryTableViewCell()
{
    UIImageView *_imageView;
    UILabel *_labelTaskName;
    UILabel *_labelTaskTime;
    UILabel *_labelTaskReward;
    
    UILabel *_labelTaskTimeContent;
    UILabel *_labelTaskRewardContent;
    
    UIImageView *_imageViewStatus;
}
@end

@implementation HistoryTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        NSArray *array = @[@"任务状态",@"订单号",@"用车时间",@"任务名称"];
        NSArray *array1 = @[@"已完成",@"122434356",@"2015.05.30",@"加州红葡萄酒代言任务"];
        
        float labelHeight = (HistoryCellHeight )/5;
        for (int i = 0; i < [array count]; i++) {
            
            if (i==0)
            {
                UIImage *image = [UIImage imageNamed:@"task_finish"];
                _imageViewStatus = [[UIImageView alloc] initWithFrame:CGRectMake(110, 10, 60, 25)];
                _imageViewStatus.image = image;//[UIImage getStrechableImageWith:image];
                [self addSubview:_imageViewStatus];
            }
            
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(30, 10 + i*labelHeight, 120, labelHeight)];
            label.backgroundColor = [UIColor clearColor];
            label.textAlignment = NSTextAlignmentLeft;
            label.textColor = [UIColor blackColor];
            label.font = [UIFont systemFontOfSize:14];
            label.text = [array objectAtIndex:i];
            [self addSubview:label];
            
            label = [[UILabel alloc] initWithFrame:CGRectMake(120, 10 + i*labelHeight, 180, labelHeight)];
            label.backgroundColor = [UIColor clearColor];
            label.textAlignment = NSTextAlignmentLeft;
            if (i==0)
            {
                label.textColor = [UIColor whiteColor];
            }
            else
            {
                label.textColor = [UIColor grayColor];
            }
            
            label.font = [UIFont systemFontOfSize:14];
            label.text = [array1 objectAtIndex:i];
            [self addSubview:label];
            
            self.backgroundColor = [UIColor whiteColor];
            
            
        }
    }
    return self;
}
@end
