//
//  HistoryDetailViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "HistoryDetailViewController.h"
#import "CustomCellData.h"
#import "HistoryTableViewCell.h"

@interface HistoryDetailViewController ()

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation HistoryDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"历史任务详情";
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = @"";
    [sectionArray addObject:cellData];
    
    
    NSMutableArray *sectionArray1 = [NSMutableArray array];
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"总里程";
    cellData.detailText = @"274.4公里";
    [sectionArray1 addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"总时长";
    cellData.detailText = @"90天";
    [sectionArray1 addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"起租价";
    cellData.detailText = @"13.00";
    [sectionArray1 addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"实际支付";
    cellData.detailText = @"900";
    [sectionArray1 addObject:cellData];
    
    self.cellDataObj = @[sectionArray,sectionArray1];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - buuton action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - tableview Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  [[self.cellDataObj objectAtIndex:section] count];;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 80;
    }
    return 15.0;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        return HistoryCellHeight;
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        CGSize size = self.view.bounds.size;
        UIImage *image = [UIImage imageNamed:@"bg_sawtooth"];
        
        UIImage *stretchableButtonImageNormal = [image stretchableImageWithLeftCapWidth:1 topCapHeight:1];
        UIImageView *_imageViewSawtooth = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, 30)];
        _imageViewSawtooth.image = stretchableButtonImageNormal;
        [view addSubview:_imageViewSawtooth];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20, 40, size.width, 40)];
        label.backgroundColor = [UIColor clearColor];
        label.textAlignment = NSTextAlignmentLeft;
        label.font = [UIFont boldSystemFontOfSize:18];
        label.textColor = [UIColor blackColor];
        label.text = @"加州红葡萄酒代言任务";
        [view addSubview:label];
    }
    return view;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1)
    {
        static NSString *cellIdentifier = @"cellIdentifier";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell == nil )
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
        }
        
        CustomCellData *data = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.textLabel.text = data.text;
        cell.detailTextLabel.text = data.detailText;
        return cell;
    }
    else
    {
        static NSString *cellIdentifier = @"cellIdentifier1";
        HistoryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell == nil )
        {
            cell = [[HistoryTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        CustomCellData *data = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryType = UITableViewCellAccessoryNone;
        //    cell.textLabel.text = data.text;
        //    cell.imageView.image = data.image;
        return cell;
    }
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    HistoryDetailViewController *ctl = [[HistoryDetailViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:ctl animated:YES];
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

@end
