//
//  TaskRecordViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "TaskRecordViewController.h"

@interface TaskRecordViewController ()
{
    UIImageView *_imageViewStart;
    UIImageView *_imageViewEnd;
}

@end

@implementation TaskRecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"任务记录";
    
    CGSize size = self.view.bounds.size;
    float sawHeight = 105;
    _imageViewStart = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 121, 121)];
    _imageViewStart.image = [UIImage imageNamed:@"task_start"];
    [self.view addSubview:_imageViewStart];
    _imageViewStart.center = CGPointMake(size.width/2, 100);
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0 , 0, 121, 121)];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blueColor];
    label.font = [UIFont boldSystemFontOfSize:20];
    label.text = @"开始任务";
    [_imageViewStart addSubview:label];
    
    
    _imageViewEnd = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 121, 121)];
    _imageViewEnd.image = [UIImage imageNamed:@"task_end"];
    [self.view addSubview:_imageViewEnd];
    _imageViewEnd.center = CGPointMake(size.width/2, size.height - 160);
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(0 , 0, 121, 121)];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor greenColor];
    label.font = [UIFont boldSystemFontOfSize:20];
    label.text = @"任务结束";
    [_imageViewEnd addSubview:label];
    
    float height = (_imageViewEnd.center.y -  _imageViewStart.center.y - 121)/3;
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 15, 15)];
    imageView.image = [UIImage imageNamed:@"task_running_blue"];
    [self.view addSubview:imageView];
    imageView.center = CGPointMake(size.width/2, _imageViewStart.center.y + 30 + height);
    
    imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    imageView.image = [UIImage imageNamed:@"task_running_blue"];
    [self.view addSubview:imageView];
    imageView.center = CGPointMake(size.width/2, _imageViewStart.center.y + 30 + height*2);
    
    UIImageView *car = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 17, 10)];
    car.image = [UIImage imageNamed:@"task_run_car"];
    [imageView addSubview:car];
    car.center = CGPointMake(15,15);
    
    imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 15, 15)];
    imageView.image = [UIImage imageNamed:@"task_running_gray"];
    [self.view addSubview:imageView];
    imageView.center = CGPointMake(size.width/2, _imageViewStart.center.y + 30 + height*3);
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
