//
//  StickerMessageViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "StickerMessageViewController.h"
#import "CustomCellData.h"
#import "StickerTackViewController.h"

#define StickerCellHeight 400

@interface StickerTabelViewCell : UITableViewCell
{
    UIImageView *_imageViewHead;
    UIImageView *_imageTipBox;
    
    UILabel *_labelName;
    UILabel *_labelUploadTime;
    UILabel *_labelLastTime;
    
    UIImageView *_imageViewStikcerUp;
    UIImageView *_imageViewStikcerDown;
}

@end

@implementation StickerTabelViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        CGSize size = self.bounds.size;
        size.height = StickerCellHeight;
        
        UIImage *image = [UIImage imageNamed:@"img_info_head"];
        UIImage *roundImage = [UIImage getRoundImageWithImage:image from:0 to:360];
        _imageViewHead = [[UIImageView alloc] initWithFrame:CGRectMake(10, 15, 60, 60)];
        _imageViewHead.image = roundImage;
        [self addSubview:_imageViewHead];
        
        UIImageView *levelImageView = [[UIImageView alloc] initWithFrame:CGRectMake(_imageViewHead.bounds.size.width-16, _imageViewHead.bounds.size.height-16, 16, 16)];
        levelImageView.image = [UIImage imageNamed:@"vip_level"];
        [_imageViewHead addSubview:levelImageView];
        
        float offsetY = 40;
        _imageTipBox = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 19, 17)];
        _imageTipBox.image = [UIImage imageNamed:@"btn_box_normal"];
        [self addSubview:_imageTipBox];
        _imageTipBox.center = CGPointMake(size.width - 30, offsetY);
        
        
        
        _labelName = [[UILabel alloc] initWithFrame:CGRectMake(20, 40, size.width - 150, 40)];
        _labelName.backgroundColor = [UIColor clearColor];
        _labelName.textAlignment = NSTextAlignmentLeft;
        _labelName.font = [UIFont boldSystemFontOfSize:16];
        _labelName.textColor = [UIColor blackColor];
        _labelName.text = @"用户名";
        [self addSubview:_labelName];
        _labelName.center = CGPointMake(size.width/2, offsetY);
        
        _labelUploadTime = [[UILabel alloc] initWithFrame:CGRectMake(20, 40, size.width - 150, 40)];
        _labelUploadTime.backgroundColor = [UIColor clearColor];
        _labelUploadTime.textAlignment = NSTextAlignmentLeft;
        _labelUploadTime.font = [UIFont boldSystemFontOfSize:12];
        _labelUploadTime.textColor = [UIColor grayColor];
        _labelUploadTime.text = @"2014年10月1日车贴上传";
        [self addSubview:_labelUploadTime];
        _labelUploadTime.center = CGPointMake(size.width/2, offsetY + 30);
        
        _labelName = [[UILabel alloc] initWithFrame:CGRectMake(20, 40, size.width - 50, 40)];
        _labelName.backgroundColor = [UIColor clearColor];
        _labelName.textAlignment = NSTextAlignmentRight;
        _labelName.font = [UIFont boldSystemFontOfSize:12];
        _labelName.textColor = [UIColor grayColor];
        _labelName.text = @"五分钟前";
        [self addSubview:_labelName];
        _labelName.center = CGPointMake(size.width/2, offsetY+30);
        
        float stickerImageHeight = (size.height - _labelName.frame.origin.y - _labelName.frame.size.height)/2;
        _imageViewStikcerUp = [[UIImageView alloc] initWithFrame:CGRectMake(10,_labelName.frame.origin.y + 50 , size.width-20,stickerImageHeight )];
        _imageViewStikcerUp.image = [UIImage imageNamed:@"img_sticker"];
        [self addSubview:_imageViewStikcerUp];
        
        
        _imageViewStikcerDown = [[UIImageView alloc] initWithFrame:CGRectMake(10,_labelName.frame.origin.y + 50 + stickerImageHeight , size.width-20,stickerImageHeight )];
        _imageViewStikcerDown.image = [UIImage imageNamed:@"img_sticker"];
        [self addSubview:_imageViewStikcerDown];
    }
    return self;
}

@end

@interface StickerMessageViewController ()

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation StickerMessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"车贴信息";
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = @"";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"";
    [sectionArray addObject:cellData];
    
    self.cellDataObj = @[sectionArray];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:[UIImage imageNamed:@"btn_photo_normal"] forState:UIControlStateNormal
     ];
    [button setImage:[UIImage imageNamed:@"btn_photo_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(takePhotoAction) forControlEvents:UIControlEventTouchUpInside];
    barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - buuton action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)takePhotoAction
{
    StickerTackViewController *ctl = [[StickerTackViewController alloc] init];
    [self.navigationController pushViewController:ctl animated:YES];
}

#pragma mark - tableview Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  [[self.cellDataObj objectAtIndex:section] count];;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 20.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return StickerCellHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        
    }
    return view;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellIdentifier";
    StickerTabelViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil )
    {
        cell = [[StickerTabelViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
    }
    
    CustomCellData *data = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.textLabel.text = data.text;
    cell.detailTextLabel.text = data.detailText;
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


@end
