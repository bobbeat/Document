//
//  StickerTackViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "StickerTackViewController.h"

#define MAX_LETTER 200

@interface StickerTackViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate>
{
    UIImageView *_imageViewBackGround;
    UITextView *_textView;
    UILabel *_labelTip;
    UIImagePickerController *_picker;
    NSMutableArray *_arrayBtn;
    UIButton *_btnCurrentEdit;
}
@end

@implementation StickerTackViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"意见反馈";
    
    CGSize size = self.view.bounds.size;
    
    _arrayBtn = [NSMutableArray array];
    
    _imageViewBackGround = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width-30, 120)];
    _imageViewBackGround.image = [UIImage getStrechableImageWith:[UIImage imageNamed:@"more_input"]];
    [self.view addSubview:_imageViewBackGround];
    _imageViewBackGround.center = CGPointMake(size.width/2, 80);
    _imageViewBackGround.userInteractionEnabled = YES;
    
    _textView = [[UITextView alloc] initWithFrame:_imageViewBackGround.bounds];
    _textView.backgroundColor = [UIColor clearColor];
    _textView.keyboardType = UIKeyboardTypeDefault;
    _textView.returnKeyType = UIReturnKeyDone;
    _textView.delegate = self;
    _textView.textColor = [UIColor grayColor];
    _textView.text = @"这一刻的想法";
    [_imageViewBackGround addSubview:_textView];
    
    _labelTip = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, size.width - 30, 40)];
    _labelTip.backgroundColor = [UIColor clearColor];
    _labelTip.textAlignment = NSTextAlignmentRight;
    _labelTip.font = [UIFont systemFontOfSize:12];
    _labelTip.textColor = [UIColor blackColor];
    _labelTip.text = [NSString stringWithFormat:@"还可以输入%d字",MAX_LETTER];
    [self.view addSubview:_labelTip];
    _labelTip.center = CGPointMake(size.width/2, 152);
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"发表" forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 45, 40);
    [button addTarget:self action:@selector(sendAction) forControlEvents:UIControlEventTouchUpInside];
    barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = barButton;
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(textViewdDidChange:) name: UITextViewTextDidChangeNotification object: nil];
    
    [self addButtonForPhoto];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addButtonForPhoto
{
    CGSize size = self.view.bounds.size;
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:[UIImage imageNamed:@"btn_add_normal"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"btn_add_highlight"] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(addPhotoAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    btn.frame = CGRectMake(0, 0, 54, 54);
    [_arrayBtn addObject:btn];
    [self setButtonFrame];
}

- (void)setButtonFrame
{
    float offsetY = 190;
    for (int i = 0; i<[_arrayBtn count]; i++)
    {
        int x = i%5;
        int y = i/5;
        UIButton *button = [_arrayBtn objectAtIndex:i];
        button.tag = i;
        button.center = CGPointMake(15 + 27 + x*58, offsetY +y*60);
    }
}
#pragma mark - action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)sendAction
{
    
}

- (void)addPhotoAction:(UIButton *)button
{
    _btnCurrentEdit = button;
    
    if (button.tag == [_arrayBtn count] - 1) {
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"编辑" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"从相册中获取",@"手机拍照", nil];
        [actionSheet showInView:self.view];
    }
    else
    {
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"编辑" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"删除", nil];
        [actionSheet showInView:self.view];
        actionSheet.tag = 1;
    }
    
}

#pragma mark UITextField delegate

- (void)textViewdDidChange:(NSNotification *)notification
{
    UITextView *textView = nil;
    NSObject* obj = [notification object];
    if ([obj isKindOfClass:[UITextView class]])
    {
        textView = (UITextView*)obj;
        
    }
    if (textView)
    {
        _labelTip.text = [NSString stringWithFormat:@"还可以输入%lu字",MAX_LETTER - [textView.text  length]];
    }
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    textView.text = nil;
    return YES;
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
    }
    return YES;
}
- (void)textViewDidChange:(UITextView *)textView
{
    
}

- (void)textViewDidChangeSelection:(UITextView *)textView
{
    
}

#pragma mark - actionSheet
// Called when a button is clicked. The view will be automatically dismissed after this call returns
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (actionSheet.tag == 1)
    {
        switch (buttonIndex) {
            case 0:
            {
                [_btnCurrentEdit removeFromSuperview];
                [_arrayBtn removeObject:_btnCurrentEdit];
                [self setButtonFrame];
            }
                break;
            default:
                break;
        }
        
    }
    else
    {
        switch (buttonIndex) {
            case 0:
            {
                if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
                    _picker = [[UIImagePickerController alloc] init];
                    _picker.delegate = self;
                    _picker.allowsEditing = YES;
                    _picker.mediaTypes =[UIImagePickerController availableMediaTypesForSourceType:_picker.sourceType];
                    _picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                    [self presentViewController:_picker animated:NO completion:nil];
                } else {
                    UIAlertView *Myalert_ext = [[UIAlertView alloc] initWithTitle:nil message:@"该设备支持该功能" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                    [Myalert_ext show];
                }
            }
                break;
            case 1:
            {
                if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
                {
                    _picker = [[UIImagePickerController alloc]init];
                    _picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                    _picker.delegate = self;
                    _picker.allowsEditing = YES;
                    [self presentViewController:_picker animated:NO completion:nil];
                } else
                {
                    UIAlertView *Myalert_ext = [[UIAlertView alloc] initWithTitle:nil message:@"该设备支持该功能" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                    [Myalert_ext show];
                }
            }
                break;
            default:
                break;
        }
    }
}
#pragma mark-
#pragma mark UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    if (picker.sourceType==UIImagePickerControllerSourceTypeCamera ||
        picker.sourceType==UIImagePickerControllerSourceTypePhotoLibrary)
    {
        UIImage *originalImage = [info objectForKey:UIImagePickerControllerEditedImage];
        if (originalImage)
        {
            CGFloat scal = [[UIScreen mainScreen] scale];
            CGRect rect = CGRectMake(0, 0, originalImage.size.width/scal, originalImage.size.height/scal);
            
            [_btnCurrentEdit setBackgroundImage:[self scaleToSize:originalImage size:rect.size changeRect:rect] forState:UIControlStateNormal];
            [_btnCurrentEdit setImage:nil forState:UIControlStateNormal];
            [_btnCurrentEdit setImage:nil forState:UIControlStateHighlighted];
            [self addButtonForPhoto];
        }
    }
    [picker dismissViewControllerAnimated:NO completion:nil];
    _picker = nil;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:NO completion:nil];
    _picker = nil;
}

- (void)saveTheImage:(UIImage*)image
{
    NSString *uniquePath = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"selectedImage.png"];
    [UIImagePNGRepresentation(image) writeToFile: uniquePath atomically:YES];
    
    
}

//图片缩放到指定大小尺寸
- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size changeRect:(CGRect)changRect
{
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(size);
    // 绘制改变大小的图片
    [img drawInRect:changRect];
    // 从当前context中创建一个改变大小后的图片
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    // 返回新的改变大小后的图片
    return scaledImage;
}


@end
