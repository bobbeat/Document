//
//  CurrentTaskViewController.h
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "BaseTableViewController.h"

@interface CurrentTaskViewController : BaseTableViewController

@end
