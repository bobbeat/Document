//
//  FeedbackViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/28.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "FeedbackViewController.h"
#import "UIImage+Category.h"

#define MAX_LETTER 200

@interface FeedbackViewController ()<UITextViewDelegate>
{
    UIImageView *_imageViewBackGround;
    UIButton *_btnSubmit;
    UITextView *_textView;
    UILabel *_labelTip;
}

@property (nonatomic,copy) NSString *editStr;

@end

@implementation FeedbackViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"意见反馈";
    
    CGSize size = self.view.bounds.size;
    
    _btnSubmit = [UIButton buttonWithType:UIButtonTypeCustom];
    [_btnSubmit setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_normal.png"]] forState:UIControlStateNormal];
    [_btnSubmit setTitle:@"提交" forState:UIControlStateNormal];
    [_btnSubmit setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_highlight.png"]] forState:UIControlStateHighlighted];
    [_btnSubmit addTarget:self action:@selector(SubmitAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_btnSubmit];
    _btnSubmit.frame = CGRectMake(0, 0, size.width-30, 40);
    _btnSubmit.center = CGPointMake(size.width/2, 220);
    
    _imageViewBackGround = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width-30, 150)];
    _imageViewBackGround.image = [UIImage getStrechableImageWith:[UIImage imageNamed:@"more_input"]];
    [self.view addSubview:_imageViewBackGround];
    _imageViewBackGround.center = CGPointMake(size.width/2, 90);
    _imageViewBackGround.userInteractionEnabled = YES;
    
    _textView = [[UITextView alloc] initWithFrame:_imageViewBackGround.bounds];
    _textView.backgroundColor = [UIColor clearColor];
    _textView.keyboardType = UIKeyboardTypeDefault;
    _textView.returnKeyType = UIReturnKeyDone;
    _textView.delegate = self;
    _textView.textColor = [UIColor grayColor];
    _textView.text = @"欢迎你提出试用众加传媒客户端的感受和建议，我们期待您的声音。";
    [_imageViewBackGround addSubview:_textView];
    
    _labelTip = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, size.width - 30, 40)];
    _labelTip.backgroundColor = [UIColor clearColor];
    _labelTip.textAlignment = NSTextAlignmentRight;
    _labelTip.font = [UIFont systemFontOfSize:12];
    _labelTip.textColor = [UIColor blackColor];
    _labelTip.text = [NSString stringWithFormat:@"还可以输入%d字",MAX_LETTER];
    [self.view addSubview:_labelTip];
    _labelTip.center = CGPointMake(size.width/2, 182);
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
     [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(textViewdDidChange:) name: UITextViewTextDidChangeNotification object: nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)SubmitAction
{
    
}

#pragma mark UITextField delegate

- (void)textViewdDidChange:(NSNotification *)notification
{
    UITextView *textView = nil;
    NSObject* obj = [notification object];
    if ([obj isKindOfClass:[UITextView class]])
    {
        textView = (UITextView*)obj;
        
    }
    if (textView)
    {
        self.editStr = textView.text;
        _labelTip.text = [NSString stringWithFormat:@"还可以输入%lu字",MAX_LETTER - [self.editStr  length]];
    }
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    textView.text = nil;
    return YES;
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
    }
    return YES;
}
- (void)textViewDidChange:(UITextView *)textView
{
    
}

- (void)textViewDidChangeSelection:(UITextView *)textView
{
    
}

@end
