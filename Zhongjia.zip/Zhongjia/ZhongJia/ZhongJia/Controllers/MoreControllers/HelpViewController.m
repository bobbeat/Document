//
//  HelpViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/28.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "HelpViewController.h"

@interface HelpViewController ()
{
    UIImageView *_imageViewUp;
    UIImageView *_imageViewDown;
}

@end

@implementation HelpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"常见问题帮助";
    
    CGSize size = self.view.bounds.size;
    
    _imageViewUp = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width-30, 210)];
    _imageViewUp.image = [UIImage getStrechableImageWith:[UIImage imageNamed:@"more_input"]];
    [self.view addSubview:_imageViewUp];
    _imageViewUp.center = CGPointMake(size.width/2, 120);
    _imageViewUp.userInteractionEnabled = YES;
    
    _imageViewDown = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width-30, 230)];
    _imageViewDown.image = [UIImage getStrechableImageWith:[UIImage imageNamed:@"more_input"]];
    [self.view addSubview:_imageViewDown];
    _imageViewDown.center = CGPointMake(size.width/2, 360);
    _imageViewDown.userInteractionEnabled = YES;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
