//
//  AboutUsViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/28.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "AboutUsViewController.h"


@interface AboutUsViewController ()
{
    UIImageView *_imageViewUp;
    UIImageView *_imageViewDown;
    
    UIImageView *_logoImageView;
    UIImageView *_logoHanziImageView;
    UIImageView *_qrcodeImageView;
    
    UILabel *_labelPhoneTip;
    UILabel *_labelPhone;
    
    UILabel *_labelWebTip;
    UILabel *_labelWeb;
    
    UILabel *_labelQrTip;
}


@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation AboutUsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"关于我们";
    
    CGSize size = self.view.bounds.size;
    
    self.tableView.contentSize = CGSizeMake(320, 528);
    
    _imageViewUp = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width-30, 210)];
    _imageViewUp.image = [UIImage getStrechableImageWith:[UIImage imageNamed:@"more_input"]];
    [self.view addSubview:_imageViewUp];
    _imageViewUp.center = CGPointMake(size.width/2, 120);
    _imageViewUp.userInteractionEnabled = YES;
    
    
    UIImage *logoimage = [UIImage imageNamed:@"logo.png"];
    CGSize size_logo = CGSizeMake(75, 75);
    _logoImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size_logo.width, size_logo.height)];
    _logoImageView.image = logoimage;
    [_imageViewUp addSubview:_logoImageView];
    _logoImageView.center = CGPointMake(_imageViewUp.bounds.size.width/2, size_logo.height/2+10);
    
    logoimage = [UIImage imageNamed:@"logo_hanzi.png"];
    size_logo = CGSizeMake(90, 20);
    _logoHanziImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size_logo.width, size_logo.height)];
    _logoHanziImageView.image = logoimage;
    [_imageViewUp addSubview:_logoHanziImageView];
    _logoHanziImageView.center = CGPointMake(_imageViewUp.bounds.size.width/2, 100);
    
    float offsetY = 105;
    _labelPhoneTip = [[UILabel alloc] initWithFrame:CGRectMake(10, offsetY, 120, 40)];
    _labelPhoneTip.backgroundColor = [UIColor clearColor];
    _labelPhoneTip.textAlignment = NSTextAlignmentLeft;
    _labelPhoneTip.textColor = [UIColor grayColor];
    _labelPhoneTip.font = [UIFont systemFontOfSize:14];
    _labelPhoneTip.text = @"服务热线";
    [_imageViewUp addSubview:_labelPhoneTip];
    
    _labelPhone = [[UILabel alloc] initWithFrame:CGRectMake(60, offsetY + 22, 120, 40)];
    _labelPhone.backgroundColor = [UIColor clearColor];
    _labelPhone.textAlignment = NSTextAlignmentLeft;
    _labelPhone.textColor = [UIColor blackColor];
    _labelPhone.font = [UIFont systemFontOfSize:18];
    _labelPhone.text = @"1010 1111";
    [_imageViewUp addSubview:_labelPhone];
    
    _labelWebTip = [[UILabel alloc] initWithFrame:CGRectMake(10, offsetY + 42, 120, 40)];
    _labelWebTip.backgroundColor = [UIColor clearColor];
    _labelWebTip.textAlignment = NSTextAlignmentLeft;
    _labelWebTip.textColor = [UIColor grayColor];
    _labelWebTip.font = [UIFont systemFontOfSize:14];
    _labelWebTip.text = @"官方网站";
    [_imageViewUp addSubview:_labelWebTip];
    
    _labelWeb = [[UILabel alloc] initWithFrame:CGRectMake(60, offsetY + 62, 180, 40)];
    _labelWeb.backgroundColor = [UIColor clearColor];
    _labelWeb.textAlignment = NSTextAlignmentLeft;
    _labelWeb.textColor = [UIColor blackColor];
    _labelWeb.font = [UIFont systemFontOfSize:18];
    _labelWeb.text = @"www.zhongjia.com";
    [_imageViewUp addSubview:_labelWeb];
    
    
    
    _imageViewDown = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width-30, 230)];
    _imageViewDown.image = [UIImage getStrechableImageWith:[UIImage imageNamed:@"more_input"]];
    [self.view addSubview:_imageViewDown];
    _imageViewDown.center = CGPointMake(size.width/2, 360);
    _imageViewDown.userInteractionEnabled = YES;
    
    
    logoimage = [UIImage imageNamed:@"img_Qrcode"];
    size_logo = CGSizeMake(164, 164);
    _qrcodeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size_logo.width, size_logo.height)];
    _qrcodeImageView.image = logoimage;
    [_imageViewDown addSubview:_qrcodeImageView];
    _qrcodeImageView.center = CGPointMake(_imageViewDown.bounds.size.width/2, size_logo.height/2+20);
    
    _labelQrTip = [[UILabel alloc] initWithFrame:CGRectMake(10,_imageViewDown.bounds.size.height-30, _imageViewDown.bounds.size.width, 40)];
    _labelQrTip.backgroundColor = [UIColor clearColor];
    _labelQrTip.textAlignment = NSTextAlignmentCenter;
    _labelQrTip.textColor = [UIColor blackColor];
    _labelQrTip.font = [UIFont systemFontOfSize:14];
    _labelQrTip.text = @"扫一扫上面的二维码图案，关注微信";
    [_imageViewDown addSubview:_labelQrTip];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 15.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 120;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {

    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"loginIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    return cell;
}

@end
