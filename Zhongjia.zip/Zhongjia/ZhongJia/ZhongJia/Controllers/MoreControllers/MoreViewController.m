//
//  WorkspaceViewController.m
//  RoadFreightage
//
//  Created by mac on 15/6/2.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "MoreViewController.h"
#import "ZJNetAPI.h"
#import "CustomCellData.h"
#import "HelpViewController.h"
#import "UserAgreementViewController.h"
#import "AboutUsViewController.h"
#import "FeedbackViewController.h"

@interface MoreViewController ()<ZJNetDelegate>
{
    ZJNetAPI * _syNet;
    UIImageView *_logoImageView;
    UILabel *_versionLabel;
}

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation MoreViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _syNet = [[ZJNetAPI alloc] init];
    _syNet.delegate = self;
    
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = @"常见问题帮助";
    cellData.image = [UIImage imageNamed:@"btn_normal_question"];
    __block MoreViewController *weakself = self;
    cellData.cellActionBlock = ^(id object){
        HelpViewController *ctl = [[HelpViewController alloc] init];
        [weakself.navigationController pushViewController:ctl animated:YES];
    };
    
    CustomCellData *feedBackData = [[CustomCellData alloc] init];
    feedBackData.text = @"用户协议";
    feedBackData.image = [UIImage imageNamed:@"btn_agreement"];
    //   __block MoreViewController *weakself = self;
    feedBackData.cellActionBlock = ^(id object){
        UserAgreementViewController *ctl = [[UserAgreementViewController alloc] init];
        [weakself.navigationController pushViewController:ctl animated:YES];
    };
    
    CustomCellData *rateData = [[CustomCellData alloc] init];
    rateData.text = @"关于我们";
    rateData.image = [UIImage imageNamed:@"btn_about_us"];
    //    __block MoreViewController *weakself = self;
    rateData.cellActionBlock = ^(id object){
        AboutUsViewController *ctl = [[AboutUsViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [weakself.navigationController pushViewController:ctl animated:YES];
    };
    
    CustomCellData *aboutData = [[CustomCellData alloc] init];
    aboutData.text = @"意见反馈";
    aboutData.image = [UIImage imageNamed:@"btn_feedback"];
    //    __block MoreViewController *weakself = self;
    aboutData.cellActionBlock = ^(id object){
        FeedbackViewController *ctl = [[FeedbackViewController alloc] init];
        [weakself.navigationController pushViewController:ctl animated:YES];
    };
    
    self.cellDataObj = @[@[cellData,feedBackData,rateData,aboutData]];
    
    UIImage *logoimage = [UIImage imageNamed:@"logo.png"];
    CGSize size = [logoimage size];
    _logoImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
    _logoImageView.image = logoimage;
    [self.view addSubview:_logoImageView];
    
    _versionLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120, 40)];
    _versionLabel.backgroundColor = [UIColor clearColor];
    _versionLabel.textAlignment = NSTextAlignmentCenter;
    _versionLabel.textColor = [UIColor blackColor];
    _versionLabel.font = [UIFont systemFontOfSize:14];
    _versionLabel.text = @"版本号:V1.6.0";
    [self.view addSubview:_versionLabel];
    
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    CGSize size = [UIScreen mainScreen].bounds.size;
    _versionLabel.center = CGPointMake(size.width/2, size.height - 140);
    _logoImageView.center = CGPointMake(size.width/2, size.height - 190);
}

- (void)RightButtonPressed
{
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  [[self.cellDataObj objectAtIndex:section] count];;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    //    if (section != 0)
    //    {
    //        return 60;
    //    }
    return 10.0;
}

//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
//{
//    float height = [self tableView:tableView heightForHeaderInSection:section];
//    UIView *view = nil;
//    if (section == 0)
//    {
//        view = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
//    }
//    else
//    {
//        view = [_photoViewArray objectAtIndex:section - 1];
//    }
//    return view;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if ([self.cellDataObj count] - 1 == section) {
        return 100;
    }
    return 1.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"cellIdentifier1";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil )
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    CustomCellData *data = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    cell.textLabel.text = data.text;
    cell.imageView.image = data.image;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
    
    
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


@end
