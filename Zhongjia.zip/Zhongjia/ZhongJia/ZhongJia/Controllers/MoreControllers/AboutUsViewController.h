//
//  AboutUsViewController.h
//  ZhongJia
//
//  Created by mac on 15/7/28.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "BaseTableViewController.h"

@interface AboutUsViewController : BaseTableViewController

@end
