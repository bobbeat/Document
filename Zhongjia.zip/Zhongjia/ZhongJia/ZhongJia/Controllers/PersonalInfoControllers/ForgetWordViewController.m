//
//  LoginViewController.m
//  RoadFreightage
//
//  Created by mac on 15/6/3.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "ForgetWordViewController.h"
#import "CustomCellDataContainTextField.h"
#import "UIImage+Category.h"
#import "CustomTextFieldCell.h"
#import "ZJNetAPI.h"
#import "QLoadingView.h"
#import "UserDataOperator.h"
#import "MainTabBarController.h"

@interface ForgetWordViewController ()<UITextFieldDelegate,ZJNetDelegate>
{
    
    UIButton *_btnRegister;
    ZJNetAPI * _syNet;
    CustomTextFieldCell *_verificationCell;
}

@property (nonatomic,strong)  NSArray *cellDataObj;


@end

@implementation ForgetWordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _syNet = [[ZJNetAPI alloc] init];
    _syNet.delegate = self;
    
    self.title = @"找回密码";
    
    _btnRegister = [UIButton buttonWithType:UIButtonTypeCustom];
    [_btnRegister setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_normal.png"]] forState:UIControlStateNormal];
    [_btnRegister setTitle:@"确定" forState:UIControlStateNormal];
    [_btnRegister setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_highlight.png"]] forState:UIControlStateHighlighted];
    [_btnRegister addTarget:self action:@selector(loginAction) forControlEvents:UIControlEventTouchUpInside];
    
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellDataContainTextField *cellData = [[CustomCellDataContainTextField alloc] init];
    cellData.placeholder = @"输入您的手机号码";
    cellData.image = [UIImage imageNamed:@"user_phone"];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellDataContainTextField alloc] init];
    cellData.placeholder = @"请输入验证码";
    cellData.image = [UIImage imageNamed:@"user_smile"];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellDataContainTextField alloc] init];
    cellData.placeholder = @"6-20位长的密码";
    cellData.image = [UIImage imageNamed:@"user_lock"];
    [sectionArray addObject:cellData];
    
    self.cellDataObj = @[sectionArray];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
    self.navigationController.navigationBarHidden = NO;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(textFieldDidChange:) name: UITextFieldTextDidChangeNotification object: nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - buuton action

- (void)goBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)getVerificationCodeAction
{
    [QLoadingView showDefaultLoadingView:nil];
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:0];
    NSString *phone = cellData.cellFieldText;
    VerifyCodeRequest *verifyCode = [[VerifyCodeRequest alloc] init];
    verifyCode.requestType  = ZJNetType_VerifyCode;
    verifyCode.sid          = @"";
    verifyCode.userid       = 0;
    verifyCode.usertype     = @"owner";
    verifyCode.platform     = @"IOS";
    verifyCode.phone        = phone;
    
    [_syNet getVerifyCode:verifyCode];
}

- (void)loginAction
{
    [QLoadingView showDefaultLoadingView:nil];
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:0];
    NSString *phone = cellData.cellFieldText;
    
    cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:1];
    NSString *code = cellData.cellFieldText;
    
    LoginRequest *loginObj = [[LoginRequest alloc] init];

    [_syNet loginAction:loginObj];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 15.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 120;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        [view addSubview:_btnRegister];
        _btnRegister.bounds = CGRectMake(0, 0, view.bounds.size.width - 20, 40);
        _btnRegister.center = CGPointMake(view.bounds.size.width/2, view.bounds.size.height/2 - 10);
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"loginIdentifier";
    
    CustomTextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[CustomTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.cellTitle = cellData.text;
    cell.textField.placeholder = cellData.placeholder;
    cell.textField.delegate = self;
    cell.textField.tag = indexPath.row;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.imageView.image = cellData.image;
    if (indexPath.row == 1) {
        cell.isShowVerificationButton = YES;
    }
    else
    {
        cell.isShowVerificationButton = NO;
    }
    
    
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
}

#pragma mark UITextField delegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag == 2)
    {
        
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

- (void)textFieldDidChange:(NSNotification *)notification
{
    UITextField *textField = nil;
    NSObject* obj = [notification object];
    if ([obj isKindOfClass:[UITextField class]])
    {
        textField = (UITextField*)obj;
        
    }
    if (textField)
    {
        CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:textField.tag];
        cellData.cellFieldText = textField.text;
    }
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

#pragma mark - ZJNetDelegate

- (void)netRequest:(id)request didFailWithError:(NSError *)error;
{
    [QLoadingView hideWithAnimated:NO];
    
    NSLog(@"\r\n%s: netRequest = %@, errInfo= %@\r\n", __func__, [request class], error);
    if ([error.domain isEqualToString:ZJNetErrorDomain])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"error" message:[NSString stringWithFormat:@"%@ code:%ld",error.description,error.code ] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }
    
}

- (void)onVerifyCodeDone:(VerifyCodeRequest *)request response:(VerifyCodeResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    
    NSLog(@"\r\n%s: netRequest = %@, resoponse= %@\r\n", __func__, [request class], response);
}

- (void)onLoginDone:(LoginRequest *)request response:(LoginResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    MainTabBarController *ctl = [[MainTabBarController alloc] init];
    self.navigationController.viewControllers = @[ctl];
    
    [UserDataOperator SavaUserWithData:response];
    NSLog(@"\r\n%s: netRequest = %@, resoponse= %@\r\n", __func__, [request class], response);
    
}

@end
