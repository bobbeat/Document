//
//  MyPointsViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "MyPointsViewController.h"
#import "CustomCellData.h"

@interface PointsTableCell : UITableViewCell
{
    UILabel *_labelTask;
    UILabel *_labelTime;
    
}

@end

@implementation PointsTableCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _labelTask = [[UILabel alloc] initWithFrame:CGRectMake(20, 8, 280, 30)];
        _labelTask.text = @"";
        _labelTask.backgroundColor = [UIColor clearColor];
        _labelTask.textColor = [UIColor blackColor];
        _labelTask.font = [UIFont systemFontOfSize:16];
        [self addSubview:_labelTask];
        
        _labelTime = [[UILabel alloc] initWithFrame:CGRectMake(20, 27, 280, 30)];
        _labelTime.text = @"";
        _labelTime.backgroundColor = [UIColor clearColor];
        _labelTime.textColor = [UIColor grayColor];
        _labelTime.font = [UIFont systemFontOfSize:12];
        [self addSubview:_labelTime];
    }
    return self;
}

- (void)SetLabelTask:(NSString *)task time:(NSString *)time
{
    _labelTask.text = task;
    _labelTime.text = time;
}

@end
@interface MyPointsViewController ()
{
    UILabel *_labelTipRecord;
    UILabel *_labelPoints;
    UILabel *_labelCurrent;
    UIButton *_btnPointsUse;
    UIButton *_btnGoBack;
}

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation MyPointsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"我的积分";
    
    
    
    
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = @"完成代言任务";
    cellData.detailText = @"+260";
    cellData.otherObject = @"2015-06-08";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"完成代言任务";
    cellData.detailText = @"+260";
    cellData.otherObject = @"2015-06-08";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"完成代言任务";
    cellData.detailText = @"+260";
    cellData.otherObject = @"2015-06-08";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"完成代言任务";
    cellData.detailText = @"+260";
    cellData.otherObject = @"2015-06-08";
    [sectionArray addObject:cellData];
    
    self.cellDataObj = @[[NSMutableArray array],sectionArray];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

#pragma mark - buuton action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)exchangeAction
{
    NSLog(@"exchangeAction");
}

#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 220;
    }
    return 25.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    if (section == 0)
    {
        view.backgroundColor = [UIColor redColor];
        CGSize size = self.view.bounds.size;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(5, 20, 45, 41.5);
        [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
         ];
        [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
         ];
        [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:button];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, size.width, 40)];
        label.text = @"我的积分";
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont boldSystemFontOfSize:18];
        label.textAlignment = NSTextAlignmentCenter;
        [view addSubview:label];
        
        
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width - 30, height - 80)];
        imageView.center = CGPointMake(size.width/2, height - imageView.bounds.size.height/2 - 5);
        [view addSubview:imageView];
        imageView.backgroundColor = [UIColor clearColor];
        imageView.image = [UIImage getStrechableImageWith:[UIImage imageNamed:@"more_input"]];
        imageView.userInteractionEnabled = YES;
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 100, 30)];
        label.text = @"当前积分";
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor grayColor];
        label.font = [UIFont systemFontOfSize:14];
        [imageView addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(10, 30, size.width, 60)];
        label.text = @"36809";
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor greenColor];
        label.font = [UIFont systemFontOfSize:36];
        [imageView addSubview:label];
        
        CGSize pointsize = [label.text sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:36]}];
        label = [[UILabel alloc] initWithFrame:CGRectMake(pointsize.width+10, 35, 100, 60)];
        label.text = @"分";
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor greenColor];
        label.font = [UIFont systemFontOfSize:18];
        [imageView addSubview:label];
        
        UIButton *btnPointsUse = [UIButton buttonWithType:UIButtonTypeCustom];
        [btnPointsUse setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_normal.png"]] forState:UIControlStateNormal];
        [btnPointsUse setTitle:@"积分兑换商品" forState:UIControlStateNormal];
        [btnPointsUse setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_highlight.png"]] forState:UIControlStateHighlighted];
        [btnPointsUse addTarget:self action:@selector(exchangeAction) forControlEvents:UIControlEventTouchUpInside];
        [imageView addSubview:btnPointsUse];
        btnPointsUse.bounds = CGRectMake(0, 0, imageView.bounds.size.width-20, 40);
        btnPointsUse.center = CGPointMake(imageView.bounds.size.width/2, imageView.bounds.size.height - 30);
    }
    else
    {
        view.backgroundColor = [UIColor clearColor];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 200, 25)];
        label.text = @"最近30天积分记录";
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor grayColor];
        label.font = [UIFont systemFontOfSize:14];
        [view addSubview:label];
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    
    if (section == 0) {
        view.backgroundColor = [UIColor redColor];
    }else
    {
        view.backgroundColor = [UIColor clearColor];
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"loginIdentifier";
    
    PointsTableCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[PointsTableCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
    }
    
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell SetLabelTask:cellData.text time:cellData.otherObject];
    cell.detailTextLabel.text = cellData.detailText;
    cell.detailTextLabel.textColor = [UIColor greenColor];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
}


@end
