//
//  PersonalInfoViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/18.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "PersonalInfoViewController.h"
#import "ZJNetAPI.h"
#import "CustomCellData.h"
#import "LoginViewController.h"
#import "UIImage+Category.h"
#import "BaseCell.h"
#import "PhotoView.h"
#import "UserInfoEditView.h"
#import "CarColorViewController.h"
#import "UserDataOperator.h"
#import "CarBrandChooseViewController.h"
#import "CarTypeChooseViewController.h"

#define SectionHeight 200

@interface PersonalInfoViewController ()<ZJNetDelegate,PhotoChooseProtocol>
{
    ZJNetAPI * _netApi;
    PhotoView *_photoHead;
    PhotoView *_photoCar;
    PhotoView *_photoDrivingLicense;
}

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation PersonalInfoViewController

- (void)dealloc
{
    _photoHead = nil;
    _photoCar = nil;
    _photoDrivingLicense = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"个人信息";
    self.navigationController.navigationBarHidden = YES;
    
    _netApi = [[ZJNetAPI alloc] init];
    _netApi.delegate = self;
    
    _photoHead = [[PhotoView alloc] initWithController:self];
    _photoHead.delegate = self;
    
    _photoCar = [[PhotoView alloc] initWithController:self];
    _photoHead.delegate = self;
    
    _photoDrivingLicense = [[PhotoView alloc] initWithController:self];
    _photoHead.delegate = self;
    
    UserInfoObject *userData = [UserDataOperator getUserData];
    
    if (userData.userHeadImage) {
        _photoHead.imageView.image = userData.userHeadImage;
    }
    
    if (userData.userCardImage) {
        _photoDrivingLicense.imageView.image = userData.userCardImage;
    }
    
    if (userData.userCarImage) {
        _photoCar.imageView.image = userData.userCarImage;
    }

    CGSize size = self.view.bounds.size;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
    [self getUserInfo];
    [self getUserHead];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    CGSize size = self.view.bounds.size;
    self.navigationController.navigationBarHidden = NO;
    [self setUserData];
    [self.tableView reloadData];
}

#pragma mark - private

- (void)setUserData
{
    UserInfoObject *userData = [UserDataOperator getUserData];
    if (_photoHead.imageView.image) {
        userData.userHeadImage = _photoHead.imageView.image;
    }
    
    if (_photoDrivingLicense.imageView.image) {
        userData.userCardImage = _photoDrivingLicense.imageView.image;
    }
    
    if (_photoCar.imageView.image ) {
        userData.userCarImage = _photoCar.imageView.image ;
    }
    
    [UserDataOperator SavaUserWithData:userData];
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.detailText = @"";
    cellData.text = @"头像";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = userData.nickname;
    cellData.text = @"昵称";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = userData.tel;
    cellData.text = @"账号";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = userData.useraddr;
    cellData.text = @"地址";
    [sectionArray addObject:cellData];
    
    NSMutableArray *sectionArray1 = [NSMutableArray array];
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = userData.brand;
    cellData.text = @"我的爱车品牌";
    [sectionArray1 addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = userData.model;
    cellData.text = @"我的爱车车型";
    [sectionArray1 addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = userData.car_num;
    cellData.text = @"车牌";
    [sectionArray1 addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = userData.colour;
    cellData.text = @"车辆颜色";
    [sectionArray1 addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = @"";
    cellData.text = @"车辆正面照";
    [sectionArray1 addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.detailText = @"";
    cellData.text = @"车辆行驶证";
    [sectionArray1 addObject:cellData];
    
    self.cellDataObj = @[sectionArray,sectionArray1];
}

#pragma mark - action
- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)HeadPressed
{
    NSLog(@"_btnHead");
    LoginViewController *ctl = [[LoginViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:ctl animated:YES];
}

#pragma mark - 获取、更新头像

- (void)getUserHead
{
    UserInfoObject *userData = [UserDataOperator getUserData];
    
    GetUserResRequest *request = [[GetUserResRequest alloc] init];
    request.tel = userData.tel;
    request.type =  @"png";
    request.index =  @"1";
    [_netApi getUserResAction:request];
}

- (void)uploadUserHead:(UIImage *)image
{
    [QLoadingView showDefaultLoadingView:@"上传头像中"];
    UserInfoObject *userData = [UserDataOperator getUserData];
    
    UploadImageRequest *uploadImageRequest = [[UploadImageRequest alloc] init];
    uploadImageRequest.tel =  userData.tel;
    uploadImageRequest.index =  @"1";
    uploadImageRequest.image = image;
    [_netApi uploadImage:uploadImageRequest];

}

#pragma mark - 获取、更新用户信息
- (void)getUserInfo
{
    [QLoadingView showDefaultLoadingView:@"获取资料中"];
    
    UserInfoObject *userData = [UserDataOperator getUserData];
    GetUserInfoRequest *getUserInfo = [[GetUserInfoRequest alloc] init];
    getUserInfo.tel = userData.tel;
    [_netApi getUserInfoAction:getUserInfo];
}

- (void)updateUserInfo:(UserInfoObject *)userdata
{
    [QLoadingView showDefaultLoadingView:@"更新资料中"];
    
    UpdateUserInfoRequest *updateRequest = [[UpdateUserInfoRequest alloc] init];
    updateRequest.userInfoObject = userdata;
    [_netApi updateUserInfoAction:updateRequest];
}

#pragma mark - 获取、更新车辆信息
- (void)getCarInfo
{
    UserInfoObject *userData = [UserDataOperator getUserData];
    
    GetCarInfoRequest *getCarInfoRequest = [[GetCarInfoRequest alloc] init];
    getCarInfoRequest.tel = userData.tel;
    [_netApi getCarInfoAction:getCarInfoRequest];
    
}

- (void)updateCarInfo:(UserInfoObject *)userdata
{
    [QLoadingView showDefaultLoadingView:@"更新资料中"];
    
    UpdateCarInfoRequest *carInfo = [[UpdateCarInfoRequest alloc] init];
    carInfo.carInfoObject = userdata;
    [_netApi updateCarInfoAction:carInfo];

}

#pragma mark - PhotoChooseProtocol

-(void)FinishChooseWith:(PhotoView *)view image:(UIImage *)image
{
    [self uploadUserHead:image];
}

#pragma mark - Table view datasouce

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row == 0) {
        return 100;
    }
    else if (indexPath.section == 1 && indexPath.row == 4) {
        return 60;
    }
    else if (indexPath.section == 1 && indexPath.row == 5) {
        return 60;
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  [[self.cellDataObj objectAtIndex:section] count];;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    if (section == 0)
    {
        CGSize size = self.view.bounds.size;
        
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section == 1) {
        return 20;
    }
    return 1.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    if (section == 0) {

        
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"cellIdentifier1";
    BaseCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil )
    {
        cell = [[BaseCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
    }
    CustomCellData *data = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    cell.textLabel.text = data.text;
    cell.detailTextLabel.text = data.detailText;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.rightView = nil;
    cell.rightViewAnother = nil;
    if (indexPath.section == 0 && indexPath.row == 0) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        _photoHead.frame = CGRectMake(0, 0, _photoHead.imageView.image.size.width, _photoHead.imageView.image.size.height);
        cell.rightView = _photoHead;
    }
    else if (indexPath.section == 1 && indexPath.row == 4) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        _photoCar.frame = CGRectMake(0, 0, _photoCar.imageView.image.size.width, _photoCar.imageView.image.size.height);
        cell.rightView = _photoCar;
    }
    else if (indexPath.section == 1 && indexPath.row == 5) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        _photoDrivingLicense.frame = CGRectMake(0, 0, _photoDrivingLicense.imageView.image.size.width, _photoDrivingLicense.imageView.image.size.height);
        cell.rightView = _photoDrivingLicense;
    }
    
    return cell;
    
    
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    if (indexPath.section == 0) {
        if (indexPath.row == 0)
        {
            [_photoHead takePhoto];
        }
        else if (indexPath.row == 1)
        {
            [UserInfoEditView ShowEditViewWithTitle:cellData.text editStr:cellData.detailText finishBlock:^(NSString *editStr) {
                UserInfoObject *userData = [UserDataOperator getUserData];
                UserInfoObject *temp = [[UserInfoObject alloc] init];
                temp.tel = userData.tel;
                temp.nickname = editStr;
                [self updateUserInfo:temp];
            }];
        }
        else if (indexPath.row == 2)
        {
            
        }
        else if (indexPath.row == 3)
        {
            [UserInfoEditView ShowEditViewWithTitle:cellData.text editStr:cellData.detailText finishBlock:^(NSString *editStr) {
                UserInfoObject *userData = [UserDataOperator getUserData];
                UserInfoObject *temp = [[UserInfoObject alloc] init];
                temp.tel = userData.tel;
                temp.useraddr = editStr;
                [self updateUserInfo:temp];
            }];
        }
    }
    else if (indexPath.section == 1){
        if (indexPath.row == 0)
        {
            CarBrandChooseViewController *ctl = [[CarBrandChooseViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [self.navigationController pushViewController:ctl animated:YES];
        }
        else if (indexPath.row == 1)
        {
            CarTypeChooseViewController *ctl = [[CarTypeChooseViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [self.navigationController pushViewController:ctl animated:YES];
        }
        else if (indexPath.row == 2)
        {
            [UserInfoEditView ShowEditViewWithTitle:cellData.text editStr:cellData.detailText finishBlock:^(NSString *editStr) {
                UserInfoObject *userData = [UserDataOperator getUserData];
                UserInfoObject *temp = [[UserInfoObject alloc] init];
                temp.tel = userData.tel;
                temp.car_num = editStr;
                [self updateCarInfo:temp];
            }];
        }
        else if (indexPath.row == 3)
        {
            CarColorViewController *ctl = [[CarColorViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [self.navigationController pushViewController:ctl animated:YES];
        }
        else if (indexPath.row == 4)
        {
            [_photoCar takePhoto];
        }
        else if (indexPath.row == 5)
        {
            [_photoDrivingLicense takePhoto];
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark - netdelegate

/*!
 @brief 当请求发生错误时，会调用代理的此方法.
 @param request 发生错误的请求.
 @param error   返回的错误.
 */
- (void)netRequest:(id)request didFailWithError:(NSError *)error
{
    [QLoadingView hideWithAnimated:NO];
    ZJRequest *requestObject = (ZJRequest *)request;
    switch (requestObject.requestType) {
        case ZJNetType_UpdateUserInfo:
        {
            [AppUtils showAlertMessage:@"更新资料失败"];
        }
            break;
            
        default:
            break;
    }
}

/*!
 @brief 获取用户信息的回调函数
 @param request 发起请求的请求选项(具体字段参考GetUserInfoRequest类中的定义)
 @param response 请求结果(具体字段参考GetUserInfoResponse类中的定义)
 */
- (void)onGetUserInfoDone:(GetUserInfoRequest *)request response:(GetUserInfoResponse *)response
{
    NSDictionary *dic = [response.userInfoObject getProperties];
    
    UserInfoObject *userData = [UserDataOperator getUserData];
    [userData setPropertiesWirh:dic];
    
    [UserDataOperator SavaUserWithData:userData];
    
    [self getCarInfo];
}

/*!
 @brief 获取车辆信息的回调函数
 @param request 发起请求的请求选项(具体字段参考GetCarInfoRequest类中的定义)
 @param response 请求结果(具体字段参考GetCarInfoResponse类中的定义)
 */
- (void)onGetCarInfoDone:(GetCarInfoRequest *)request response:(GetCarInfoResponse *)response
{
    UserInfoObject *userObject = [response.carInfoArray firstObject];
    if (userObject) {
        NSDictionary *dic = [userObject getProperties];
        
        UserInfoObject *userData = [UserDataOperator getUserData];
        [userData setPropertiesWirh:dic];
        
        [UserDataOperator SavaUserWithData:userData];
        [self setUserData];
        [self.tableView reloadData];
    }
    
    [QLoadingView hideWithAnimated:NO];
}

/*!
 @brief 更新用户信息的回调函数
 @param request 发起请求的请求选项(具体字段参考UpdateUserInfoRequest类中的定义)
 @param response 请求结果(具体字段参考UpdateUserInfoResponse类中的定义)
 */
- (void)onUpdateUserInfoDone:(UpdateUserInfoRequest *)request response:(UpdateUserInfoResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    NSDictionary *dic = [request.userInfoObject getProperties];
    
    UserInfoObject *userData = [UserDataOperator getUserData];
    [userData setPropertiesWirh:dic];

    [UserDataOperator SavaUserWithData:userData];
    [self setUserData];
    [self.tableView reloadData];
    
}

/*!
 @brief 添加车辆信息的回调函数
 @param request 发起请求的请求选项(具体字段参考AddCarInfoRequest类中的定义)
 @param response 请求结果(具体字段参考AddCarInfoResponse类中的定义)
 */
- (void)onAddCarInfoDone:(AddCarInfoRequest *)request response:(AddCarInfoResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
}

/*!
 @brief 更新车辆信息的回调函数
 @param request 发起请求的请求选项(具体字段参考AddCarInfoRequest类中的定义)
 @param response 请求结果(具体字段参考AddCarInfoResponse类中的定义)
 */
- (void)onUpdateCarInfoDone:(UpdateCarInfoRequest *)request response:(UpdateCarInfoResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
}



/*!
 @brief 获取用户资源的回调函数
 @param request 发起请求的请求选项(具体字段参考GetUserResRequest类中的定义)
 @param response 请求结果(具体字段参考GetUserResResponse类中的定义)
 */
- (void)onGetUserResDone:(GetUserResRequest *)request response:(GetUserResResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    UserInfoObject *userData = [UserDataOperator getUserData];
    userData.userHeadImage = response.image;
    
    [UserDataOperator SavaUserWithData:userData];
    _photoHead.imageView.image = userData.userHeadImage;
}

/*!
 @brief 获取用户任务信息的回调函数
 @param request 发起请求的请求选项(具体字段参考GetUserTaskInfoRequest类中的定义)
 @param response 请求结果(具体字段参考GetUserTaskInfoResponse类中的定义)
 */
- (void)onGetUserTaskInfoDone:(GetUserTaskInfoRequest *)request response:(GetUserTaskInfoResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
}

/*!
 @brief 图片上传
 @param request 发起请求的请求选项(具体字段参考UploadImageRequest类中的定义)
 @param response 请求结果(具体字段参考UploadImageResponse类中的定义)
 */
- (void)onUploadImageDone:(UploadImageRequest *)request response:(UploadImageResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    UserInfoObject *userData = [UserDataOperator getUserData];
    userData.userHeadImage = request.image;
    
    [UserDataOperator SavaUserWithData:userData];
    
    [AppUtils showAlertMessage:@"上传成功"];
    _photoHead.imageView.image = userData.userHeadImage;
}


@end