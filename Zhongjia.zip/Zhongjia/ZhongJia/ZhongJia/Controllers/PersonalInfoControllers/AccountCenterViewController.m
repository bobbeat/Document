//
//  PersonalInfoViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/18.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "AccountCenterViewController.h"
#import "ZJNetAPI.h"
#import "CustomCellData.h"
#import "LoginViewController.h"
#import "UIImage+Category.h"
#import "LoginViewController.h"
#import "MyMessageViewController.h"
#import "MyPointsViewController.h"
#import "MySettingViewController.h"
#import "MyTaskViewController.h"
#import "UserDataOperator.h"
#import "PersonalInfoViewController.h"

#define SectionHeight 200

@interface AccountCenterViewController ()<ZJNetDelegate>
{
    ZJNetAPI * _syNet;
    UIImageView *_redBackgroundView;
    UILabel *_labelTip;
    UILabel *_labelMore;
    UIButton *_btnHead;
    UIButton *_btnGoBack;
    UIButton *_btnLogout;
}

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation AccountCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = YES;
    
    _syNet = [[ZJNetAPI alloc] init];
    _syNet.delegate = self;
    
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = @"我的任务";
    cellData.image = [UIImage imageNamed:@"ic_my_mission"];
    __block AccountCenterViewController *weakself = self;
    cellData.cellActionBlock = ^(id object){
        MyTaskViewController *ctl = [[MyTaskViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [weakself.navigationController pushViewController:ctl animated:YES];
    };
    
    CustomCellData *feedBackData = [[CustomCellData alloc] init];
    feedBackData.text = @"我的消息";
    feedBackData.image = [UIImage imageNamed:@"ic_my_message"];
    //   __block MoreViewController *weakself = self;
    feedBackData.cellActionBlock = ^(id object){
        MyMessageViewController *ctl = [[MyMessageViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [weakself.navigationController pushViewController:ctl animated:YES];
    };
    
    CustomCellData *rateData = [[CustomCellData alloc] init];
    rateData.text = @"我的积分";
    rateData.image = [UIImage imageNamed:@"ic_my_integral"];
    //    __block MoreViewController *weakself = self;
    rateData.cellActionBlock = ^(id object){
        MyPointsViewController *ctl = [[MyPointsViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [weakself.navigationController pushViewController:ctl animated:YES];
    };
    
    CustomCellData *aboutData = [[CustomCellData alloc] init];
    aboutData.text = @"设置";
    aboutData.image = [UIImage imageNamed:@"ic_setting"];
    //    __block MoreViewController *weakself = self;
    aboutData.cellActionBlock = ^(id object){
        MySettingViewController *ctl = [[MySettingViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [weakself.navigationController pushViewController:ctl animated:YES];
    };
    
    self.cellDataObj = @[@[cellData,feedBackData,rateData,aboutData]];
    
    CGSize size = self.view.bounds.size;
    _redBackgroundView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, SectionHeight)];
    _redBackgroundView.backgroundColor = [UIColor redColor];
    [self.view addSubview:_redBackgroundView];
    _redBackgroundView.userInteractionEnabled = YES;
    
    UIImage *headImage = [UIImage imageNamed:@"HeadImage.png"];
    _btnHead = [UIButton buttonWithType:UIButtonTypeCustom];
    _btnHead.frame = CGRectMake(10, 10, headImage.size.width, headImage.size.height);
    [_btnHead setBackgroundImage:headImage forState:UIControlStateNormal];
    [_btnHead addTarget:self action:@selector(HeadPressed) forControlEvents:UIControlEventTouchUpInside];
    [_redBackgroundView addSubview:_btnHead];
    
    _labelTip = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, size.width, 40)];
    _labelTip.backgroundColor = [UIColor clearColor];
    _labelTip.textColor = [UIColor whiteColor];
    _labelTip.textAlignment = NSTextAlignmentCenter;
    _labelTip.font = [UIFont systemFontOfSize:16];
    _labelTip.text = @"立即登陆众加";
    [_redBackgroundView addSubview:_labelTip];
    
    _labelMore = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, size.width, 40)];
    _labelMore.backgroundColor = [UIColor clearColor];
    _labelMore.textColor = [UIColor yellowColor];
    _labelMore.textAlignment = NSTextAlignmentCenter;
    _labelMore.font = [UIFont systemFontOfSize:14];
    _labelMore.text = @"体验更多功能";
    [_redBackgroundView addSubview:_labelMore];
    
    _btnGoBack = [UIButton buttonWithType:UIButtonTypeCustom];
    _btnGoBack.frame = CGRectMake(5, 20, 45, 41.5);
    [_btnGoBack setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [_btnGoBack setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    [_btnGoBack addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    [_redBackgroundView addSubview:_btnGoBack];
    
    _btnLogout = [UIButton buttonWithType:UIButtonTypeCustom];
    [_btnLogout addTarget:self action:@selector(Logout) forControlEvents:UIControlEventTouchUpInside];
    [_btnLogout setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_normal"]] forState:UIControlStateNormal];
    [_btnLogout setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_highlight"]] forState:UIControlStateHighlighted];
    [_btnLogout setTitle:@"退出登陆" forState:UIControlStateNormal];
    _btnLogout.frame = CGRectMake(0, 0, self.view.bounds.size.width-30, 45);
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    CGSize size = self.view.bounds.size;
    self.navigationController.navigationBarHidden = YES;
    
    [self setUIStatus];
    
}

- (void)setUIStatus
{
    if ([UserDataOperator getUserLoginStatus]) {
        _btnLogout.hidden = NO;
        
        UserInfoObject *response = [UserDataOperator getUserData];
        UIImage *headImage = [UIImage getRoundImageWithImage:response.userHeadImage from:0 to:360];
        [_btnHead setBackgroundImage:headImage forState:UIControlStateNormal];
        
        _labelTip.text = response.nickname;
        _labelMore.hidden = YES;
    }
    else
    {
        UIImage *temp = [UIImage imageNamed:@"HeadImage.png"];
        UIImage *headImage = [UIImage getRoundImageWithImage:temp from:0 to:360];
        [_btnHead setBackgroundImage:headImage forState:UIControlStateNormal];
        
        _btnLogout.hidden = YES;
        _labelTip.text = @"立即登陆众加";
        _labelMore.hidden = NO;
    }
}

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)Logout
{
    [UserDataOperator DestroyLocalUserData];
    [self setUIStatus];
}

- (void)HeadPressed
{
    if ([UserDataOperator getUserLoginStatus]) {
        _btnLogout.hidden = NO;
        
       PersonalInfoViewController *ctl = [[PersonalInfoViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [self.navigationController pushViewController:ctl animated:YES];

    }
    else
    {
        LoginViewController *ctl = [[LoginViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [self.navigationController pushViewController:ctl animated:YES];
    }
   
}

- (void)RightButtonPressed
{
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  [[self.cellDataObj objectAtIndex:section] count];;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return SectionHeight;
    }
    return 10.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    if (section == 0)
    {
        CGSize size = self.view.bounds.size;
        _redBackgroundView.frame = CGRectMake(0, 0, size.width, SectionHeight);
        _btnHead.center = CGPointMake(size.width/2, SectionHeight/2);
        _labelTip.center = CGPointMake(size.width/2, SectionHeight/2 + 50);
        _labelMore.center = CGPointMake(size.width/2, SectionHeight/2 + 70);
        view = _redBackgroundView;
        
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if ([self.cellDataObj count] - 1 == section) {
        return 100;
    }
    return 1.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    if (section == 0) {
        [view addSubview:_btnLogout];
        _btnLogout.center = CGPointMake(self.view.bounds.size.width/2, height/2);
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"cellIdentifier1";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil )
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    CustomCellData *data = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    cell.textLabel.text = data.text;
    cell.imageView.image = data.image;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
    
    
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


@end