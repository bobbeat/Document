//
//  MySettingViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "MySettingViewController.h"
#import "CustomCellData.h"

@interface MySettingViewController ()

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation MySettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"设置";
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = @"正文字号";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"信息推送";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"Wi-Fi自动离线";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"非Wi-Fi网络不上传图片";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"列表自动加载更多";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"手动清除缓存";
    cellData.detailText = @"1.07M";
    [sectionArray addObject:cellData];
    
    NSMutableArray *sectionArray1 = [NSMutableArray array];
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"检查更新";
    cellData.detailText = @"V1.6.0";
    [sectionArray1 addObject:cellData];
    
    self.cellDataObj = @[sectionArray,sectionArray1];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
}

#pragma mark - buuton action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)segmentAction:(UISegmentedControl *)sender
{
    NSLog(@"%lu",sender.selectedSegmentIndex);
}

- (void)switchAction:(UISwitch *)sender
{
     NSLog(@"%lu",sender.tag);
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 25.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        view.backgroundColor = [UIColor clearColor];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 200, height)];
        label.text = @"系统设置";
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor grayColor];
        label.font = [UIFont systemFontOfSize:14];
        [view addSubview:label];
    }
    else if (section == 1)
    {
        view.backgroundColor = [UIColor clearColor];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 200, height)];
        label.text = @"其他设置";
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor grayColor];
        label.font = [UIFont systemFontOfSize:14];
        [view addSubview:label];
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"loginIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
    }
    
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.text = cellData.text;
    cell.detailTextLabel.text = cellData.detailText;
    
    if (indexPath.section ==1)
    {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    else if (indexPath.section ==0 &&indexPath.row == 5)
    {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    else
    {
        if (indexPath.row == 0) {
            UISegmentedControl *control = [[UISegmentedControl alloc] initWithItems:@[@"大",@"中",@"小"]];
            control.frame = CGRectMake(0, 0, 90, 30);
            cell.accessoryView = control;
            
            [control addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
        }
        else
        {
            cell.accessoryType = UITableViewCellAccessoryNone;
            UISwitch *temp_switch = [[UISwitch alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
            temp_switch.backgroundColor = [UIColor clearColor];
            temp_switch.onImage = [UIImage imageNamed:@"on"];
            temp_switch.offImage = [UIImage imageNamed:@"off"];
            temp_switch.tag = indexPath.row;
            cell.accessoryView = temp_switch;
            
            [temp_switch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
}


@end
