//
//  LoginViewController.m
//  RoadFreightage
//
//  Created by mac on 15/6/3.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "RegisterViewController.h"
#import "CustomCellDataContainTextField.h"
#import "UIImage+Category.h"
#import "CustomTextFieldCell.h"
#import "ZJNetAPI.h"
#import "QLoadingView.h"
#import "UserDataOperator.h"
#import "MainTabBarController.h"

@interface RegisterViewController ()<UITextFieldDelegate,ZJNetDelegate>
{
    
    UIButton *_btnRegister;
    ZJNetAPI * _netApi;
    CustomTextFieldCell *_verificationCell;
}

@property (nonatomic,strong)  NSArray *cellDataObj;


@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _netApi = [[ZJNetAPI alloc] init];
    _netApi.delegate = self;

    self.title = @"注册";
    
    _btnRegister = [UIButton buttonWithType:UIButtonTypeCustom];
    [_btnRegister setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_normal.png"]] forState:UIControlStateNormal];
    [_btnRegister setTitle:@"注册" forState:UIControlStateNormal];
    [_btnRegister setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_highlight.png"]] forState:UIControlStateHighlighted];
    [_btnRegister addTarget:self action:@selector(registerAction) forControlEvents:UIControlEventTouchUpInside];
    
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellDataContainTextField *cellData = [[CustomCellDataContainTextField alloc] init];
    cellData.placeholder = @"输入您的手机号码";
    cellData.image = [UIImage imageNamed:@"user_phone"];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellDataContainTextField alloc] init];
    cellData.placeholder = @"请输入验证码";
    cellData.image = [UIImage imageNamed:@"user_smile"];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellDataContainTextField alloc] init];
    cellData.placeholder = @"6-20位长的密码";
    cellData.image = [UIImage imageNamed:@"user_lock"];
    [sectionArray addObject:cellData];
    
    self.cellDataObj = @[sectionArray];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
    self.navigationController.navigationBarHidden = NO;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(textFieldDidChange:) name: UITextFieldTextDidChangeNotification object: nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - buuton action

- (void)goBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)forgetAction
{
    NSLog(@"forgetAction");
}

- (void)registerAction
{
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:0];
    NSString *phone = cellData.cellFieldText;
    
    cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:2];
    NSString *password =  cellData.cellFieldText;
    
    if (![NSString checkPhoneStandardWith:phone])
    {
        [AppUtils showAlertMessage:@"请输入正确手机号码"];
        return;
    }
    
    if ([password length] == 0)
    {
        [AppUtils showAlertMessage:@"请输入密码"];
        return;
    }
    
    UserInfoObject *userData = [UserDataOperator getUserData];
    userData.tel = phone;
    userData.passwd = password;
    [UserDataOperator SavaUserWithData:userData];
    
    RegitsterRequest *request = [[RegitsterRequest alloc] init];
    request.tel = phone;
    request.passwd = password;
    request.nickname = @"众加用户";
    request.useraddr = @" ";
    [_netApi registerAction:request];
    
    [QLoadingView showDefaultLoadingView:@"注册中"];

}

- (void)getVerificationCodeAction
{
    [QLoadingView showDefaultLoadingView:nil];
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:0];
    NSString *phone = cellData.cellFieldText;
    VerifyCodeRequest *verifyCode = [[VerifyCodeRequest alloc] init];
    verifyCode.requestType  = ZJNetType_VerifyCode;
    verifyCode.sid          = @"";
    verifyCode.userid       = 0;
    verifyCode.usertype     = @"owner";
    verifyCode.platform     = @"IOS";
    verifyCode.phone        = phone;
    
    [_netApi getVerifyCode:verifyCode];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 15.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
       
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 120;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        [view addSubview:_btnRegister];
        _btnRegister.bounds = CGRectMake(0, 0, view.bounds.size.width - 20, 40);
        _btnRegister.center = CGPointMake(view.bounds.size.width/2, view.bounds.size.height/2 - 10);
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"loginIdentifier";
    
    CustomTextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[CustomTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.cellTitle = cellData.text;
    cell.textField.placeholder = cellData.placeholder;
    cell.textField.delegate = self;
    cell.textField.tag = indexPath.row;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.imageView.image = cellData.image;
    if (indexPath.row == 0) {
        cell.textField.secureTextEntry = NO;
        cell.isShowVerificationButton = NO;
    }
    else if (indexPath.row == 1)
    {
        cell.textField.secureTextEntry = NO;
        cell.isShowVerificationButton = YES;
    }
    else
    {
        cell.textField.secureTextEntry = YES;
        cell.isShowVerificationButton = NO;
    }
    
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
}

#pragma mark UITextField delegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag == 2)
    {
        
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

- (void)textFieldDidChange:(NSNotification *)notification
{
    UITextField *textField = nil;
    NSObject* obj = [notification object];
    if ([obj isKindOfClass:[UITextField class]])
    {
        textField = (UITextField*)obj;
        
    }
    if (textField)
    {
        CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:textField.tag];
        cellData.cellFieldText = textField.text;
    }
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

#pragma mark - ZJNetDelegate

/*!
 @brief 当请求发生错误时，会调用代理的此方法.
 @param request 发生错误的请求.
 @param error   返回的错误.
 */
- (void)netRequest:(id)request didFailWithError:(NSError *)error
{
    [QLoadingView hideWithAnimated:NO];
    [AppUtils showAlertMessage:@"失败"];
}

/*!
 @brief 请求注册的回调函数
 @param request 发起请求的请求选项(具体字段参考RegitsterRequest类中的定义)
 @param response 请求结果(具体字段参考RegitsterResponse类中的定义)
 */
- (void)onRegisterDone:(RegitsterRequest *)request response:(RegitsterResponse *)response
{
    NSDictionary *dic = [response.userInfoObject getProperties];
    UserInfoObject *userData = [UserDataOperator getUserData];
    [userData setPropertiesWirh:dic];
    
    [UserDataOperator SavaUserWithData:userData];
    
    [QLoadingView hideWithAnimated:NO];
    
    [AppUtils showAlertMessage:@"注册成功"];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)onVerifyCodeDone:(VerifyCodeRequest *)request response:(VerifyCodeResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    
    NSLog(@"\r\n%s: netRequest = %@, resoponse= %@\r\n", __func__, [request class], response);
}


@end
