//
//  LoginViewController.m
//  RoadFreightage
//
//  Created by mac on 15/6/3.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "LoginViewController.h"
#import "CustomCellDataContainTextField.h"
#import "UIImage+Category.h"
#import "CustomTextFieldCell.h"
#import "ZJNetAPI.h"
#import "QLoadingView.h"
#import "UserDataOperator.h"
#import "MainTabBarController.h"
#import "RegisterViewController.h"
#import "ForgetWordViewController.h"
#import "PersonalInfoViewController.h"

@interface LoginViewController ()<UITextFieldDelegate,ZJNetDelegate>
{
    
    UIButton *_loginButton;
    ZJNetAPI * _netApi;
    CustomTextFieldCell *_verificationCell;
    UIButton *_btnForgetWord;
    UIButton *_btnRegister;
}

@property (nonatomic,strong)  NSArray *cellDataObj;


@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"登陆众加传媒";
    
    _netApi = [[ZJNetAPI alloc] init];
    _netApi.delegate = self;

    
    _loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_loginButton setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_normal.png"]] forState:UIControlStateNormal];
    [_loginButton setTitle:@"登录" forState:UIControlStateNormal];
    [_loginButton setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_highlight.png"]] forState:UIControlStateHighlighted];
    [_loginButton addTarget:self action:@selector(loginAction) forControlEvents:UIControlEventTouchUpInside];
    
    _btnForgetWord = [UIButton buttonWithType:UIButtonTypeCustom];
    [_btnForgetWord setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [_btnForgetWord setTitle:@"忘记密码？" forState:UIControlStateNormal];
    [_btnForgetWord addTarget:self action:@selector(forgetAction) forControlEvents:UIControlEventTouchUpInside];
    _btnForgetWord.frame = CGRectMake(0, 0, 100, 40);
    
    _btnRegister = [UIButton buttonWithType:UIButtonTypeCustom];
    [_btnRegister setTitle:@"快速注册" forState:UIControlStateNormal];
    [_btnRegister addTarget:self action:@selector(registerAction) forControlEvents:UIControlEventTouchUpInside];
    [_btnRegister setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    _btnRegister.frame = CGRectMake(0, 0, 100, 40);
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellDataContainTextField *cellData = [[CustomCellDataContainTextField alloc] init];
    cellData.placeholder = @"请输入";
    cellData.text = @"手机号";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellDataContainTextField alloc] init];
    cellData.placeholder = @"请输入";
    cellData.text = @"密码";
    [sectionArray addObject:cellData];
    
    self.cellDataObj = @[sectionArray];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
    
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(textFieldDidChange:) name: UITextFieldTextDidChangeNotification object: nil];
    self.navigationController.navigationBarHidden = NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - buuton action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)forgetAction
{
    NSLog(@"forgetAction");
    ForgetWordViewController *ctl = [[ForgetWordViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:ctl animated:YES];
}

- (void)registerAction
{
    NSLog(@"registerAction");
    RegisterViewController *ctl = [[RegisterViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:ctl animated:YES];
}

- (void)getVerificationCodeAction
{
    [QLoadingView showDefaultLoadingView:nil];
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:0];
    NSString *phone = cellData.cellFieldText;
    VerifyCodeRequest *verifyCode = [[VerifyCodeRequest alloc] init];
    verifyCode.requestType  = ZJNetType_VerifyCode;
    verifyCode.sid          = @"";
    verifyCode.userid       = 0;
    verifyCode.usertype     = @"owner";
    verifyCode.platform     = @"IOS";
    verifyCode.phone        = phone;
    
    [_netApi getVerifyCode:verifyCode];
}

- (void)loginAction
{
    
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:0];
    NSString *phone = cellData.cellFieldText;
    
    cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:1];
    NSString *password =  cellData.cellFieldText;
    
    if (![NSString checkPhoneStandardWith:phone])
    {
        [AppUtils showAlertMessage:@"请输入正确手机号码"];
        return;
    }
    
    if ([password length] == 0)
    {
        [AppUtils showAlertMessage:@"请输入密码"];
        return;
    }
    
    UserInfoObject *userData = [UserDataOperator getUserData];
    userData.tel = phone;
    userData.passwd = password;
    [UserDataOperator SavaUserWithData:userData];
    
    [QLoadingView showDefaultLoadingView:nil];
    LoginRequest *loginRequest = [[LoginRequest alloc] init];
    loginRequest.tel = phone;
    loginRequest.passwd = password;
    [_netApi loginAction:loginRequest];
    
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 15.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
       
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 120;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        [view addSubview:_loginButton];
        [view addSubview:_btnForgetWord];
        [view addSubview:_btnRegister];
        _loginButton.bounds = CGRectMake(0, 0, view.bounds.size.width - 20, 40);
        _loginButton.center = CGPointMake(view.bounds.size.width/2, view.bounds.size.height/2 - 10);
        _btnForgetWord.center = CGPointMake(view.bounds.size.width/2-50, view.bounds.size.height/2 + 40);
        _btnRegister.center = CGPointMake(view.bounds.size.width/2+50, view.bounds.size.height/2 + 40);
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"loginIdentifier";
    
    CustomTextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[CustomTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.cellTitle = cellData.text;
    cell.textField.placeholder = cellData.placeholder;
    cell.textField.delegate = self;
    cell.textField.tag = indexPath.row;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.isShowVerificationButton = NO;

    if (indexPath.row == 0)
    {
        cell.textField.secureTextEntry = NO;
    }
    else if (indexPath.row == 1)
    {
        cell.textField.secureTextEntry = YES;
    }
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
}

#pragma mark UITextField delegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag == 2)
    {
        
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

- (void)textFieldDidChange:(NSNotification *)notification
{
    UITextField *textField = nil;
    NSObject* obj = [notification object];
    if ([obj isKindOfClass:[UITextField class]])
    {
        textField = (UITextField*)obj;
        
    }
    if (textField)
    {
        CustomCellDataContainTextField *cellData = [[self.cellDataObj objectAtIndex:0] objectAtIndex:textField.tag];
        cellData.cellFieldText = textField.text;
    }
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

#pragma mark - ZJNetDelegate

- (void)netRequest:(id)request didFailWithError:(NSError *)error;
{
    [QLoadingView hideWithAnimated:NO];
    
    NSLog(@"\r\n%s: netRequest = %@, errInfo= %@\r\n", __func__, [request class], error);
    if ([error.domain isEqualToString:ZJNetErrorDomain])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"error" message:[NSString stringWithFormat:@"%@ code:%ld",error.description,error.code ] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }
    
}

- (void)onVerifyCodeDone:(VerifyCodeRequest *)request response:(VerifyCodeResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    
    NSLog(@"\r\n%s: netRequest = %@, resoponse= %@\r\n", __func__, [request class], response);
}

- (void)onLoginDone:(LoginRequest *)request response:(LoginResponse *)response
{
    [QLoadingView hideWithAnimated:NO];
    
    UserInfoObject *userData = [UserDataOperator getUserData];
    userData.loginStatus = @"1";
    [UserDataOperator SavaUserWithData:userData];
    
    PersonalInfoViewController *ctl = [[PersonalInfoViewController alloc] initWithStyle:UITableViewStyleGrouped];
    NSMutableArray *array = [[NSMutableArray alloc] initWithArray:self.navigationController.viewControllers];
    [array removeLastObject];
    [array addObject:ctl];
    
    self.navigationController.viewControllers = array;
    
    NSLog(@"\r\n%s: netRequest = %@, resoponse= %@\r\n", __func__, [request class], response);
    
}

@end
