//
//  LoginViewController.h
//  RoadFreightage
//
//  Created by mac on 15/6/3.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "BaseTableViewController.h"

@interface  RegisterViewController: BaseTableViewController

@end
