//
//  CityChooseViewController.h
//  RoadFreightage
//
//  Created by gaozhimin on 15/7/20.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "BaseTableViewController.h"

@interface CarBrandChooseViewController : BaseTableViewController

@end
