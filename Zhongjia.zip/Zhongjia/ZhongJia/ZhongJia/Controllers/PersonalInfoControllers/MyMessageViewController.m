//
//  MyMessageViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "MyMessageViewController.h"
#import "CustomCellData.h"

@interface MessageTableCell : UITableViewCell
{
    UILabel *_labelMessage;
    UILabel *_labelTime;
    UIImageView *_imageViewBack;
}

@end

@implementation MessageTableCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        CGSize size = self.bounds.size;
        _imageViewBack = [[UIImageView alloc] initWithFrame:CGRectMake(10, 30, size.width - 20, 50)];
        [self addSubview:_imageViewBack];
        _imageViewBack.backgroundColor = [UIColor whiteColor];
        
        _labelMessage = [[UILabel alloc] initWithFrame:CGRectMake(20, 30, size.width - 40, 50)];
        _labelMessage.text = @"";
        _labelMessage.backgroundColor = [UIColor clearColor];
        _labelMessage.textColor = [UIColor blackColor];
        _labelMessage.font = [UIFont systemFontOfSize:12];
        _labelMessage.numberOfLines = 3;
        [self addSubview:_labelMessage];
        
        _labelTime = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, 280, 30)];
        _labelTime.text = @"";
        _labelTime.backgroundColor = [UIColor clearColor];
        _labelTime.textColor = [UIColor grayColor];
        _labelTime.font = [UIFont systemFontOfSize:12];
        [self addSubview:_labelTime];
        
        _imageViewBack = [[UIImageView alloc] init];
        
        self.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
        
    }
    return self;
}

- (void)SetLabelTask:(NSString *)task time:(NSString *)time
{
    _labelMessage.text = task;
    _labelTime.text = time;
}

@end

@interface MyMessageViewController ()

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation MyMessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"我的消息";
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = @"1392，为您的验证码（一小时有效）。感谢您选择众加传媒，请尽快完成验证，谢谢！【众加传媒】";
    cellData.otherObject = @"06月08 09：52";
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"1392，为您的验证码（一小时有效）。感谢您选择众加传媒，请尽快完成验证，谢谢！【众加传媒】";
    cellData.otherObject = @"06月08 09：52";
    [sectionArray addObject:cellData];
    
    self.cellDataObj = @[sectionArray];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.tableView.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
}

#pragma mark - buuton action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 15.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 120;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"loginIdentifier";
    
    MessageTableCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[MessageTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell SetLabelTask:cellData.text time:cellData.otherObject];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    if (cellData.cellActionBlock)
    {
        cellData.cellActionBlock(nil);
    }
}


@end
