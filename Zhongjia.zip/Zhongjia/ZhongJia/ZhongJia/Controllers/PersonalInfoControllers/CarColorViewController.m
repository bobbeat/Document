//
//  CarColorViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/29.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "CarColorViewController.h"
#import "CustomCellData.h"
#import "UserDataOperator.h"

@interface CarColorViewController ()

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation CarColorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"车辆颜色";
    
    CGSize size = self.view.bounds.size;
    
    NSMutableArray *sectionArray = [NSMutableArray array];
    CustomCellData *cellData = [[CustomCellData alloc] init];
    cellData.text = @"白色";
    cellData.otherObject = [UIColor whiteColor];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"黑色";
    cellData.otherObject = [UIColor blackColor];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"银色";
    cellData.otherObject = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"红色";
    cellData.otherObject = [UIColor redColor];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"灰色";
    cellData.otherObject = [UIColor grayColor];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"蓝色";
    cellData.otherObject = [UIColor blueColor];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"黄色";
    cellData.otherObject = [UIColor yellowColor];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"绿色";
    cellData.otherObject = [UIColor greenColor];
    [sectionArray addObject:cellData];
    
    cellData = [[CustomCellData alloc] init];
    cellData.text = @"其他颜色";
    cellData.otherObject = [UIColor orangeColor];
    [sectionArray addObject:cellData];
    
    self.cellDataObj = @[sectionArray];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.cellDataObj objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 15.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForHeaderInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0)
    {
        
    }
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"loginIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.textLabel.text = cellData.text;
    
    CGSize size = cell.bounds.size;
    UIView *colorView = [cell viewWithTag:100];
    if (colorView == nil) {
        colorView = [[UIView alloc] initWithFrame:CGRectMake(size.width - 140, 5, 120, size.height-10)];
        [cell.contentView addSubview:colorView];
        colorView.tag = 100;
    }
    colorView.backgroundColor = cellData.otherObject;
    
    if (indexPath.row == 0) {
        [colorView.layer setBorderColor:[UIColor blackColor].CGColor];
        [colorView.layer setBorderWidth:1.0f];
    }
    else
    {
        [colorView.layer setBorderWidth:0];
    }
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    UserInfoObject *userData = [UserDataOperator getUserData];
    userData.colour = cellData.text;
    [UserDataOperator SavaUserWithData:userData];
    [self.navigationController popViewControllerAnimated:YES];
}
@end
