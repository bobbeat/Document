//
//  PersonalInfoViewController.h
//  ZhongJia
//
//  Created by mac on 15/7/18.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "BaseTableViewController.h"

@interface PersonalInfoViewController : BaseTableViewController

@end
