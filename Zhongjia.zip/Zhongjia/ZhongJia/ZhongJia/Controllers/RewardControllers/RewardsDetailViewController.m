//
//  RewardsDetailViewController.m
//  ZhongJia
//
//  Created by mac on 15/8/1.
//  Copyright (c) 2015年 gzm. All rights reserved.
//
#import "RewardsDetailViewController.h"

@interface RewardsDetailViewController ()
{
    UIImageView *_imageViewTaskImage;
    UIImageView *_imageViewSawtooth;
    UITextView *_textViewForDetail;
    UILabel *_labelDetail;
}

@end

@implementation RewardsDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"奖励通知";
    CGSize size = self.view.bounds.size;
    
    float imageHeitght = 180;
    _imageViewTaskImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, imageHeitght)];
    _imageViewTaskImage.image = [UIImage imageNamed:@"img_test5"];
    [self.view addSubview:_imageViewTaskImage];
    
    UIImage *image = [UIImage imageNamed:@"bg_sawtooth"];
    UIImage *stretchableButtonImageNormal = [image stretchableImageWithLeftCapWidth:1 topCapHeight:1];
    
    float sawHeight = 100;
    _imageViewSawtooth = [[UIImageView alloc] initWithFrame:CGRectMake(0, imageHeitght, size.width, sawHeight)];
    _imageViewSawtooth.image = stretchableButtonImageNormal;
    [self.view addSubview:_imageViewSawtooth];
    
    NSArray *textArray = @[@"任务类型：",@"所在地点：",@"任务周期：",@"征车数量：",@"征车酬金："];
    NSArray *detailArray = @[@"代言任务",@"厦门",@"三个月",@"500辆",@"900加油卡"];
    NSArray *imageArray = @[[UIImage imageNamed:@"ic_task_type"],[UIImage imageNamed:@"ic_task_city"],[UIImage imageNamed:@"ic_task_time"],[UIImage imageNamed:@"ic_task_carnumber"],[UIImage imageNamed:@"ic_task_pay"]];
    
    for (int i = 0; i < 5; i++)
    {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0 , 0, 120, 30)];
        label.backgroundColor = [UIColor clearColor];
        label.textAlignment = NSTextAlignmentLeft;
        label.textColor = [UIColor blackColor];
        label.font = [UIFont systemFontOfSize:12];
        label.text = [textArray objectAtIndex:i];
        [_imageViewSawtooth addSubview:label];
        
        UILabel * label1 = [[UILabel alloc] initWithFrame:CGRectMake(0 , 0, 120, 30)];
        label1.backgroundColor = [UIColor clearColor];
        label1.textAlignment = NSTextAlignmentLeft;
        label1.textColor = [UIColor grayColor];
        label1.font = [UIFont systemFontOfSize:12];
        label1.text = [detailArray objectAtIndex:i];
        [_imageViewSawtooth addSubview:label1];
        
        UIImage *image = [imageArray objectAtIndex:i];
        UIImageView *imageview = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0,image.size.width, image.size.height)];
        imageview.image = image;
        [_imageViewSawtooth addSubview:imageview];
        
        
        float imageX = (i%2)*size.width/2 + 20;
        float imagey = (i/2)* (_imageViewSawtooth.bounds.size.height/3.0) + 15;
        imageview.center = CGPointMake(imageX, imagey);
        label.center = CGPointMake(imageX + 70, imagey);
        label1.center = CGPointMake(imageX + 70 + 60, imagey);
    }
    
    UIView *redView = [[UIView alloc] initWithFrame:CGRectMake(10, imageHeitght+sawHeight + 9, 2, 13)];
    redView.backgroundColor = [UIColor redColor];
    [self.view addSubview:redView];
    
    _labelDetail = [[UILabel alloc] initWithFrame:CGRectMake(20, imageHeitght+sawHeight, 120, 30)];
    _labelDetail.backgroundColor = [UIColor clearColor];
    _labelDetail.textAlignment = NSTextAlignmentLeft;
    _labelDetail.textColor = [UIColor redColor];
    _labelDetail.font = [UIFont boldSystemFontOfSize:14];
    _labelDetail.text = @"奖励通知";
    [self.view addSubview:_labelDetail];
    
    _textViewForDetail = [[UITextView alloc] initWithFrame:CGRectMake(10, imageHeitght+sawHeight + 30, size.width - 20, size.height - (imageHeitght+sawHeight + 30 + 80))];
    _textViewForDetail.backgroundColor = [UIColor whiteColor];
    _textViewForDetail.keyboardType = UIKeyboardTypeDefault;
    _textViewForDetail.returnKeyType = UIReturnKeyDone;
    _textViewForDetail.textColor = [UIColor blackColor];
    _textViewForDetail.font = [UIFont systemFontOfSize:16];
    _textViewForDetail.text = @"亲爱的众加会员：\r      你好！\r       加州红葡萄酒车贴活动(10月1日-12月31日)已开始陆续到期，请大家先查看自己合同上的到期时间\r酬金领取时间和地点会在全部车友到期后确定好给大家通知。\r祝：若发的照片未在客服确认情况下私自提前去掉车贴";
    [self.view addSubview:_textViewForDetail];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal
     ];
    [button setBackgroundImage:[UIImage imageNamed:@"btn_back_highlight"] forState:UIControlStateHighlighted
     ];
    button.frame = CGRectMake(0, 0, 35, 35);
    [button addTarget:self action:@selector(GoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = barButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action

- (void)GoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}


@end
