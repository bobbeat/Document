//
//  RewardViewController.m
//  ZhongJia
//
//  Created by mac on 15/7/25.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "RewardViewController.h"
#import "CustomCellData.h"
#import "RewardsDetailViewController.h"

#define RewardCellHeight 120

@interface RewardTableViewCell : UITableViewCell
{
    UIImageView *_imageView;
    UILabel *_labelTaskName;
    UILabel *_labelTaskTime;
    UILabel *_labelTaskReward;
    
    UILabel *_labelTaskTimeContent;
    UILabel *_labelTaskRewardContent;
}

@end

@implementation RewardTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(10, 10, 300, RewardCellHeight - 20)];
        view.backgroundColor = [UIColor whiteColor];
        [self addSubview:view];
        
        CGSize size = view.bounds.size;
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(5,5 , size.height - 10, size.height - 10)];
        _imageView.image = [UIImage imageNamed:@"img_redwine"];
        [view addSubview:_imageView];
        
        _labelTaskName = [[UILabel alloc] initWithFrame:CGRectMake(size.height, 3, 120, size.height/3)];
        _labelTaskName.backgroundColor = [UIColor clearColor];
        _labelTaskName.textAlignment = NSTextAlignmentLeft;
        _labelTaskName.textColor = [UIColor blackColor];
        _labelTaskName.font = [UIFont boldSystemFontOfSize:14];
        _labelTaskName.text = @"加州红葡萄酒";
        [view addSubview:_labelTaskName];
        
        _labelTaskTime = [[UILabel alloc] initWithFrame:CGRectMake(size.height, size.height/3, 120, size.height/3)];
        _labelTaskTime.backgroundColor = [UIColor clearColor];
        _labelTaskTime.textAlignment = NSTextAlignmentLeft;
        _labelTaskTime.textColor = [UIColor blackColor];
        _labelTaskTime.font = [UIFont systemFontOfSize:12];
        _labelTaskTime.text = @"任务周期：";
        [view addSubview:_labelTaskTime];
        
        _labelTaskReward = [[UILabel alloc] initWithFrame:CGRectMake(size.height, size.height*2/3 - 5, 120, size.height/3)];
        _labelTaskReward.backgroundColor = [UIColor clearColor];
        _labelTaskReward.textAlignment = NSTextAlignmentLeft;
        _labelTaskReward.textColor = [UIColor blackColor];
        _labelTaskReward.font = [UIFont systemFontOfSize:12];
        _labelTaskReward.text = @"任务奖励：";
        [view addSubview:_labelTaskReward];
        
        float contentOffsetX = 60;
        _labelTaskTimeContent = [[UILabel alloc] initWithFrame:CGRectMake(size.height + contentOffsetX, size.height/3, 120, size.height/3)];
        _labelTaskTimeContent.backgroundColor = [UIColor clearColor];
        _labelTaskTimeContent.textAlignment = NSTextAlignmentLeft;
        _labelTaskTimeContent.textColor = [UIColor grayColor];
        _labelTaskTimeContent.font = [UIFont systemFontOfSize:12];
        _labelTaskTimeContent.text = @"三个月";
        [view addSubview:_labelTaskTimeContent];
        
        _labelTaskRewardContent = [[UILabel alloc] initWithFrame:CGRectMake(size.height + contentOffsetX, size.height*2/3 - 5, 120, size.height/3)];
        _labelTaskRewardContent.backgroundColor = [UIColor clearColor];
        _labelTaskRewardContent.textAlignment = NSTextAlignmentLeft;
        _labelTaskRewardContent.textColor = [UIColor grayColor];
        _labelTaskRewardContent.font = [UIFont systemFontOfSize:12];
        _labelTaskRewardContent.text = @"100元";
        [view addSubview:_labelTaskRewardContent];
    }
    return self;
}

- (void)setImageWith:(UIImage *)image name:(NSString *)name time:(NSString *)time reward:(NSString *)reward
{
    _imageView.image = image;
    _labelTaskName.text = name;
    _labelTaskTime.text = time;
    _labelTaskRewardContent.text = reward;
}

@end

@interface RewardViewController ()

@property (nonatomic,strong)  NSArray *cellDataObj;

@end

@implementation RewardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    self.tableView.separatorColor = [UIColor clearColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - tableview Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{return 1;
    // Return the number of sections.
    return [self.cellDataObj count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{return 10;
    return  [[self.cellDataObj objectAtIndex:section] count];;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1.0;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return RewardCellHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    float height = [self tableView:tableView heightForFooterInSection:section];
    UIView *view = nil;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, height)];
    
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"cellIdentifier1";
    RewardTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil )
    {
        cell = [[RewardTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    CustomCellData *data = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    cell.textLabel.text = data.text;
    cell.imageView.image = data.image;
    cell.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    return cell;
    
    
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomCellData *cellData = [[self.cellDataObj objectAtIndex:indexPath.section] objectAtIndex:indexPath.row ];
    RewardsDetailViewController *ctl = [[RewardsDetailViewController alloc] init];
    [self.navigationController pushViewController:ctl animated:YES];
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


@end
