//
//  ZJCommonObj.h
//  SuYun
//
//  Created by yu.liao on 15/5/15.
//  Copyright (c) 2015年 yu.liao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZJCommonObj : NSObject

@end
