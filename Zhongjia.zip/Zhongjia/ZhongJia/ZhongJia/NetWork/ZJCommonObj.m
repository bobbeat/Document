//
//  ZJCommonObj.m
//  SuYun
//
//  Created by yu.liao on 15/5/15.
//  Copyright (c) 2015年 yu.liao. All rights reserved.
//

#import "ZJCommonObj.h"

@implementation ZJCommonObj

@end
