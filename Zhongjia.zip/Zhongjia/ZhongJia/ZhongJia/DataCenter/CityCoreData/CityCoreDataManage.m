//
//  CityCoreDataManage.m
//  ZhongJia
//
//  Created by mac on 15/7/25.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "CityCoreDataManage.h"
#import <CoreData/CoreData.h>


@interface CityCoreDataManage()
{
    
}

@property (nonatomic,strong) NSManagedObjectModel *managedObjectModel;
@property (nonatomic,strong) NSManagedObjectContext *managedObjectContext;
@property (nonatomic,strong) NSPersistentStoreCoordinator *persistentStoreCoordinator;

@end

@implementation CityCoreDataManage

+ (instancetype)SharedInstance
{
    static CityCoreDataManage *cityCoreData = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cityCoreData = [[CityCoreDataManage alloc] init];
    });
    return cityCoreData;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

//托管对象
-(NSManagedObjectModel *)managedObjectModel
{
    if (_managedObjectModel!=nil) {
        return _managedObjectModel;
    }
//    NSURL* modelURL=[[NSBundle mainBundle] URLForResource:@"CityModel" withExtension:@"xcdatamodeld"];
//    _managedObjectModel=[[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    _managedObjectModel=[NSManagedObjectModel mergedModelFromBundles:nil] ;
    return _managedObjectModel;
}
//托管对象上下文
-(NSManagedObjectContext *)managedObjectContext
{
    if (_managedObjectContext!=nil) {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator* coordinator=[self persistentStoreCoordinator];
    if (coordinator!=nil) {
        _managedObjectContext=[[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
        
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return _managedObjectContext;
}
//持久化存储协调器
-(NSPersistentStoreCoordinator *)persistentStoreCoordinator
{
    if (_persistentStoreCoordinator!=nil) {
        return _persistentStoreCoordinator;
    }
    //    NSURL* storeURL=[[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"CoreaDataExample.CDBStore"];
    //    NSFileManager* fileManager=[NSFileManager defaultManager];
    //    if(![fileManager fileExistsAtPath:[storeURL path]])
    //    {
    //        NSURL* defaultStoreURL=[[NSBundle mainBundle] URLForResource:@"CoreDataExample" withExtension:@"CDBStore"];
    //        if (defaultStoreURL) {
    //            [fileManager copyItemAtURL:defaultStoreURL toURL:storeURL error:NULL];
    //        }
    //    }
    NSString* docs=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSURL* storeURL=[NSURL fileURLWithPath:[docs stringByAppendingPathComponent:@"CityCoreData.sqlite"]];
    NSLog(@"path is %@",storeURL);
    NSError* error=nil;
    _persistentStoreCoordinator=[[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        NSLog(@"Error: %@,%@",error,[error userInfo]);
    }
    return _persistentStoreCoordinator;
}

-(CityEntity *)getCityEntntity
{
    CityEntity* city=(CityEntity *)[NSEntityDescription insertNewObjectForEntityForName:@"CityEntity" inManagedObjectContext:self.managedObjectContext];
    return city;
}

//插入数据
- (void)addIntoDataSource:(CityEntity *)entity {
    [self.managedObjectContext insertObject:entity];
    NSError* error;
    BOOL isSaveSuccess=[self.managedObjectContext save:&error];
    if (!isSaveSuccess) {
        NSLog(@"Error:%@",error);
    }else{
        NSLog(@"Save successful!");
    }
    
}

- (NSArray *)GetCityList
{
    NSFetchRequest* request=[[NSFetchRequest alloc] init];
    NSEntityDescription* user=[NSEntityDescription entityForName:@"CityEntity" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:user];
    
    NSSortDescriptor* sortDescriptor=[[NSSortDescriptor alloc] initWithKey:@"firstLetter" ascending:YES];
    NSArray* sortDescriptions=[[NSArray alloc] initWithObjects:sortDescriptor, nil];
    [request setSortDescriptors:sortDescriptions];
    
    NSError* error=nil;
    NSArray* mutableFetchResult=[self.managedObjectContext executeFetchRequest:request error:&error];
    if (mutableFetchResult==nil) {
        NSLog(@"Error:%@",error);
    }
//    for (CityEntity* user in mutableFetchResult) {
//        NSLog(@"name:%@",user.cityName);
//    }
    return mutableFetchResult;
}
//查询
- (NSArray *)QueryCityWitchFirstLetter:(NSString *)firstLetter {
    NSFetchRequest* request=[[NSFetchRequest alloc] init];
    NSEntityDescription* user=[NSEntityDescription entityForName:@"CityEntity" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:user];
    
    //查询条件
    NSPredicate* predicate=[NSPredicate predicateWithFormat:@"firstLetter==%@",firstLetter];
    [request setPredicate:predicate];
    NSError* error=nil;
    NSArray* mutableFetchResult=[self.managedObjectContext executeFetchRequest:request error:&error];
    if (mutableFetchResult==nil) {
        NSLog(@"Error:%@",error);
    }
    for (CityEntity* user in mutableFetchResult) {
         NSLog(@"name:%@",user.cityName);
    }
    return mutableFetchResult;
}

//查询
- (NSArray *)QueryCityWithKeyword:(NSString *)keyword {
    NSFetchRequest* request=[[NSFetchRequest alloc] init];
    NSEntityDescription* user=[NSEntityDescription entityForName:@"CityEntity" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:user];
    
    //查询条件
    NSPredicate* predicate=[NSPredicate predicateWithFormat:@"cityName CONTAINS %@ || enName BEGINSWITH %@",keyword,keyword];
    [request setPredicate:predicate];
    NSError* error=nil;
    NSArray* mutableFetchResult=[self.managedObjectContext executeFetchRequest:request error:&error];
    if (mutableFetchResult==nil) {
        NSLog(@"Error:%@",error);
    }
    for (CityEntity* user in mutableFetchResult) {
        NSLog(@"name:%@",user.cityName);
    }
    return mutableFetchResult;
}

//更新
- (void)update:(id)sender {
    NSFetchRequest* request=[[NSFetchRequest alloc] init];
    NSEntityDescription* user=[NSEntityDescription entityForName:@"CityEntity" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:user];
    //查询条件
    NSPredicate* predicate=[NSPredicate predicateWithFormat:@"name==%@",@"chen"];
    [request setPredicate:predicate];
    NSError* error=nil;
    NSMutableArray* mutableFetchResult=[[self.managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
    if (mutableFetchResult==nil) {
        NSLog(@"Error:%@",error);
    }
    //更新age后要进行保存，否则没更新
    for (CityEntity* user in mutableFetchResult) {
        
        
    }
    [self.managedObjectContext save:&error];
    
}
//删除
- (void)del:(id)sender {
    NSFetchRequest* request=[[NSFetchRequest alloc] init];
    NSEntityDescription* user=[NSEntityDescription entityForName:@"CityEntity" inManagedObjectContext:self.managedObjectContext];
    [request setEntity:user];
    NSPredicate* predicate=[NSPredicate predicateWithFormat:@"name==%@",@"chen"];
    [request setPredicate:predicate];
    NSError* error=nil;
    NSMutableArray* mutableFetchResult=[[self.managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
    if (mutableFetchResult==nil) {
        NSLog(@"Error:%@",error);
    }
    for (CityEntity* user in mutableFetchResult) {
        [self.managedObjectContext deleteObject:user];
    }
    
    if ([self.managedObjectContext save:&error]) {
        NSLog(@"Error:%@,%@",error,[error userInfo]);
    }  
}

@end
