//
//  CityEntity.m
//  ZhongJia
//
//  Created by mac on 15/7/25.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "CityEntity.h"


@implementation CityEntity

@dynamic adcode;
@dynamic cityName;
@dynamic enName;
@dynamic firstLetter;
@dynamic isHotCity;

@end
