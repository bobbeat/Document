//
//  CityCoreDataManage.h
//  ZhongJia
//
//  Created by mac on 15/7/25.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CityEntity.h"

@interface CityCoreDataManage : NSObject

+ (instancetype)SharedInstance;

- (NSArray *)GetCityList;

-(CityEntity *)getCityEntntity;

//查询
- (NSArray *)QueryCityWitchFirstLetter:(NSString *)firstLetter;

//查询
- (NSArray *)QueryCityWithKeyword:(NSString *)keyword;

//插入数据
- (void)addIntoDataSource:(CityEntity *)entity;
@end
