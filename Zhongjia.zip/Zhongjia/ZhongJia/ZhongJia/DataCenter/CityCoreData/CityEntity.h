//
//  CityEntity.h
//  ZhongJia
//
//  Created by mac on 15/7/25.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface CityEntity : NSManagedObject

@property (nonatomic, retain) NSNumber * adcode;
@property (nonatomic, retain) NSString * cityName;
@property (nonatomic, retain) NSString * enName;
@property (nonatomic, retain) NSString * firstLetter;
@property (nonatomic, retain) NSNumber * isHotCity;

@end
