//
//  UserData.m
//  RoadFreightage
//
//  Created by mac on 15/6/6.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "UserDataOperator.h"
#import "Constants.h"
#import "ZJNetObj.h"
#import "NSObject+Category.h"

@implementation UserDataOperator

/*!
 @brief 保存用户数据至本地
 @param data        用户数据
 */
+ (void)SavaUserWithData:(UserInfoObject *)data
{
    NSDictionary *userDic = [data getProperties];
    
    NSMutableData *dataForSave = [[NSMutableData alloc] init];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:dataForSave];
    [archiver encodeObject:userDic forKey:@"Some Key Value"];
    [archiver finishEncoding];
    BOOL sign = [dataForSave writeToFile:LocalUserDataPath atomically:YES];
    if (sign) {
        NSLog(@"保存用户数据成功 路径= %@",LocalUserDataPath);
    }
}

/*!
 @brief 获取用户数据
 @return   用户数据
 */
+ (UserInfoObject *)getUserData
{
    UserInfoObject *response = [[UserInfoObject alloc] init];
    
    NSData *data = [[NSMutableData alloc] initWithContentsOfFile:LocalUserDataPath];
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    NSDictionary *userDic = [unarchiver decodeObjectForKey:@"Some Key Value"];
    [unarchiver finishDecoding];
    [response setPropertiesWirh:userDic];
    return response;
}
/*!
 @brief 删除本地用户数据
 */
+ (void)DestroyLocalUserData
{
    NSError *error = nil;
    [[NSFileManager defaultManager] removeItemAtPath:LocalUserDataPath error:&error];
}

/*!
 @brief 获取用户登陆状态
 */
+ (BOOL)getUserLoginStatus
{
    UserInfoObject *userData = [UserDataOperator getUserData];
    return [userData.loginStatus isEqualToString:@"1"];
}
@end
