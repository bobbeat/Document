//
//  UserData.h
//  RoadFreightage
//
//  Created by mac on 15/6/6.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZJNetObj.h"

@class LoginResponse;

@interface UserDataOperator : NSObject

/*!
 @brief 保存用户数据至本地
 @param data        用户数据
 */
+ (void)SavaUserWithData:(UserInfoObject *)data;

/*!
 @brief 获取用户数据
 @return   用户数据
 */
+ (UserInfoObject *)getUserData;

/*!
 @brief 删除本地用户数据
 */
+ (void)DestroyLocalUserData;

/*!
 @brief 获取用户登陆状态
 */
+ (BOOL)getUserLoginStatus;

@end
