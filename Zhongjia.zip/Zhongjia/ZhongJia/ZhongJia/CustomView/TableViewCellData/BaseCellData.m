//
//  BaseCellData.m
//  RoadFreightage
//
//  Created by mac on 15/6/6.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "BaseCellData.h"

@implementation BaseCellData

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    return self;
}

@end
