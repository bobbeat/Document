//
//  CustomCellData.m
//  RoadFreightage
//
//  Created by gaozhimin on 15/6/4.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "CustomCellData.h"

@implementation CustomCellData


- (instancetype)init
{
    self = [super init];
    if (self)
    {
       
    }
    return self;
}

- (void)dealloc
{
    self.cellActionBlock = nil;
}

@end
