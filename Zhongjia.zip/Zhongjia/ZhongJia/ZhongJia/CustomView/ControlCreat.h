//
//  ControlCreat.h
//  RoadFreightage
//
//  Created by mac on 15/6/3.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ControlCreat : NSObject

@end
