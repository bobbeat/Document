//
//  UserInfoEditView.h
//  ZhongJia
//
//  Created by mac on 15/7/26.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^ UserEditFinishBlock)(NSString* editStr);

@interface UserInfoEditView : UIView

+ (void)ShowEditViewWithTitle:(NSString *)title editStr:(NSString*)editStr finishBlock:(UserEditFinishBlock)block;

@end
