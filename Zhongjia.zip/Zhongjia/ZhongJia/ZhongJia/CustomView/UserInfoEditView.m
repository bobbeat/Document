//
//  UserInfoEditView.m
//  ZhongJia
//
//  Created by mac on 15/7/26.
//  Copyright (c) 2015年 gzm. All rights reserved.
//

#import "UserInfoEditView.h"
#import "UIImage+Category.h"
#import <QuartzCore/QuartzCore.h>

static UserInfoEditView *g_editView = nil;

@interface UserInfoEditView ()<UITextFieldDelegate>
{
    UIView *_shadeView;
    UIButton *_btnOK;
    UIButton *_btnCancel;
    UIImageView *_imageViewWhite;
    UILabel *_labelTitle;
    UITextField *_textField;
    UIImageView *_imageViewField;
}

@property(nonatomic,strong) NSString *title;
@property(nonatomic,copy) UserEditFinishBlock block;
@property(nonatomic,copy) NSString *editStr;

@end

@implementation UserInfoEditView

+ (void)ShowEditViewWithTitle:(NSString *)title editStr:(NSString*)editStr finishBlock:(UserEditFinishBlock)block
{
    if (g_editView) {
        [g_editView removeFromSuperview];
        g_editView = nil;
    }
    g_editView = [[UserInfoEditView alloc] initWithTitle:title editStr:editStr];
    g_editView.block = block;
    g_editView.title = title;
    g_editView.editStr = editStr;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    self.block = nil;
    self.title = nil;
    self.editStr = nil;
}

- (instancetype)initWithTitle:(NSString *)str editStr:(NSString *)edit
{
    self = [super init];
    if (self) {
        
        UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
        UIView *superView = window.rootViewController.view;
        self.frame = superView.bounds;
        [superView addSubview:self];
        
        CGSize size = superView.bounds.size;
        _shadeView = [[UIView alloc] initWithFrame:superView.bounds];
        _shadeView.backgroundColor = [UIColor colorWithHue:0 saturation:0 brightness:0 alpha:0.5];
        [self addSubview:_shadeView];
        
        _imageViewWhite = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width-60, 160)];
        _imageViewWhite.backgroundColor = [UIColor whiteColor];
        _imageViewWhite.userInteractionEnabled = YES;
        [self addSubview:_imageViewWhite];
        _imageViewWhite.center = CGPointMake(size.width/2, size.height - 216 - _imageViewWhite.bounds.size.height/2.0-30);
        
        CGSize imageSie = _imageViewWhite.bounds.size;
        
        _imageViewField = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, imageSie.width-30, 40)];
//        _imageViewField.image = [UIImage getStrechableImageWith:[UIImage imageNamed:@"bg_task_sche_highlight"]];
        _imageViewField.backgroundColor = [UIColor clearColor];
        _imageViewField.userInteractionEnabled = YES;
        [_imageViewWhite addSubview:_imageViewField];
        _imageViewField.center = CGPointMake(imageSie.width/2, imageSie.height/2-10);
        [_imageViewField.layer setBorderColor:[UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:0.5].CGColor];
        [_imageViewField.layer setBorderWidth:1.0f];
        
        _textField = [[UITextField alloc] initWithFrame:CGRectMake(0, 10, imageSie.width - 50, 30)];
        _textField.backgroundColor = [UIColor clearColor];
        _textField.textColor = [UIColor blackColor];
        _textField.borderStyle = UITextBorderStyleNone;
        _textField.autocorrectionType = UITextAutocorrectionTypeNo;
        _textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        _textField.keyboardType = UIKeyboardTypeDefault;
        _textField.returnKeyType = UIReturnKeyDone;
        _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        _textField.leftView=nil;
        _textField.background=nil;
        _textField.delegate = self;
        _textField.placeholder = @"请输入...";
        [_imageViewWhite addSubview:_textField];
        _textField.center = CGPointMake(imageSie.width/2, imageSie.height/2-10);
        
        _labelTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, imageSie.width, 40)];
        _labelTitle.backgroundColor = [UIColor clearColor];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.font = [UIFont systemFontOfSize:18];
        _labelTitle.textColor = [UIColor blackColor];
        _labelTitle.text = str;
        [_imageViewWhite addSubview:_labelTitle];
        
        _btnOK = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOK setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_normal.png"]] forState:UIControlStateNormal];
        [_btnOK setTitle:@"确定" forState:UIControlStateNormal];
        [_btnOK setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_highlight.png"]] forState:UIControlStateHighlighted];
        [_btnOK addTarget:self action:@selector(ActionOK) forControlEvents:UIControlEventTouchUpInside];
        [_imageViewWhite addSubview:_btnOK];
        _btnOK.frame = CGRectMake(0, 0, (imageSie.width - 30)/2 - 1, 40);
        _btnOK.center = CGPointMake(imageSie.width/2.0 + _btnOK.bounds.size.width/2.0 +1, imageSie.height - 30);
        
        _btnCancel = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnCancel setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_normal.png"]] forState:UIControlStateNormal];
        [_btnCancel setTitle:@"取消" forState:UIControlStateNormal];
        [_btnCancel setBackgroundImage:[UIImage getStrechableImageWith:[UIImage imageNamed:@"btn_green_highlight.png"]] forState:UIControlStateHighlighted];
        [_btnCancel addTarget:self action:@selector(ActionCancel) forControlEvents:UIControlEventTouchUpInside];
        [_imageViewWhite addSubview:_btnCancel];
        _btnCancel.frame = CGRectMake(0, 0, (imageSie.width - 30)/2 - 1, 40);
        _btnCancel.center = CGPointMake(imageSie.width/2.0 - _btnOK.bounds.size.width/2.0 -1, imageSie.height - 30);
        
        [_textField becomeFirstResponder];
        _textField.text = edit;
        
        [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(textFieldDidChange:) name: UITextFieldTextDidChangeNotification object: nil];
    }
    return self;
}

- (void)ActionOK
{
    if (self.block) {
        self.block(self.editStr);
    }
    if (g_editView) {
        [g_editView removeFromSuperview];
        g_editView = nil;
    }
    
}

- (void)ActionCancel
{
    if (g_editView) {
        [g_editView removeFromSuperview];
        g_editView = nil;
    }
}

#pragma mark UITextField delegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag == 2)
    {
        
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

- (void)textFieldDidChange:(NSNotification *)notification
{
    UITextField *textField = nil;
    NSObject* obj = [notification object];
    if ([obj isKindOfClass:[UITextField class]])
    {
        textField = (UITextField*)obj;
        
    }
    if (textField)
    {
        self.editStr = textField.text;
    }
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (self.block) {
        self.block(self.editStr);
    }
    
    if (g_editView) {
        [g_editView removeFromSuperview];
        g_editView = nil;
    }
    [textField resignFirstResponder];
    return YES;
}



@end
