//
//  PhotoView.h
//  RoadFreightage
//
//  Created by gaozhimin on 15/6/5.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PhotoView;

@protocol PhotoChooseProtocol <NSObject>

- (void)FinishChooseWith:(PhotoView *)view image:(UIImage *)image;

@end

@interface PhotoView : UIView


- (instancetype)initWithController:(UIViewController *)viewController;

@property (nonatomic,assign) id<PhotoChooseProtocol> delegate;

@property (nonatomic,readonly) UILabel *informationlabel;

@property (nonatomic,readonly) UIImageView *imageView;

- (void)takePhoto;

@end
