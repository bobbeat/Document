//
//  BaseCell.m
//  RoadFreightage
//
//  Created by mac on 15/6/6.
//  Copyright (c) 2015年 WuKongSuYun. All rights reserved.
//

#import "BaseCell.h"

@implementation BaseCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setRightView:(UIView *)rightView
{
    if (_rightView)
    {
        [_rightView removeFromSuperview];
        _rightView = nil;
    }
    if (rightView) {
        _rightView = rightView;
        [self addSubview:rightView];
    }
}

- (void)setRightViewAnother:(UIView *)rightViewAnother
{
    if (_rightViewAnother)
    {
        [_rightViewAnother removeFromSuperview];
        _rightViewAnother = nil;
    }
    if (rightViewAnother) {
        _rightViewAnother = rightViewAnother;
        [self addSubview:_rightViewAnother];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    float offsetY = 16.0;
    if (_rightView) {
        CGSize ori_size = _rightView.bounds.size;
        CGSize size = self.bounds.size;
        size.height = size.height - offsetY;
        float scal = (size.height-ori_size.height)/ori_size.height;
        ori_size.height = size.height;
        ori_size.width += ori_size.width*scal;
        
        _rightView.frame = CGRectMake(0, 0, ori_size.width, ori_size.height);
        _rightView.center = CGPointMake(size.width - ori_size.width/2.0 - 20, self.bounds.size.height/2.0);
    }
    if (_rightViewAnother) {
        CGSize ori_size_another = _rightViewAnother.bounds.size;
        CGSize size = self.bounds.size;
        size.height = size.height - offsetY;
        float scal = (size.height-ori_size_another.height)/ori_size_another.height;
        ori_size_another.height = size.height;
        ori_size_another.width += ori_size_another.width*scal;
        
        _rightViewAnother.frame = CGRectMake(0, 0, ori_size_another.width, ori_size_another.height);
        
        _rightViewAnother.center = CGPointMake(size.width -_rightView.bounds.size.width - ori_size_another.width/2.0 - 25, self.bounds.size.height/2.0);
    }
}

@end
