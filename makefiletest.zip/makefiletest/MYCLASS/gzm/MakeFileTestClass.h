//
//  MakeFileTestClass.h
//  makefileTest
//
//  Created by gaozhimin on 14-3-26.
//  Copyright (c) 2014年 autonavi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MakeFileTestClass : NSObject

- (void)makeFileTestLog;

@end
