//
//  MakeFileTestClass.m
//  makefileTest
//
//  Created by gaozhimin on 14-3-26.
//  Copyright (c) 2014年 autonavi. All rights reserved.
//

#import "MakeFileTestClass.h"

@implementation MakeFileTestClass

- (void)makeFileTestLog
{
    NSLog(@"makeFileTestLog");
}
@end
